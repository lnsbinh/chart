INSERT INTO organization_structure.branches
(id, organization_id, code, name, address)
values (gen_random_uuid(), gen_random_uuid(), 'BR001', 'Branch 1', '123 Main St'),
       (gen_random_uuid(), gen_random_uuid(), 'BR002', 'Branch 2', '456 Elm St'),
       (gen_random_uuid(), gen_random_uuid(), 'BR003', 'Branch 3', '789 Oak St');