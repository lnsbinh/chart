-- XLogis PostgreSQL DDL - Phase 1
-- Strategy: modular monolith, module-owned schemas, limited cross-schema foreign keys,
-- duplicated snapshot fields allowed for fast reads, outbox for async integration.
-- Requires PostgreSQL 14+.

create extension if not exists pgcrypto;

create schema if not exists organization_structure;
create schema if not exists identity_access;
create schema if not exists master_data;
create schema if not exists service_orders;
create schema if not exists dispatch_execution;
create schema if not exists trip_execution;
create schema if not exists receivables_payables;
create schema if not exists operational_reporting;
create schema if not exists system_integration;

-- =========================================================
-- organization_structure
-- =========================================================

create table if not exists organization_structure.organizations (
    id uuid primary key default gen_random_uuid(),
    code varchar(30) not null unique,
    name varchar(255) not null,
    status_code varchar(30) not null default 'ACTIVE',
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

comment on table organization_structure.organizations is 'Root company / tenant table.';

create table if not exists organization_structure.branches (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    code varchar(30) not null,
    name varchar(255) not null,
    address text,
    status_code varchar(30) not null default 'ACTIVE',
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    unique (organization_id, code)
);

comment on table organization_structure.branches is 'Operational branches. Keep organization_id without cross-schema FK for future service split.';
create index if not exists ix_branches_org on organization_structure.branches (organization_id);

create table if not exists organization_structure.fleet_teams (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    branch_id uuid not null,
    code varchar(30) not null,
    name varchar(255) not null,
    status_code varchar(30) not null default 'ACTIVE',
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    unique (branch_id, code)
);

comment on table organization_structure.fleet_teams is 'Dispatch and fleet execution teams.';
create index if not exists ix_fleet_teams_branch on organization_structure.fleet_teams (branch_id);

create table if not exists organization_structure.operating_regions (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    code varchar(30) not null,
    name varchar(255) not null,
    status_code varchar(30) not null default 'ACTIVE',
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    unique (organization_id, code)
);

comment on table organization_structure.operating_regions is 'Optional regional ownership layer for data scope.';
create index if not exists ix_regions_org on organization_structure.operating_regions (organization_id);

-- =========================================================
-- identity_access
-- =========================================================

create table if not exists identity_access.users (
    id uuid primary key default gen_random_uuid(),
    user_code varchar(30) not null unique,
    keycloak_user_id uuid,
    organization_id uuid not null,
    username varchar(120) not null,
    password_hash varchar(255) not null,
    first_name varchar(255) not null,
    last_name varchar(255) not null,
    email varchar(255),
    phone varchar(50),
    status_code varchar(30) not null default 'ACTIVE',
    default_branch_id uuid,
    avatar_url text,
    is_deleted boolean default false,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    unique (organization_id, username)
);

comment on table identity_access.users is 'Login users. Application layer handles password policy and MFA.';
create index if not exists ix_users_org_status on identity_access.users (organization_id, status_code);

create table if not exists identity_access.roles (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    role_code varchar(80) not null,
    role_name varchar(255) not null,
    description text,
    active_from date,
    active_to date,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    unique (organization_id, role_code)
);

comment on table identity_access.roles is 'Business roles such as dispatcher, order manager, finance manager.';
create index if not exists ix_roles_org on identity_access.roles (organization_id);

create table if not exists identity_access.permissions (
    id uuid primary key default gen_random_uuid(),
    permission_code varchar(120) not null unique,
    module_code varchar(80) not null,
    action_code varchar(80) not null,
    permission_name varchar(255) not null,
    risk_level varchar(30) not null default 'LOW',
    description text,
    created_at timestamptz not null default now()
);

comment on table identity_access.permissions is 'Atomic permissions used by the role-permission matrix.';

create table if not exists identity_access.user_roles (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    user_id uuid not null,
    role_id uuid not null,
    assigned_at timestamptz not null default now(),
    assigned_by uuid,
    revoked_at timestamptz,
    constraint fk_user_roles_user foreign key (user_id) references identity_access.users(id),
    constraint fk_user_roles_role foreign key (role_id) references identity_access.roles(id)
);

comment on table identity_access.user_roles is 'Role assignment table. Revoked role rows are retained for audit.';
create index if not exists ix_user_roles_user on identity_access.user_roles (user_id);
create index if not exists ix_user_roles_role on identity_access.user_roles (role_id);

create table if not exists identity_access.role_permissions (
    id uuid primary key default gen_random_uuid(),
    role_id uuid not null,
    permission_id uuid not null,
    granted_at timestamptz not null default now(),
    granted_by uuid,
    constraint fk_role_permissions_role foreign key (role_id) references identity_access.roles(id),
    constraint fk_role_permissions_permission foreign key (permission_id) references identity_access.permissions(id),
    unique (role_id, permission_id)
);

comment on table identity_access.role_permissions is 'Atomic role-permission grants.';

create table if not exists identity_access.user_data_scopes (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    user_id uuid not null,
    scope_type varchar(40) not null,
    scope_id uuid not null,
    assigned_at timestamptz not null default now(),
    assigned_by uuid,
    constraint fk_user_scope_user foreign key (user_id) references identity_access.users(id)
);

comment on table identity_access.user_data_scopes is 'Row-level data scope by branch, fleet team, or region.';
create index if not exists ix_user_scopes_user on identity_access.user_data_scopes (user_id);
create index if not exists ix_user_scopes_type_id on identity_access.user_data_scopes (scope_type, scope_id);

create table if not exists identity_access.login_audit_logs (
    id bigserial primary key,
    organization_id uuid not null,
    user_id uuid,
    username_snapshot varchar(120),
    success boolean not null,
    ip_address inet,
    user_agent text,
    attempted_at timestamptz not null default now()
);

comment on table identity_access.login_audit_logs is 'Security and login audit log.';
create index if not exists ix_login_audit_user_time on identity_access.login_audit_logs (user_id, attempted_at desc);

-- =========================================================
-- master_data
-- =========================================================

create table if not exists master_data.business_partners (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    partner_type varchar(40) not null,
    partner_code varchar(40) not null,
    partner_name varchar(255) not null,
    tax_code varchar(50),
    phone varchar(50),
    email varchar(255),
    address text,
    payment_term_days int,
    credit_limit_amount numeric(18,2),
    status_code varchar(30) not null default 'ACTIVE',
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    unique (organization_id, partner_code)
);

comment on table master_data.business_partners is 'Customers, outsourced carriers, fuel suppliers, garages, insurers, and other business counterparties.';
create index if not exists ix_business_partners_org_type on master_data.business_partners (organization_id, partner_type);

create table if not exists master_data.business_partner_contacts (
    id uuid primary key default gen_random_uuid(),
    business_partner_id uuid not null,
    full_name varchar(255) not null,
    phone varchar(50),
    email varchar(255),
    job_title varchar(255),
    is_default boolean not null default false,
    created_at timestamptz not null default now(),
    constraint fk_partner_contacts_partner foreign key (business_partner_id) references master_data.business_partners(id)
);

comment on table master_data.business_partner_contacts is 'Contact people per business partner.';

create table if not exists master_data.locations (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    location_type varchar(40) not null,
    location_code varchar(40) not null,
    location_name varchar(255) not null,
    address text,
    latitude numeric(10,7),
    longitude numeric(10,7),
    status_code varchar(30) not null default 'ACTIVE',
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    unique (organization_id, location_code)
);

comment on table master_data.locations is 'Pickup, delivery, port, CY, depot, warehouse, or other operational point.';
create index if not exists ix_locations_org_type on master_data.locations (organization_id, location_type);

create table if not exists master_data.vehicles (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    vehicle_code varchar(40),
    vehicle_type varchar(30) not null,
    plate_no varchar(30) not null,
    chassis_no varchar(60),
    engine_no varchar(60),
    branch_id uuid,
    fleet_team_id uuid,
    payload_kg numeric(18,2),
    volume_m3 numeric(18,2),
    container_capability varchar(60),
    status_code varchar(30) not null default 'ACTIVE',
    operational_state varchar(30) not null default 'AVAILABLE',
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    unique (organization_id, plate_no)
);

comment on table master_data.vehicles is 'Vehicle master. Phase 1 keeps only the fields required for dispatch and reporting.';
create index if not exists ix_vehicles_org_state on master_data.vehicles (organization_id, operational_state);

create table if not exists master_data.drivers (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    driver_code varchar(40),
    driver_type varchar(20) not null default 'DRIVER',
    full_name varchar(255) not null,
    phone varchar(50),
    license_no varchar(60),
    license_expiry_date date,
    branch_id uuid,
    fleet_team_id uuid,
    employment_status varchar(30) not null default 'ACTIVE',
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    unique (organization_id, driver_code)
);

comment on table master_data.drivers is 'Driver and co-driver master data.';
create index if not exists ix_drivers_org_status on master_data.drivers (organization_id, employment_status);

create table if not exists master_data.routes (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    route_code varchar(40) not null,
    route_name varchar(255) not null,
    origin_location_id uuid,
    destination_location_id uuid,
    standard_km numeric(12,2),
    standard_duration_minutes int,
    status_code varchar(30) not null default 'ACTIVE',
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    unique (organization_id, route_code)
);

comment on table master_data.routes is 'Standard route setup used in planning, pricing, and later fuel norms.';
create index if not exists ix_routes_org on master_data.routes (organization_id);

create table if not exists master_data.tariffs (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    customer_id uuid,
    route_id uuid,
    vehicle_type varchar(30),
    container_type varchar(30),
    currency_code varchar(10) not null default 'VND',
    base_price numeric(18,2) not null,
    effective_from date not null,
    effective_to date,
    status_code varchar(30) not null default 'ACTIVE',
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

comment on table master_data.tariffs is 'Pricing rule table. Phase 1 keeps structure simple and defers complex pricing engines.';
create index if not exists ix_tariffs_org_effective on master_data.tariffs (organization_id, effective_from, effective_to);

create table if not exists master_data.surcharges (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    surcharge_code varchar(40) not null,
    surcharge_name varchar(255) not null,
    charge_method varchar(30) not null,
    default_amount numeric(18,2),
    currency_code varchar(10) not null default 'VND',
    status_code varchar(30) not null default 'ACTIVE',
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    unique (organization_id, surcharge_code)
);

comment on table master_data.surcharges is 'Charge and fee catalogue for quoting and later finance lines.';
create index if not exists ix_surcharges_org on master_data.surcharges (organization_id);

-- =========================================================
-- service_orders
-- =========================================================

create table if not exists service_orders.service_orders (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    service_order_no varchar(40) not null,
    customer_id uuid not null,
    customer_code_snapshot varchar(40),
    customer_name_snapshot varchar(255),
    service_type varchar(40) not null default 'TRUCKING_CONTAINER',
    business_mode varchar(40) not null default 'TRUCKING',
    pickup_location_id uuid,
    pickup_location_name_snapshot varchar(255),
    delivery_location_id uuid,
    delivery_location_name_snapshot varchar(255),
    requested_pickup_at timestamptz,
    requested_delivery_at timestamptz,
    special_requirements text,
    source_channel varchar(30),
    quoted_amount numeric(18,2) not null default 0,
    discount_amount numeric(18,2) not null default 0,
    estimated_total_amount numeric(18,2) not null default 0,
    status_code varchar(30) not null default 'DRAFT',
    confirmed_at timestamptz,
    confirmed_by uuid,
    created_by uuid,
    updated_by uuid,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    version int not null default 0,
    unique (organization_id, service_order_no)
);

comment on table service_orders.service_orders is 'Commercial service order aggregate. Snapshot fields are intentional to reduce join cost and preserve business context.';
create index if not exists ix_service_orders_org_status on service_orders.service_orders (organization_id, status_code);
create index if not exists ix_service_orders_customer on service_orders.service_orders (organization_id, customer_id);
create index if not exists ix_service_orders_pickup_time on service_orders.service_orders (organization_id, requested_pickup_at);

create table if not exists service_orders.service_order_units (
    id uuid primary key default gen_random_uuid(),
    service_order_id uuid not null,
    unit_type varchar(30) not null default 'CONTAINER',
    container_no varchar(30),
    container_type varchar(30),
    cargo_description text,
    gross_weight_kg numeric(18,2),
    is_empty_container boolean not null default false,
    seal_no varchar(50),
    booking_no varchar(60),
    delivery_order_no varchar(60),
    created_at timestamptz not null default now(),
    constraint fk_service_order_units_order foreign key (service_order_id) references service_orders.service_orders(id)
);

comment on table service_orders.service_order_units is 'Container or shipment units under a service order.';
create index if not exists ix_service_order_units_order on service_orders.service_order_units (service_order_id);

create table if not exists service_orders.service_order_stops (
    id uuid primary key default gen_random_uuid(),
    service_order_id uuid not null,
    stop_no int not null,
    stop_type varchar(30) not null,
    location_id uuid,
    location_name_snapshot varchar(255),
    planned_arrival_at timestamptz,
    planned_departure_at timestamptz,
    contact_name varchar(255),
    contact_phone varchar(50),
    note text,
    created_at timestamptz not null default now(),
    constraint fk_service_order_stops_order foreign key (service_order_id) references service_orders.service_orders(id),
    unique (service_order_id, stop_no)
);

comment on table service_orders.service_order_stops is 'Ordered stop list under the service order.';
create index if not exists ix_service_order_stops_order on service_orders.service_order_stops (service_order_id);

create table if not exists service_orders.service_order_charge_items (
    id uuid primary key default gen_random_uuid(),
    service_order_id uuid not null,
    line_no int not null,
    charge_code varchar(60) not null,
    charge_name varchar(255) not null,
    amount numeric(18,2) not null,
    currency_code varchar(10) not null default 'VND',
    is_discount boolean not null default false,
    source_type varchar(30) not null default 'MANUAL',
    created_at timestamptz not null default now(),
    constraint fk_service_order_charges_order foreign key (service_order_id) references service_orders.service_orders(id),
    unique (service_order_id, line_no)
);

comment on table service_orders.service_order_charge_items is 'Commercial price components, discounts, or manual charge lines.';
create index if not exists ix_service_order_charges_order on service_orders.service_order_charge_items (service_order_id);

create table if not exists service_orders.service_order_status_history (
    id bigserial primary key,
    service_order_id uuid not null,
    from_status varchar(30),
    to_status varchar(30) not null,
    changed_at timestamptz not null default now(),
    changed_by uuid,
    reason_code varchar(40),
    note text,
    constraint fk_service_order_status_order foreign key (service_order_id) references service_orders.service_orders(id)
);

comment on table service_orders.service_order_status_history is 'Append-only history of service-order status transitions.';
create index if not exists ix_service_order_status_hist_order on service_orders.service_order_status_history (service_order_id, changed_at desc);

create table if not exists service_orders.service_order_change_logs (
    id bigserial primary key,
    service_order_id uuid not null,
    change_type varchar(40) not null,
    field_name varchar(120),
    old_value text,
    new_value text,
    changed_at timestamptz not null default now(),
    changed_by uuid,
    reason_text text,
    constraint fk_service_order_change_order foreign key (service_order_id) references service_orders.service_orders(id)
);

comment on table service_orders.service_order_change_logs is 'Detailed business change log for major order amendments.';
create index if not exists ix_service_order_change_logs_order on service_orders.service_order_change_logs (service_order_id, changed_at desc);

create table if not exists service_orders.service_order_attachments (
    id uuid primary key default gen_random_uuid(),
    service_order_id uuid not null,
    file_id uuid not null,
    attachment_type varchar(40) not null,
    file_name_snapshot varchar(255),
    uploaded_by uuid,
    uploaded_at timestamptz not null default now(),
    constraint fk_service_order_attach_order foreign key (service_order_id) references service_orders.service_orders(id)
);

comment on table service_orders.service_order_attachments is 'Business attachment metadata linked to service orders.';
create index if not exists ix_service_order_attach_order on service_orders.service_order_attachments (service_order_id);

-- =========================================================
-- dispatch_execution
-- =========================================================

create table if not exists dispatch_execution.dispatch_orders (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    dispatch_order_no varchar(40) not null,
    service_order_id uuid not null,
    service_order_no_snapshot varchar(40),
    customer_id uuid,
    customer_name_snapshot varchar(255),
    dispatcher_user_id uuid,
    planned_start_at timestamptz,
    planned_end_at timestamptz,
    status_code varchar(30) not null default 'NEW',
    note text,
    created_by uuid,
    updated_by uuid,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    version int not null default 0,
    unique (organization_id, dispatch_order_no)
);

comment on table dispatch_execution.dispatch_orders is 'Back-office dispatch document created from service orders.';
create index if not exists ix_dispatch_orders_order on dispatch_execution.dispatch_orders (organization_id, service_order_id);
create index if not exists ix_dispatch_orders_status on dispatch_execution.dispatch_orders (organization_id, status_code);

create table if not exists dispatch_execution.trips (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    trip_no varchar(40) not null,
    dispatch_order_id uuid not null,
    service_order_id uuid not null,
    service_order_no_snapshot varchar(40),
    customer_id uuid,
    customer_name_snapshot varchar(255),
    route_id uuid,
    route_name_snapshot varchar(255),
    business_mode varchar(40) not null default 'TRUCKING',
    branch_id uuid,
    fleet_team_id uuid,
    origin_location_id uuid,
    origin_location_name_snapshot varchar(255),
    destination_location_id uuid,
    destination_location_name_snapshot varchar(255),
    primary_vehicle_id uuid,
    primary_vehicle_plate_snapshot varchar(30),
    primary_driver_id uuid,
    primary_driver_name_snapshot varchar(255),
    planned_start_at timestamptz,
    planned_end_at timestamptz,
    actual_start_at timestamptz,
    actual_end_at timestamptz,
    status_code varchar(30) not null default 'PLANNED',
    delay_reason_code varchar(40),
    incident_flag boolean not null default false,
    created_by uuid,
    updated_by uuid,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    version int not null default 0,
    constraint fk_trips_dispatch_order foreign key (dispatch_order_id) references dispatch_execution.dispatch_orders(id),
    unique (organization_id, trip_no)
);

comment on table dispatch_execution.trips is 'Execution aggregate for a real transport run. One service order may create one or multiple trips.';
create index if not exists ix_trips_status on dispatch_execution.trips (organization_id, status_code);
create index if not exists ix_trips_order on dispatch_execution.trips (organization_id, service_order_id);
create index if not exists ix_trips_planned_start on dispatch_execution.trips (organization_id, planned_start_at);

create table if not exists dispatch_execution.trip_stops (
    id uuid primary key default gen_random_uuid(),
    trip_id uuid not null,
    stop_no int not null,
    stop_type varchar(30) not null,
    location_id uuid,
    location_name_snapshot varchar(255),
    planned_arrival_at timestamptz,
    planned_departure_at timestamptz,
    actual_arrival_at timestamptz,
    actual_departure_at timestamptz,
    status_code varchar(30) not null default 'PLANNED',
    note text,
    created_at timestamptz not null default now(),
    constraint fk_trip_stops_trip foreign key (trip_id) references dispatch_execution.trips(id),
    unique (trip_id, stop_no)
);

comment on table dispatch_execution.trip_stops is 'Execution stop list under the trip.';
create index if not exists ix_trip_stops_trip on dispatch_execution.trip_stops (trip_id);

create table if not exists dispatch_execution.trip_vehicle_assignments (
    id uuid primary key default gen_random_uuid(),
    trip_id uuid not null,
    vehicle_id uuid not null,
    vehicle_plate_snapshot varchar(30),
    assignment_role varchar(20) not null,
    assigned_at timestamptz not null default now(),
    assigned_by uuid,
    released_at timestamptz,
    constraint fk_trip_vehicle_assign_trip foreign key (trip_id) references dispatch_execution.trips(id)
);

comment on table dispatch_execution.trip_vehicle_assignments is 'Vehicle assignment history under a trip.';
create index if not exists ix_trip_vehicle_assign_trip on dispatch_execution.trip_vehicle_assignments (trip_id);
create index if not exists ix_trip_vehicle_assign_vehicle on dispatch_execution.trip_vehicle_assignments (vehicle_id);

create table if not exists dispatch_execution.trip_driver_assignments (
    id uuid primary key default gen_random_uuid(),
    trip_id uuid not null,
    driver_id uuid not null,
    driver_name_snapshot varchar(255),
    assignment_role varchar(20) not null,
    assigned_at timestamptz not null default now(),
    assigned_by uuid,
    released_at timestamptz,
    constraint fk_trip_driver_assign_trip foreign key (trip_id) references dispatch_execution.trips(id)
);

comment on table dispatch_execution.trip_driver_assignments is 'Driver and co-driver assignment history.';
create index if not exists ix_trip_driver_assign_trip on dispatch_execution.trip_driver_assignments (trip_id);
create index if not exists ix_trip_driver_assign_driver on dispatch_execution.trip_driver_assignments (driver_id);

create table if not exists dispatch_execution.trip_status_history (
    id bigserial primary key,
    trip_id uuid not null,
    from_status varchar(30),
    to_status varchar(30) not null,
    changed_at timestamptz not null default now(),
    changed_by uuid,
    source_type varchar(20) not null default 'WEB',
    reason_code varchar(40),
    note text,
    constraint fk_trip_status_history_trip foreign key (trip_id) references dispatch_execution.trips(id)
);

comment on table dispatch_execution.trip_status_history is 'Append-only history for trip status transitions.';
create index if not exists ix_trip_status_history_trip on dispatch_execution.trip_status_history (trip_id, changed_at desc);

create table if not exists dispatch_execution.trip_incidents (
    id uuid primary key default gen_random_uuid(),
    trip_id uuid not null,
    incident_type varchar(40) not null,
    severity_code varchar(20) not null default 'MEDIUM',
    status_code varchar(30) not null default 'OPEN',
    reported_at timestamptz not null default now(),
    reported_by uuid,
    description text,
    resolution_note text,
    resolved_at timestamptz,
    resolved_by uuid,
    constraint fk_trip_incidents_trip foreign key (trip_id) references dispatch_execution.trips(id)
);

comment on table dispatch_execution.trip_incidents is 'Operational incidents and abnormal situations during trip execution.';
create index if not exists ix_trip_incidents_trip on dispatch_execution.trip_incidents (trip_id);

create table if not exists dispatch_execution.dispatch_recommendations (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    service_order_id uuid not null,
    candidate_vehicle_id uuid,
    candidate_driver_id uuid,
    score numeric(10,4),
    rule_breakdown jsonb,
    generated_at timestamptz not null default now(),
    accepted_flag boolean not null default false
);

comment on table dispatch_execution.dispatch_recommendations is 'Rule-based recommendation output for dispatching. It is not the final source of truth.';
create index if not exists ix_dispatch_reco_order on dispatch_execution.dispatch_recommendations (organization_id, service_order_id);

-- =========================================================
-- trip_execution
-- =========================================================

create table if not exists trip_execution.trip_command_acknowledgements (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    trip_id uuid not null,
    trip_no_snapshot varchar(40),
    driver_id uuid not null,
    driver_name_snapshot varchar(255),
    acknowledgement_type varchar(20) not null,
    acknowledged_at timestamptz not null default now(),
    reason_text text
);

comment on table trip_execution.trip_command_acknowledgements is 'Mobile acknowledgement of trip commands by drivers.';
create index if not exists ix_trip_ack_trip on trip_execution.trip_command_acknowledgements (trip_id);

create table if not exists trip_execution.trip_proofs (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    trip_id uuid not null,
    trip_stop_id uuid,
    trip_no_snapshot varchar(40),
    stop_no_snapshot int,
    driver_id uuid,
    driver_name_snapshot varchar(255),
    proof_type varchar(40) not null,
    file_id uuid not null,
    note text,
    captured_at timestamptz not null default now()
);

comment on table trip_execution.trip_proofs is 'POD photo, field image, receipt image, and other mobile evidence.';
create index if not exists ix_trip_proofs_trip on trip_execution.trip_proofs (trip_id);

create table if not exists trip_execution.trip_signatures (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    trip_id uuid not null,
    trip_stop_id uuid,
    trip_no_snapshot varchar(40),
    signer_name varchar(255),
    signer_phone varchar(50),
    signature_file_id uuid not null,
    signed_at timestamptz not null default now()
);

comment on table trip_execution.trip_signatures is 'Signature evidence collected at a stop or final delivery.';
create index if not exists ix_trip_signatures_trip on trip_execution.trip_signatures (trip_id);

create table if not exists trip_execution.trip_notes (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    trip_id uuid not null,
    trip_stop_id uuid,
    trip_no_snapshot varchar(40),
    driver_id uuid,
    note_type varchar(40) not null,
    note_text text not null,
    recorded_at timestamptz not null default now()
);

comment on table trip_execution.trip_notes is 'Field notes, exception notes, or operational annotations recorded during execution.';
create index if not exists ix_trip_notes_trip on trip_execution.trip_notes (trip_id);

-- =========================================================
-- receivables_payables
-- =========================================================

create table if not exists receivables_payables.receivables (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    receivable_no varchar(40) not null,
    customer_id uuid not null,
    customer_code_snapshot varchar(40),
    customer_name_snapshot varchar(255),
    service_order_id uuid,
    service_order_no_snapshot varchar(40),
    trip_id uuid,
    trip_no_snapshot varchar(40),
    document_date date not null,
    due_date date,
    currency_code varchar(10) not null default 'VND',
    gross_amount numeric(18,2) not null default 0,
    discount_amount numeric(18,2) not null default 0,
    net_amount numeric(18,2) not null default 0,
    collected_amount numeric(18,2) not null default 0,
    balance_amount numeric(18,2) not null default 0,
    status_code varchar(30) not null default 'OPEN',
    created_by uuid,
    updated_by uuid,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    version int not null default 0,
    unique (organization_id, receivable_no)
);

comment on table receivables_payables.receivables is 'Accounts receivable document header.';
create index if not exists ix_receivables_customer on receivables_payables.receivables (organization_id, customer_id);
create index if not exists ix_receivables_due on receivables_payables.receivables (organization_id, due_date, status_code);

create table if not exists receivables_payables.receivable_lines (
    id uuid primary key default gen_random_uuid(),
    receivable_id uuid not null,
    line_no int not null,
    charge_code varchar(60) not null,
    description varchar(255) not null,
    amount numeric(18,2) not null,
    source_type varchar(30) not null default 'MANUAL',
    created_at timestamptz not null default now(),
    constraint fk_receivable_lines_header foreign key (receivable_id) references receivables_payables.receivables(id),
    unique (receivable_id, line_no)
);

comment on table receivables_payables.receivable_lines is 'Receivable detail lines.';
create index if not exists ix_receivable_lines_receivable on receivables_payables.receivable_lines (receivable_id);

create table if not exists receivables_payables.payables (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    payable_no varchar(40) not null,
    vendor_id uuid not null,
    vendor_code_snapshot varchar(40),
    vendor_name_snapshot varchar(255),
    service_order_id uuid,
    service_order_no_snapshot varchar(40),
    trip_id uuid,
    trip_no_snapshot varchar(40),
    document_date date not null,
    due_date date,
    currency_code varchar(10) not null default 'VND',
    gross_amount numeric(18,2) not null default 0,
    paid_amount numeric(18,2) not null default 0,
    balance_amount numeric(18,2) not null default 0,
    status_code varchar(30) not null default 'OPEN',
    created_by uuid,
    updated_by uuid,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    version int not null default 0,
    unique (organization_id, payable_no)
);

comment on table receivables_payables.payables is 'Accounts payable document header.';
create index if not exists ix_payables_vendor on receivables_payables.payables (organization_id, vendor_id);
create index if not exists ix_payables_due on receivables_payables.payables (organization_id, due_date, status_code);

create table if not exists receivables_payables.payable_lines (
    id uuid primary key default gen_random_uuid(),
    payable_id uuid not null,
    line_no int not null,
    cost_code varchar(60) not null,
    description varchar(255) not null,
    amount numeric(18,2) not null,
    source_type varchar(30) not null default 'MANUAL',
    created_at timestamptz not null default now(),
    constraint fk_payable_lines_header foreign key (payable_id) references receivables_payables.payables(id),
    unique (payable_id, line_no)
);

comment on table receivables_payables.payable_lines is 'Payable detail lines.';
create index if not exists ix_payable_lines_payable on receivables_payables.payable_lines (payable_id);

create table if not exists receivables_payables.reconciliation_batches (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    batch_no varchar(40) not null,
    reconciliation_type varchar(30) not null,
    party_id uuid not null,
    party_name_snapshot varchar(255),
    period_from date not null,
    period_to date not null,
    status_code varchar(30) not null default 'DRAFT',
    confirmed_at timestamptz,
    confirmed_by uuid,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    unique (organization_id, batch_no)
);

comment on table receivables_payables.reconciliation_batches is 'Header for customer or vendor reconciliation cycle.';
create index if not exists ix_recon_batches_party on receivables_payables.reconciliation_batches (organization_id, party_id);

create table if not exists receivables_payables.reconciliation_items (
    id uuid primary key default gen_random_uuid(),
    reconciliation_batch_id uuid not null,
    service_order_id uuid,
    service_order_no_snapshot varchar(40),
    trip_id uuid,
    trip_no_snapshot varchar(40),
    quantity numeric(18,2),
    amount numeric(18,2),
    surcharge_amount numeric(18,2),
    confirmed_flag boolean not null default false,
    note text,
    constraint fk_recon_items_batch foreign key (reconciliation_batch_id) references receivables_payables.reconciliation_batches(id)
);

comment on table receivables_payables.reconciliation_items is 'Trip/order items included in a reconciliation batch.';
create index if not exists ix_recon_items_batch on receivables_payables.reconciliation_items (reconciliation_batch_id);

create table if not exists receivables_payables.cash_receipts (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    receipt_no varchar(40) not null,
    receivable_id uuid not null,
    customer_id uuid,
    customer_name_snapshot varchar(255),
    received_at timestamptz not null,
    amount numeric(18,2) not null,
    payment_method varchar(30),
    reference_no varchar(80),
    note text,
    created_at timestamptz not null default now(),
    constraint fk_cash_receipts_receivable foreign key (receivable_id) references receivables_payables.receivables(id),
    unique (organization_id, receipt_no)
);

comment on table receivables_payables.cash_receipts is 'Receipt header for AR settlements.';
create index if not exists ix_cash_receipts_receivable on receivables_payables.cash_receipts (receivable_id);

create table if not exists receivables_payables.cash_payments (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    payment_no varchar(40) not null,
    payable_id uuid not null,
    vendor_id uuid,
    vendor_name_snapshot varchar(255),
    paid_at timestamptz not null,
    amount numeric(18,2) not null,
    payment_method varchar(30),
    reference_no varchar(80),
    note text,
    created_at timestamptz not null default now(),
    constraint fk_cash_payments_payable foreign key (payable_id) references receivables_payables.payables(id),
    unique (organization_id, payment_no)
);

comment on table receivables_payables.cash_payments is 'Payment header for AP settlements.';
create index if not exists ix_cash_payments_payable on receivables_payables.cash_payments (payable_id);

create table if not exists receivables_payables.receivable_status_history (
    id bigserial primary key,
    receivable_id uuid not null,
    from_status varchar(30),
    to_status varchar(30) not null,
    changed_at timestamptz not null default now(),
    changed_by uuid,
    note text,
    constraint fk_receivable_status_header foreign key (receivable_id) references receivables_payables.receivables(id)
);

comment on table receivables_payables.receivable_status_history is 'Append-only AR status history.';
create index if not exists ix_receivable_status_history on receivables_payables.receivable_status_history (receivable_id, changed_at desc);

create table if not exists receivables_payables.payable_status_history (
    id bigserial primary key,
    payable_id uuid not null,
    from_status varchar(30),
    to_status varchar(30) not null,
    changed_at timestamptz not null default now(),
    changed_by uuid,
    note text,
    constraint fk_payable_status_header foreign key (payable_id) references receivables_payables.payables(id)
);

comment on table receivables_payables.payable_status_history is 'Append-only AP status history.';
create index if not exists ix_payable_status_history on receivables_payables.payable_status_history (payable_id, changed_at desc);

-- =========================================================
-- operational_reporting
-- =========================================================

create table if not exists operational_reporting.service_order_list_projection (
    service_order_id uuid primary key,
    organization_id uuid not null,
    service_order_no varchar(40) not null,
    customer_id uuid,
    customer_name varchar(255),
    pickup_location_name varchar(255),
    delivery_location_name varchar(255),
    requested_pickup_at timestamptz,
    requested_delivery_at timestamptz,
    estimated_total_amount numeric(18,2),
    status_code varchar(30),
    last_event_at timestamptz not null default now()
);

comment on table operational_reporting.service_order_list_projection is 'Flattened read table for service-order lists and quick search.';
create index if not exists ix_order_projection_org_status on operational_reporting.service_order_list_projection (organization_id, status_code);

create table if not exists operational_reporting.trip_list_projection (
    trip_id uuid primary key,
    organization_id uuid not null,
    trip_no varchar(40) not null,
    service_order_id uuid,
    service_order_no varchar(40),
    customer_name varchar(255),
    route_name varchar(255),
    vehicle_plate_no varchar(30),
    driver_name varchar(255),
    planned_start_at timestamptz,
    planned_end_at timestamptz,
    actual_start_at timestamptz,
    actual_end_at timestamptz,
    status_code varchar(30),
    incident_flag boolean not null default false,
    last_event_at timestamptz not null default now()
);

comment on table operational_reporting.trip_list_projection is 'Flattened read table for trip monitoring screens.';
create index if not exists ix_trip_projection_org_status on operational_reporting.trip_list_projection (organization_id, status_code);

create table if not exists operational_reporting.receivable_list_projection (
    receivable_id uuid primary key,
    organization_id uuid not null,
    receivable_no varchar(40) not null,
    customer_name varchar(255),
    service_order_no varchar(40),
    trip_no varchar(40),
    due_date date,
    balance_amount numeric(18,2),
    status_code varchar(30),
    last_event_at timestamptz not null default now()
);

comment on table operational_reporting.receivable_list_projection is 'Flattened AR list for finance screens.';
create index if not exists ix_receivable_projection_org_status on operational_reporting.receivable_list_projection (organization_id, status_code);

create table if not exists operational_reporting.daily_operations_summary (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    business_date date not null,
    branch_id uuid,
    total_service_orders int not null default 0,
    total_trips int not null default 0,
    trips_in_progress int not null default 0,
    trips_completed int not null default 0,
    trips_delayed int not null default 0,
    active_vehicles int not null default 0,
    idle_vehicles int not null default 0,
    created_at timestamptz not null default now(),
    unique (organization_id, business_date, branch_id)
);

comment on table operational_reporting.daily_operations_summary is 'Pre-aggregated daily operations dashboard.';
create index if not exists ix_daily_ops_date on operational_reporting.daily_operations_summary (organization_id, business_date);

create table if not exists operational_reporting.vehicle_utilization_daily (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    business_date date not null,
    vehicle_id uuid not null,
    vehicle_plate_snapshot varchar(30),
    trip_count int not null default 0,
    loaded_km numeric(12,2) not null default 0,
    empty_km numeric(12,2) not null default 0,
    utilization_pct numeric(8,2) not null default 0,
    created_at timestamptz not null default now(),
    unique (organization_id, business_date, vehicle_id)
);

comment on table operational_reporting.vehicle_utilization_daily is 'Daily per-vehicle utilization read table.';
create index if not exists ix_vehicle_util_daily on operational_reporting.vehicle_utilization_daily (organization_id, business_date);

create table if not exists operational_reporting.customer_revenue_daily (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    business_date date not null,
    customer_id uuid not null,
    customer_name_snapshot varchar(255),
    revenue_amount numeric(18,2) not null default 0,
    created_at timestamptz not null default now(),
    unique (organization_id, business_date, customer_id)
);

comment on table operational_reporting.customer_revenue_daily is 'Daily revenue summary by customer.';
create index if not exists ix_customer_revenue_daily on operational_reporting.customer_revenue_daily (organization_id, business_date);

-- =========================================================
-- system_integration
-- =========================================================

create table if not exists system_integration.files (
    id uuid primary key default gen_random_uuid(),
    organization_id uuid not null,
    storage_provider varchar(40) not null default 'OBJECT_STORAGE',
    storage_key varchar(500) not null,
    file_name varchar(255) not null,
    mime_type varchar(120),
    size_bytes bigint,
    checksum_sha256 varchar(64),
    uploaded_by uuid,
    uploaded_at timestamptz not null default now()
);

comment on table system_integration.files is 'Attachment metadata only. File binary should live in object storage or dedicated file storage.';
create index if not exists ix_files_org_time on system_integration.files (organization_id, uploaded_at desc);

create table if not exists system_integration.audit_logs (
    id bigserial primary key,
    organization_id uuid not null,
    actor_user_id uuid,
    module_code varchar(80) not null,
    entity_type varchar(80) not null,
    entity_id uuid,
    action_code varchar(80) not null,
    before_data jsonb,
    after_data jsonb,
    ip_address inet,
    occurred_at timestamptz not null default now()
);

comment on table system_integration.audit_logs is 'Append-only audit trail for business and administrative actions.';
create index if not exists ix_audit_logs_entity on system_integration.audit_logs (entity_type, entity_id);
create index if not exists ix_audit_logs_time on system_integration.audit_logs (occurred_at desc);

create table if not exists system_integration.outbox_events (
    id bigserial primary key,
    organization_id uuid not null,
    aggregate_type varchar(80) not null,
    aggregate_id uuid not null,
    event_type varchar(120) not null,
    event_key varchar(120),
    payload jsonb not null,
    headers jsonb,
    status_code varchar(20) not null default 'NEW',
    occurred_at timestamptz not null default now(),
    published_at timestamptz,
    last_error text,
    retry_count int not null default 0
);

comment on table system_integration.outbox_events is 'Reliable event handoff table. Poll this table by bigserial id, then publish to Redis Streams or another broker.';
create index if not exists ix_outbox_status_id on system_integration.outbox_events (status_code, id);
create index if not exists ix_outbox_aggregate on system_integration.outbox_events (aggregate_type, aggregate_id);

create table if not exists system_integration.idempotency_keys (
    id bigserial primary key,
    organization_id uuid not null,
    idempotency_key varchar(120) not null,
    request_hash varchar(128),
    response_hash varchar(128),
    created_at timestamptz not null default now(),
    unique (organization_id, idempotency_key)
);

comment on table system_integration.idempotency_keys is 'Prevents duplicate submit/retry processing from API or mobile channels.';
create index if not exists ix_idempotency_created on system_integration.idempotency_keys (created_at desc);

create table if not exists system_integration.integration_jobs (
    id bigserial primary key,
    organization_id uuid not null,
    job_type varchar(60) not null,
    status_code varchar(30) not null default 'NEW',
    requested_by uuid,
    payload jsonb,
    started_at timestamptz,
    finished_at timestamptz,
    last_error text,
    created_at timestamptz not null default now()
);

comment on table system_integration.integration_jobs is 'Tracks operational background jobs such as report exports and event replay.';
create index if not exists ix_integration_jobs_status on system_integration.integration_jobs (status_code, created_at desc);
