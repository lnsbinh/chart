INSERT INTO identity_access.roles
(id, organization_id, role_code, role_name, description, active_from, active_to)
values (gen_random_uuid(), gen_random_uuid(), 'ADMIN', 'Administrator', 'Full access to all resources', CURRENT_DATE, NULL),
(gen_random_uuid(), gen_random_uuid(), 'DISPATCHER', 'Dispatcher', 'Access to dispatching and scheduling features', CURRENT_DATE, NULL),
(gen_random_uuid(), gen_random_uuid(), 'DRIVER', 'Driver', 'Access to driver-specific features and information', CURRENT_DATE, NULL),
(gen_random_uuid(), gen_random_uuid(), 'SUPERVISOR', 'Supervisor', 'Access to supervisory features and reports', CURRENT_DATE, NULL),
(gen_random_uuid(), gen_random_uuid(), 'FINANCE_OPS', 'Finance Operations', 'Access to financial operations and reporting features', CURRENT_DATE, NULL),
(gen_random_uuid(), gen_random_uuid(), 'OPERATION_STAFF', 'Operation Staff', 'Access to operational features and information', CURRENT_DATE, NULL);
