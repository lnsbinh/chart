package com.tms.user.repo;

import com.tms.common.response.PageResult;
import com.tms.user.model.User;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface UserQueryRepository {
    Optional<User> findUserByEmail(String email);
    User saveUser(User user);
    List<User> findAllUsers();
    PageResult<User> findAllUsersWithPagination(int page, int size);
    User findUserById(UUID id);
    PageResult<User> findAllUserWithRolesAndBranches(int page, int size, List<String> status, List<UUID> roleIds, List<UUID> branchIds, String idSort, String statusSort, String search);
}
