package com.tms.user.repo;

import com.tms.common.response.PageResult;
import com.tms.user.model.User;
import com.tms.user.repo.UserQueryRepository;
import com.tms.user.model.UserMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public class UserQueryRepositoryImpl implements UserQueryRepository {

    private final UserJpaRepository userJpaRepository;
    private final UserMapper userMapper;

    public UserQueryRepositoryImpl(UserJpaRepository userJpaRepository, UserMapper userMapper) {
        this.userJpaRepository = userJpaRepository;
        this.userMapper = userMapper;
    }

    @Override
    public Optional<User> findUserByEmail(String email) {
        return userJpaRepository.findByEmail(email)
                .map(this::toDomain);
    }

    @Override
    public User saveUser(User user) {
        UserEntity entity = toEntity(user);
        UserEntity saved = userJpaRepository.save(entity);
        return toDomain(saved);
    }

    @Override
    public List<User> findAllUsers() {
        return userJpaRepository.findAll()
                .stream()
                .map(this::toDomain)
                .toList();
    }

    @Override
    public PageResult<User> findAllUsersWithPagination(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<UserEntity> pageResult = userJpaRepository.findAll(pageable);

        List<User> users = pageResult.getContent()
                .stream()
                .map(this::toDomain)
                .toList();

        return PageResult.<User>builder()
                .content(users)
                .page(pageResult.getNumber())
                .size(pageResult.getSize())
                .totalElements(pageResult.getTotalElements())
                .totalPages(pageResult.getTotalPages())
                .build();
    }

    @Override
    public User findUserById(UUID id) {
        return userJpaRepository.findById(id)
                .map(this::toDomain)
                .orElse(null);
    }

    @Override
    public PageResult<User> findAllUserWithRolesAndBranches(int page, int size, List<String> status, List<UUID> roleIds, List<UUID> branchIds, String idSort, String statusSort, String search) {
        Sort sort = Sort.unsorted();

        if (idSort != null && !idSort.isBlank()) {
            Sort.Direction idDirection = "desc".equalsIgnoreCase(idSort) ? Sort.Direction.DESC : Sort.Direction.ASC;
            sort = sort.and(Sort.by(new Sort.Order(idDirection, "userCode")));
        }

        if (statusSort != null && !statusSort.isBlank()) {
            Sort.Direction statusDirection = "desc".equalsIgnoreCase(statusSort) ? Sort.Direction.DESC : Sort.Direction.ASC;
            sort = sort.and(Sort.by(new Sort.Order(statusDirection, "statusCode")));
        }

        Pageable pageable = PageRequest.of(page, size, sort);
        Page<UserEntity> pageResult = userJpaRepository.findAllWithRolesAndBranchesFiltered(status, roleIds, branchIds, search, pageable);

        List<User> users = pageResult.getContent()
                .stream()
                .map(userMapper::toDomain)
                .toList();

        return PageResult.<User>builder()
                .content(users)
                .page(pageResult.getNumber())
                .size(pageResult.getSize())
                .totalElements(pageResult.getTotalElements())
                .totalPages(pageResult.getTotalPages())
                .build();
    }

    private User toDomain(UserEntity entity) {
        return new User(
                entity.getId(),
                entity.getUserCode(),
                entity.getUsername(),
                entity.getEmail(),
                entity.getPhone(),
                entity.getFirstName(),
                entity.getLastName(),
                entity.getStatusCode(),
                entity.getAvatarUrl(),
                entity.getPassword()
        );
    }

    private UserEntity toEntity(User user) {
        UserEntity entity = new UserEntity();
        entity.setId(user.getId());
        entity.setUsername(user.getUsername());
        entity.setEmail(user.getEmail());
        entity.setPhone(user.getPhone());
        entity.setFirstName(user.getFirstName());
        entity.setLastName(user.getLastName());
        entity.setPassword(user.getPassword());
        entity.setStatusCode("ACTIVE");
        entity.setCreatedAt(LocalDateTime.now());
        entity.setUpdatedAt(LocalDateTime.now());
        return entity;
    }
}
