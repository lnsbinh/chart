package com.tms.user.repo;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.Set;
import java.util.UUID;

@Entity
@Table(name = "users", schema = "identity_access")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UserEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(name = "keycloak_user_id")
    private UUID keycloakUserId;

    @Column(name = "organization_id")
    private UUID organizationId;

    @Column(name = "user_code", unique = true)
    private String userCode;

    private String username;

    @Column(name = "password_hash")
    private String password;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    private String email;
    private String phone;

    @Column(name = "status_code")
    private String statusCode = "ACTIVE";

    @Column(name = "avatar_url")
    private String avatarUrl;

    @Column(name = "default_branch_id")
    private UUID defaultBranchId;

    @Column(name = "is_deleted")
    private Boolean deleted;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
        name = "user_roles",
        schema = "identity_access",
        joinColumns = @JoinColumn(name = "user_id"),
        inverseJoinColumns = @JoinColumn(name = "role_id"),
        foreignKey = @ForeignKey(name = "fk_user_roles_user"),
        inverseForeignKey = @ForeignKey(name = "fk_user_roles_role")
    )
    private Set<RoleEntity> roles;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
        name = "user_data_scopes",
        schema = "identity_access",
        joinColumns = @JoinColumn(name = "user_id"),
        inverseJoinColumns = @JoinColumn(name = "scope_id"),
        foreignKey = @ForeignKey(name = "fk_user_scopes_user"),
        inverseForeignKey = @ForeignKey(name = "fk_user_scopes_branch"),
        uniqueConstraints = @UniqueConstraint(columnNames = {"user_id", "scope_id"})
    )
    private Set<BranchEntity> branches;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}
