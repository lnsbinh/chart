package com.tms.user.repo;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface UserJpaRepository extends JpaRepository<UserEntity, UUID> {
    Optional<UserEntity> findByEmail(String email);
    boolean existsByUsername(String username);
    boolean existsByEmail(String email);
    boolean existsByUserCode(String userCode);
    Optional<UserEntity> findByUsername(String username);
    Optional<UserEntity> findById(UUID id);
    @Query("""
    SELECT DISTINCT u FROM UserEntity u
    LEFT JOIN FETCH u.roles
    LEFT JOIN FETCH u.branches
    WHERE (u.deleted = false OR u.deleted IS NULL)
    AND (:status IS NULL OR u.statusCode IN :status)
    AND (:roleIds IS NULL OR EXISTS (SELECT 1 FROM u.roles r WHERE r.id IN :roleIds))
    AND (:branchIds IS NULL OR EXISTS (SELECT 1 FROM u.branches b WHERE b.id IN :branchIds))
    AND (:search IS NULL OR LOWER(CAST(u.username AS text)) LIKE CONCAT('%', LOWER(CAST(:search AS text)), '%')
        OR LOWER(CAST(u.email AS text)) LIKE CONCAT('%', LOWER(CAST(:search AS text)), '%')
        OR LOWER(CAST(u.firstName AS text)) LIKE CONCAT('%', LOWER(CAST(:search AS text)), '%')
        OR LOWER(CAST(u.lastName AS text)) LIKE CONCAT('%', LOWER(CAST(:search AS text)), '%'))
""")
    Page<UserEntity> findAllWithRolesAndBranchesFiltered(
            @Param("status") List<String> status,
            @Param("roleIds") List<UUID> roleIds,
            @Param("branchIds") List<UUID> branchIds,
            @Param("search") String search,
            Pageable pageable);
}
