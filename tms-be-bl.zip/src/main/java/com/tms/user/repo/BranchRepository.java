package com.tms.user.repo;

import com.tms.user.repo.BranchEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface BranchRepository extends JpaRepository<BranchEntity, UUID> {
    List<BranchEntity> findByIdIn(List<UUID> ids);
}
