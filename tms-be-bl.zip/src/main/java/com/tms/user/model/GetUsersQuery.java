package com.tms.user.model;

import java.util.List;
import java.util.UUID;

public record GetUsersQuery(
        int page,
        int size,
        List<String> status,
        List<UUID> roleIds,
        List<UUID> branchIds,
        String idSort,
        String statusSort,
        String search
) {
}
