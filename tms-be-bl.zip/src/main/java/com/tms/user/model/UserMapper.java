package com.tms.user.model;

import com.tms.user.model.BranchDto;
import com.tms.user.model.RoleDto;
import com.tms.user.model.UserDto;
import com.tms.user.model.Branch;
import com.tms.user.model.Role;
import com.tms.user.model.User;
import com.tms.user.repo.BranchEntity;
import com.tms.user.repo.RoleEntity;
import com.tms.user.repo.UserEntity;

import java.util.List;
import java.util.Set;

public interface UserMapper {
    public User toDomain(UserEntity entity);
    public List<Role> mapRoles(Set<RoleEntity> roles);
    public List<Branch> mapBranches(Set<BranchEntity> branches);

    public UserDto toDto(User user);
    public List<RoleDto> mapRoleDtos(List<Role> roles);
    public List<BranchDto> mapBranchDtos(List<Branch> branches);
}
