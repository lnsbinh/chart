package com.tms.user.model;

import java.util.List;
import java.util.UUID;

public record UserDto(
        UUID id,
        String userCode,
        String username,
        String email,
        String phone,
        String firstName,
        String lastName,
        String statusCode,
        String avatarUrl,
        List<RoleDto> roleDtos,
        List<BranchDto> branchDtos
) {
}
