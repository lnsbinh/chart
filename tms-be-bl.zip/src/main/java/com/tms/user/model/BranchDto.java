package com.tms.user.model;

import java.util.UUID;

public record BranchDto(
        UUID id,
        String code,
        String name,
        String address,
        String statusCode
) {
}
