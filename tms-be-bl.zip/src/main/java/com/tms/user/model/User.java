package com.tms.user.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.UUID;

@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class User {
    private UUID id;
    private String userCode;
    private String username;
    private String email;
    private String phone;
    private String firstName;
    private String lastName;
    private String statusCode;
    private String avatarUrl;
    @JsonIgnore
    private String password;

    private List<Role> roles;
    private List<Branch> branches;

    public User(UUID id, String userCode, String username, String email, String phone, String firstName, String lastName, String statusCode, String avatarUrl, String password) {
        this.id = id;
        this.userCode = userCode;
        this.username = username;
        this.email = email;
        this.phone = phone;
        this.firstName = firstName;
        this.lastName = lastName;
        this.statusCode = statusCode;
        this.avatarUrl = avatarUrl;
        this.password = password;
    }
}
