package com.tms.user.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.UUID;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Role {
    private UUID id;
    private UUID organizationId;
    private String roleCode;
    private String roleName;
    private String description;
    private LocalDate activeFrom;
    private LocalDate activeTo;
}
