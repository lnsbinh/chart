package com.tms.user.model;

import java.time.LocalDate;
import java.util.UUID;

public record RoleDto(
        UUID id,
        String roleCode,
        String roleName,
        String description,
        LocalDate activeFrom,
        LocalDate activeTo
) {
}
