package com.tms.user.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Branch {
    private UUID id;
    private UUID organizationId;
    private String code;
    private String name;
    private String address;
    private String statusCode;
}
