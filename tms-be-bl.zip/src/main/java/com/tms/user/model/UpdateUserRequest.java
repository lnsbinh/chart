package com.tms.user.model;

import jakarta.validation.constraints.*;
import lombok.Data;

import java.util.List;
import java.util.UUID;

@Data
public class UpdateUserRequest {

    @NotBlank(message = "First name is required")
    private String firstName;

    @NotBlank(message = "Last name is required")
    private String lastName;

    @NotBlank(message = "Email is required")
    @Email(message = "Invalid email format")
    private String email;

    @NotEmpty(message = "At least one role is required")
    private List<UUID> roleIds;

    @NotEmpty(message = "At least one branch is required")
    private List<UUID>  branchIds;

//    @NotBlank(message = "Status is required")
//    @Pattern(regexp = "^(ACTIVE|LOCKED)$", message = "Status must be ACTIVE or LOCKED")
//    private String status;
}
