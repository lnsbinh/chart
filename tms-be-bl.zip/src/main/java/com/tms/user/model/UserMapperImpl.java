package com.tms.user.model;

import com.tms.user.model.BranchDto;
import com.tms.user.model.RoleDto;
import com.tms.user.model.UserDto;
import com.tms.user.model.Branch;
import com.tms.user.model.Role;
import com.tms.user.model.User;
import com.tms.user.repo.BranchEntity;
import com.tms.user.repo.RoleEntity;
import com.tms.user.repo.UserEntity;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Set;

@Component
public class UserMapperImpl implements UserMapper{
    @Override
    public User toDomain(UserEntity entity) {
        return User.builder()
                .id(entity.getId())
                .userCode(entity.getUserCode())
                .username(entity.getUsername())
                .email(entity.getEmail())
                .phone(entity.getPhone())
                .firstName(entity.getFirstName())
                .lastName(entity.getLastName())
                .statusCode(entity.getStatusCode())
                .avatarUrl(entity.getAvatarUrl())
                .roles(mapRoles(entity.getRoles()))
                .branches(mapBranches(entity.getBranches()))
                .build();
    }

    @Override
    public List<Role> mapRoles(Set<RoleEntity> roles) {
        return roles.stream()
                .map(r -> new Role(r.getId(), r.getOrganizationId(), r.getRoleCode(), r.getRoleName(), r.getDescription(), r.getActiveFrom(), r.getActiveTo()))
                .toList();
    }

    @Override
    public List<Branch> mapBranches(Set<BranchEntity> branches) {
        return branches.stream()
                .map(b -> new Branch(b.getId(), b.getOrganizationId(), b.getCode(), b.getName(), b.getAddress(), b.getStatusCode()))
                .toList();
    }

    @Override
    public UserDto toDto(User user) {
        return new UserDto(
                user.getId(),
                user.getUserCode(),
                user.getUsername(),
                user.getEmail(),
                user.getPhone(),
                user.getFirstName(),
                user.getLastName(),
                user.getStatusCode(),
                user.getAvatarUrl(),
                mapRoleDtos(user.getRoles()),
                mapBranchDtos(user.getBranches())
        );
    }

    @Override
    public List<RoleDto> mapRoleDtos(List<Role> roles) {
        return roles.stream()
                .map(r -> new RoleDto(r.getId(), r.getRoleCode(), r.getRoleName(), r.getDescription(), r.getActiveFrom(), r.getActiveTo()))
                .toList();
    }

    @Override
    public List<BranchDto> mapBranchDtos(List<Branch> branches) {
        return branches.stream()
                .map(b -> new BranchDto(b.getId(), b.getCode(), b.getName(), b.getAddress(), b.getStatusCode()))
                .toList();
    }
}
