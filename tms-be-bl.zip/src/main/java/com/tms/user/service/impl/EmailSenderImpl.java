package com.tms.user.service.impl;

import com.tms.user.service.EmailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailSenderImpl implements EmailSender {

    @Override
    public void sendEmail(String to, String subject, String body) {
        // TODO: Implement email sending
        System.out.println("Sending email to: " + to + " subject: " + subject + " body: " + body);
    }

    @Override
    public void sendResetPasswordEmail(String to, String newPassword) {
        // TODO: Implement reset password email
        sendEmail(to, "Password Reset", "Your new password is: " + newPassword);
    }
}