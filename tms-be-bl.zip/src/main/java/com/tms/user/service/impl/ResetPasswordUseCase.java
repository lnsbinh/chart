package com.tms.user.service.impl;

import com.tms.common.exception.BusinessException;
import com.tms.common.exception.ErrorCode;
import com.tms.user.service.EmailSender;
import com.tms.user.service.AuthUtils;
import com.tms.user.model.User;
import com.tms.user.repo.UserQueryRepository;
import com.tms.user.service.PasswordGenerator;
import com.tms.user.repo.UserEntity;
import com.tms.user.repo.UserJpaRepository;
import com.tms.auth.repo.service.KeycloakService;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Slf4j
@Service
public class ResetPasswordUseCase {
    private final UserQueryRepository userQueryRepository;
    private final PasswordGenerator passwordGenerator;
    private final KeycloakService keycloakService;
    private final UserJpaRepository userJpaRepository;
    private final EmailSender emailSender;

    public ResetPasswordUseCase(
            UserQueryRepository userQueryRepository,
            PasswordGenerator passwordGenerator,
            KeycloakService keycloakService,
            UserJpaRepository userJpaRepository,
            EmailSender emailSender
    ) {
        this.userQueryRepository = userQueryRepository;
        this.passwordGenerator = passwordGenerator;
        this.keycloakService = keycloakService;
        this.userJpaRepository = userJpaRepository;
        this.emailSender = emailSender;
    }

    @Transactional
    public void execute(UUID userID){

        // get current user
        String currentUser = AuthUtils.getCurrentUsername();
        String emailOfCurrentUser = AuthUtils.getEmailOfCurrentUser();
        log.info("current user: {}", currentUser);
        log.info("email of current user: {}", emailOfCurrentUser);

        // check valid user
        User user = userQueryRepository.findUserById(userID);
        if (user == null) {
            throw new BusinessException(ErrorCode.USER_NOT_FOUND);
        }

        // check user status
        if(user.getStatusCode().equalsIgnoreCase("LOCKED")){
            throw new BusinessException(ErrorCode.USER_ALREAD_LOCKED);
        }

        // rule: can not reset password of current user
        if(user.getUsername().equals(currentUser) || user.getEmail().equals(emailOfCurrentUser)){
            throw new BusinessException(ErrorCode.CAN_NOT_RESET_OWN_PASSWORD);
        }

        // generate new password
        String newPassword = passwordGenerator.generate(10);

        // update password on keycloak
        UserEntity userEntity = userJpaRepository.findById(userID).orElseThrow(() -> new BusinessException(ErrorCode.USER_NOT_FOUND));
        keycloakService.resetPassword(userEntity.getKeycloakUserId().toString(), newPassword);

        // logout session
        keycloakService.logoutUser(userEntity.getKeycloakUserId().toString());

        // send email
        emailSender.sendResetPasswordEmail(
                user.getEmail(),
                newPassword
        );

    }
}
