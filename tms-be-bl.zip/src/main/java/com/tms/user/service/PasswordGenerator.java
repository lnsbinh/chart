package com.tms.user.service;

public interface PasswordGenerator {
    String generatePassword();
    String generate(int length);
}