package com.tms.user.service;

public interface UserCodeGeneratorPort {
    String generateUserCode();
}