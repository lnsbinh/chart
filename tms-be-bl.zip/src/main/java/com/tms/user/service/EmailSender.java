package com.tms.user.service;

public interface EmailSender {
    void sendEmail(String to, String subject, String body);
    void sendResetPasswordEmail(String to, String newPassword);
}