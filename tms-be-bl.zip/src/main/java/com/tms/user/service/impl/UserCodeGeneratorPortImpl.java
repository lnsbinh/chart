package com.tms.user.service.impl;

import com.tms.user.service.UserCodeGeneratorPort;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class UserCodeGeneratorPortImpl implements UserCodeGeneratorPort {

    @Override
    public String generateUserCode() {
        // Simple implementation: generate a random code
        return "USR" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }
}