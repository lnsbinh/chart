package com.tms.user.service.impl;

import com.tms.common.exception.BusinessException;
import com.tms.common.exception.ErrorCode;
import com.tms.common.response.PageResult;
import com.tms.user.model.UserDto;
import com.tms.user.model.GetUsersQuery;
import com.tms.user.model.User;
import com.tms.user.repo.UserQueryRepository;
import com.tms.user.model.UserMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class GetUsersUseCase {
    private final UserQueryRepository userQueryRepository;
    private final UserMapper userMapper;

    public GetUsersUseCase(
            UserQueryRepository userQueryRepository,
            UserMapper userMapper
    ) {
        this.userQueryRepository = userQueryRepository;
        this.userMapper = userMapper;
    }

    public PageResult<UserDto> execute(GetUsersQuery query) {

        if(query.page() < 0 || query.size() <= 0){
            throw new BusinessException(ErrorCode.INVALID_REQUEST);
        }

        List<UUID> validRoleIds = (query.roleIds() != null && query.roleIds().isEmpty()) ? null : query.roleIds();
        List<UUID> validBranchIds = (query.branchIds() != null && query.branchIds().isEmpty()) ? null : query.branchIds();

        PageResult<User> pageResult = userQueryRepository.findAllUserWithRolesAndBranches(
                query.page(),
                query.size(),
                query.status(),
                validRoleIds,
                validBranchIds,
                query.idSort(),
                query.statusSort(),
                query.search()
        );

        List<UserDto> userDtos = pageResult.getContent().stream()
                .map(userMapper::toDto)
                .toList();

        return PageResult.<UserDto>builder()
                .content(userDtos)
                .page(pageResult.getPage())
                .size(pageResult.getSize())
                .totalElements(pageResult.getTotalElements())
                .totalPages(pageResult.getTotalPages())
                .build();
    }

}
