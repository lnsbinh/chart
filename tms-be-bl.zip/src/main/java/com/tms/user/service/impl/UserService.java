package com.tms.user.service.impl;

import com.tms.common.exception.BusinessException;
import com.tms.common.exception.ErrorCode;
import com.tms.user.model.CreateUserRequest;
import com.tms.user.model.UpdateUserRequest;
import com.tms.user.service.UserCodeGeneratorPort;
import com.tms.user.model.User;
import com.tms.user.repo.BranchEntity;
import com.tms.user.repo.BranchRepository;
import com.tms.user.repo.RoleEntity;
import com.tms.user.repo.RoleRepository;
import com.tms.user.repo.UserEntity;
import com.tms.user.repo.UserJpaRepository;
import com.tms.auth.repo.service.KeycloakService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserService {

    private final UserJpaRepository userJpaRepository;
    private final RoleRepository roleRepository;
    private final BranchRepository branchRepository;
    private final KeycloakService keycloakService;
    private final PasswordEncoder passwordEncoder;
    private final JdbcTemplate jdbcTemplate;
    private final UserCodeGeneratorPort userCodeGeneratorPort;

    @Transactional
    public String createUser(CreateUserRequest request) {
        // Check uniqueness
        if (userJpaRepository.existsByUsername(request.getUsername())) {
            throw new BusinessException(ErrorCode.USERNAME_ALREADY_EXISTS);
        }
        if (userJpaRepository.existsByEmail(request.getEmail())) {
            throw new BusinessException(ErrorCode.EMAIL_ALREADY_EXISTS);
        }
//        if (userJpaRepository.existsByUserCode(request.getUserCode())) {
//            throw new BusinessException(ErrorCode.USER_CODE_ALREADY_EXISTS);
//        }

        // check duplicate username/email in Keycloak before creating user in Keycloak to avoid unnecessary calls
        if (keycloakService.userExistsByUsername(request.getUsername())) {
            throw new BusinessException(ErrorCode.USERNAME_EXISTS_IN_KEYCLOAK);
        }

        if (keycloakService.userExistsByEmail(request.getEmail())) {
            throw new BusinessException(ErrorCode.EMAIL_EXISTS_IN_KEYCLOAK);
        }

        // Fetch roles
        List<RoleEntity> roles = roleRepository.findAllById(request.getRoleIds()).stream().toList();
        roles.forEach(
                r -> log.info("Role: {}", r.getRoleCode())
        );
        if (roles.size() != request.getRoleIds().size()) {
            throw new BusinessException(ErrorCode.ROLES_NOT_FOUND);
        }

        // Fetch branches
        List<BranchEntity> branches = branchRepository.findByIdIn(request.getBranchIds());
        if (branches.size() != request.getBranchIds().size()) {
            throw new BusinessException(ErrorCode.BRANCHES_NOT_FOUND);
        }

        // Create user in Keycloak
        String keycloakUserId = null;
        try {
            keycloakUserId = keycloakService.createUser(request.getUsername(), request.getEmail(), request.getFirstName(), request.getLastName());
            keycloakService.setPassword(keycloakUserId, request.getPassword());
            List<String> roleNames = roles.stream().map(RoleEntity::getRoleCode).toList();
            keycloakService.assignRealmRoles(keycloakUserId, roleNames);
        } catch (Exception e) {
            log.error("Failed to create user in Keycloak", e);
            throw new RuntimeException("Failed to create user");
        }

        // Save in DB
        try {
            UserEntity user = new UserEntity();
            user.setKeycloakUserId(UUID.fromString(keycloakUserId));
            user.setOrganizationId(UUID.randomUUID()); // TODO: get from context
            user.setUserCode(userCodeGeneratorPort.generateUserCode());
            user.setUsername(request.getUsername());
            user.setPassword(passwordEncoder.encode(request.getPassword()));
            user.setFirstName(request.getFirstName());
            user.setLastName(request.getLastName());
            user.setEmail(request.getEmail());
            user.setStatusCode(request.getStatus());
//            user.setAvatarUrl(request.getAvatarUrl());
            user.setDefaultBranchId(request.getBranchIds().get(0)); // first branch as default
            user.setCreatedAt(LocalDateTime.now());
            user.setUpdatedAt(LocalDateTime.now());

            UserEntity savedUser =  userJpaRepository.saveAndFlush(user);
            log.debug("User saved in DB with ID: {}", user.getId());

            // Save user roles
            for (RoleEntity role : roles) {
                jdbcTemplate.update(
                    "INSERT INTO identity_access.user_roles (organization_id, user_id, role_id, assigned_at) VALUES (?, ?, ?, ?)",
                    user.getOrganizationId(), user.getId(), role.getId(), LocalDateTime.now()
                );
            }

            // Save user branches
            for (BranchEntity branch : branches) {
                jdbcTemplate.update(
                    "INSERT INTO identity_access.user_data_scopes (organization_id, user_id, scope_type, scope_id, assigned_at) VALUES (?, ?, ?, ?, ?)",
                    user.getOrganizationId(), user.getId(), "BRANCH", branch.getId(), LocalDateTime.now()
                );
            }
            return savedUser.getId().toString();
        } catch (Exception e) {
            log.error("Failed to save user in DB, deleting from Keycloak", e);
            try {
                keycloakService.deleteUser(keycloakUserId);
            } catch (Exception ex) {
                log.error("Failed to delete user from Keycloak", ex);
            }
            throw new RuntimeException("Failed to create user");
        }
    }

    public List<UserEntity> getAllUsers() {
        return userJpaRepository.findAll();
    }

    public Optional<UserEntity> findByEmail(String email) {
        return userJpaRepository.findByEmail(email);
    }

    public List<RoleEntity> getAllRoles() {
        return roleRepository.findAll();
    }

    public Optional<RoleEntity> getRoleById(UUID roleId) {
        return roleRepository.findById(roleId);
    }

    public List<BranchEntity> getAllBranches() {
        return branchRepository.findAll();
    }

    public Optional<BranchEntity> getBranchById(UUID branchId) {
        return branchRepository.findById(branchId);
    }

    @Transactional
    public String toggleUserStatus(UUID userId, String newStatus) {
        // Get current user from context (assuming authentication is set up)
//        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
//
//        JwtAuthenticationToken jwtAuth = (JwtAuthenticationToken) auth;
//
//        Jwt jwt = jwtAuth.getToken();
//
//        String currentUsername = jwt.getClaim("preferred_username");
//
//        String currentUsername = jwt.getClaim("preferred_username");
//
//        Optional<UserEntity> currentUserOpt = userJpaRepository.findByUsername(currentUsername);
//
//        if (currentUserOpt.isEmpty()) {
//            throw new BadRequestException("Current user not found");
//        }

        // 1. Use userid to find user in database
        Optional<UserEntity> currentUserOpt = userJpaRepository.findById(userId);
        if (currentUserOpt.isEmpty()) {
            throw new BusinessException(ErrorCode.USER_NOT_FOUND);
        }

        UserEntity targetUser = currentUserOpt.get();

        // 2. Get Keycloak user ID from found user
        String keycloakUserId = targetUser.getKeycloakUserId().toString();

        // Rule: Admin cannot lock their own account
//        if (currentUserOpt.get().getId().equals(userId) && "LOCKED".equals(newStatus)) {
//            throw new BadRequestException("Cannot lock your own account");
//        }

        // Rule: If only 1 ADMIN exists and trying to lock the last admin
        if ("LOCKED".equals(newStatus) && isUserAdmin(targetUser)) {
            long activeAdminCount = countActiveAdmins();
            if (activeAdminCount <= 1) {
                throw new BusinessException(ErrorCode.CANNOT_LOCK_LAST_ADMIN);
            }
        }

        String oldStatus = targetUser.getStatusCode();
        targetUser.setStatusCode(newStatus);
        targetUser.setUpdatedAt(LocalDateTime.now());
        userJpaRepository.save(targetUser);

        // 3. Lock/unlock in Keycloak using the Keycloak user ID
        if ("LOCKED".equals(newStatus)) {
            terminateUserSessions(keycloakUserId);
            return "User has been locked";
        } else {
            keycloakService.enableUser(keycloakUserId);
        }

        return "User has been unlocked";
    }

    private boolean isUserAdmin(UserEntity user) {
        // Check if user has ADMIN role
        if (user.getRoles() == null) {
            return false;
        }
        return user.getRoles().stream()
                .anyMatch(role -> "ADMIN".equalsIgnoreCase(role.getRoleCode()));
    }

    private long countActiveAdmins() {
        List<UserEntity> allUsers = userJpaRepository.findAll();
        return allUsers.stream()
                .filter(user -> "ACTIVE".equals(user.getStatusCode()) && isUserAdmin(user))
                .count();
    }

    private void terminateUserSessions(String keycloakUserId) {
        // Terminate all active sessions for the user
        // This can be implemented using:
        // 1. JWT blacklist: Add token to Redis/database
        // 2. Session invalidation: Remove from session store
        // 3. Keycloak logout: Call Keycloak admin API to logout user
        try {
            // 1. Disable user in Keycloak
            keycloakService.disableUser(keycloakUserId);
            // 2. Call Keycloak API to logout user to kill active session
            keycloakService.logoutUser(keycloakUserId);
            log.info("Terminating sessions for user with keycloakUserId: {}", keycloakUserId);
        } catch (Exception e) {
            log.warn("Failed to terminate sessions for user with keycloakUserId: {}", keycloakUserId, e);
        }
    }

    @Transactional
    public String updateUser(UUID userId, UpdateUserRequest request) {
        // Get the user to update
        Optional<UserEntity> userOpt = userJpaRepository.findById(userId);
        if (userOpt.isEmpty()) {
            throw new BusinessException(ErrorCode.USER_NOT_FOUND);
        }

        UserEntity user = userOpt.get();

        // Validate email uniqueness if email changed
        if (!user.getEmail().equals(request.getEmail()) && 
            userJpaRepository.existsByEmail(request.getEmail())) {
            throw new BusinessException(ErrorCode.EMAIL_ALREADY_EXISTS);
        }

        // Fetch new roles
        List<RoleEntity> newRoles = roleRepository.findAllById(request.getRoleIds()).stream().toList();
        if (newRoles.size() != request.getRoleIds().size()) {
            throw new BusinessException(ErrorCode.ROLES_NOT_FOUND);
        }

        // Fetch new branches
        List<BranchEntity> newBranches = branchRepository.findByIdIn(request.getBranchIds());
        if (newBranches.size() != request.getBranchIds().size()) {
            throw new BusinessException(ErrorCode.BRANCHES_NOT_FOUND);
        }

        // Rule: If only ONE ADMIN exists → cannot remove ADMIN role
        boolean currentUserHasAdminRole = isUserAdmin(user);
        boolean newRolesHaveAdmin = newRoles.stream()
                .anyMatch(role -> "ADMIN".equalsIgnoreCase(role.getRoleCode()));

        if (currentUserHasAdminRole && !newRolesHaveAdmin) {
            long activeAdminCount = countActiveAdmins();
            if (activeAdminCount <= 1) {
                throw new BusinessException(ErrorCode.CANNOT_REMOVE_ADMIN_ROLE);
            }
        }

        // Update user info
        user.setFirstName(request.getFirstName());
        user.setLastName(request.getLastName());
        user.setEmail(request.getEmail());
//        user.setStatusCode(request.getStatus());
        user.setUpdatedAt(LocalDateTime.now());

        // Delete old roles and branches
        jdbcTemplate.update("DELETE FROM identity_access.user_roles WHERE user_id = ?", user.getId());
        jdbcTemplate.update("DELETE FROM identity_access.user_data_scopes WHERE user_id = ? AND scope_type = 'BRANCH'", user.getId());

        // Save updated user
        userJpaRepository.save(user);

        // Save new roles
        for (RoleEntity role : newRoles) {
            jdbcTemplate.update(
                "INSERT INTO identity_access.user_roles (organization_id, user_id, role_id, assigned_at) VALUES (?, ?, ?, ?)",
                user.getOrganizationId(), user.getId(), role.getId(), LocalDateTime.now()
            );
        }

        // Save new branches
        for (BranchEntity branch : newBranches) {
            jdbcTemplate.update(
                "INSERT INTO identity_access.user_data_scopes (organization_id, user_id, scope_type, scope_id, assigned_at) VALUES (?, ?, ?, ?, ?)",
                user.getOrganizationId(), user.getId(), "BRANCH", branch.getId(), LocalDateTime.now()
            );
        }

        return "User updated successfully";
    }

    @Transactional
    public void deleteUser(UUID userId) {
        UserEntity user = userJpaRepository.findById(userId)
                .orElseThrow(() -> new BusinessException(ErrorCode.USER_NOT_FOUND));

        user.setDeleted(true);

        // Soft delete: set isDeleted flag to true and status to DELETED
        userJpaRepository.save(user);

        keycloakService.disableUser(user.getKeycloakUserId().toString());
        keycloakService.logoutUser(user.getKeycloakUserId().toString());
    }
}
