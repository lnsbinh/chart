package com.tms.user.controller;

import com.tms.common.response.ApiResponse;
import com.tms.common.response.PageResult;
import com.tms.user.model.CreateUserRequest;
import com.tms.user.model.LockUserRequest;
import com.tms.user.model.UpdateUserRequest;
import com.tms.user.model.UserDto;
import com.tms.user.model.GetUsersQuery;
import com.tms.user.service.impl.UserService;
import com.tms.user.service.impl.GetUsersUseCase;
import com.tms.user.service.impl.ResetPasswordUseCase;
import com.tms.user.model.User;
import com.tms.user.model.UserMapper;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

@Slf4j
@RestController
@RequestMapping("/api/v1/users")
public class UserController {

    private final UserService userService;
    private final GetUsersUseCase getUsersUseCase;
    private final ResetPasswordUseCase resetPasswordUseCase;
    private final UserMapper userMapper;

    public UserController(
            UserService userService,
            GetUsersUseCase getUsersUseCase,
            ResetPasswordUseCase resetPasswordUseCase,
            UserMapper userMapper
    ) {
        this.userService = userService;
        this.getUsersUseCase = getUsersUseCase;
        this.resetPasswordUseCase = resetPasswordUseCase;
        this.userMapper = userMapper;
    }

//    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
//    @GetMapping
//    public ResponseEntity<List<User>> getAllUsers() {
//        List<User> users = userService.getAllUsers();
//        return ResponseEntity.ok(users);
//    }

    @PostMapping
//    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<?>> createUser(@Valid @RequestBody CreateUserRequest request) {
        String userId = userService.createUser(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(Map.of("userId", userId)));
    }

    @PatchMapping("/{userId}/status")
//    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<?>> toggleUserStatus(
            @PathVariable(name = "userId") UUID userId,
            @Valid @RequestBody LockUserRequest request) {
        String message = userService.toggleUserStatus(userId, request.getStatus());
        return ResponseEntity.ok(ApiResponse.success(message));
    }

    @PutMapping("/{userId}")
//    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<?>> updateUser(
            @PathVariable(name = "userId") UUID userId,
            @Valid @RequestBody UpdateUserRequest request) {
        String message = userService.updateUser(userId, request);
        return ResponseEntity.ok(ApiResponse.success(message));
    }

//    @PreAuthorize("hasAnyAuthority('ROLE_ADMIN', 'ROLE_SUPERVISOR')")
    @GetMapping("/{email:.+}")
    public ResponseEntity<Object> getUserByEmail(@PathVariable String email) {
        Optional<Object> user = userService.findByEmail(email).map(u -> (Object) u);
        return user.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

//    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @GetMapping
    public ResponseEntity<ApiResponse<?>> getAllUsersWithPagination(
            @RequestParam(name = "page", defaultValue = "0", required = false) int page,
            @RequestParam(name = "size", defaultValue = "10", required = false) int size,
            @RequestParam(name = "status", required = false) List<String> status,
            @RequestParam(name = "roleIds", required = false) List<UUID> roleIds,
            @RequestParam(name = "branchIds", required = false) List<UUID> branchIds,
            @RequestParam(name = "idSort",  required = false) String idSort,
            @RequestParam(name = "statusSort", required = false) String statusSort,
            @RequestParam(name = "search", required = false) String search
    ){
        GetUsersQuery getUsersQuery = new GetUsersQuery(page, size, status, roleIds, branchIds, idSort, statusSort, search);

        PageResult<UserDto> pageResult = getUsersUseCase.execute(getUsersQuery);

        return ResponseEntity.ok(
                ApiResponse.success(
                        pageResult
                )
        );
    }

    @GetMapping("/roles")
    public ResponseEntity<ApiResponse<?>> getAllRoles() {
        return ResponseEntity.ok(ApiResponse.success(userService.getAllRoles()));
    }

    @GetMapping("/roles/{roleId}")
    public ResponseEntity<?> getRoleById(@PathVariable UUID roleId) {
        return userService.getRoleById(roleId)
                .map(role -> ResponseEntity.ok(ApiResponse.success(role)))
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
    @GetMapping("/branches")
    public ResponseEntity<ApiResponse<?>> getAllBranches() {
        return ResponseEntity.ok(ApiResponse.success(userService.getAllBranches()));
    }

    @GetMapping("/branches/{branchId}")
    public ResponseEntity<?> getBranchById(@PathVariable UUID branchId) {
        return userService.getBranchById(branchId)
                .map(branch -> ResponseEntity.ok(ApiResponse.success(branch)))
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping("/{userId}/reset-password")
    public ResponseEntity<ApiResponse<?>> resetPassword(@PathVariable(name = "userId") UUID userId) {
        resetPasswordUseCase.execute(userId);
        return ResponseEntity.ok(ApiResponse.success("Password reset successfully"));
    }

    @PatchMapping("/{userId}/delete")
    public ResponseEntity<ApiResponse<?>> softDeleteUser(
            @PathVariable(name = "userId") UUID userId
    ){
        userService.deleteUser(userId);

        return ResponseEntity.ok(ApiResponse.success("User deleted successfully"));
    }
}
