package com.tms.user.controller;

import com.tms.common.response.ApiResponse;
import com.tms.user.service.impl.UserService;
import com.tms.user.service.impl.UploadAvatarUseCase;

import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/users")
public class FileUploadController {
    private final UploadAvatarUseCase uploadAvatarUseCase;

    private final UserService userService;

    public FileUploadController(UploadAvatarUseCase uploadAvatarUseCase, UserService userService) {
        this.uploadAvatarUseCase = uploadAvatarUseCase;
        this.userService = userService;
    }

    @PostMapping("/{userId}/avatar")
    public ResponseEntity<?> uploadAvatar(@PathVariable(name = "userId") UUID userId, @RequestParam("file") MultipartFile file) throws IOException {
        try {
            byte[] fileContent = file.getBytes();

            String filename = file.getOriginalFilename();
            String fileUrl = uploadAvatarUseCase.execute(userId, filename, fileContent);

            return ResponseEntity.ok(ApiResponse.success(Map.of("avatarUrl", fileUrl)));
        } catch (Exception ex){
            return ResponseEntity.badRequest().body(ApiResponse.error(ex.getMessage()));
        }
    }
}
