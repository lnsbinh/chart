package com.tms.auth.service.impl.service;

import com.tms.auth.service.impl.dto.LoginRequest;
import com.tms.auth.service.impl.dto.LoginResponse;
import com.tms.user.service.impl.UserService;
import com.tms.user.repo.UserEntity;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthService {

    private final UserService userService;

    public AuthService(UserService userService) {
        this.userService = userService;
    }

    public Optional<LoginResponse> login(LoginRequest request) {
        Optional<UserEntity> user = userService.findByEmail(request.email());

        if (user.isPresent()) {
            // Keycloak is the source of truth for authentication
            // Just verify the user exists, actual authentication is handled by Keycloak
            return Optional.of(new LoginResponse("dummy-token", "Login successful"));
        }

        return Optional.empty();
    }
}
