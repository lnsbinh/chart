package com.tms.auth.service.impl.dto;

public record LoginResponse(String token, String message) {
}
