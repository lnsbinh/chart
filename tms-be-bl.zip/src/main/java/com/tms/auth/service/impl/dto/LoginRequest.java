package com.tms.auth.service.impl.dto;

public record LoginRequest(String email, String password) {
}
