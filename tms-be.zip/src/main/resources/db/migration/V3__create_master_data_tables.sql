CREATE schema IF NOT EXISTS "master_data";

CREATE TABLE master_data.customers
(
    customer_id                uuid            DEFAULT gen_random_uuid() NOT NULL,
    customer_name              varchar(100)    NOT NULL,
    contact_person             varchar(50)     NOT NULL,
    customer_contact_phone     varchar(20)     NOT NULL,
    customer_email             varchar(100),
    address                    varchar(200)    NOT NULL,
    pickup_address             varchar(200)    NOT NULL,
    payment_term               varchar(30)     NOT NULL,
    credit_limit               numeric(18,2),
    is_deleted boolean DEFAULT false NOT NULL,

    created_at                 timestamptz     DEFAULT now() NOT NULL,
    updated_at                 timestamptz     DEFAULT now() NOT NULL,

    CONSTRAINT customers_pkey PRIMARY KEY (customer_id),
    CONSTRAINT uq_customers_phone UNIQUE (customer_contact_phone),
    CONSTRAINT uq_customers_email UNIQUE (customer_email),
    CONSTRAINT chk_customers_credit_limit_non_negative CHECK (credit_limit IS NULL OR credit_limit >= 0)
);

COMMENT ON TABLE master_data.customers IS 'Master data khách hàng B2B phục vụ quản lý đối tác khách hàng.';

COMMENT ON COLUMN master_data.customers.customer_id IS 'Mã khách hàng, định danh duy nhất của khách hàng.';
COMMENT ON COLUMN master_data.customers.customer_name IS 'Tên công ty hoặc đối tác B2B.';
COMMENT ON COLUMN master_data.customers.contact_person IS 'Người liên hệ chính phía khách hàng.';
COMMENT ON COLUMN master_data.customers.customer_contact_phone IS 'Số điện thoại liên hệ chính của khách hàng.';
COMMENT ON COLUMN master_data.customers.customer_email IS 'Email chính thức của khách hàng.';
COMMENT ON COLUMN master_data.customers.address IS 'Địa chỉ công ty hoặc địa chỉ giao dịch chính của khách hàng.';
COMMENT ON COLUMN master_data.customers.pickup_address IS 'Địa chỉ lấy hàng mặc định hoặc địa chỉ có thể đến lấy hàng.';
COMMENT ON COLUMN master_data.customers.payment_term IS 'Điều khoản thanh toán, ví dụ COD, 30DAYS, PREPAID.';
COMMENT ON COLUMN master_data.customers.credit_limit IS 'Hạn mức tín dụng của khách hàng, đơn vị VND.';
COMMENT ON COLUMN master_data.customers.created_at IS 'Thời điểm tạo bản ghi khách hàng.';
COMMENT ON COLUMN master_data.customers.updated_at IS 'Thời điểm cập nhật bản ghi khách hàng gần nhất.';
COMMENT ON COLUMN master_data.customers.is_deleted IS 'Đánh dấu xóa mềm khách hàng.';

------------------------------------------------------------------------------------------------------------------------

-- Cập nhật bảng locations theo yêu cầu
CREATE TABLE master_data.locations (
   id               uuid            DEFAULT gen_random_uuid() NOT NULL,                -- Mã địa điểm, kiểu UUID
   location_type    varchar(40)     NOT NULL,                                              -- Loại địa điểm (Cảng, Kho, Depot)
   location_name    varchar(255)    NOT NULL,                                              -- Tên địa điểm
   address          text,                                                          -- Địa chỉ công ty
   latitude         numeric(10,7),                                                    -- Vĩ độ GPS
   longitude        numeric(10,7),                                                    -- Kinh độ GPS
   status_code      varchar(30)     DEFAULT 'ACTIVE'::character varying NOT NULL,      -- Trạng thái địa điểm (ACTIVE/INACTIVE)
   gate_height      numeric(5,2),                                                     -- Cao cổng (m)
   allowed_vehicle  varchar(100),                                                     -- Loại xe cho phép (Xe container)
   capacity_cont    integer,                                                         -- Dung lượng container
   contact_phone    varchar(50),                                                      -- Số điện thoại liên hệ
   remark           text,                                                          -- Ghi chú về địa điểm
   province         varchar(100),                                                     -- Tỉnh/TP
   district         varchar(100),                                                     -- Quận/Huyện
   time_window_from time,                                                           -- Giờ mở cửa
   time_window_to   time,                                                           -- Giờ đóng cửa
   active_flag      boolean        DEFAULT true NOT NULL,                              -- Trạng thái hoạt động
   created_at       timestamptz     DEFAULT now() NOT NULL,                            -- Thời gian tạo
   updated_at       timestamptz     DEFAULT now() NOT NULL,                            -- Thời gian cập nhật
   CONSTRAINT locations_pkey PRIMARY KEY (id),                                         -- Primary key cho bảng locations
   CONSTRAINT location_status_check CHECK (status_code IN ('ACTIVE', 'INACTIVE'))      -- Trạng thái hợp lệ
);

-- Tạo chỉ mục cho các trường cần thiết
CREATE INDEX IF NOT EXISTS ix_locations_type ON master_data.locations USING btree (location_type);
CREATE INDEX IF NOT EXISTS ix_locations_status ON master_data.locations USING btree (status_code);

-- COMMENT cho bảng locations
COMMENT ON TABLE master_data.locations IS 'Pickup, delivery, port, CY, depot, warehouse, or other operational point.';

-- COMMENT cho từng cột
COMMENT ON COLUMN master_data.locations.location_type IS 'Loại địa điểm (Cảng, Kho, Depot)';
COMMENT ON COLUMN master_data.locations.location_name IS 'Tên địa điểm (tên đơn vị hoặc kho)';
COMMENT ON COLUMN master_data.locations.address IS 'Địa chỉ đầy đủ của địa điểm';
COMMENT ON COLUMN master_data.locations.latitude IS 'Vĩ độ GPS của địa điểm';
COMMENT ON COLUMN master_data.locations.longitude IS 'Kinh độ GPS của địa điểm';
COMMENT ON COLUMN master_data.locations.status_code IS 'Trạng thái hoạt động của địa điểm (ACTIVE/INACTIVE)';
COMMENT ON COLUMN master_data.locations.gate_height IS 'Chiều cao cổng (m)';
COMMENT ON COLUMN master_data.locations.allowed_vehicle IS 'Loại xe được phép vào (ví dụ: xe container)';
COMMENT ON COLUMN master_data.locations.capacity_cont IS 'Dung lượng container (số lượng container có thể chứa)';
COMMENT ON COLUMN master_data.locations.contact_phone IS 'Số điện thoại liên hệ tại địa điểm';
COMMENT ON COLUMN master_data.locations.remark IS 'Ghi chú về địa điểm (chú thích thêm)';
COMMENT ON COLUMN master_data.locations.province IS 'Tỉnh hoặc thành phố của địa điểm';
COMMENT ON COLUMN master_data.locations.district IS 'Quận hoặc huyện của địa điểm';
COMMENT ON COLUMN master_data.locations.time_window_from IS 'Giờ mở cửa của địa điểm';
COMMENT ON COLUMN master_data.locations.time_window_to IS 'Giờ đóng cửa của địa điểm';
COMMENT ON COLUMN master_data.locations.active_flag IS 'Trạng thái hoạt động của địa điểm';
COMMENT ON COLUMN master_data.locations.created_at IS 'Thời gian tạo địa điểm';
COMMENT ON COLUMN master_data.locations.updated_at IS 'Thời gian cập nhật địa điểm';

------------------------------------------------------------------------------------------------------------------------
CREATE TABLE master_data.vehicles
(
    vehicle_id          uuid            DEFAULT gen_random_uuid() NOT NULL,
    license_plate       varchar(15)     NOT NULL,
    vehicle_name        varchar(50)     NOT NULL,
    vehicle_type        varchar(50)     NOT NULL,
    brand_model         varchar(30),
    production_year     integer         NOT NULL,
    capacity_kg         numeric(18,2)   NOT NULL,
    volume_m3           numeric(18,2)   NOT NULL,
    fuel_type           varchar(30)     NOT NULL,
    fuel_norm           numeric(10,2)   NOT NULL,
    owner_branch        uuid            ,
    gps_device_code     varchar(20),
    registry_expiry     date            NOT NULL,
    insurance_expiry    date            NOT NULL,
    active_flag         boolean         DEFAULT true NOT NULL,
    is_deleted          boolean DEFAULT false NOT NULL,
    created_at          timestamptz     DEFAULT now() NOT NULL,
    updated_at          timestamptz     DEFAULT now() NOT NULL,

    CONSTRAINT vehicles_pkey PRIMARY KEY (vehicle_id),
    CONSTRAINT uq_vehicles_license_plate UNIQUE (license_plate),
    CONSTRAINT uq_vehicles_gps_device_code UNIQUE (gps_device_code),

    CONSTRAINT fk_vehicles_owner_branch
        FOREIGN KEY (owner_branch)
            REFERENCES iam.branches(id),

    CONSTRAINT chk_vehicles_capacity_kg_positive
        CHECK (capacity_kg > 0),

    CONSTRAINT chk_vehicles_volume_m3_non_negative
        CHECK (volume_m3 >= 0),

    CONSTRAINT chk_vehicles_fuel_norm_positive
        CHECK (fuel_norm > 0)
);

CREATE INDEX IF NOT EXISTS ix_vehicles_vehicle_name
    ON master_data.vehicles(vehicle_name);

CREATE INDEX IF NOT EXISTS ix_vehicles_vehicle_type
    ON master_data.vehicles(vehicle_type);

CREATE INDEX IF NOT EXISTS ix_vehicles_owner_branch
    ON master_data.vehicles(owner_branch);

CREATE INDEX IF NOT EXISTS ix_vehicles_active_flag
    ON master_data.vehicles(active_flag);

CREATE INDEX IF NOT EXISTS ix_vehicles_registry_expiry
    ON master_data.vehicles(registry_expiry);

CREATE INDEX IF NOT EXISTS ix_vehicles_insurance_expiry
    ON master_data.vehicles(insurance_expiry);

COMMENT ON TABLE master_data.vehicles IS 'Master data phương tiện phục vụ điều độ, bảo trì, tính chi phí và kiểm soát pháp lý.';

COMMENT ON COLUMN master_data.vehicles.vehicle_id IS 'Mã xe, định danh duy nhất cho từng xe trong hệ thống.';
COMMENT ON COLUMN master_data.vehicles.license_plate IS 'Biển số đăng ký của xe.';
COMMENT ON COLUMN master_data.vehicles.vehicle_name IS 'Tên xe để dễ nhớ và phục vụ điều độ.';
COMMENT ON COLUMN master_data.vehicles.vehicle_type IS 'Loại xe như Light Truck, Medium Truck, Heavy Truck, Container Truck, Reefer Truck, Tanker, Pickup Truck hoặc Camionnette.';
COMMENT ON COLUMN master_data.vehicles.brand_model IS 'Hãng sản xuất và model xe.';
COMMENT ON COLUMN master_data.vehicles.production_year IS 'Năm sản xuất của xe.';
COMMENT ON COLUMN master_data.vehicles.capacity_kg IS 'Tải trọng xe theo đơn vị kg.';
COMMENT ON COLUMN master_data.vehicles.volume_m3 IS 'Thể tích thùng xe theo đơn vị m3.';
COMMENT ON COLUMN master_data.vehicles.fuel_type IS 'Loại nhiên liệu sử dụng, ví dụ Diesel, Electric, RON95-V, RON95-III, E5 RON 92.';
COMMENT ON COLUMN master_data.vehicles.fuel_norm IS 'Định mức tiêu hao nhiên liệu dùng để tính chi phí, ví dụ lít trên 100km.';
COMMENT ON COLUMN master_data.vehicles.owner_branch IS 'Chi nhánh hoặc đội xe quản lý phương tiện, tham chiếu đến iam.branches.';
COMMENT ON COLUMN master_data.vehicles.gps_device_code IS 'Mã thiết bị GPS gắn trên xe.';
COMMENT ON COLUMN master_data.vehicles.registry_expiry IS 'Ngày hết hạn đăng kiểm xe.';
COMMENT ON COLUMN master_data.vehicles.insurance_expiry IS 'Ngày hết hạn bảo hiểm xe.';
COMMENT ON COLUMN master_data.vehicles.active_flag IS 'Trạng thái hoạt động của xe, TRUE là còn sử dụng, FALSE là ngừng sử dụng.';
COMMENT ON COLUMN master_data.vehicles.created_at IS 'Thời điểm tạo bản ghi.';
COMMENT ON COLUMN master_data.vehicles.updated_at IS 'Thời điểm cập nhật bản ghi gần nhất.';

----------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE master_data.drivers
(
    driver_id                  uuid            DEFAULT gen_random_uuid() NOT NULL,
    full_name           varchar(100)    NOT NULL,
    phone_number        varchar(20)  UNIQUE    NOT NULL,
    id_number           varchar(20)  UNIQUE   NOT NULL,
    license_class       varchar(10)     NOT NULL,
    license_number      varchar(40)  UNIQUE   NOT NULL,
    license_expiry      date            NOT NULL,
    employment_type     varchar(30),
    driver_group        varchar(50)     NOT NULL,
    familiar_routes     text,
    join_date           date,
    active_flag         boolean         DEFAULT true NOT NULL,
    is_deleted          boolean         DEFAULT false NOT NULL,
    app_username        varchar(50),
    created_at          timestamptz     DEFAULT now() NOT NULL,
    updated_at          timestamptz     DEFAULT now() NOT NULL,

    CONSTRAINT drivers_pkey PRIMARY KEY (driver_id),
    CONSTRAINT uq_driver_phone UNIQUE (phone_number),
    CONSTRAINT uq_driver_app_username UNIQUE (app_username)
);

COMMENT ON TABLE master_data.drivers IS 'Master data tài xế phục vụ phân công, chấm công và quản lý tuân thủ.';

COMMENT ON COLUMN master_data.drivers.driver_id IS 'Khóa chính nội bộ của bản ghi tài xế.';
COMMENT ON COLUMN master_data.drivers.full_name IS 'Họ và tên đầy đủ của tài xế.';
COMMENT ON COLUMN master_data.drivers.phone_number IS 'Số điện thoại chính của tài xế, duy nhất.';
COMMENT ON COLUMN master_data.drivers.id_number IS 'Số giấy tờ tùy thân của tài xế, ví dụ CMND hoặc CCCD.';
COMMENT ON COLUMN master_data.drivers.license_class IS 'Hạng bằng lái phù hợp với loại xe được phép điều khiển.';
COMMENT ON COLUMN master_data.drivers.license_number IS 'Số giấy phép lái xe.';
COMMENT ON COLUMN master_data.drivers.license_expiry IS 'Ngày hết hạn giấy phép lái xe.';
COMMENT ON COLUMN master_data.drivers.employment_type IS 'Hình thức làm việc, ví dụ full-time hoặc contract.';
COMMENT ON COLUMN master_data.drivers.driver_group IS 'Đội hoặc nhóm tài xế mà tài xế trực thuộc.';
COMMENT ON COLUMN master_data.drivers.familiar_routes IS 'Danh sách tuyến quen thuộc của tài xế, lưu tạm dạng text như CSV hoặc JSON.';
COMMENT ON COLUMN master_data.drivers.join_date IS 'Ngày tài xế bắt đầu làm việc.';
COMMENT ON COLUMN master_data.drivers.active_flag IS 'Trạng thái hoạt động của tài xế, TRUE là đang hoạt động, FALSE là ngừng hoạt động.';
COMMENT ON COLUMN master_data.drivers.app_username IS 'Tên đăng nhập ứng dụng tài xế, duy nhất nếu có sử dụng app.';
COMMENT ON COLUMN master_data.drivers.created_at IS 'Thời điểm tạo bản ghi.';
COMMENT ON COLUMN master_data.drivers.updated_at IS 'Thời điểm cập nhật bản ghi gần nhất.';

---------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE master_data.routes
(
    route_id                 uuid            DEFAULT gen_random_uuid() NOT NULL,
    route_name               varchar(50)     NOT NULL,
    origin_location_id       uuid            NOT NULL,
    destination_location_id  uuid            NOT NULL,
    distance_km              numeric(10,2)   NOT NULL,
    std_transit_time         varchar(10)     NOT NULL,
    toll_cost                numeric(18,2)   NOT NULL,
    route_risk_note          varchar(200),
    forbidden_hours          varchar(100),
    preferred_flag           boolean         DEFAULT false NOT NULL,
    active_flag              boolean         DEFAULT true NOT NULL,
    created_at               timestamptz     DEFAULT now() NOT NULL,
    updated_at               timestamptz     DEFAULT now() NOT NULL,

    CONSTRAINT routes_pkey PRIMARY KEY (route_id),
    CONSTRAINT uq_routes_route_name UNIQUE (route_name),
    CONSTRAINT fk_routes_origin_location
        FOREIGN KEY (origin_location_id)
            REFERENCES master_data.locations(id),
    CONSTRAINT fk_routes_destination_location
        FOREIGN KEY (destination_location_id)
            REFERENCES master_data.locations(id),
    CONSTRAINT chk_routes_distance_km_positive
        CHECK (distance_km > 0),
    CONSTRAINT chk_routes_toll_cost_non_negative
        CHECK (toll_cost >= 0)
);

CREATE INDEX IF NOT EXISTS ix_routes_origin_location_id
    ON master_data.routes(origin_location_id);

CREATE INDEX IF NOT EXISTS ix_routes_destination_location_id
    ON master_data.routes(destination_location_id);

CREATE INDEX IF NOT EXISTS ix_routes_active_flag
    ON master_data.routes(active_flag);

CREATE INDEX IF NOT EXISTS ix_routes_preferred_flag
    ON master_data.routes(preferred_flag);

COMMENT ON TABLE master_data.routes IS 'Master data lộ trình hoặc tuyến xe phục vụ lập kế hoạch tuyến, tính chi phí chuẩn và kiểm soát vận hành.';

COMMENT ON COLUMN master_data.routes.route_id IS 'Khóa chính của tuyến.';
COMMENT ON COLUMN master_data.routes.route_name IS 'Tên tuyến, mô tả dễ hiểu, duy nhất trong hệ thống.';
COMMENT ON COLUMN master_data.routes.origin_location_id IS 'Điểm đi, tham chiếu đến master_data.locations.';
COMMENT ON COLUMN master_data.routes.destination_location_id IS 'Điểm đến, tham chiếu đến master_data.locations.';
COMMENT ON COLUMN master_data.routes.distance_km IS 'Cự ly chuẩn của tuyến, đơn vị km, dùng để tính thời gian và chi phí.';
COMMENT ON COLUMN master_data.routes.std_transit_time IS 'Thời gian chạy chuẩn của tuyến, lưu theo format hh:mm như 4:00.';
COMMENT ON COLUMN master_data.routes.toll_cost IS 'Chi phí cầu đường hoặc BOT chuẩn cho một chuyến.';
COMMENT ON COLUMN master_data.routes.route_risk_note IS 'Ghi chú rủi ro của tuyến như kẹt xe, ngập nước, tai nạn, đường xấu.';
COMMENT ON COLUMN master_data.routes.forbidden_hours IS 'Khung giờ cấm tải hoặc hạn chế lưu thông trên tuyến.';
COMMENT ON COLUMN master_data.routes.preferred_flag IS 'Đánh dấu tuyến ưu tiên khi tối ưu vận hành.';
COMMENT ON COLUMN master_data.routes.active_flag IS 'Đánh dấu tuyến còn đang áp dụng vận hành.';
COMMENT ON COLUMN master_data.routes.created_at IS 'Thời điểm tạo bản ghi.';
COMMENT ON COLUMN master_data.routes.updated_at IS 'Thời điểm cập nhật bản ghi gần nhất.';