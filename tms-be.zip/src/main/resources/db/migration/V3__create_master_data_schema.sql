
BEGIN;

CREATE SCHEMA IF NOT EXISTS master_data;

CREATE TABLE IF NOT EXISTS master_data.business_partners (
                                                             id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id uuid NOT NULL,
    partner_type varchar(40) NOT NULL,
    partner_code varchar(40) NOT NULL,
    partner_name varchar(255) NOT NULL,
    tax_code varchar(50),
    phone varchar(50),
    email varchar(255),
    address text,
    payment_term_days int,
    credit_limit_amount numeric(18,2),
    status_code varchar(30) NOT NULL DEFAULT 'ACTIVE',
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (organization_id, partner_code)
    );

COMMENT ON TABLE master_data.business_partners IS 'Customers, outsourced carriers, fuel suppliers, garages, insurers, and other business counterparties.';
CREATE INDEX IF NOT EXISTS ix_business_partners_org_type ON master_data.business_partners (organization_id, partner_type);

CREATE TABLE IF NOT EXISTS master_data.business_partner_contacts (
                                                                     id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    business_partner_id uuid NOT NULL,
    full_name varchar(255) NOT NULL,
    phone varchar(50),
    email varchar(255),
    job_title varchar(255),
    is_default boolean NOT NULL DEFAULT false,
    created_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT fk_partner_contacts_partner FOREIGN KEY (business_partner_id) REFERENCES master_data.business_partners(id)
    );

COMMENT ON TABLE master_data.business_partner_contacts IS 'Contact people per business partner.';

CREATE TABLE IF NOT EXISTS master_data.locations (
                                                     id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id uuid NOT NULL,
    location_type varchar(40) NOT NULL,
    location_code varchar(40) NOT NULL,
    location_name varchar(255) NOT NULL,
    address text,
    latitude numeric(10,7),
    longitude numeric(10,7),
    status_code varchar(30) NOT NULL DEFAULT 'ACTIVE',
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (organization_id, location_code)
    );

COMMENT ON TABLE master_data.locations IS 'Pickup, delivery, port, CY, depot, warehouse, or other operational point.';
CREATE INDEX IF NOT EXISTS ix_locations_org_type ON master_data.locations (organization_id, location_type);

CREATE TABLE IF NOT EXISTS master_data.vehicles (
                                                    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id uuid NOT NULL,
    vehicle_code varchar(40),
    vehicle_type varchar(30) NOT NULL,
    plate_no varchar(30) NOT NULL,
    chassis_no varchar(60),
    engine_no varchar(60),
    branch_id uuid,
    fleet_team_id uuid,
    payload_kg numeric(18,2),
    volume_m3 numeric(18,2),
    container_capability varchar(60),
    status_code varchar(30) NOT NULL DEFAULT 'ACTIVE',
    operational_state varchar(30) NOT NULL DEFAULT 'AVAILABLE',
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (organization_id, plate_no)
    );

COMMENT ON TABLE master_data.vehicles IS 'Vehicle master. Phase 1 keeps only the fields required for dispatch and reporting.';
CREATE INDEX IF NOT EXISTS ix_vehicles_org_state ON master_data.vehicles (organization_id, operational_state);

CREATE TABLE IF NOT EXISTS master_data.drivers (
                                                   id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id uuid NOT NULL,
    driver_code varchar(40),
    driver_type varchar(20) NOT NULL DEFAULT 'DRIVER',
    full_name varchar(255) NOT NULL,
    phone varchar(50),
    license_no varchar(60),
    license_expiry_date date,
    branch_id uuid,
    fleet_team_id uuid,
    employment_status varchar(30) NOT NULL DEFAULT 'ACTIVE',
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (organization_id, driver_code)
    );

COMMENT ON TABLE master_data.drivers IS 'Driver and co-driver master data.';
CREATE INDEX IF NOT EXISTS ix_drivers_org_status ON master_data.drivers (organization_id, employment_status);

CREATE TABLE IF NOT EXISTS master_data.routes (
                                                  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id uuid NOT NULL,
    route_code varchar(40) NOT NULL,
    route_name varchar(255) NOT NULL,
    origin_location_id uuid,
    destination_location_id uuid,
    standard_km numeric(12,2),
    standard_duration_minutes int,
    status_code varchar(30) NOT NULL DEFAULT 'ACTIVE',
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (organization_id, route_code)
    );

COMMENT ON TABLE master_data.routes IS 'Standard route setup used in planning, pricing, and later fuel norms.';
CREATE INDEX IF NOT EXISTS ix_routes_org ON master_data.routes (organization_id);

CREATE TABLE IF NOT EXISTS master_data.tariffs (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id uuid NOT NULL,
    customer_id uuid,
    route_id uuid,
    vehicle_type varchar(30),
    container_type varchar(30),
    currency_code varchar(10) NOT NULL DEFAULT 'VND',
    base_price numeric(18,2) NOT NULL,
    effective_from date NOT NULL,
    effective_to date,
    status_code varchar(30) NOT NULL DEFAULT 'ACTIVE',
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
    );

COMMENT ON TABLE master_data.tariffs IS 'Pricing rule table. Phase 1 keeps structure simple and defers complex pricing engines.';
CREATE INDEX IF NOT EXISTS ix_tariffs_org_effective ON master_data.tariffs (organization_id, effective_from, effective_to);

CREATE TABLE IF NOT EXISTS master_data.surcharges (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id uuid NOT NULL,
    surcharge_code varchar(40) NOT NULL,
    surcharge_name varchar(255) NOT NULL,
    charge_method varchar(30) NOT NULL,
    default_amount numeric(18,2),
    currency_code varchar(10) NOT NULL DEFAULT 'VND',
    status_code varchar(30) NOT NULL DEFAULT 'ACTIVE',
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (organization_id, surcharge_code)
    );

COMMENT ON TABLE master_data.surcharges IS 'Charge and fee catalogue for quoting and later finance lines.';
CREATE INDEX IF NOT EXISTS ix_surcharges_org ON master_data.surcharges (organization_id);

CREATE TABLE IF NOT EXISTS master_data.reference_data_items (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    group_code      VARCHAR(50) NOT NULL,
    item_code       VARCHAR(50) NOT NULL,
    name_vi         VARCHAR(255) NOT NULL,
    name_en         VARCHAR(255) NOT NULL,
    description     TEXT,
    sort_order      INT NOT NULL DEFAULT 0,
    is_system       BOOLEAN NOT NULL DEFAULT TRUE,
    status_code     VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uk_reference_data_items UNIQUE (group_code, item_code),
    CONSTRAINT chk_reference_data_items_status
    CHECK (status_code IN ('ACTIVE', 'INACTIVE'))
    );

CREATE INDEX IF NOT EXISTS ix_reference_data_items_group_status_sort
    ON master_data.reference_data_items (group_code, status_code, sort_order, item_code);

COMMIT;
