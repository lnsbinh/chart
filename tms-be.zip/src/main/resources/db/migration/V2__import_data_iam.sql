
BEGIN;

-- =========================================================
-- SEED CORE DATA
-- =========================================================
INSERT INTO iam.organizations (code, name, status)
VALUES ('ORG_TMS_TMA', 'Logis Organization', 'ACTIVE')
    ON CONFLICT (code) DO NOTHING;

INSERT INTO iam.branches (organization_id, code, name, status)
SELECT o.id, x.code, x.name, 'ACTIVE'
FROM iam.organizations o
         JOIN (VALUES
                   ('HCM', 'Ho Chi Minh Branch'),
                   ('HN',  'Ha Noi Branch'),
                   ('DN',  'Da Nang Branch')
) AS x(code, name) ON TRUE
WHERE o.code = 'ORG_TMS_TMA'
    ON CONFLICT (organization_id, code) DO NOTHING;

INSERT INTO iam.roles (code, name, description, allowed_scope_type, is_system, status)
VALUES
    ('SUPER_ADMIN', 'Super Admin', 'Full global platform access', 'GLOBAL', TRUE, 'ACTIVE'),
    ('ADMIN', 'Organization Admin', 'Administrative role inside an organization', 'ORGANIZATION_AND_BRANCH', TRUE, 'ACTIVE'),
    ('FINANCE_OPS', 'Finance Ops', 'Finance and audit related role', 'ORGANIZATION_AND_BRANCH', TRUE, 'ACTIVE'),
    ('SUPERVISOR', 'Supervisor', 'Branch supervisor role', 'BRANCH', TRUE, 'ACTIVE'),
    ('DISPATCHER', 'Dispatcher', 'Branch dispatcher role', 'BRANCH', TRUE, 'ACTIVE'),
    ('OPERATION_STAFF', 'Operation Staff', 'Branch operation staff role', 'BRANCH', TRUE, 'ACTIVE'),
    ('DRIVER', 'Driver', 'Driver role', 'BRANCH', TRUE, 'ACTIVE')
    ON CONFLICT (code) DO NOTHING;

-- Hierarchy: parent inherits child
INSERT INTO iam.role_hierarchy (parent_role_id, child_role_id)
SELECT p.id, c.id
FROM iam.roles p
         JOIN iam.roles c ON c.code = 'ADMIN'
WHERE p.code = 'SUPER_ADMIN'
    ON CONFLICT DO NOTHING;

INSERT INTO iam.role_hierarchy (parent_role_id, child_role_id)
SELECT p.id, c.id
FROM iam.roles p
         JOIN iam.roles c ON c.code = 'FINANCE_OPS'
WHERE p.code = 'ADMIN'
    ON CONFLICT DO NOTHING;

INSERT INTO iam.role_hierarchy (parent_role_id, child_role_id)
SELECT p.id, c.id
FROM iam.roles p
         JOIN iam.roles c ON c.code = 'SUPERVISOR'
WHERE p.code = 'ADMIN'
    ON CONFLICT DO NOTHING;

-- INSERT INTO iam.role_hierarchy (parent_role_id, child_role_id)
-- SELECT p.id, c.id
-- FROM iam.roles p
-- JOIN iam.roles c ON c.code = 'DISPATCHER'
-- WHERE p.code = 'SUPERVISOR'
-- ON CONFLICT DO NOTHING;
--
-- INSERT INTO iam.role_hierarchy (parent_role_id, child_role_id)
-- SELECT p.id, c.id
-- FROM iam.roles p
-- JOIN iam.roles c ON c.code = 'OPERATION_STAFF'
-- WHERE p.code = 'SUPERVISOR'
-- ON CONFLICT DO NOTHING;

INSERT INTO iam.permissions (
    code,
    name,
    display_name_vi,
    display_name_en,
    description_vi,
    description_en,
    module_code,
    resource_code,
    action_code,
    assignment_scope_hint,
    is_sensitive,
    status
)
VALUES
-- customer
('customer.all', 'Customer All', 'Toàn quyền khách hàng', 'Customer All Permission', 'Cho phép toàn quyền trên khách hàng', 'Allows full access to customers', 'partner_management', 'customer', 'ALL', 'ORGANIZATION', FALSE, 'ACTIVE'),
('customer.read', 'Customer Read', 'Xem khách hàng', 'Customer Read Permission', 'Cho phép xem khách hàng', 'Allows viewing customers', 'partner_management', 'customer', 'READ', 'ORGANIZATION', FALSE, 'ACTIVE'),
('customer.update', 'Customer Update', 'Tạo/sửa khách hàng', 'Customer Update Permission', 'Cho phép tạo và cập nhật khách hàng', 'Allows creating and updating customers', 'partner_management', 'customer', 'UPDATE', 'ORGANIZATION', FALSE, 'ACTIVE'),
('customer.delete', 'Customer Delete', 'Xóa/ngưng hiệu lực khách hàng', 'Customer Delete Permission', 'Cho phép xóa hoặc ngưng hiệu lực khách hàng', 'Allows deleting or deactivating customers', 'partner_management', 'customer', 'DELETE', 'ORGANIZATION', TRUE, 'ACTIVE'),

-- outsourced_carrier
('outsourced_carrier.all', 'Outsourced Carrier All', 'Toàn quyền nhà xe thuê ngoài', 'Outsourced Carrier All Permission', 'Cho phép toàn quyền trên nhà xe thuê ngoài', 'Allows full access to outsourced carriers', 'partner_management', 'outsourced_carrier', 'ALL', 'ORGANIZATION', FALSE, 'ACTIVE'),
('outsourced_carrier.read', 'Outsourced Carrier Read', 'Xem nhà xe thuê ngoài', 'Outsourced Carrier Read Permission', 'Cho phép xem nhà xe thuê ngoài', 'Allows viewing outsourced carriers', 'partner_management', 'outsourced_carrier', 'READ', 'ORGANIZATION', FALSE, 'ACTIVE'),
('outsourced_carrier.update', 'Outsourced Carrier Update', 'Tạo/sửa nhà xe thuê ngoài', 'Outsourced Carrier Update Permission', 'Cho phép tạo và cập nhật nhà xe thuê ngoài', 'Allows creating and updating outsourced carriers', 'partner_management', 'outsourced_carrier', 'UPDATE', 'ORGANIZATION', FALSE, 'ACTIVE'),
('outsourced_carrier.delete', 'Outsourced Carrier Delete', 'Xóa/ngưng hiệu lực nhà xe thuê ngoài', 'Outsourced Carrier Delete Permission', 'Cho phép xóa hoặc ngưng hiệu lực nhà xe thuê ngoài', 'Allows deleting or deactivating outsourced carriers', 'partner_management', 'outsourced_carrier', 'DELETE', 'ORGANIZATION', TRUE, 'ACTIVE'),

-- vehicle
('vehicle.all', 'Vehicle All', 'Toàn quyền phương tiện', 'Vehicle All Permission', 'Cho phép toàn quyền trên phương tiện', 'Allows full access to vehicles', 'fleet_management', 'vehicle', 'ALL', 'ORGANIZATION', FALSE, 'ACTIVE'),
('vehicle.read', 'Vehicle Read', 'Xem phương tiện', 'Vehicle Read Permission', 'Cho phép xem phương tiện', 'Allows viewing vehicles', 'fleet_management', 'vehicle', 'READ', 'ORGANIZATION', FALSE, 'ACTIVE'),
('vehicle.update', 'Vehicle Update', 'Tạo/sửa phương tiện', 'Vehicle Update Permission', 'Cho phép tạo và cập nhật phương tiện', 'Allows creating and updating vehicles', 'fleet_management', 'vehicle', 'UPDATE', 'ORGANIZATION', FALSE, 'ACTIVE'),
('vehicle.delete', 'Vehicle Delete', 'Xóa/ngưng hiệu lực phương tiện', 'Vehicle Delete Permission', 'Cho phép xóa hoặc ngưng hiệu lực phương tiện', 'Allows deleting or deactivating vehicles', 'fleet_management', 'vehicle', 'DELETE', 'ORGANIZATION', TRUE, 'ACTIVE'),

-- driver
('driver.all', 'Driver All', 'Toàn quyền tài xế', 'Driver All Permission', 'Cho phép toàn quyền trên tài xế', 'Allows full access to drivers', 'fleet_management', 'driver', 'ALL', 'ORGANIZATION', FALSE, 'ACTIVE'),
('driver.read', 'Driver Read', 'Xem tài xế', 'Driver Read Permission', 'Cho phép xem tài xế', 'Allows viewing drivers', 'fleet_management', 'driver', 'READ', 'ORGANIZATION', FALSE, 'ACTIVE'),
('driver.update', 'Driver Update', 'Tạo/sửa tài xế', 'Driver Update Permission', 'Cho phép tạo và cập nhật tài xế', 'Allows creating and updating drivers', 'fleet_management', 'driver', 'UPDATE', 'ORGANIZATION', FALSE, 'ACTIVE'),
('driver.delete', 'Driver Delete', 'Xóa/ngưng hiệu lực tài xế', 'Driver Delete Permission', 'Cho phép xóa hoặc ngưng hiệu lực tài xế', 'Allows deleting or deactivating drivers', 'fleet_management', 'driver', 'DELETE', 'ORGANIZATION', TRUE, 'ACTIVE'),

-- route
('route.all', 'Route All', 'Toàn quyền tuyến đường', 'Route All Permission', 'Cho phép toàn quyền trên tuyến đường', 'Allows full access to routes', 'route_management', 'route', 'ALL', 'ORGANIZATION', FALSE, 'ACTIVE'),
('route.read', 'Route Read', 'Xem tuyến đường', 'Route Read Permission', 'Cho phép xem tuyến đường', 'Allows viewing routes', 'route_management', 'route', 'READ', 'ORGANIZATION', FALSE, 'ACTIVE'),
('route.update', 'Route Update', 'Tạo/sửa tuyến đường', 'Route Update Permission', 'Cho phép tạo và cập nhật tuyến đường', 'Allows creating and updating routes', 'route_management', 'route', 'UPDATE', 'ORGANIZATION', FALSE, 'ACTIVE'),
('route.delete', 'Route Delete', 'Xóa/ngưng hiệu lực tuyến đường', 'Route Delete Permission', 'Cho phép xóa hoặc ngưng hiệu lực tuyến đường', 'Allows deleting or deactivating routes', 'route_management', 'route', 'DELETE', 'ORGANIZATION', TRUE, 'ACTIVE'),

-- tariff
('tariff.all', 'Tariff All', 'Toàn quyền biểu giá', 'Tariff All Permission', 'Cho phép toàn quyền trên biểu giá', 'Allows full access to tariffs', 'pricing_management', 'tariff', 'ALL', 'ORGANIZATION', FALSE, 'ACTIVE'),
('tariff.read', 'Tariff Read', 'Xem biểu giá', 'Tariff Read Permission', 'Cho phép xem biểu giá', 'Allows viewing tariffs', 'pricing_management', 'tariff', 'READ', 'ORGANIZATION', FALSE, 'ACTIVE'),
('tariff.update', 'Tariff Update', 'Tạo/sửa biểu giá', 'Tariff Update Permission', 'Cho phép tạo và cập nhật biểu giá', 'Allows creating and updating tariffs', 'pricing_management', 'tariff', 'UPDATE', 'ORGANIZATION', FALSE, 'ACTIVE'),
('tariff.delete', 'Tariff Delete', 'Xóa/ngưng hiệu lực biểu giá', 'Tariff Delete Permission', 'Cho phép xóa hoặc ngưng hiệu lực biểu giá', 'Allows deleting or deactivating tariffs', 'pricing_management', 'tariff', 'DELETE', 'ORGANIZATION', TRUE, 'ACTIVE'),

-- surcharge
('surcharge.all', 'Surcharge All', 'Toàn quyền phụ phí', 'Surcharge All Permission', 'Cho phép toàn quyền trên phụ phí', 'Allows full access to surcharges', 'pricing_management', 'surcharge', 'ALL', 'ORGANIZATION', FALSE, 'ACTIVE'),
('surcharge.read', 'Surcharge Read', 'Xem phụ phí', 'Surcharge Read Permission', 'Cho phép xem phụ phí', 'Allows viewing surcharges', 'pricing_management', 'surcharge', 'READ', 'ORGANIZATION', FALSE, 'ACTIVE'),
('surcharge.update', 'Surcharge Update', 'Tạo/sửa phụ phí', 'Surcharge Update Permission', 'Cho phép tạo và cập nhật phụ phí', 'Allows creating and updating surcharges', 'pricing_management', 'surcharge', 'UPDATE', 'ORGANIZATION', FALSE, 'ACTIVE'),
('surcharge.delete', 'Surcharge Delete', 'Xóa/ngưng hiệu lực phụ phí', 'Surcharge Delete Permission', 'Cho phép xóa hoặc ngưng hiệu lực phụ phí', 'Allows deleting or deactivating surcharges', 'pricing_management', 'surcharge', 'DELETE', 'ORGANIZATION', TRUE, 'ACTIVE'),

-- user_management
('user_management.all', 'User Management All', 'Toàn quyền quản lý người dùng', 'User Management All Permission', 'Cho phép toàn quyền quản lý người dùng, gán role, organization, branch', 'Allows full user management including role, organization, and branch assignment', 'iam', 'user_management', 'ALL', 'GLOBAL', TRUE, 'ACTIVE'),
('user_management.read', 'User Management Read', 'Xem người dùng và phân quyền', 'User Management Read Permission', 'Cho phép xem người dùng, role, organization, branch được gán', 'Allows viewing users and their assigned roles, organizations, and branches', 'iam', 'user_management', 'READ', 'GLOBAL', TRUE, 'ACTIVE'),
('user_management.update', 'User Management Update', 'Tạo/sửa người dùng và phân quyền', 'User Management Update Permission', 'Cho phép tạo, cập nhật người dùng và gán role, organization, branch', 'Allows creating/updating users and assigning roles, organizations, and branches', 'iam', 'user_management', 'UPDATE', 'GLOBAL', TRUE, 'ACTIVE'),
('user_management.delete', 'User Management Delete', 'Xóa/khóa người dùng và thu hồi phân quyền', 'User Management Delete Permission', 'Cho phép xóa, khóa người dùng và thu hồi role, organization, branch', 'Allows deleting/locking users and revoking roles, organizations, and branches', 'iam', 'user_management', 'DELETE', 'GLOBAL', TRUE, 'ACTIVE'),

-- order
('order.all', 'Order All', 'Toàn quyền đơn hàng', 'Order All Permission', 'Cho phép toàn quyền trên đơn hàng', 'Allows full access to orders', 'order_management', 'order', 'ALL', 'ORGANIZATION', FALSE, 'ACTIVE'),
('order.read', 'Order Read', 'Xem đơn hàng', 'Order Read Permission', 'Cho phép xem đơn hàng', 'Allows viewing orders', 'order_management', 'order', 'READ', 'ORGANIZATION', FALSE, 'ACTIVE'),
('order.update', 'Order Update', 'Tạo/sửa đơn hàng', 'Order Update Permission', 'Cho phép tạo và cập nhật đơn hàng', 'Allows creating and updating orders', 'order_management', 'order', 'UPDATE', 'ORGANIZATION', FALSE, 'ACTIVE'),
('order.delete', 'Order Delete', 'Xóa/ngưng hiệu lực đơn hàng', 'Order Delete Permission', 'Cho phép xóa hoặc ngưng hiệu lực đơn hàng', 'Allows deleting or deactivating orders', 'order_management', 'order', 'DELETE', 'ORGANIZATION', TRUE, 'ACTIVE'),

-- trip
('trip.all', 'Trip All', 'Toàn quyền chuyến', 'Trip All Permission', 'Cho phép toàn quyền trên chuyến', 'Allows full access to trips', 'trip_management', 'trip', 'ALL', 'ORGANIZATION', FALSE, 'ACTIVE'),
('trip.read', 'Trip Read', 'Xem chuyến', 'Trip Read Permission', 'Cho phép xem chuyến', 'Allows viewing trips', 'trip_management', 'trip', 'READ', 'ORGANIZATION', FALSE, 'ACTIVE'),
('trip.update', 'Trip Update', 'Tạo/sửa chuyến', 'Trip Update Permission', 'Cho phép tạo và cập nhật chuyến', 'Allows creating and updating trips', 'trip_management', 'trip', 'UPDATE', 'ORGANIZATION', FALSE, 'ACTIVE'),
('trip.delete', 'Trip Delete', 'Xóa/ngưng hiệu lực chuyến', 'Trip Delete Permission', 'Cho phép xóa hoặc ngưng hiệu lực chuyến', 'Allows deleting or deactivating trips', 'trip_management', 'trip', 'DELETE', 'ORGANIZATION', TRUE, 'ACTIVE'),

-- dispatch
('dispatch.all', 'Dispatch All', 'Toàn quyền điều độ', 'Dispatch All Permission', 'Cho phép toàn quyền trên điều độ', 'Allows full access to dispatch operations', 'dispatch_management', 'dispatch', 'ALL', 'ORGANIZATION', FALSE, 'ACTIVE'),
('dispatch.read', 'Dispatch Read', 'Xem điều độ', 'Dispatch Read Permission', 'Cho phép xem điều độ', 'Allows viewing dispatch operations', 'dispatch_management', 'dispatch', 'READ', 'ORGANIZATION', FALSE, 'ACTIVE'),
('dispatch.update', 'Dispatch Update', 'Tạo/sửa điều độ', 'Dispatch Update Permission', 'Cho phép tạo và cập nhật điều độ', 'Allows creating and updating dispatch operations', 'dispatch_management', 'dispatch', 'UPDATE', 'ORGANIZATION', FALSE, 'ACTIVE'),
('dispatch.delete', 'Dispatch Delete', 'Xóa/ngưng hiệu lực điều độ', 'Dispatch Delete Permission', 'Cho phép xóa hoặc ngưng hiệu lực điều độ', 'Allows deleting or deactivating dispatch operations', 'dispatch_management', 'dispatch', 'DELETE', 'ORGANIZATION', TRUE, 'ACTIVE'),

-- reporting
('reporting.all', 'Reporting All', 'Toàn quyền báo cáo', 'Reporting All Permission', 'Cho phép toàn quyền trên báo cáo', 'Allows full access to reporting', 'reporting', 'reporting', 'ALL', 'ORGANIZATION', TRUE, 'ACTIVE'),
('reporting.read', 'Reporting Read', 'Xem báo cáo', 'Reporting Read Permission', 'Cho phép xem báo cáo', 'Allows viewing reports', 'reporting', 'reporting', 'READ', 'ORGANIZATION', FALSE, 'ACTIVE'),
('reporting.update', 'Reporting Update', 'Tạo/sửa cấu hình báo cáo', 'Reporting Update Permission', 'Cho phép tạo và cập nhật cấu hình báo cáo', 'Allows creating and updating report configurations', 'reporting', 'reporting', 'UPDATE', 'ORGANIZATION', TRUE, 'ACTIVE'),
('reporting.delete', 'Reporting Delete', 'Xóa/ngưng hiệu lực cấu hình báo cáo', 'Reporting Delete Permission', 'Cho phép xóa hoặc ngưng hiệu lực cấu hình báo cáo', 'Allows deleting or deactivating report configurations', 'reporting', 'reporting', 'DELETE', 'ORGANIZATION', TRUE, 'ACTIVE');

-- =========================================
-- ROLE_PERMISSIONS SEED - FINAL
-- Rule:
-- A   -> *.all
-- R   -> *.read
-- U   -> *.update
-- C/U -> *.update
-- DRIVER app -> driver.all
-- =========================================

-- ADMIN = A
INSERT INTO iam.role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM iam.roles r
         JOIN iam.permissions p ON p.code IN (
                                              'user_management.all',

                                              'customer.all',
                                              'outsourced_carrier.all',
                                              'vehicle.all',
                                              'driver.all',
                                              'route.all',
                                              'tariff.all',
                                              'surcharge.all',

                                              'order.all',
                                              'trip.all',
                                              'dispatch.all',
                                              'reporting.all'
    )
WHERE r.code = 'ADMIN'
    ON CONFLICT DO NOTHING;

-- SUPERVISOR = R
INSERT INTO iam.role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM iam.roles r
         JOIN iam.permissions p ON p.code IN (
                                              'user_management.read',

                                              'customer.read',
                                              'outsourced_carrier.read',
                                              'vehicle.read',
                                              'driver.read',
                                              'route.read',
                                              'tariff.read',
                                              'surcharge.read',

                                              'order.read',
                                              'trip.read',
                                              'dispatch.read',
                                              'reporting.read'
    )
WHERE r.code = 'SUPERVISOR'
    ON CONFLICT DO NOTHING;

-- DISPATCHER
-- master data = R
-- order = U
-- trip = C/U -> UPDATE
-- dispatch = U
-- reporting = R
INSERT INTO iam.role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM iam.roles r
         JOIN iam.permissions p ON p.code IN (
                                              'customer.read',
                                              'outsourced_carrier.read',
                                              'vehicle.read',
                                              'driver.read',
                                              'route.read',
                                              'tariff.read',
                                              'surcharge.read',

                                              'order.update',
                                              'trip.update',
                                              'dispatch.update',

                                              'reporting.read'
    )
WHERE r.code = 'DISPATCHER'
    ON CONFLICT DO NOTHING;

-- OPERATION_STAFF
-- master data = C/R/U -> UPDATE
-- order = C/U -> UPDATE
INSERT INTO iam.role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM iam.roles r
         JOIN iam.permissions p ON p.code IN (
                                              'customer.update',
                                              'outsourced_carrier.update',
                                              'vehicle.update',
                                              'driver.update',
                                              'route.update',
                                              'tariff.update',
                                              'surcharge.update',

                                              'order.update'
    )
WHERE r.code = 'OPERATION_STAFF'
    ON CONFLICT DO NOTHING;

-- FINANCE_OPS
-- master data = R
-- order = R
-- reporting = A
INSERT INTO iam.role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM iam.roles r
         JOIN iam.permissions p ON p.code IN (
                                              'customer.read',
                                              'outsourced_carrier.read',
                                              'vehicle.read',
                                              'driver.read',
                                              'route.read',
                                              'tariff.read',
                                              'surcharge.read',

                                              'order.read',

                                              'reporting.all'
    )
WHERE r.code = 'FINANCE_OPS'
    ON CONFLICT DO NOTHING;

-- DRIVER
-- Driver App = A -> map to driver.all
INSERT INTO iam.role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM iam.roles r
         JOIN iam.permissions p ON p.code IN (
    'driver.all'
    )
WHERE r.code = 'DRIVER'
    ON CONFLICT DO NOTHING;

INSERT INTO iam.users (external_subject, username, email, display_name, status)
VALUES
    ('superadmin', 'superadmin', 'superadmin@example.com', 'Super Admin', 'ACTIVE')
    ON CONFLICT (external_subject) DO NOTHING;


INSERT INTO iam.user_branches (user_id, organization_id, branch_id, is_primary)
SELECT u.id, o.id, b.id, TRUE
FROM iam.users u
         JOIN iam.organizations o ON o.code = 'ORG_TMS_TMA'
         JOIN iam.branches b ON b.organization_id = o.id AND b.code = 'HCM'
WHERE u.external_subject IN ('admin','finance_ops','supervisor','dispatcher','operation_staff','driver')
    ON CONFLICT (user_id, branch_id) DO NOTHING;

INSERT INTO iam.user_branches (user_id, organization_id, branch_id, is_primary)
SELECT u.id, o.id, b.id, FALSE
FROM iam.users u
         JOIN iam.organizations o ON o.code = 'ORG_TMS_TMA'
         JOIN iam.branches b ON b.organization_id = o.id AND b.code = 'HN'
WHERE u.external_subject IN ('finance_ops','dispatcher')
    ON CONFLICT (user_id, branch_id) DO NOTHING;

INSERT INTO iam.user_role_assignments (user_id, role_id, scope_type, organization_id, branch_id, source_type)
SELECT u.id, r.id, 'GLOBAL', NULL, NULL, 'SEED'
FROM iam.users u
         JOIN iam.roles r ON r.code = 'SUPER_ADMIN'
WHERE u.external_subject = 'superadmin'
    ON CONFLICT (user_id, role_id, scope_type, organization_id, branch_id) DO NOTHING;

INSERT INTO iam.user_role_assignments (user_id, role_id, scope_type, organization_id, branch_id, source_type)
SELECT u.id, r.id, 'ORGANIZATION', o.id, NULL, 'SEED'
FROM iam.users u
         JOIN iam.roles r ON r.code IN ('ADMIN','FINANCE_OPS')
         JOIN iam.organizations o ON o.code = 'ORG_TMS_TMA'
WHERE (u.external_subject = 'admin' AND r.code = 'ADMIN')
   OR (u.external_subject = 'finance_ops' AND r.code = 'FINANCE_OPS')
    ON CONFLICT (user_id, role_id, scope_type, organization_id, branch_id) DO NOTHING;

INSERT INTO iam.user_role_assignments (user_id, role_id, scope_type, organization_id, branch_id, source_type)
SELECT u.id, r.id, 'BRANCH', o.id, b.id, 'SEED'
FROM iam.users u
         JOIN iam.roles r ON r.code IN ('SUPERVISOR','DISPATCHER','OPERATION_STAFF','DRIVER')
         JOIN iam.organizations o ON o.code = 'ORG_TMS_TMA'
         JOIN iam.branches b ON b.organization_id = o.id AND b.code = 'HCM'
WHERE (u.external_subject = 'supervisor' AND r.code = 'SUPERVISOR')
   OR (u.external_subject = 'dispatcher' AND r.code = 'DISPATCHER')
   OR (u.external_subject = 'operation_staff' AND r.code = 'OPERATION_STAFF')
   OR (u.external_subject = 'driver' AND r.code = 'DRIVER')
    ON CONFLICT (user_id, role_id, scope_type, organization_id, branch_id) DO NOTHING;

-- INSERT INTO iam.sensitive_action_policies (action_code, param_key, param_type, param_value, description)
-- VALUES
-- ('shipment.reopen', 'require_reason', 'BOOLEAN', 'true', 'Require reason when reopening shipment'),
-- ('shipment.reopen', 'require_audit', 'BOOLEAN', 'true', 'Audit shipment reopen'),
-- ('shipment.reopen', 'allowed_time_window_minutes', 'INTEGER', '1440', 'Allow reopen within 24 hours'),
-- ('audit.export', 'require_reason', 'BOOLEAN', 'true', 'Require reason when exporting audit'),
-- ('audit.export', 'require_audit', 'BOOLEAN', 'true', 'Audit export'),
-- ('audit.export', 'require_mfa', 'BOOLEAN', 'true', 'Require MFA for export')
-- ON CONFLICT (action_code, param_key) DO NOTHING;

-- clear old materialized permissions if muốn rebuild full
TRUNCATE TABLE iam.user_effective_permissions;

WITH RECURSIVE resolved_roles AS (
    -- direct assigned roles
    SELECT
        ura.user_id,
        ura.role_id,
        ura.scope_type,
        ura.organization_id,
        ura.branch_id
    FROM iam.user_role_assignments ura
    WHERE ura.status = 'ACTIVE'

    UNION

    -- inherited child roles
    -- rule hiện tại: parent inherits child
    SELECT
        rr.user_id,
        rh.child_role_id AS role_id,
        rr.scope_type,
        rr.organization_id,
        rr.branch_id
    FROM resolved_roles rr
             JOIN iam.role_hierarchy rh
                  ON rh.parent_role_id = rr.role_id
),
               effective_role_permissions AS (
                   SELECT DISTINCT
                       rr.user_id,
                       rp.permission_id,
                       rr.scope_type,
                       rr.organization_id,
                       rr.branch_id
                   FROM resolved_roles rr
                            JOIN iam.role_permissions rp
                                 ON rp.role_id = rr.role_id
               )
INSERT INTO iam.user_effective_permissions (
    user_id,
    permission_id,
    scope_type,
    organization_id,
    branch_id
)
SELECT
    erp.user_id,
    erp.permission_id,
    erp.scope_type,
    erp.organization_id,
    erp.branch_id
FROM effective_role_permissions erp
    ON CONFLICT DO NOTHING;


COMMIT;
