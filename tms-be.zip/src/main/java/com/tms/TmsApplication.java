package com.tms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.TimeZone;

@SpringBootApplication
public class TmsApplication {
    public static void main(String[] args) {
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));

        System.out.println(java.time.ZoneId.systemDefault());
        System.out.println("JVM TZ = " + java.util.TimeZone.getDefault().getID());

        SpringApplication.run(TmsApplication.class, args);
    }
}
