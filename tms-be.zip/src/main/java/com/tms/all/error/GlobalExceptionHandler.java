package com.tms.all.error;

import com.tms.modules.iam.exception.BusinessException;
import com.tms.security.exception.ForbiddenException;
import jakarta.persistence.PersistenceException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import org.hibernate.PropertyValueException;
import org.hibernate.exception.DataException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.sql.SQLException;
import java.time.OffsetDateTime;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@ControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    private static final Pattern PG_DUPLICATE_DETAIL =
            Pattern.compile("Key \\((.+?)\\)=\\((.+?)\\) already exists\\.");
    private static final Pattern PG_FK_DETAIL =
            Pattern.compile("Key \\((.+?)\\)=\\((.+?)\\) is not present in table \"(.+?)\"\\.");
    private static final Pattern PG_FK_DELETE_DETAIL =
            Pattern.compile("Key \\((.+?)\\)=\\((.+?)\\) is still referenced from table \"(.+?)\"\\.");
    private static final Pattern PG_NOT_NULL_DETAIL =
            Pattern.compile("null value in column \"(.+?)\" .* violates not-null constraint");
    private static final Pattern PG_VALUE_TOO_LONG =
            Pattern.compile("value too long for type (.+)");
    private static final Pattern PG_INVALID_INPUT =
            Pattern.compile("invalid input syntax for type (.+?):\\s*\"(.+?)\"");
    private static final Pattern PG_NUMERIC_OVERFLOW =
            Pattern.compile("numeric field overflow");

    @ExceptionHandler(ForbiddenException.class)
    public ResponseEntity<Map<String, Object>> handleForbidden(
            ForbiddenException exception,
            HttpServletRequest request
    ) {
        log.error("ForbiddenException at path={}", request.getRequestURI(), exception);
        return build(HttpStatus.FORBIDDEN, "FORBIDDEN", safeMessage(exception.getMessage(), "Access denied"), request.getRequestURI());
    }

    @ExceptionHandler(IllegalStateException.class)
    public ResponseEntity<Map<String, Object>> handleIllegalState(
            IllegalStateException exception,
            HttpServletRequest request
    ) {
        log.error("IllegalStateException at path={}", request.getRequestURI(), exception);
        return build(HttpStatus.BAD_REQUEST, "ILLEGAL_STATE", safeMessage(exception.getMessage(), "Invalid state"), request.getRequestURI());
    }

    @ExceptionHandler(BusinessException.class)
    public ResponseEntity<Map<String, Object>> handleBusiness(
            BusinessException exception,
            HttpServletRequest request
    ) {
        log.error("BusinessException at path={}", request.getRequestURI(), exception);
        return build(
                exception.getErrorCode().getStatus(),
                exception.getErrorCode().toString(),
                safeMessage(exception.getMessage(), "Business error"),
                request.getRequestURI()
        );
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handleMethodArgumentNotValid(
            MethodArgumentNotValidException exception,
            HttpServletRequest request
    ) {
        log.error("MethodArgumentNotValidException at path={}", request.getRequestURI(), exception);

        String message = exception.getBindingResult()
                .getFieldErrors()
                .stream()
                .map(err -> err.getField() + ": " + safeMessage(err.getDefaultMessage(), "invalid"))
                .collect(Collectors.joining("; "));

        return build(HttpStatus.BAD_REQUEST, "VALIDATION_FAILED",
                safeMessage(message, "Request validation failed"), request.getRequestURI());
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<Map<String, Object>> handleValidationConstraint(
            ConstraintViolationException exception,
            HttpServletRequest request
    ) {
        log.error("ConstraintViolationException at path={}", request.getRequestURI(), exception);

        String message = exception.getConstraintViolations()
                .stream()
                .map(this::toValidationMessage)
                .collect(Collectors.joining("; "));

        return build(HttpStatus.BAD_REQUEST, "VALIDATION_CONSTRAINT_VIOLATION",
                safeMessage(message, "Constraint violation"), request.getRequestURI());
    }

    @ExceptionHandler(DuplicateKeyException.class)
    public ResponseEntity<Map<String, Object>> handleDuplicateKey(
            DuplicateKeyException exception,
            HttpServletRequest request
    ) {
        log.error("DuplicateKeyException at path={}", request.getRequestURI(), exception);
        Throwable root = getRootCause(exception);
        String detail = extractDetailedDatabaseMessage(root);
        return build(HttpStatus.CONFLICT, "DUPLICATE_KEY",
                safeMessage(detail, "Duplicate key violation"), request.getRequestURI());
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<Map<String, Object>> handleDataIntegrity(
            DataIntegrityViolationException exception,
            HttpServletRequest request
    ) {
        log.error("DataIntegrityViolationException at path={}", request.getRequestURI(), exception);

        Throwable root = getRootCause(exception);

        if (root instanceof PropertyValueException ex) {
            return build(
                    HttpStatus.BAD_REQUEST,
                    "NOT_NULL_VIOLATION",
                    ex.getPropertyName() + " is required",
                    request.getRequestURI()
            );
        }

        if (root instanceof org.hibernate.exception.ConstraintViolationException ex) {
            return handleHibernateConstraintViolation(ex, request);
        }

        if (root instanceof DataException ex) {
            return handleHibernateDataException(ex, request);
        }

        String detail = extractDetailedDatabaseMessage(root);
        if (detail != null) {
            HttpStatus status = inferStatusFromMessage(detail);
            return build(status, inferCodeFromStatus(status), detail, request.getRequestURI());
        }

        return build(HttpStatus.BAD_REQUEST, "DATA_INTEGRITY_VIOLATION",
                "Database integrity violation", request.getRequestURI());
    }

    @ExceptionHandler(TransactionSystemException.class)
    public ResponseEntity<Map<String, Object>> handleTransactionSystem(
            TransactionSystemException exception,
            HttpServletRequest request
    ) {
        log.error("TransactionSystemException at path={}", request.getRequestURI(), exception);

        Throwable root = getRootCause(exception);

        if (root instanceof ConstraintViolationException ex) {
            String message = ex.getConstraintViolations()
                    .stream()
                    .map(this::toValidationMessage)
                    .collect(Collectors.joining("; "));
            return build(HttpStatus.BAD_REQUEST, "VALIDATION_CONSTRAINT_VIOLATION",
                    safeMessage(message, "Transaction validation failed"), request.getRequestURI());
        }

        String detail = extractDetailedDatabaseMessage(root);
        if (detail != null) {
            HttpStatus status = inferStatusFromMessage(detail);
            return build(status, inferCodeFromStatus(status), detail, request.getRequestURI());
        }

        return build(HttpStatus.BAD_REQUEST, "TRANSACTION_SYSTEM_ERROR",
                "Transaction failed", request.getRequestURI());
    }

    @ExceptionHandler(JpaSystemException.class)
    public ResponseEntity<Map<String, Object>> handleJpaSystem(
            JpaSystemException exception,
            HttpServletRequest request
    ) {
        log.error("JpaSystemException at path={}", request.getRequestURI(), exception);

        Throwable root = getRootCause(exception);

        if (root instanceof PropertyValueException ex) {
            return build(
                    HttpStatus.BAD_REQUEST,
                    "NOT_NULL_VIOLATION",
                    ex.getPropertyName() + " is required",
                    request.getRequestURI()
            );
        }

        if (root instanceof org.hibernate.exception.ConstraintViolationException ex) {
            return handleHibernateConstraintViolation(ex, request);
        }

        if (root instanceof DataException ex) {
            return handleHibernateDataException(ex, request);
        }

        String detail = extractDetailedDatabaseMessage(root);
        if (detail != null) {
            HttpStatus status = inferStatusFromMessage(detail);
            return build(status, inferCodeFromStatus(status), detail, request.getRequestURI());
        }

        return build(HttpStatus.BAD_REQUEST, "JPA_SYSTEM_ERROR",
                "Persistence error", request.getRequestURI());
    }

    @ExceptionHandler(PersistenceException.class)
    public ResponseEntity<Map<String, Object>> handlePersistence(
            PersistenceException exception,
            HttpServletRequest request
    ) {
        log.error("PersistenceException at path={}", request.getRequestURI(), exception);

        Throwable root = getRootCause(exception);

        if (root instanceof org.hibernate.exception.ConstraintViolationException ex) {
            return handleHibernateConstraintViolation(ex, request);
        }

        if (root instanceof DataException ex) {
            return handleHibernateDataException(ex, request);
        }

        if (root instanceof PropertyValueException ex) {
            return build(
                    HttpStatus.BAD_REQUEST,
                    "NOT_NULL_VIOLATION",
                    ex.getPropertyName() + " is required",
                    request.getRequestURI()
            );
        }

        String detail = extractDetailedDatabaseMessage(root);
        if (detail != null) {
            HttpStatus status = inferStatusFromMessage(detail);
            return build(status, inferCodeFromStatus(status), detail, request.getRequestURI());
        }

        return build(HttpStatus.BAD_REQUEST, "PERSISTENCE_ERROR",
                "Persistence error", request.getRequestURI());
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleUnknown(
            Exception exception,
            HttpServletRequest request
    ) {
        log.error("Unhandled exception at path={}", request.getRequestURI(), exception);

        Throwable root = getRootCause(exception);
        String detail = extractDetailedDatabaseMessage(root);

        if (detail != null) {
            HttpStatus status = inferStatusFromMessage(detail);
            return build(status, inferCodeFromStatus(status), detail, request.getRequestURI());
        }

        return build(
                HttpStatus.INTERNAL_SERVER_ERROR,
                "INTERNAL_SERVER_ERROR",
                "Unexpected internal server error",
                request.getRequestURI()
        );
    }

    private ResponseEntity<Map<String, Object>> handleHibernateConstraintViolation(
            org.hibernate.exception.ConstraintViolationException ex,
            HttpServletRequest request
    ) {
        String detail = buildConstraintViolationMessage(ex);
        HttpStatus status = inferStatusFromMessage(detail);
        return build(status, inferCodeFromStatus(status), detail, request.getRequestURI());
    }

    private ResponseEntity<Map<String, Object>> handleHibernateDataException(
            DataException ex,
            HttpServletRequest request
    ) {
        String detail = buildDataExceptionMessage(ex);
        return build(HttpStatus.BAD_REQUEST, "DATA_EXCEPTION", detail, request.getRequestURI());
    }

    private String buildConstraintViolationMessage(org.hibernate.exception.ConstraintViolationException ex) {
        String constraintName = ex.getConstraintName();
        SQLException sqlEx = ex.getSQLException();
        String raw = sqlEx != null ? sqlEx.getMessage() : ex.getMessage();

        String parsed = parsePostgresConstraintMessage(raw);
        if (parsed != null) {
            return parsed;
        }

        if (constraintName != null && !constraintName.isBlank()) {
            return "Database constraint violated: " + constraintName;
        }

        return safeMessage(raw, "Database constraint violation");
    }

    private String buildDataExceptionMessage(DataException ex) {
        SQLException sqlEx = ex.getSQLException();
        String raw = sqlEx != null ? sqlEx.getMessage() : ex.getMessage();

        String parsed = parsePostgresDataMessage(raw);
        if (parsed != null) {
            return parsed;
        }

        return safeMessage(raw, "Invalid database value");
    }

    private String extractDetailedDatabaseMessage(Throwable throwable) {
        if (throwable == null) {
            return null;
        }

        if (throwable instanceof SQLException ex) {
            String parsedConstraint = parsePostgresConstraintMessage(ex.getMessage());
            if (parsedConstraint != null) {
                return parsedConstraint;
            }
            String parsedData = parsePostgresDataMessage(ex.getMessage());
            if (parsedData != null) {
                return parsedData;
            }
            return sanitize(ex.getMessage());
        }

        if (throwable instanceof PropertyValueException ex) {
            return ex.getPropertyName() + " is required";
        }

        if (throwable instanceof org.hibernate.exception.ConstraintViolationException ex) {
            return buildConstraintViolationMessage(ex);
        }

        if (throwable instanceof DataException ex) {
            return buildDataExceptionMessage(ex);
        }

        String msg = throwable.getMessage();
        if (msg == null || msg.isBlank()) {
            return null;
        }

        String generic = parseGenericConstraintMessage(msg);
        if (generic != null) {
            return generic;
        }

        String parsedConstraint = parsePostgresConstraintMessage(msg);
        if (parsedConstraint != null) {
            return parsedConstraint;
        }

        String parsedData = parsePostgresDataMessage(msg);
        if (parsedData != null) {
            return parsedData;
        }

        return sanitize(msg);
    }

    private String parseGenericConstraintMessage(String message) {
        if (message == null || message.isBlank()) {
            return null;
        }

        String m = message.toLowerCase();

        if (m.contains("unique index or primary key violation")) {
            return "Duplicate value violates unique constraint";
        }

        if (m.contains("referential integrity constraint violation")) {
            return "Foreign key constraint violation";
        }

        if (m.contains("not null")) {
            return "Required field is missing";
        }

        return null;
    }

    private String parsePostgresConstraintMessage(String message) {
        if (message == null || message.isBlank()) {
            return null;
        }

        Matcher duplicateMatcher = PG_DUPLICATE_DETAIL.matcher(message);
        if (duplicateMatcher.find()) {
            String fields = duplicateMatcher.group(1);
            String values = duplicateMatcher.group(2);
            return "Duplicate value for unique field(s): " + fields + " = " + values;
        }

        Matcher fkInsertMatcher = PG_FK_DETAIL.matcher(message);
        if (fkInsertMatcher.find()) {
            String field = fkInsertMatcher.group(1);
            String value = fkInsertMatcher.group(2);
            String table = fkInsertMatcher.group(3);
            return "Foreign key violation: field " + field + " = " + value + " does not exist in table " + table;
        }

        Matcher fkDeleteMatcher = PG_FK_DELETE_DETAIL.matcher(message);
        if (fkDeleteMatcher.find()) {
            String field = fkDeleteMatcher.group(1);
            String value = fkDeleteMatcher.group(2);
            String table = fkDeleteMatcher.group(3);
            return "Foreign key violation: field " + field + " = " + value + " is still referenced by table " + table;
        }

        Matcher notNullMatcher = PG_NOT_NULL_DETAIL.matcher(message);
        if (notNullMatcher.find()) {
            String field = notNullMatcher.group(1);
            return field + " is required";
        }

        if (message.contains("violates check constraint")) {
            return sanitize(message);
        }

        return null;
    }

    private String parsePostgresDataMessage(String message) {
        if (message == null || message.isBlank()) {
            return null;
        }

        Matcher tooLongMatcher = PG_VALUE_TOO_LONG.matcher(message);
        if (tooLongMatcher.find()) {
            return "Value is too long for database column type: " + tooLongMatcher.group(1);
        }

        Matcher invalidInputMatcher = PG_INVALID_INPUT.matcher(message);
        if (invalidInputMatcher.find()) {
            String type = invalidInputMatcher.group(1);
            String value = invalidInputMatcher.group(2);
            return "Invalid value '" + value + "' for database type " + type;
        }

        Matcher notNullMatcher = PG_NOT_NULL_DETAIL.matcher(message);
        if (notNullMatcher.find()) {
            return notNullMatcher.group(1) + " is required";
        }

        Matcher overflowMatcher = PG_NUMERIC_OVERFLOW.matcher(message);
        if (overflowMatcher.find()) {
            return "Numeric value is out of range";
        }

        if (message.contains("not-null property references a null or transient value")) {
            return sanitize(message);
        }

        return null;
    }

    private HttpStatus inferStatusFromMessage(String message) {
        if (message == null) {
            return HttpStatus.BAD_REQUEST;
        }
        String m = message.toLowerCase();

        if (m.contains("duplicate")
                || m.contains("already exists")
                || m.contains("unique")
                || m.contains("primary key violation")
                || m.contains("foreign key")
                || m.contains("referential integrity")
                || m.contains("still referenced")
                || m.contains("constraint violation")) {
            return HttpStatus.CONFLICT;
        }

        return HttpStatus.BAD_REQUEST;
    }

    private String inferCodeFromStatus(HttpStatus status) {
        return status == HttpStatus.CONFLICT ? "DATABASE_CONFLICT" : "DATABASE_ERROR";
    }

    private String toValidationMessage(ConstraintViolation<?> violation) {
        String path = violation.getPropertyPath() != null ? violation.getPropertyPath().toString() : "field";
        String msg = safeMessage(violation.getMessage(), "invalid");
        return path + ": " + msg;
    }

    private ResponseEntity<Map<String, Object>> build(
            HttpStatus status,
            String code,
            String message,
            String path
    ) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", OffsetDateTime.now().toString());
        body.put("traceId", UUID.randomUUID().toString());
        body.put("status", status.value());
        body.put("error", code);
        body.put("message", message);
        body.put("path", path);
        return ResponseEntity.status(status).body(body);
    }

    private Throwable getRootCause(Throwable throwable) {
        Throwable result = throwable;
        while (result.getCause() != null && result.getCause() != result) {
            result = result.getCause();
        }
        return result;
    }

    private String safeMessage(String value, String fallback) {
        return (value == null || value.isBlank()) ? fallback : value;
    }

    private String sanitize(String message) {
        return message == null ? null : message.trim();
    }
}