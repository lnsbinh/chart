package com.tms.all.controller;

import com.tms.security.config.AppSecurityContextHolder;
import com.tms.modules.iam.dto.AppSecurityContext;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/secure")
public class SecureController {

    @GetMapping("/me")
    public Map<String, Object> me(@AuthenticationPrincipal Jwt jwt) {
        AppSecurityContext context = AppSecurityContextHolder.getRequired();
        Map<String, Object> response = new LinkedHashMap<>();
        response.put("sub", jwt.getSubject());
        response.put("preferred_username", jwt.getClaimAsString("preferred_username"));
        response.put("azp", jwt.getClaimAsString("azp"));
        response.put("appSecurityContext", context);
        return response;
    }
}
