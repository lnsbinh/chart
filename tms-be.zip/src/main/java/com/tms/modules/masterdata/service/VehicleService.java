package com.tms.modules.masterdata.service;

import com.tms.modules.masterdata.dto.PagedResponse;
import com.tms.shared.model.masterdata.VehicleEntity;
import com.tms.modules.masterdata.repository.VehicleRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.UUID;

@Service
public class VehicleService {

    private final VehicleRepository repository;

    public VehicleService(VehicleRepository repository) {
        this.repository = repository;
    }

    public PagedResponse<VehicleEntity> search(
            String keyword,
            String vehicleType,
            UUID ownerBranchId,
            Boolean activeFlag,
            Pageable pageable
    ) {
        Pageable safePageable = normalizePageable(pageable, Sort.by("licensePlate").ascending());
        String keywordLike = normalizeLike(keyword);

        return PagedResponse.from(
                repository.search(
                        keywordLike,
                        normalize(vehicleType),
                        ownerBranchId,
                        activeFlag,
                        safePageable
                )
        );
    }

    public VehicleEntity get(UUID id) {
        return repository.findById(id).orElseThrow();
    }

    public VehicleEntity create(VehicleEntity entity) {
        return repository.save(entity);
    }

    public VehicleEntity update(UUID id, VehicleEntity request) {
        VehicleEntity entity = get(id);

        entity.setLicensePlate(request.getLicensePlate());
        entity.setVehicleName(request.getVehicleName());
        entity.setVehicleType(request.getVehicleType());
        entity.setBrandModel(request.getBrandModel());
        entity.setProductionYear(request.getProductionYear());
        entity.setCapacityKg(request.getCapacityKg());
        entity.setVolumeM3(request.getVolumeM3());
        entity.setFuelType(request.getFuelType());
        entity.setFuelNorm(request.getFuelNorm());
        entity.setOwnerBranch(request.getOwnerBranch());
        entity.setGpsDeviceCode(request.getGpsDeviceCode());
        entity.setRegistryExpiry(request.getRegistryExpiry());
        entity.setInsuranceExpiry(request.getInsuranceExpiry());
        entity.setActiveFlag(request.getActiveFlag());

        return repository.save(entity);
    }

    public VehicleEntity deactivate(UUID id) {
        VehicleEntity entity = get(id);
        entity.setDeleted(false);

        return repository.save(entity);
    }

    private Pageable normalizePageable(Pageable pageable, Sort defaultSort) {
        if (pageable == null) {
            return PageRequest.of(0, 20, defaultSort);
        }
        Sort sort = pageable.getSort().isSorted() ? pageable.getSort() : defaultSort;
        return PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), sort);
    }

    private String normalize(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    private String normalizeLike(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        return "%" + value.trim().toLowerCase() + "%";
    }
}