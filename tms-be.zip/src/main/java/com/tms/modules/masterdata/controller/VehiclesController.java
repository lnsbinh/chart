package com.tms.modules.masterdata.controller;

import com.tms.modules.masterdata.dto.PagedResponse;
import com.tms.shared.model.masterdata.VehicleEntity;
import com.tms.modules.masterdata.service.VehicleService;
import com.tms.security.annotation.RequireAnyPermission;
import com.tms.security.annotation.RequireAnyRole;
import com.tms.modules.iam.constants.RoleCodes;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/master-data/vehicles")
@RequireAnyRole({
        RoleCodes.SUPER_ADMIN,
        RoleCodes.ORG_ADMIN,
        RoleCodes.SUPERVISOR,
        RoleCodes.DISPATCHER,
        RoleCodes.OPERATION_STAFF,
        RoleCodes.FINANCE_OPS
})
@RequireAnyPermission({"vehicle.read", "vehicle.all"})
@Tag(name = "Master Data - Vehicles")
public class VehiclesController {

    private final VehicleService service;

    public VehiclesController(VehicleService service) {
        this.service = service;
    }

    @GetMapping
    @Operation(summary = "Search vehicles with paging")
    public PagedResponse<VehicleEntity> list(
            @Parameter(
                    description = "Search by vehicle name, license plate, brand model, or GPS device code",
                    schema = @Schema(defaultValue = "HCM"))
            @RequestParam(required = false) String keyword,

            @Parameter(
                    description = "Vehicle type",
                    schema = @Schema(defaultValue = "LIGHT_TRUCK"))
            @RequestParam(required = false) String vehicleType,

            @Parameter(
                    description = "Owner branch ID",
                    schema = @Schema(example = "00000000-0000-0000-0000-000000000002"))
            @RequestParam(required = false) UUID ownerBranchId,

            @Parameter(
                    description = "Active flag",
                    schema = @Schema(defaultValue = "true"))
            @RequestParam(required = false) Boolean activeFlag,

            @ParameterObject
            @PageableDefault(size = 20, sort = "licensePlate") Pageable pageable
    ) {
        return service.search(keyword, vehicleType, ownerBranchId, activeFlag, pageable);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get vehicle by ID")
    public VehicleEntity get(
            @Parameter(description = "Vehicle ID", schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id
    ) {
        return service.get(id);
    }

    @PostMapping
    @RequireAnyRole({RoleCodes.SUPER_ADMIN, RoleCodes.ORG_ADMIN, RoleCodes.OPERATION_STAFF})
    @RequireAnyPermission({"vehicle.update", "vehicle.all"})
    @Operation(summary = "Create vehicle")
    public VehicleEntity create(@RequestBody VehicleEntity request) {
        return service.create(request);
    }

    @PutMapping("/{id}")
    @RequireAnyRole({RoleCodes.SUPER_ADMIN, RoleCodes.ORG_ADMIN, RoleCodes.OPERATION_STAFF})
    @RequireAnyPermission({"vehicle.update", "vehicle.all"})
    @Operation(summary = "Update vehicle")
    public VehicleEntity update(
            @Parameter(description = "Vehicle ID", schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id,
            @RequestBody VehicleEntity request
    ) {
        return service.update(id, request);
    }

    @PatchMapping("/{id}/deactivate")
    @RequireAnyRole({RoleCodes.SUPER_ADMIN, RoleCodes.ORG_ADMIN, RoleCodes.OPERATION_STAFF})
    @RequireAnyPermission({"vehicle.delete", "vehicle.all"})
    @Operation(summary = "Deactivate vehicle")
    public VehicleEntity deactivate(
            @Parameter(description = "Vehicle ID", schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id
    ) {
        return service.deactivate(id);
    }
}
