package com.tms.modules.masterdata.service;

import com.tms.modules.masterdata.dto.PagedResponse;
import com.tms.shared.model.masterdata.RouteEntity;
import com.tms.modules.masterdata.repository.RouteRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class RouteService {

    private final RouteRepository repository;

    public RouteService(RouteRepository repository) {
        this.repository = repository;
    }

    public PagedResponse<RouteEntity> search(
            String keyword,
            UUID originLocationId,
            UUID destinationLocationId,
            Boolean preferredFlag,
            Boolean activeFlag,
            Pageable pageable
    ) {
        Pageable safePageable = normalizePageable(pageable, Sort.by("routeName").ascending());
        String keywordLike = normalizeLike(keyword);

        return PagedResponse.from(
                repository.search(
                        keywordLike,
                        originLocationId,
                        destinationLocationId,
                        preferredFlag,
                        activeFlag,
                        safePageable
                )
        );
    }

    public RouteEntity get(UUID id) {
        return repository.findById(id).orElseThrow();
    }

    public RouteEntity create(RouteEntity entity) {
        return repository.save(entity);
    }

    public RouteEntity update(UUID id, RouteEntity request) {
        RouteEntity entity = get(id);

        entity.setRouteName(request.getRouteName());
        entity.setOriginLocation(request.getOriginLocation());
        entity.setDestinationLocation(request.getDestinationLocation());
        entity.setDistanceKm(request.getDistanceKm());
        entity.setStdTransitTime(request.getStdTransitTime());
        entity.setTollCost(request.getTollCost());
        entity.setRouteRiskNote(request.getRouteRiskNote());
        entity.setForbiddenHours(request.getForbiddenHours());
        entity.setPreferredFlag(request.getPreferredFlag());
        entity.setActiveFlag(request.getActiveFlag());

        return repository.save(entity);
    }

    public RouteEntity deactivate(UUID id) {
        RouteEntity entity = get(id);
        entity.setActiveFlag(false);
        return repository.save(entity);
    }

    private Pageable normalizePageable(Pageable pageable, Sort defaultSort) {
        if (pageable == null) {
            return PageRequest.of(0, 20, defaultSort);
        }
        Sort sort = pageable.getSort().isSorted() ? pageable.getSort() : defaultSort;
        return PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), sort);
    }

    private String normalize(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    private String normalizeLike(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        return "%" + value.trim().toLowerCase() + "%";
    }
}
