package com.tms.modules.masterdata.service;

import com.tms.modules.masterdata.dto.PagedResponse;
import com.tms.shared.model.masterdata.RouteEntity;
import com.tms.modules.masterdata.repository.RouteRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class RouteService {
    private final RouteRepository repository;

    public RouteService(RouteRepository repository) { this.repository = repository; }

    public PagedResponse<RouteEntity> search(UUID organizationId, String keyword, String statusCode, UUID originLocationId, UUID destinationLocationId, Pageable pageable) {
        Pageable safePageable = normalizePageable(pageable, Sort.by("routeCode").ascending());
        return PagedResponse.from(repository.search(organizationId, normalize(keyword), normalize(statusCode), originLocationId, destinationLocationId, safePageable));
    }

    public RouteEntity get(UUID organizationId, UUID id) {
        return repository.findByIdAndOrganizationId(id, organizationId).orElseThrow();
    }

    public RouteEntity create(RouteEntity entity) { return repository.save(entity); }

    public RouteEntity update(UUID organizationId, UUID id, RouteEntity request) {
        RouteEntity entity = get(organizationId, id);
        entity.setRouteCode(request.getRouteCode());
        entity.setRouteName(request.getRouteName());
        entity.setOriginLocationId(request.getOriginLocationId());
        entity.setDestinationLocationId(request.getDestinationLocationId());
        entity.setStandardKm(request.getStandardKm());
        entity.setStandardDurationMinutes(request.getStandardDurationMinutes());
        entity.setStatusCode(request.getStatusCode());
        return repository.save(entity);
    }

    public RouteEntity deactivate(UUID organizationId, UUID id) {
        RouteEntity entity = get(organizationId, id);
        entity.setStatusCode("INACTIVE");
        return repository.save(entity);
    }

    private Pageable normalizePageable(Pageable pageable, Sort defaultSort) {
        if (pageable == null) {
            return PageRequest.of(0, 20, defaultSort);
        }
        Sort sort = pageable.getSort().isSorted() ? pageable.getSort() : defaultSort;
        return PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), sort);
    }

    private String normalize(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}
