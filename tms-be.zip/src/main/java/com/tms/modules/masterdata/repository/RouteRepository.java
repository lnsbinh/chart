package com.tms.modules.masterdata.repository;

import com.tms.shared.model.masterdata.RouteEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface RouteRepository extends JpaRepository<RouteEntity, UUID> {

    @Query("""
        select r
        from RouteEntity r
        where (
                :keywordLike is null
                or lower(coalesce(r.routeName, '')) like :keywordLike
        )
          and (:originLocationId is null or r.originLocation.id = :originLocationId)
          and (:destinationLocationId is null or r.destinationLocation.id = :destinationLocationId)
          and (:preferredFlag is null or r.preferredFlag = :preferredFlag)
          and (:activeFlag is null or r.activeFlag = :activeFlag)
    """)
    Page<RouteEntity> search(
            @Param("keywordLike") String keywordLike,
            @Param("originLocationId") UUID originLocationId,
            @Param("destinationLocationId") UUID destinationLocationId,
            @Param("preferredFlag") Boolean preferredFlag,
            @Param("activeFlag") Boolean activeFlag,
            Pageable pageable
    );
}
