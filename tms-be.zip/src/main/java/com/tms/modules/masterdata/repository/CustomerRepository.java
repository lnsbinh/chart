package com.tms.modules.masterdata.repository;

import com.tms.shared.model.masterdata.CustomerEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface CustomerRepository extends JpaRepository<CustomerEntity, UUID> {

    @Query("""
        select c
        from CustomerEntity c
        where c.deleted = false
          and (
                :keywordLike is null
                or lower(coalesce(c.customerName, '')) like :keywordLike
                or lower(coalesce(c.contactPerson, '')) like :keywordLike
                or lower(coalesce(c.customerContactPhone, '')) like :keywordLike
                or lower(coalesce(c.customerEmail, '')) like :keywordLike
                or lower(coalesce(c.address, '')) like :keywordLike
                or lower(coalesce(c.pickupAddress, '')) like :keywordLike
          )
    """)
    Page<CustomerEntity> search(
            String keywordLike,
            Pageable pageable
    );

    Optional<CustomerEntity> findByCustomerIdAndDeletedFalse(UUID customerId);
}
