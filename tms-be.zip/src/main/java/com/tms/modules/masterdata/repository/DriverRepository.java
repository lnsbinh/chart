package com.tms.modules.masterdata.repository;

import com.tms.shared.model.masterdata.DriverEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface DriverRepository extends JpaRepository<DriverEntity, UUID> {

    @Query("""
        select d
        from DriverEntity d
        where (
                :keywordLike is null
                or lower(coalesce(d.fullName, '')) like :keywordLike
                or lower(coalesce(d.phoneNumber, '')) like :keywordLike
                or lower(coalesce(d.idNumber, '')) like :keywordLike
                or lower(coalesce(d.licenseNumber, '')) like :keywordLike
                or lower(coalesce(d.appUsername, '')) like :keywordLike
        )
          and (:licenseClass is null or d.licenseClass = :licenseClass)
          and (:employmentType is null or d.employmentType = :employmentType)
          and (:driverGroup is null or d.driverGroup = :driverGroup)
          and (:activeFlag is null or d.activeFlag = :activeFlag)
          and d.deleted = false
    """)
    Page<DriverEntity> search(
            @Param("keywordLike") String keywordLike,
            @Param("licenseClass") String licenseClass,
            @Param("employmentType") String employmentType,
            @Param("driverGroup") String driverGroup,
            @Param("activeFlag") Boolean activeFlag,
            Pageable pageable
    );
}
