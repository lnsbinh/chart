package com.tms.modules.masterdata.repository;

import com.tms.shared.model.masterdata.BusinessPartnerContactEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface BusinessPartnerContactRepository extends JpaRepository<BusinessPartnerContactEntity, UUID> {
    List<BusinessPartnerContactEntity> findByBusinessPartnerIdOrderByFullName(UUID businessPartnerId);
}
