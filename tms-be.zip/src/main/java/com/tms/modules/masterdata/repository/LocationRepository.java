package com.tms.modules.masterdata.repository;

import com.tms.shared.model.masterdata.LocationEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;
import java.util.UUID;

public interface LocationRepository extends JpaRepository<LocationEntity, UUID> {
    @Query("""
            select l
            from LocationEntity l
            where l.organizationId = :organizationId
              and (:keyword is null or lower(l.locationCode) like lower(concat('%', :keyword, '%'))
                   or lower(l.locationName) like lower(concat('%', :keyword, '%'))
                   or lower(coalesce(l.address, '')) like lower(concat('%', :keyword, '%')))
              and (:locationType is null or l.locationType = :locationType)
              and (:statusCode is null or l.statusCode = :statusCode)
            """)
    Page<LocationEntity> search(
            @Param("organizationId") UUID organizationId,
            @Param("keyword") String keyword,
            @Param("locationType") String locationType,
            @Param("statusCode") String statusCode,
            Pageable pageable
    );

    Optional<LocationEntity> findByIdAndOrganizationId(UUID id, UUID organizationId);
}
