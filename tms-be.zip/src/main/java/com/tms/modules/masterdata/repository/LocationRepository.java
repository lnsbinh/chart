package com.tms.modules.masterdata.repository;

import com.tms.shared.model.masterdata.LocationEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface LocationRepository extends JpaRepository<LocationEntity, UUID> {

        //     where (:keyword is null
        //         or lower(coalesce(l.locationName, '')) like lower(concat('%', :keyword, '%'))
        //         or lower(coalesce(l.address, '')) like lower(concat('%', :keyword, '%')))
        // and (:locationType is null or l.locationType = :locationType)
        // and (:statusCode is null or l.statusCode = :statusCode)
    @Query("""
        select l
        from LocationEntity l
        where activeFlag = true
    """)
    Page<LocationEntity> search(
            @Param("keyword") String keyword,
            @Param("locationType") String locationType,
            @Param("statusCode") String statusCode,
            Pageable pageable
    );

    Optional<LocationEntity> findById(UUID id);
}
