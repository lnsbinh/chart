package com.tms.modules.masterdata.service;

import com.tms.modules.masterdata.dto.PagedResponse;
import com.tms.modules.masterdata.repository.DriverRepository;
import com.tms.shared.model.masterdata.DriverEntity;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class DriverService {

    private final DriverRepository repository;

    public DriverService(DriverRepository repository) {
        this.repository = repository;
    }

    public PagedResponse<DriverEntity> search(
            String keyword,
            String licenseClass,
            String employmentType,
            String driverGroup,
            Boolean activeFlag,
            Pageable pageable
    ) {
        Pageable safePageable = normalizePageable(pageable, Sort.by("fullName").ascending());
        String keywordLike = normalizeLike(keyword);

        return PagedResponse.from(
                repository.search(
                        keywordLike,
                        normalize(licenseClass),
                        normalize(employmentType),
                        normalize(driverGroup),
                        activeFlag,
                        safePageable
                )
        );
    }

    public DriverEntity get(UUID id) {
        return repository.findById(id).orElseThrow();
    }

    public DriverEntity create(DriverEntity entity) {
        return repository.save(entity);
    }

    public DriverEntity update(UUID id, DriverEntity request) {
        DriverEntity entity = get(id);

        entity.setFullName(request.getFullName());
        entity.setPhoneNumber(request.getPhoneNumber());
        entity.setIdNumber(request.getIdNumber());

        entity.setLicenseClass(request.getLicenseClass());
        entity.setLicenseNumber(request.getLicenseNumber());
        entity.setLicenseExpiry(request.getLicenseExpiry());

        entity.setEmploymentType(request.getEmploymentType());
        entity.setDriverGroup(request.getDriverGroup());
        entity.setFamiliarRoutes(request.getFamiliarRoutes());
        entity.setJoinDate(request.getJoinDate());

        entity.setActiveFlag(request.getActiveFlag());
        entity.setAppUsername(request.getAppUsername());

        return repository.save(entity);
    }

    public DriverEntity deactivate(UUID id) {
        DriverEntity entity = get(id);
        entity.setDeleted(false);

        return repository.save(entity);
    }

    private Pageable normalizePageable(Pageable pageable, Sort defaultSort) {
        if (pageable == null) {
            return PageRequest.of(0, 20, defaultSort);
        }
        Sort sort = pageable.getSort().isSorted() ? pageable.getSort() : defaultSort;
        return PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), sort);
    }

    private String normalize(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    private String normalizeLike(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        return "%" + value.trim().toLowerCase() + "%";
    }
}
