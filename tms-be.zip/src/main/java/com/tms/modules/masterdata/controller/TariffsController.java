package com.tms.modules.masterdata.controller;

import com.tms.shared.model.masterdata.TariffEntity;
import com.tms.modules.masterdata.service.TariffService;
import com.tms.security.annotation.RequireAnyPermission;
import com.tms.security.annotation.RequireAnyRole;
import com.tms.modules.iam.constants.RoleCodes;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/master-data/tariffs")
@RequireAnyRole({
        RoleCodes.SUPER_ADMIN,
        RoleCodes.ORG_ADMIN,
        RoleCodes.SUPERVISOR,
        RoleCodes.DISPATCHER,
        RoleCodes.OPERATION_STAFF,
        RoleCodes.FINANCE_OPS
})
@RequireAnyPermission({"tariff.read", "tariff.all"})
@Tag(name = "Master Data - Tariffs")
public class TariffsController {
    private final TariffService service;

    public TariffsController(TariffService service) { this.service = service; }

    @GetMapping
    @Operation(summary = "List tariffs")
    public List<TariffEntity> list(
            @Parameter(description = "Organization ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000001"))
            @RequestParam UUID organizationId,
            @Parameter(description = "Tariff status", schema = @Schema(defaultValue = "ACTIVE"))
            @RequestParam(required = false) String statusCode,
            @Parameter(description = "Effective date", schema = @Schema(type = "string", format = "date", defaultValue = "2026-04-01"))
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate effectiveDate) {
        return service.list(organizationId, statusCode, effectiveDate);
    }

    @PostMapping
    @RequireAnyRole({RoleCodes.SUPER_ADMIN, RoleCodes.ORG_ADMIN, RoleCodes.OPERATION_STAFF})
    @RequireAnyPermission({"tariff.update", "tariff.all"})
    @Operation(summary = "Create tariff")
    public TariffEntity create(@RequestBody TariffEntity request) { return service.create(request); }

    @PutMapping("/{id}")
    @RequireAnyRole({RoleCodes.SUPER_ADMIN, RoleCodes.ORG_ADMIN, RoleCodes.OPERATION_STAFF})
    @RequireAnyPermission({"tariff.update", "tariff.all"})
    @Operation(summary = "Update tariff")
    public TariffEntity update(
            @Parameter(description = "Tariff ID", schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id,
            @RequestBody TariffEntity request) { return service.update(id, request); }

    @PatchMapping("/{id}/deactivate")
    @RequireAnyRole({RoleCodes.SUPER_ADMIN, RoleCodes.ORG_ADMIN, RoleCodes.OPERATION_STAFF})
    @RequireAnyPermission({"tariff.delete", "tariff.all"})
    @Operation(summary = "Deactivate tariff")
    public TariffEntity deactivate(
            @Parameter(description = "Tariff ID", schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id) { return service.deactivate(id); }
}
