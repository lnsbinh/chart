package com.tms.modules.masterdata.repository;

import com.tms.shared.model.masterdata.VehicleEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface VehicleRepository extends JpaRepository<VehicleEntity, UUID> {

    @Query("""
        select v
        from VehicleEntity v
        where (
                :keywordLike is null
                or lower(coalesce(v.vehicleName, '')) like :keywordLike
                or lower(coalesce(v.licensePlate, '')) like :keywordLike
                or lower(coalesce(v.brandModel, '')) like :keywordLike
                or lower(coalesce(v.gpsDeviceCode, '')) like :keywordLike
        )
          and (:vehicleType is null or v.vehicleType = :vehicleType)
          and (:ownerBranchId is null or v.ownerBranch.id = :ownerBranchId)
          and (:activeFlag is null or v.activeFlag = :activeFlag)
          and v.deleted = false
    """)
    Page<VehicleEntity> search(
            @Param("keywordLike") String keywordLike,
            @Param("vehicleType") String vehicleType,
            @Param("ownerBranchId") UUID ownerBranchId,
            @Param("activeFlag") Boolean activeFlag,
            Pageable pageable
    );
}
