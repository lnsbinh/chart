package com.tms.modules.masterdata.service;

import com.tms.shared.model.masterdata.ReferenceDataItemEntity;
import com.tms.modules.masterdata.repository.ReferenceDataItemRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class ReferenceDataItemService {

    private static final String STATUS_ACTIVE = "ACTIVE";
    private static final String STATUS_INACTIVE = "INACTIVE";

    public static final String GROUP_BUSINESS_PARTNER_TYPE = "BUSINESS_PARTNER_TYPE";
    public static final String GROUP_LOCATION_TYPE = "LOCATION_TYPE";
    public static final String GROUP_VEHICLE_TYPE = "VEHICLE_TYPE";
    public static final String GROUP_DRIVER_TYPE = "DRIVER_TYPE";
    public static final String GROUP_CONTAINER_TYPE = "CONTAINER_TYPE";
    public static final String GROUP_SURCHARGE_CHARGE_METHOD = "SURCHARGE_CHARGE_METHOD";

    private final ReferenceDataItemRepository repository;

    public ReferenceDataItemService(ReferenceDataItemRepository repository) {
        this.repository = repository;
    }

    @Transactional(readOnly = true)
    public List<ReferenceDataItemEntity> getActiveByGroup(String groupCode) {
        return repository.findByGroupCodeAndStatusCodeOrderBySortOrderAscItemCodeAsc(
                        normalize(groupCode), STATUS_ACTIVE)
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public List<ReferenceDataItemEntity> getAllByGroup(String groupCode) {
        return repository.findByGroupCodeOrderBySortOrderAscItemCodeAsc(normalize(groupCode))
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public ReferenceDataItemEntity getByGroupAndCode(String groupCode, String itemCode) {
        return repository.findByGroupCodeAndItemCode(normalize(groupCode), normalize(itemCode))
                .map(this::toResponse)
                .orElseThrow(() -> new EntityNotFoundException(
                        "Reference data item not found: " + groupCode + "/" + itemCode));
    }

    public ReferenceDataItemEntity create(ReferenceDataItemEntity request) {
        validateRequest(request);

        String groupCode = normalize(request.getGroupCode());
        String itemCode = normalize(request.getItemCode());

        if (repository.existsByGroupCodeAndItemCode(groupCode, itemCode)) {
            throw new IllegalArgumentException("Reference data item already exists: " + groupCode + "/" + itemCode);
        }

        ReferenceDataItemEntity entity = new ReferenceDataItemEntity();
        apply(request, entity);
        return toResponse(repository.save(entity));
    }

    public ReferenceDataItemEntity update(String groupCode, String itemCode, ReferenceDataItemEntity request) {
        validateRequest(request);

        String normalizedGroup = normalize(groupCode);
        String normalizedItem = normalize(itemCode);

        if (!normalizedGroup.equals(normalize(request.getGroupCode()))) {
            throw new IllegalArgumentException("Path groupCode and request groupCode must match.");
        }
        if (!normalizedItem.equals(normalize(request.getItemCode()))) {
            throw new IllegalArgumentException("Path itemCode and request itemCode must match.");
        }

        ReferenceDataItemEntity entity = repository.findByGroupCodeAndItemCode(normalizedGroup, normalizedItem)
                .orElseThrow(() -> new EntityNotFoundException(
                        "Reference data item not found: " + groupCode + "/" + itemCode));

        apply(request, entity);
        return toResponse(repository.save(entity));
    }

    public ReferenceDataItemEntity activate(String groupCode, String itemCode) {
        ReferenceDataItemEntity entity = load(groupCode, itemCode);
        entity.setStatusCode(STATUS_ACTIVE);
        return toResponse(repository.save(entity));
    }

    public ReferenceDataItemEntity deactivate(String groupCode, String itemCode) {
        ReferenceDataItemEntity entity = load(groupCode, itemCode);
        entity.setStatusCode(STATUS_INACTIVE);
        return toResponse(repository.save(entity));
    }

    @Transactional(readOnly = true)
    public List<String> getAllGroups() {
        return repository.findDistinctGroupCodes();
    }

    private ReferenceDataItemEntity load(String groupCode, String itemCode) {
        return repository.findByGroupCodeAndItemCode(normalize(groupCode), normalize(itemCode))
                .orElseThrow(() -> new EntityNotFoundException(
                        "Reference data item not found: " + groupCode + "/" + itemCode));
    }

    private void validateRequest(ReferenceDataItemEntity request) {
        if (isBlank(request.getGroupCode())) {
            throw new IllegalArgumentException("groupCode is required.");
        }
        if (isBlank(request.getItemCode())) {
            throw new IllegalArgumentException("itemCode is required.");
        }
        if (isBlank(request.getNameVi())) {
            throw new IllegalArgumentException("nameVi is required.");
        }
        if (isBlank(request.getNameEn())) {
            throw new IllegalArgumentException("nameEn is required.");
        }
        if (request.getSortOrder() == null) {
            throw new IllegalArgumentException("sortOrder is required.");
        }
        if (request.getIsSystem() == null) {
            throw new IllegalArgumentException("isSystem is required.");
        }
        if (isBlank(request.getStatusCode())) {
            throw new IllegalArgumentException("statusCode is required.");
        }

        String status = normalize(request.getStatusCode());
        if (!STATUS_ACTIVE.equals(status) && !STATUS_INACTIVE.equals(status)) {
            throw new IllegalArgumentException("statusCode must be ACTIVE or INACTIVE.");
        }
    }

    private void apply(ReferenceDataItemEntity request, ReferenceDataItemEntity entity) {
        entity.setGroupCode(request.getGroupCode());
        entity.setItemCode(request.getItemCode());
        entity.setNameVi(request.getNameVi());
        entity.setNameEn(request.getNameEn());
        entity.setDescription(request.getDescription());
        entity.setSortOrder(request.getSortOrder());
        entity.setIsSystem(request.getIsSystem());
        entity.setStatusCode(request.getStatusCode());
    }

    private ReferenceDataItemEntity toResponse(ReferenceDataItemEntity entity) {
        ReferenceDataItemEntity response = new ReferenceDataItemEntity();
        response.setId(entity.getId());
        response.setGroupCode(entity.getGroupCode());
        response.setItemCode(entity.getItemCode());
        response.setNameVi(entity.getNameVi());
        response.setNameEn(entity.getNameEn());
        response.setDescription(entity.getDescription());
        response.setSortOrder(entity.getSortOrder());
        response.setIsSystem(entity.getIsSystem());
        response.setStatusCode(entity.getStatusCode());
        response.setCreatedAt(entity.getCreatedAt());
        response.setUpdatedAt(entity.getUpdatedAt());
        return response;
    }

    private String normalize(String value) {
        return value == null ? null : value.trim().toUpperCase();
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}