package com.tms.modules.masterdata.controller;

import com.tms.modules.masterdata.dto.PagedResponse;
import com.tms.shared.model.masterdata.DriverEntity;
import com.tms.modules.masterdata.service.DriverService;
import com.tms.security.annotation.RequireAnyPermission;
import com.tms.security.annotation.RequireAnyRole;
import com.tms.modules.iam.constants.RoleCodes;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/master-data/drivers")
@RequireAnyRole({
        RoleCodes.SUPER_ADMIN,
        RoleCodes.ORG_ADMIN,
        RoleCodes.SUPERVISOR,
        RoleCodes.DISPATCHER,
        RoleCodes.OPERATION_STAFF,
        RoleCodes.FINANCE_OPS
})
@RequireAnyPermission({"driver.read", "driver.all"})
@Tag(name = "Master Data - Drivers")
public class DriversController {

    private final DriverService service;

    public DriversController(DriverService service) {
        this.service = service;
    }

    @GetMapping
    @Operation(summary = "Search drivers with paging")
    public PagedResponse<DriverEntity> list(
            @Parameter(
                    description = "Search by full name, phone number, ID number, license number, or app username",
                    schema = @Schema(defaultValue = "nguyen"))
            @RequestParam(required = false) String keyword,

            @Parameter(
                    description = "License class",
                    schema = @Schema(defaultValue = "C"))
            @RequestParam(required = false) String licenseClass,

            @Parameter(
                    description = "Employment type",
                    schema = @Schema(defaultValue = "FULL_TIME"))
            @RequestParam(required = false) String employmentType,

            @Parameter(
                    description = "Driver group",
                    schema = @Schema(defaultValue = "HCM_LineA"))
            @RequestParam(required = false) String driverGroup,

            @Parameter(
                    description = "Active flag",
                    schema = @Schema(defaultValue = "true"))
            @RequestParam(required = false) Boolean activeFlag,

            @ParameterObject
            @PageableDefault(size = 20, sort = "fullName") Pageable pageable
    ) {
        return service.search(keyword, licenseClass, employmentType, driverGroup, activeFlag, pageable);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get driver by ID")
    public DriverEntity get(
            @Parameter(
                    description = "Driver ID",
                    schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id
    ) {
        return service.get(id);
    }

    @PostMapping
    @RequireAnyRole({RoleCodes.SUPER_ADMIN, RoleCodes.ORG_ADMIN, RoleCodes.OPERATION_STAFF})
    @RequireAnyPermission({"driver.update", "driver.all"})
    @Operation(summary = "Create driver")
    public DriverEntity create(@RequestBody DriverEntity request) {
        return service.create(request);
    }

    @PutMapping("/{id}")
    @RequireAnyRole({RoleCodes.SUPER_ADMIN, RoleCodes.ORG_ADMIN, RoleCodes.OPERATION_STAFF})
    @RequireAnyPermission({"driver.update", "driver.all"})
    @Operation(summary = "Update driver")
    public DriverEntity update(
            @Parameter(
                    description = "Driver ID",
                    schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id,
            @RequestBody DriverEntity request
    ) {
        return service.update(id, request);
    }

    @PatchMapping("/{id}/deactivate")
    @RequireAnyRole({RoleCodes.SUPER_ADMIN, RoleCodes.ORG_ADMIN, RoleCodes.OPERATION_STAFF})
    @RequireAnyPermission({"driver.delete", "driver.all"})
    @Operation(summary = "Deactivate driver")
    public DriverEntity deactivate(
            @Parameter(
                    description = "Driver ID",
                    schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id
    ) {
        return service.deactivate(id);
    }
}
