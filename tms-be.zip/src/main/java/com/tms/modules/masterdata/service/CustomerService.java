package com.tms.modules.masterdata.service;

import com.tms.modules.masterdata.dto.PagedResponse;
import com.tms.modules.masterdata.repository.CustomerRepository;
import com.tms.shared.model.masterdata.CustomerEntity;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class CustomerService {

    private final CustomerRepository customerRepository;

    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public PagedResponse<CustomerEntity> search(String keyword, Pageable pageable) {
        Pageable safePageable = normalizePageable(pageable, Sort.by("customerName").ascending());
        String keywordLike = normalizeLike(keyword);
        return PagedResponse.from(customerRepository.search(keywordLike, safePageable));
    }

    public CustomerEntity get(UUID customerId) {
        return customerRepository.findByCustomerIdAndDeletedFalse(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
    }

    public CustomerEntity create(CustomerEntity customer) {
        return customerRepository.saveAndFlush(customer);
    }

    public CustomerEntity update(UUID customerId, CustomerEntity request) {
        CustomerEntity customer = get(customerId);

        customer.setCustomerName(request.getCustomerName());
        customer.setContactPerson(request.getContactPerson());
        customer.setCustomerContactPhone(request.getCustomerContactPhone());
        customer.setCustomerEmail(request.getCustomerEmail());
        customer.setAddress(request.getAddress());
        customer.setPickupAddress(request.getPickupAddress());
        customer.setPaymentTerm(request.getPaymentTerm());
        customer.setCreditLimit(request.getCreditLimit());

        return customerRepository.saveAndFlush(customer);
    }

    public void delete(UUID customerId) {
        CustomerEntity customer = get(customerId);
        customer.setDeleted(true);
        customerRepository.save(customer);
    }

    private Pageable normalizePageable(Pageable pageable, Sort defaultSort) {
        if (pageable == null) {
            return PageRequest.of(0, 20, defaultSort);
        }
        Sort sort = pageable.getSort().isSorted() ? pageable.getSort() : defaultSort;
        return PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), sort);
    }

    private String normalizeLike(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        return "%" + value.trim().toLowerCase() + "%";
    }
}
