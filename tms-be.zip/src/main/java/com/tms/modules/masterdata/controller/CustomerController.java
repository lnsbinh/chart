package com.tms.modules.masterdata.controller;

import com.tms.modules.masterdata.dto.PagedResponse;
import com.tms.modules.masterdata.service.CustomerService;
import com.tms.security.annotation.RequireAnyPermission;
import com.tms.shared.model.masterdata.CustomerEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;
import java.util.UUID;

@RequireAnyPermission({"customer.read", "customer.all"})
@RestController
@RequestMapping("/api/v1/customers")
public class CustomerController {

    private final CustomerService customerService;

    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    @GetMapping
    public PagedResponse<CustomerEntity> list(
            @RequestParam(required = false) String keyword,
            @PageableDefault(size = 20, sort = "customerName") Pageable pageable
    ) {
        return customerService.search(keyword, pageable);
    }

    @GetMapping("/{customerId}")
    public CustomerEntity getById(@PathVariable UUID customerId) {
        return customerService.get(customerId);
    }

    @RequireAnyPermission({"customer.update", "customer.all"})
    @PostMapping
    public CustomerEntity create(@RequestBody CustomerEntity customer) {
        return customerService.create(customer);
    }

    @RequireAnyPermission({"customer.update", "customer.all"})
    @PutMapping("/{customerId}")
    public CustomerEntity update(
            @PathVariable UUID customerId,
            @RequestBody CustomerEntity customer
    ) {
        return customerService.update(customerId, customer);
    }

    @RequireAnyPermission({"customer.update", "customer.all"})
    @DeleteMapping("/{customerId}")
    public void delete(@PathVariable UUID customerId) {
        customerService.delete(customerId);
    }
}
