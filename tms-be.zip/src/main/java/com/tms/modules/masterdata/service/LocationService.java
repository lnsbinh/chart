package com.tms.modules.masterdata.service;

import com.tms.modules.masterdata.dto.PagedResponse;
import com.tms.shared.model.masterdata.LocationEntity;
import com.tms.modules.masterdata.repository.LocationRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class LocationService {
    private final LocationRepository repository;

    public LocationService(LocationRepository repository) {
        this.repository = repository;
    }

    public PagedResponse<LocationEntity> search(UUID organizationId, String keyword, String locationType, String statusCode, Pageable pageable) {
        Pageable safePageable = normalizePageable(pageable, Sort.by("locationCode").ascending());
        return PagedResponse.from(repository.search(organizationId, normalize(keyword), normalize(locationType), normalize(statusCode), safePageable));
    }

    public LocationEntity get(UUID organizationId, UUID id) {
        return repository.findByIdAndOrganizationId(id, organizationId).orElseThrow();
    }

    public LocationEntity create(LocationEntity entity) { return repository.save(entity); }

    public LocationEntity update(UUID organizationId, UUID id, LocationEntity request) {
        LocationEntity entity = get(organizationId, id);
        entity.setLocationType(request.getLocationType());
        entity.setLocationCode(request.getLocationCode());
        entity.setLocationName(request.getLocationName());
        entity.setAddress(request.getAddress());
        entity.setLatitude(request.getLatitude());
        entity.setLongitude(request.getLongitude());
        entity.setStatusCode(request.getStatusCode());
        return repository.save(entity);
    }

    public LocationEntity deactivate(UUID organizationId, UUID id) {
        LocationEntity entity = get(organizationId, id);
        entity.setStatusCode("INACTIVE");
        return repository.save(entity);
    }

    private Pageable normalizePageable(Pageable pageable, Sort defaultSort) {
        if (pageable == null) {
            return PageRequest.of(0, 20, defaultSort);
        }
        Sort sort = pageable.getSort().isSorted() ? pageable.getSort() : defaultSort;
        return PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), sort);
    }

    private String normalize(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}
