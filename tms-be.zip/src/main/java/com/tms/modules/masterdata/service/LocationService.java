package com.tms.modules.masterdata.service;

import com.tms.modules.masterdata.dto.PagedResponse;
import com.tms.shared.model.masterdata.LocationEntity;
import com.tms.modules.masterdata.repository.LocationRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class LocationService {

    private final LocationRepository repository;

    @Autowired
    public LocationService(LocationRepository repository) {
        this.repository = repository;
    }

    // Phương thức tìm kiếm với phân trang
    public PagedResponse<LocationEntity> search(String keyword, String locationType, String statusCode, Pageable pageable) {
        Pageable safePageable = normalizePageable(pageable, Sort.by("locationName").ascending()); // Dùng locationName làm mặc định sắp xếp
        // Trả về kết quả phân trang
        return PagedResponse.from(repository.search(normalizeLike(keyword), normalize(locationType), normalize(statusCode), safePageable));
    }

    // Lấy địa điểm theo ID
    public LocationEntity get(UUID id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Location not found"));
    }

    // Tạo mới địa điểm
    public LocationEntity create(LocationEntity entity) {
        return repository.save(entity);
    }

    // Cập nhật thông tin địa điểm
    public LocationEntity update(UUID id, LocationEntity request) {
        // Lấy entity cũ từ database
        LocationEntity entity = get(id);

        // Cập nhật các trường từ request vào entity
        entity.setLocationType(request.getLocationType());  // Loại địa điểm
        entity.setLocationName(request.getLocationName());  // Tên địa điểm
        entity.setAddress(request.getAddress());            // Địa chỉ
        entity.setLatitude(request.getLatitude());          // Vĩ độ
        entity.setLongitude(request.getLongitude());        // Kinh độ
        entity.setStatusCode(request.getStatusCode());      // Trạng thái
        entity.setGateHeight(request.getGateHeight());      // Chiều cao cổng
        entity.setAllowedVehicle(request.getAllowedVehicle());// Loại xe được phép
        entity.setCapacityCont(request.getCapacityCont());  // Dung lượng container
        entity.setContactPhone(request.getContactPhone());  // Số điện thoại liên hệ
        entity.setRemark(request.getRemark());              // Ghi chú
        entity.setProvince(request.getProvince());          // Tỉnh/TP
        entity.setDistrict(request.getDistrict());          // Quận/Huyện
        entity.setTimeWindowFrom(request.getTimeWindowFrom());// Thời gian mở cửa
        entity.setTimeWindowTo(request.getTimeWindowTo());  // Thời gian đóng cửa
        entity.setActiveFlag(request.getActiveFlag());      // Trạng thái hoạt động

        // Cập nhật thời gian
        entity.setUpdatedAt(OffsetDateTime.now());

        // Lưu entity đã cập nhật
        return repository.save(entity);
    }

    // Xóa mềm địa điểm
    public LocationEntity deactivate(UUID id) {
        LocationEntity entity = get(id);  // Không còn cần organizationId
        entity.setStatusCode("INACTIVE");  // Đánh dấu trạng thái là INACTIVE
        return repository.save(entity);
    }

    // Phương thức chuẩn hóa Pageable để tránh lỗi khi không truyền Pageable
    private Pageable normalizePageable(Pageable pageable, Sort defaultSort) {
        if (pageable == null) {
            return PageRequest.of(0, 20, defaultSort);  // Sắp xếp mặc định theo locationName
        }
        Sort sort = pageable.getSort().isSorted() ? pageable.getSort() : defaultSort;
        return PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), sort);
    }

    // Phương thức chuẩn hóa giá trị String trước khi query
    private String normalize(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    private String normalizeLike(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        return "%" + value.trim().toLowerCase() + "%";
    }
}
