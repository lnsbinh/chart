package com.tms.modules.masterdata.controller;

import com.tms.shared.model.masterdata.ReferenceDataItemEntity;
import com.tms.modules.masterdata.service.ReferenceDataItemService;
import com.tms.security.annotation.RequireAnyRole;
import com.tms.modules.iam.constants.RoleCodes;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/master-data/reference-data")
@RequireAnyRole({
        RoleCodes.SUPER_ADMIN,
        RoleCodes.ORG_ADMIN,
        RoleCodes.SUPERVISOR,
        RoleCodes.DISPATCHER,
        RoleCodes.OPERATION_STAFF,
        RoleCodes.FINANCE_OPS
})
@Tag(name = "Master Data - Reference Data")
public class ReferenceDataItemController {

    private final ReferenceDataItemService service;

    public ReferenceDataItemController(ReferenceDataItemService service) {
        this.service = service;
    }

    @GetMapping("/groups")
    @Operation(summary = "Get reference-data groups")
    public List<String> getGroups() {
        return service.getAllGroups();
    }

    @GetMapping("/business-partner-types")
    @Operation(summary = "Get business-partner types")
    public List<ReferenceDataItemEntity> getBusinessPartnerTypes() {
        return service.getActiveByGroup(ReferenceDataItemService.GROUP_BUSINESS_PARTNER_TYPE);
    }

    @GetMapping("/location-types")
    @Operation(summary = "Get location types")
    public List<ReferenceDataItemEntity> getLocationTypes() {
        return service.getActiveByGroup(ReferenceDataItemService.GROUP_LOCATION_TYPE);
    }

    @GetMapping("/vehicle-types")
    @Operation(summary = "Get vehicle types")
    public List<ReferenceDataItemEntity> getVehicleTypes() {
        return service.getActiveByGroup(ReferenceDataItemService.GROUP_VEHICLE_TYPE);
    }

    @GetMapping("/driver-types")
    @Operation(summary = "Get driver types")
    public List<ReferenceDataItemEntity> getDriverTypes() {
        return service.getActiveByGroup(ReferenceDataItemService.GROUP_DRIVER_TYPE);
    }

    @GetMapping("/container-types")
    @Operation(summary = "Get container types")
    public List<ReferenceDataItemEntity> getContainerTypes() {
        return service.getActiveByGroup(ReferenceDataItemService.GROUP_CONTAINER_TYPE);
    }

    @GetMapping("/surcharge-charge-methods")
    @Operation(summary = "Get surcharge charge methods")
    public List<ReferenceDataItemEntity> getSurchargeChargeMethods() {
        return service.getActiveByGroup(ReferenceDataItemService.GROUP_SURCHARGE_CHARGE_METHOD);
    }

    @GetMapping("/{groupCode}")
    @Operation(summary = "Get all items by group")
    public List<ReferenceDataItemEntity> getAllByGroup(
            @Parameter(description = "Reference-data group code", schema = @Schema(defaultValue = "BUSINESS_PARTNER_TYPE"))
            @PathVariable String groupCode) {
        return service.getAllByGroup(groupCode);
    }

    @GetMapping("/{groupCode}/{itemCode}")
    @Operation(summary = "Get reference-data item by group and code")
    public ReferenceDataItemEntity getByGroupAndCode(
            @Parameter(description = "Reference-data group code", schema = @Schema(defaultValue = "BUSINESS_PARTNER_TYPE"))
            @PathVariable String groupCode,
            @Parameter(description = "Reference-data item code", schema = @Schema(defaultValue = "CUSTOMER"))
            @PathVariable String itemCode
    ) {
        return service.getByGroupAndCode(groupCode, itemCode);
    }

    @PostMapping
    @RequireAnyRole({RoleCodes.SUPER_ADMIN, RoleCodes.ORG_ADMIN, RoleCodes.OPERATION_STAFF})
    @Operation(summary = "Create reference-data item")
    public ReferenceDataItemEntity create(@RequestBody ReferenceDataItemEntity request) {
        return service.create(request);
    }

    @PutMapping("/{groupCode}/{itemCode}")
    @RequireAnyRole({RoleCodes.SUPER_ADMIN, RoleCodes.ORG_ADMIN, RoleCodes.OPERATION_STAFF})
    @Operation(summary = "Update reference-data item")
    public ReferenceDataItemEntity update(
            @Parameter(description = "Reference-data group code", schema = @Schema(defaultValue = "BUSINESS_PARTNER_TYPE"))
            @PathVariable String groupCode,
            @Parameter(description = "Reference-data item code", schema = @Schema(defaultValue = "CUSTOMER"))
            @PathVariable String itemCode,
            @RequestBody ReferenceDataItemEntity request
    ) {
        return service.update(groupCode, itemCode, request);
    }

    @PatchMapping("/{groupCode}/{itemCode}/activate")
    @RequireAnyRole({RoleCodes.SUPER_ADMIN, RoleCodes.ORG_ADMIN, RoleCodes.OPERATION_STAFF})
    @Operation(summary = "Activate reference-data item")
    public ReferenceDataItemEntity activate(
            @Parameter(description = "Reference-data group code", schema = @Schema(defaultValue = "BUSINESS_PARTNER_TYPE"))
            @PathVariable String groupCode,
            @Parameter(description = "Reference-data item code", schema = @Schema(defaultValue = "CUSTOMER"))
            @PathVariable String itemCode
    ) {
        return service.activate(groupCode, itemCode);
    }

    @PatchMapping("/{groupCode}/{itemCode}/deactivate")
    @RequireAnyRole({RoleCodes.SUPER_ADMIN, RoleCodes.ORG_ADMIN, RoleCodes.OPERATION_STAFF})
    @Operation(summary = "Deactivate reference-data item")
    public ReferenceDataItemEntity deactivate(
            @Parameter(description = "Reference-data group code", schema = @Schema(defaultValue = "BUSINESS_PARTNER_TYPE"))
            @PathVariable String groupCode,
            @Parameter(description = "Reference-data item code", schema = @Schema(defaultValue = "CUSTOMER"))
            @PathVariable String itemCode
    ) {
        return service.deactivate(groupCode, itemCode);
    }
}
