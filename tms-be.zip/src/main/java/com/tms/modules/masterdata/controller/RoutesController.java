package com.tms.modules.masterdata.controller;

import com.tms.modules.masterdata.dto.PagedResponse;
import com.tms.shared.model.masterdata.RouteEntity;
import com.tms.modules.masterdata.service.RouteService;
import com.tms.security.annotation.RequireAnyPermission;
import com.tms.security.annotation.RequireAnyRole;
import com.tms.modules.iam.constants.RoleCodes;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/master-data/routes")
@RequireAnyRole({
        RoleCodes.SUPER_ADMIN,
        RoleCodes.ORG_ADMIN,
        RoleCodes.SUPERVISOR,
        RoleCodes.DISPATCHER,
        RoleCodes.OPERATION_STAFF,
        RoleCodes.FINANCE_OPS
})
@RequireAnyPermission({"route.read", "route.all"})
@Tag(name = "Master Data - Routes")
public class RoutesController {

    private final RouteService service;

    public RoutesController(RouteService service) {
        this.service = service;
    }

    @GetMapping
    @Operation(summary = "Search routes with paging")
    public PagedResponse<RouteEntity> list(
            @Parameter(
                    description = "Search by route name",
                    schema = @Schema(defaultValue = "HCM"))
            @RequestParam(required = false) String keyword,

            @Parameter(
                    description = "Origin location ID",
                    schema = @Schema(example = "00000000-0000-0000-0000-000000000021"))
            @RequestParam(required = false) UUID originLocationId,

            @Parameter(
                    description = "Destination location ID",
                    schema = @Schema(example = "00000000-0000-0000-0000-000000000022"))
            @RequestParam(required = false) UUID destinationLocationId,

            @Parameter(
                    description = "Preferred flag",
                    schema = @Schema(defaultValue = "true"))
            @RequestParam(required = false) Boolean preferredFlag,

            @Parameter(
                    description = "Active flag",
                    schema = @Schema(defaultValue = "true"))
            @RequestParam(required = false) Boolean activeFlag,

            @ParameterObject
            @PageableDefault(size = 20, sort = "routeName") Pageable pageable
    ) {
        return service.search(keyword, originLocationId, destinationLocationId, preferredFlag, activeFlag, pageable);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get route by ID")
    public RouteEntity get(
            @Parameter(
                    description = "Route ID",
                    schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id
    ) {
        return service.get(id);
    }

    @PostMapping
    @RequireAnyRole({RoleCodes.SUPER_ADMIN, RoleCodes.ORG_ADMIN, RoleCodes.OPERATION_STAFF})
    @RequireAnyPermission({"route.update", "route.all"})
    @Operation(summary = "Create route")
    public RouteEntity create(@RequestBody RouteEntity request) {
        return service.create(request);
    }

    @PutMapping("/{id}")
    @RequireAnyRole({RoleCodes.SUPER_ADMIN, RoleCodes.ORG_ADMIN, RoleCodes.OPERATION_STAFF})
    @RequireAnyPermission({"route.update", "route.all"})
    @Operation(summary = "Update route")
    public RouteEntity update(
            @Parameter(
                    description = "Route ID",
                    schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id,
            @RequestBody RouteEntity request
    ) {
        return service.update(id, request);
    }

    @PatchMapping("/{id}/deactivate")
    @RequireAnyRole({RoleCodes.SUPER_ADMIN, RoleCodes.ORG_ADMIN, RoleCodes.OPERATION_STAFF})
    @RequireAnyPermission({"route.delete", "route.all"})
    @Operation(summary = "Deactivate route")
    public RouteEntity deactivate(
            @Parameter(
                    description = "Route ID",
                    schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id
    ) {
        return service.deactivate(id);
    }
}
