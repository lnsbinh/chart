package com.tms.modules.iam.service;

import com.tms.shared.model.iam.AuditLogEntity;
import com.tms.modules.iam.repository.AuditLogRepository;
import org.springframework.stereotype.Service;

@Service
public class AuditService {
    private final AuditLogRepository auditLogRepository;

    public AuditService(AuditLogRepository auditLogRepository) {
        this.auditLogRepository = auditLogRepository;
    }

    public AuditLogEntity save(AuditLogEntity entity) {
        return auditLogRepository.save(entity);
    }
}
