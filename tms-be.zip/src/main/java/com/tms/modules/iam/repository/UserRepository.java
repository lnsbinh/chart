package com.tms.modules.iam.repository;

import com.tms.shared.model.iam.UserEntity;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface UserRepository extends JpaRepository<UserEntity, UUID> {
    Optional<UserEntity> findByEmail(String email);
    boolean existsByUsername(String username);
    boolean existsByEmail(String email);
    boolean existsByUserCode(String userCode);
    Optional<UserEntity> findByUsername(String username);
    Optional<UserEntity> findById(UUID id);

    @Query("""
    SELECT DISTINCT u
    FROM UserEntity u
    LEFT JOIN FETCH u.userRoleAssignments ura
    LEFT JOIN FETCH ura.role r
    LEFT JOIN FETCH u.userBranches ub
    LEFT JOIN FETCH ub.branch b
    LEFT JOIN FETCH ura.organization organization
    WHERE (u.deleted = false OR u.deleted IS NULL)
    AND u.username != 'superadmin'
    AND (:status IS NULL OR u.status IN :status)
    AND (:roleIds IS NULL OR r.id IN :roleIds)
    AND (:branchIds IS NULL OR b.id IN :branchIds)
    AND (:search IS NULL OR LOWER(CAST(u.username AS text)) LIKE CONCAT('%', LOWER(CAST(:search AS text)), '%')
    OR LOWER(CAST(u.email AS text)) LIKE CONCAT('%', LOWER(CAST(:search AS text)), '%')
    OR LOWER(CAST(u.firstName AS text)) LIKE CONCAT('%', LOWER(CAST(:search AS text)), '%')
    OR LOWER(CAST(u.lastName AS text)) LIKE CONCAT('%', LOWER(CAST(:search AS text)), '%'))
    """)
    Page<UserEntity> findAllWithRolesAndBranchesFiltered(
            @Param("status") List<String> status,
            @Param("roleIds") List<UUID> roleIds,
            @Param("branchIds") List<UUID> branchIds,
            @Param("search") String search,
            Pageable pageable);

    Optional<UserEntity> findByKeycloakUserNameAndStatus(String externalSubject, String status);

    @Query(
    "SELECT u FROM UserEntity u " +
    "WHERE (u.username = :username OR u.email = :email) " +
    "AND (u.deleted = false OR u.deleted IS NULL)"
    )
    List<UserEntity> findByUsernameOrEmail(@NotBlank(message = "Username is required") String username, @NotBlank(message = "Email is required") @Email(message = "Invalid email format") String email);
}
