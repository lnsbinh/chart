package com.tms.modules.iam.controller.rbac;

import com.tms.shared.model.iam.RoleEntity;
import com.tms.modules.iam.service.rbac.RoleService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/roles")
public class RoleController {
    private final RoleService roleService;

    public RoleController(RoleService roleService) {
        this.roleService = roleService;
    }

    @GetMapping
    public List<RoleEntity> getAllRoles() { return roleService.getAllRoles(); }

    @PostMapping
    public RoleEntity createRole(@RequestBody RoleEntity role) { return roleService.addRole(role); }

    @DeleteMapping("/{id}")
    public void deleteRole(@PathVariable UUID id) { roleService.deleteRole(id); }
}
