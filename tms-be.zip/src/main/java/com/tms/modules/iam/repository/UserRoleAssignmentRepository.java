package com.tms.modules.iam.repository;

import com.tms.shared.model.iam.UserEntity;
import com.tms.shared.model.iam.UserRoleAssignmentEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;

public interface UserRoleAssignmentRepository extends JpaRepository<UserRoleAssignmentEntity, UUID> {
    @Query("""
            select ura from UserRoleAssignmentEntity ura
            join fetch ura.role r
            left join fetch ura.organization o
            left join fetch ura.branch b
            where ura.user.id = :userId
              and ura.status = 'ACTIVE'
              and (ura.validFrom is null or ura.validFrom <= CURRENT_TIMESTAMP)
              and (ura.validTo is null or ura.validTo >= CURRENT_TIMESTAMP)
            order by r.code, ura.scopeType
            """)
    List<UserRoleAssignmentEntity> findActiveByUserId(@Param("userId") UUID userId);

    void deleteAllByUserIs(UserEntity user);

    @Query(
            """
            select ura from UserRoleAssignmentEntity ura
            join fetch ura.role r
            left join fetch ura.organization o
            left join fetch ura.branch b
            where ura.user = :user
              and (ura.validFrom is null or ura.validFrom <= CURRENT_TIMESTAMP)
              and (ura.validTo is null or ura.validTo >= CURRENT_TIMESTAMP)
            order by r.code, ura.scopeType
            """
    )
    List<UserRoleAssignmentEntity> findAllByUserIs(UserEntity user);
}
