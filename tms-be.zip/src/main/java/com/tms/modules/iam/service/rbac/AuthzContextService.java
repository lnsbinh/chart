package com.tms.modules.iam.service.rbac;

import com.tms.modules.iam.dto.AppSecurityContext;
import com.tms.modules.iam.dto.BranchMembership;
import com.tms.modules.iam.dto.EffectivePermissionGrant;
import com.tms.modules.iam.dto.ScopedRoleAssignment;
import com.tms.shared.model.iam.UserBranchEntity;
import com.tms.shared.model.iam.UserEffectivePermissionEntity;
import com.tms.shared.model.iam.UserEntity;
import com.tms.shared.model.iam.UserRoleAssignmentEntity;
import com.tms.modules.iam.repository.UserBranchRepository;
import com.tms.modules.iam.repository.UserEffectivePermissionRepository;
import com.tms.modules.iam.repository.UserRepository;
import com.tms.modules.iam.repository.UserRoleAssignmentRepository;
import com.tms.security.util.JwtUtil;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class AuthzContextService {

    private final UserRepository userRepository;
    private final UserRoleAssignmentRepository userRoleAssignmentRepository;
    private final UserBranchRepository userBranchRepository;
    private final UserEffectivePermissionRepository userEffectivePermissionRepository;
    private final JwtUtil jwtUtil;
    private final RedisTemplate<String, Object> redisTemplate;

    public AuthzContextService(
            UserRepository userRepository,
            UserRoleAssignmentRepository userRoleAssignmentRepository,
            UserBranchRepository userBranchRepository,
            UserEffectivePermissionRepository userEffectivePermissionRepository,
            JwtUtil jwtUtil,
            RedisTemplate<String, Object> redisTemplate
    ) {
        this.userRepository = userRepository;
        this.userRoleAssignmentRepository = userRoleAssignmentRepository;
        this.userBranchRepository = userBranchRepository;
        this.userEffectivePermissionRepository = userEffectivePermissionRepository;
        this.jwtUtil = jwtUtil;
        this.redisTemplate = redisTemplate;
    }

    public AppSecurityContext buildContext(Jwt jwt) {
        return buildHumanContext(jwt);
    }

    private AppSecurityContext buildHumanContext(Jwt jwt) {
        String subject = jwtUtil.getUsername(jwt);
        UserEntity user = userRepository.findByKeycloakUserNameAndStatus(subject, "ACTIVE")
                .orElseThrow(() -> new IllegalStateException("Active local user not found for subject=" + subject));

        String cacheKey = "authz:user:" + user.getId() + ":v:" + user.getAuthzVersion();
        AppSecurityContext cached = getCached(cacheKey);

        if (cached != null) {
            return cached;
        }

        List<UserRoleAssignmentEntity> assignments = userRoleAssignmentRepository.findActiveByUserId(user.getId());
        List<UserBranchEntity> branches = userBranchRepository.findActiveByUserId(user.getId());
        List<UserEffectivePermissionEntity> effectivePermissionRows = userEffectivePermissionRepository.findByUserIdWithRefs(user.getId());

        Set<String> roleCodes = assignments.stream()
                .map(a -> a.getRole().getCode())
                .collect(Collectors.toCollection(LinkedHashSet::new));

        List<EffectivePermissionGrant> normalizedGrants = normalizeEffectivePermissionRows(effectivePermissionRows);
        Set<String> permissionCodes = normalizedGrants.stream()
                .map(EffectivePermissionGrant::getPermissionCode)
                .collect(Collectors.toCollection(LinkedHashSet::new));

        AppSecurityContext context = AppSecurityContext.builder()
                .subjectId(user.getId().toString())
                .subjectType("human_user")
                .username(user.getUsername())
                .clientId(jwtUtil.getAuthorizedParty(jwt))
                .authzVersion(user.getAuthzVersion())
                .roles(roleCodes)
                .permissions(permissionCodes)
                .effectivePermissionGrants(normalizedGrants)
                .roleAssignments(assignments.stream().map(a -> new ScopedRoleAssignment(
                        a.getRole().getCode(),
                        a.getScopeType(),
                        a.getOrganization() != null ? a.getOrganization().getId() : null,
                        a.getBranch() != null ? a.getBranch().getId() : null
                )).toList())
                .accessibleOrganizationIds(assignments.stream()
                        .map(a -> a.getOrganization() != null ? a.getOrganization().getId() : null)
                        .filter(Objects::nonNull)
                        .collect(Collectors.toCollection(LinkedHashSet::new)))
                .accessibleBranchIds(assignments.stream()
                        .map(a -> a.getBranch() != null ? a.getBranch().getId() : null)
                        .filter(Objects::nonNull)
                        .collect(Collectors.toCollection(LinkedHashSet::new)))
                .branchMemberships(branches.stream().map(b -> new BranchMembership(
                        b.getOrganization().getId(),
                        b.getBranch().getId(),
                        b.getBranch().getCode(),
                        b.getBranch().getName(),
                        b.isPrimary()
                )).toList())
                .build();

        putCached(cacheKey, context);
        return context;
    }

    /**
     * user_effective_permissions can contain rows that are technically duplicated from a business point of view,
     * for example because a higher role grants *.all while an inherited role still contributes *.read.
     *
     * Runtime authorization should never iterate over raw rows directly.
     * We first normalize them into distinct permission+scope tuples so later checks stay deterministic and easy to reason about.
     */
    private List<EffectivePermissionGrant> normalizeEffectivePermissionRows(List<UserEffectivePermissionEntity> rows) {
        Map<String, EffectivePermissionGrant> dedup = new LinkedHashMap<>();
        for (UserEffectivePermissionEntity row : rows) {
            String permissionCode = row.getPermission().getCode();
            java.util.UUID organizationId = row.getOrganization() != null ? row.getOrganization().getId() : null;
            java.util.UUID branchId = row.getBranch() != null ? row.getBranch().getId() : null;
            String key = permissionCode + "|" + row.getScopeType() + "|" + organizationId + "|" + branchId;
            dedup.putIfAbsent(key, EffectivePermissionGrant.builder()
                    .permissionCode(permissionCode)
                    .scopeType(row.getScopeType())
                    .organizationId(organizationId)
                    .branchId(branchId)
                    .build());
        }
        return new ArrayList<>(dedup.values());
    }

    private void putCached(String key, AppSecurityContext context) {
        redisTemplate.opsForValue().set(key, context, Duration.ofMinutes(10));
    }

    private AppSecurityContext getCached(String key) {
        Object value = redisTemplate.opsForValue().get(key);
        return value instanceof AppSecurityContext c ? c : null;
    }
}
