package com.tms.modules.iam.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class AssignedBranchDTO {
    private UUID id;
    private String code;
    private String name;

}
