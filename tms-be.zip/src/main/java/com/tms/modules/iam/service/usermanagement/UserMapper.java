package com.tms.modules.iam.service.usermanagement;

import com.tms.modules.iam.dto.*;
import com.tms.shared.model.iam.BranchEntity;
import com.tms.shared.model.iam.RoleEntity;
import com.tms.shared.model.iam.UserBranchEntity;
import com.tms.shared.model.iam.UserEntity;
import com.tms.shared.model.iam.UserRoleAssignmentEntity;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Component
public class UserMapper {

    public UserDTO toDomain(UserEntity entity) {
        return UserDTO.builder()
                .id(entity.getId())
                .userCode(entity.getUserCode())
                .username(entity.getUsername())
                .email(entity.getEmail())
                .phone(entity.getPhone())
                .firstName(entity.getFirstName())
                .lastName(entity.getLastName())
                .statusCode(entity.getStatus())
                .avatarUrl(entity.getAvatarUrl())
                .roles(mapRoles(entity.getUserRoleAssignments()))
                .branches(mapBranches(entity.getUserBranches()))
                .build();
    }


    public List<AssignedRoleDTO> mapRoles(Set<UserRoleAssignmentEntity> userRoles) {
        return userRoles.stream()
                .collect(Collectors.toMap(
                        ur -> ur.getRole().getId(), // key = roleId
                        ur -> new AssignedRoleDTO(
                                ur.getRole().getId(),
                                ur.getRole().getCode(),
                                ur.getRole().getName()
                        ),
                        (existing, duplicate) -> existing // giữ cái đầu
                ))
                .values()
                .stream()
                .toList();
    }

    public List<AssignedBranchDTO> mapBranches(Set<UserBranchEntity> branches) {
        return branches.stream()
                .filter(b -> b.getBranch() != null) // tránh NPE
                .collect(Collectors.toMap(
                        b -> b.getBranch().getId(), // key = branchId
                        b -> new AssignedBranchDTO(
                                b.getBranch().getId(),
                                b.getBranch().getCode(),
                                b.getBranch().getName()
                        ),
                        (existing, duplicate) -> existing // giữ cái đầu
                ))
                .values()
                .stream()
                .toList();
    }


    public UserDTO toDto(UserEntity user) {
        return new UserDTO(
                user.getId(),
                user.getUserCode(),
                user.getUsername(),
                user.getEmail(),
                user.getPhone(),
                user.getFirstName(),
                user.getLastName(),
                user.getStatus(),
                user.getAvatarUrl(),
                mapRoles(user.getUserRoleAssignments()),
                mapBranches(user.getUserBranches())
        );
    }
}