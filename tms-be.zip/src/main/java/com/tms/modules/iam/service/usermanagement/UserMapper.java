package com.tms.modules.iam.service.usermanagement;

import com.tms.modules.iam.dto.BranchDTO;
import com.tms.modules.iam.dto.RoleDTO;
import com.tms.modules.iam.dto.UserDTO;
import com.tms.shared.model.iam.BranchEntity;
import com.tms.shared.model.iam.RoleEntity;
import com.tms.shared.model.iam.UserBranchEntity;
import com.tms.shared.model.iam.UserEntity;
import com.tms.shared.model.iam.UserRoleAssignmentEntity;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Set;

@Component
public class UserMapper {
    
    public UserDTO toDomain(UserEntity entity) {
        return UserDTO.builder()
                .id(entity.getId())
                .userCode(entity.getUserCode())
                .username(entity.getUsername())
                .email(entity.getEmail())
                .phone(entity.getPhone())
                .firstName(entity.getFirstName())
                .lastName(entity.getLastName())
                .statusCode(entity.getStatus())
                .avatarUrl(entity.getAvatarUrl())
                .roles(mapRoles(entity.getUserRoleAssignments()))
                .branches(mapBranches(entity.getUserBranches()))
                .build();
    }

    
    public List<RoleDTO> mapRoles(Set<UserRoleAssignmentEntity> userRoles) {
        return userRoles.stream()
                .map(userRole ->
                        new RoleDTO(userRole.getId(), userRole.getOrganization().getId(),
                                userRole.getRole().getCode(), userRole.getRole().getName(),
                                userRole.getRole().getDescription(),
                                null, null))
                .toList();
    }

    
    public List<BranchDTO> mapBranches(Set<UserBranchEntity> branches) {
        return branches.stream()
                .map(b -> new BranchDTO(b.getId(), b.getOrganization().getId(),
                        b.getBranch().getCode(), b.getBranch().getName(),
                        b.getBranch().getAddress(), b.getStatus()))
                .toList();
    }

    
    public UserDTO toDto(UserEntity user) {
        return new UserDTO(
                user.getId(),
                user.getUserCode(),
                user.getUsername(),
                user.getEmail(),
                user.getPhone(),
                user.getFirstName(),
                user.getLastName(),
                user.getStatus(),
                user.getAvatarUrl(),
                mapRoles(user.getUserRoleAssignments()),
                mapBranches(user.getUserBranches())
        );
    }
}
