package com.tms.modules.iam.service.rbac;

import com.tms.modules.iam.dto.RequestScopeContext;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.UUID;

@Component
public class RequestScopeContextResolver {
    public static final String ORGANIZATION_HEADER = "X-Organization-Id";
    public static final String BRANCH_HEADER = "X-Branch-Id";

    public RequestScopeContext resolveCurrent() {
        RequestAttributes attributes = RequestContextHolder.getRequestAttributes();
        if (!(attributes instanceof ServletRequestAttributes servletAttributes)) {
            return RequestScopeContext.builder().build();
        }
        HttpServletRequest request = servletAttributes.getRequest();
        return RequestScopeContext.builder()
                .organizationId(parseUuid(request.getHeader(ORGANIZATION_HEADER)))
                .branchId(parseUuid(request.getHeader(BRANCH_HEADER)))
                .build();
    }

    private UUID parseUuid(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        try {
            return UUID.fromString(value.trim());
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }
}
