package com.tms.modules.iam.service.usermanagement;

import org.springframework.stereotype.Service;

@Service
public class EmailSender {
    public void sendEmail(String to, String subject, String body) {
        // TODO: Implement email sending
        System.out.println("Sending email to: " + to + " subject: " + subject + " body: " + body);
    }

    
    public void sendResetPasswordEmail(String to, String newPassword) {
        // TODO: Implement reset password email
        sendEmail(to, "Password Reset", "Your new password is: " + newPassword);
    }
}
