package com.tms.modules.iam.service.rbac;

import com.tms.shared.model.iam.BranchEntity;
import com.tms.modules.iam.repository.BranchRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class BranchService {
    private final BranchRepository branchRepository;

    public BranchService(BranchRepository branchRepository) {
        this.branchRepository = branchRepository;
    }

    public List<BranchEntity> getAllBranches() {
        return branchRepository.findAll();
    }

    public BranchEntity addBranch(BranchEntity branch) {
        return branchRepository.save(branch);
    }

    public void deleteBranch(UUID id) {
        branchRepository.deleteById(id);
    }
}
