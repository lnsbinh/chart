package com.tms.modules.iam.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class BranchDTO {
    private UUID id;
    private UUID organizationId;
    private String code;
    private String name;
    private String address;
    private String statusCode;
}
