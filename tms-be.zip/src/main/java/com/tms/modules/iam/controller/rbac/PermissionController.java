package com.tms.modules.iam.controller.rbac;

import com.tms.shared.model.iam.PermissionEntity;
import com.tms.modules.iam.service.rbac.PermissionService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/permissions")
public class PermissionController {
    private final PermissionService permissionService;

    public PermissionController(PermissionService permissionService) {
        this.permissionService = permissionService;
    }

    @GetMapping
    public List<PermissionEntity> getAllPermissions() { return permissionService.getAllPermissions(); }

    @PostMapping
    public PermissionEntity createPermission(@RequestBody PermissionEntity permission) { return permissionService.addPermission(permission); }

    @DeleteMapping("/{id}")
    public void deletePermission(@PathVariable UUID id) { permissionService.deletePermission(id); }
}
