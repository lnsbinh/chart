package com.tms.modules.iam.caching;

import com.tms.modules.iam.service.rbac.RoleService;
import com.tms.shared.model.iam.PermissionEntity;
import com.tms.shared.model.iam.RoleEntity;
import com.tms.shared.model.iam.RolePermissionEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class RolePermissionCacheService implements ApplicationRunner {
    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    @Autowired
    private RoleService roleService;
    public void setCacheRolePermissions(String roleCode, List<PermissionEntity> permissionIds) {
        String key = "role:" + roleCode;
        // Lưu set permissions của role vào Redis
        redisTemplate.opsForSet().add(key, permissionIds.toArray());
    }

    public List<PermissionEntity> getRolePermissions(String roleCode) {
        String key = "role:" + roleCode;

        // Lấy permissions của role từ Redis
        return redisTemplate.opsForSet().members(key)
                .stream()
                .map(PermissionEntity.class::cast)
                .collect(Collectors.toList());
    }

    /**
     *
     * @param args
     * @throws Exception
     */
    @Override
    public void run(ApplicationArguments args) throws Exception {
//        List<RoleEntity> roles = roleService.getAllRoles();
//
//        for (RoleEntity role : roles) {
//            List<RolePermissionEntity> rolePermissions = roleService.findPermissionsByRoleCode(role.getCode());
//            List<PermissionEntity> permissions = rolePermissions.stream().map(rp -> rp.getPermission()).toList();
//
//            setCacheRolePermissions(role.getCode(), permissions);
//        }

    }
}
