package com.tms.modules.iam.service.usermanagement;

import com.tms.modules.iam.exception.BusinessException;
import com.tms.modules.iam.exception.ErrorCode;
import com.tms.modules.iam.repository.UserRepository;
import com.tms.shared.model.iam.UserEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.UUID;

@Slf4j
@Service
public class FileUploadService {
    private final String UPLOAD_DIR = "uploads/avatars/";
    private final UserRepository userRepository;

    @Value("${file.storage.base-url}")
    private String BASE_URL;


    public FileUploadService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public String saveFile(String givenFilename, byte[] content) {
        try {
            Path uploadPath = Paths.get(UPLOAD_DIR);
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }

            Path filePath = uploadPath.resolve(givenFilename);
            Files.write(filePath, content);

            return BASE_URL + givenFilename;
        } catch (Exception ex){
            throw new BusinessException(ErrorCode.FILE_UPLOAD_FAILED);
        }
    }

    @Transactional(rollbackFor = Exception.class)
    public String execute(UUID userId, String filename, byte[] content){
        UserEntity userEntity = userRepository.findById(userId)
                .orElseThrow(() -> new BusinessException(ErrorCode.USER_NOT_FOUND));

        String oldAvatarUrl = userEntity.getAvatarUrl();
        if (oldAvatarUrl != null && !oldAvatarUrl.isEmpty()) {
            try {
                String oldFilename = oldAvatarUrl.substring(oldAvatarUrl.lastIndexOf("/") + 1);
                Path oldFilePath = Paths.get(UPLOAD_DIR).resolve(oldFilename);

                Files.deleteIfExists(oldFilePath);
            } catch (Exception e) {
                log.warn("Failed to delete old avatar file: " + e.getMessage());
            }
        }

        String extension = "";
        int dotIndex = filename.lastIndexOf(".");
        if (dotIndex >= 0) {
            extension = filename.substring(dotIndex);
        }

        long timestamp = Instant.now().toEpochMilli();
        String meaningfulFilename = "user_" + userId + "_" + timestamp + extension;

        String fileUrl = saveFile(meaningfulFilename, content);

        userEntity.setAvatarUrl(fileUrl);
        userRepository.save(userEntity);

        return fileUrl;
    }
}
