package com.tms.modules.iam.service.usermanagement;

import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.UserResource;
import org.keycloak.representations.idm.CredentialRepresentation;
import org.keycloak.representations.idm.RoleRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@RequiredArgsConstructor
@Service
public class KeycloakService {

    private final Keycloak keycloak;

    @Value("${keycloak.realm}")
    private String realm;

    public boolean userExistsByUsername(String username) {
        List<UserRepresentation> users = keycloak.realm(realm)
                .users()
                .search(username, true);

        return users.stream()
                .anyMatch(u -> u.getUsername().equalsIgnoreCase(username));
    }

    public boolean userExistsByEmail(String email) {
        return !keycloak.realm(realm)
                .users()
                .search(null, null, null, email, 0, 1)
                .isEmpty();
    }

    public String createUser(String username, String email, String firstName, String lastName) {
        UserRepresentation user = new UserRepresentation();
        user.setUsername(username);
        user.setEmail(email);
        user.setEnabled(true);
        user.setFirstName(firstName);
        user.setLastName(lastName);

        Response response = keycloak.realm(realm).users().create(user);
        if (response.getStatus() != 201) {
            String error = response.readEntity(String.class);
            log.error("Keycloak create user failed: status={}, body={}", response.getStatus(), error);
            throw new RuntimeException("Keycloak error: " + error);
        }

        String userId = response.getLocation().getPath().replaceAll(".*/([^/]+)$", "$1");
        return userId;
    }

    public void setPassword(String keycloakUserId, String password) {
        CredentialRepresentation credential = new CredentialRepresentation();
        credential.setType(CredentialRepresentation.PASSWORD);
        credential.setValue(password);
        credential.setTemporary(false);

        keycloak.realm(realm).users().get(keycloakUserId).resetPassword(credential);
    }

    public void assignRealmRoles(String keycloakUserId, List<String> roleNames) {
        List<RoleRepresentation> roles = roleNames.stream()
                .map(roleName -> {
                    try {
                        return keycloak.realm(realm)
                                .roles()
                                .get(roleName)
                                .toRepresentation();
                    } catch (Exception e) {
                        throw new RuntimeException("Role not found in Keycloak: " + roleName);
                    }
                })
                .toList();

        keycloak.realm(realm).users().get(keycloakUserId).roles().realmLevel().add(roles);
    }

    public void deleteUser(String keycloakUserId) {
        keycloak.realm(realm).users().delete(keycloakUserId);
    }

    public void enableUser(String keycloakUserId) {
        UserResource userResource = keycloak.realm(realm).users().get(keycloakUserId);
        UserRepresentation user = userResource.toRepresentation();
        user.setEnabled(true);
        userResource.update(user);
    }

    public void disableUser(String keycloakUserId) {
        UserResource userResource = keycloak.realm(realm).users().get(keycloakUserId);
        UserRepresentation user = userResource.toRepresentation();
        user.setEnabled(false);
        userResource.update(user);
    }

    public void logoutUser(String keycloakUserId) {
        keycloak.realm(realm)
                .users()
                .get(keycloakUserId)
                .logout();
    }

    public void resetPassword(String keycloakUserId, String newPassword) {
        CredentialRepresentation credential = new CredentialRepresentation();
        credential.setType(CredentialRepresentation.PASSWORD);
        credential.setValue(newPassword);

        keycloak.realm(realm)
                .users()
                .get(keycloakUserId)
                .resetPassword(credential);
    }
}
