package com.tms.modules.iam.repository;

import com.tms.shared.model.iam.UserBranchEntity;
import com.tms.shared.model.iam.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;

public interface UserBranchRepository extends JpaRepository<UserBranchEntity, UUID> {
    @Query("""
            select ub from UserBranchEntity ub
            join fetch ub.branch b
            where ub.user.id = :userId and ub.status = 'ACTIVE'
            order by ub.primary desc, b.code asc
            """)
    List<UserBranchEntity> findActiveByUserId(@Param("userId") UUID userId);

    void deleteAllByUserIs(UserEntity user);
}
