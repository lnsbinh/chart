package com.tms.modules.iam.service.usermanagement;

import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

@Slf4j
@Component
@RequiredArgsConstructor
public class EmailService implements EmailSender {

    private final JavaMailSender mailSender;
    private final TemplateEngine templateEngine;

    @Value("${app.mail.from}")
    private String fromEmail;

    @Async("emailExecutor")
    @Override
    public void sendResetPasswordEmail(String toEmail, String password) {
        try {
            MimeMessage message = mailSender.createMimeMessage();

            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");
            helper.setTo(toEmail);
            helper.setFrom(fromEmail);
            helper.setSubject("[TMS] Password Reset Notification");

            Context thymeleafContext = new Context();
            thymeleafContext.setVariable("password", password);

            String htmlContent = templateEngine.process("reset-password", thymeleafContext);


            helper.setText(htmlContent, true);

            mailSender.send(message);

            log.info("Reset password HTML email sent successfully to {}", toEmail);

        } catch (Exception e) {
            log.error("Failed to send reset password HTML email to {}: {}", toEmail, e.getMessage());
            throw new RuntimeException("Failed to send HTML email", e);
        }
    }
}
