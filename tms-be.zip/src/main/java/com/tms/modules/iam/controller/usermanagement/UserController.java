package com.tms.modules.iam.controller.usermanagement;

import com.tms.modules.iam.dto.CreateUserRequestDTO;
import com.tms.modules.iam.dto.LockUserRequestDTO;
import com.tms.modules.iam.dto.UpdateUserRequestDTO;
import com.tms.modules.iam.dto.UserDTO;
import com.tms.modules.iam.service.usermanagement.UserService;
import com.tms.shared.dto.ApiResponseDTO;
import com.tms.shared.dto.PageResultDTO;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

@Slf4j
@RestController
@RequestMapping("/api/v1/users")
public class UserController {

    private final UserService userService;

    public UserController(
            UserService userService
    ) {
        this.userService = userService;
    }

    @PostMapping
//    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponseDTO<?>> createUser(@Valid @RequestBody CreateUserRequestDTO request) {
        String userId = userService.createUser(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponseDTO.success(Map.of("userId", userId)));
    }

    @PatchMapping("/{userId}/status")
//    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponseDTO<?>> toggleUserStatus(
            @PathVariable(name = "userId") UUID userId,
            @Valid @RequestBody LockUserRequestDTO request) {
        String message = userService.toggleUserStatus(userId, request.getStatus());
        return ResponseEntity.ok(ApiResponseDTO.success(message));
    }

    @PutMapping("/{userId}")
//    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponseDTO<?>> updateUser(
            @PathVariable(name = "userId") UUID userId,
            @Valid @RequestBody UpdateUserRequestDTO request) {
        String message = userService.updateUser(userId, request);
        return ResponseEntity.ok(ApiResponseDTO.success(message));
    }

//    @PreAuthorize("hasAnyAuthority('ROLE_ADMIN', 'ROLE_SUPERVISOR')")
    @GetMapping("/{email:.+}")
    public ResponseEntity<Object> getUserByEmail(@PathVariable String email) {
        Optional<Object> user = userService.findByEmail(email).map(u -> (Object) u);
        return user.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

//    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @GetMapping
    public ResponseEntity<ApiResponseDTO<?>> getAllUsersWithPagination(
            @RequestParam(name = "page", defaultValue = "0", required = false) int page,
            @RequestParam(name = "size", defaultValue = "10", required = false) int size,
            @RequestParam(name = "status", required = false) List<String> status,
            @RequestParam(name = "roleIds", required = false) List<UUID> roleIds,
            @RequestParam(name = "branchIds", required = false) List<UUID> branchIds,
            @RequestParam(name = "idSort",  required = false) String idSort,
            @RequestParam(name = "statusSort", required = false) String statusSort,
            @RequestParam(name = "search", required = false) String search
    ) {
        PageResultDTO<UserDTO> pageResult = userService.findAllUserWithRolesAndBranches(page, size, status, roleIds,
                branchIds, idSort, statusSort, search
        );
        return ResponseEntity.ok(
                ApiResponseDTO.success(
                        pageResult
                )
        );
    }

    @PostMapping("/{userId}/reset-password")
    public ResponseEntity<ApiResponseDTO<?>> resetPassword(@PathVariable(name = "userId") UUID targetUserId) {
        userService.resetPassword(targetUserId);
        return ResponseEntity.ok(ApiResponseDTO.success("Password reset successfully"));
    }

    @PatchMapping("/{userId}/delete")
    public ResponseEntity<ApiResponseDTO<?>> softDeleteUser(
            @PathVariable(name = "userId") UUID userId
    ){
        userService.deleteUser(userId);
        return ResponseEntity.ok(ApiResponseDTO.success("User deleted successfully"));
    }
}
