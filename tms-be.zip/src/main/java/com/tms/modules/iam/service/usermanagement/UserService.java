package com.tms.modules.iam.service.usermanagement;

import com.tms.modules.iam.dto.CreateUserRequestDTO;
import com.tms.modules.iam.dto.UpdateUserRequestDTO;
import com.tms.modules.iam.dto.UserDTO;
import com.tms.modules.iam.exception.BusinessException;
import com.tms.modules.iam.exception.ErrorCode;
import com.tms.modules.iam.repository.BranchRepository;
import com.tms.modules.iam.repository.RoleRepository;
import com.tms.modules.iam.repository.UserBranchRepository;
import com.tms.modules.iam.repository.UserRepository;
import com.tms.modules.iam.repository.UserRoleAssignmentRepository;
import com.tms.modules.iam.service.rbac.AuthzContextService;
import com.tms.shared.dto.PageResultDTO;
import com.tms.shared.model.iam.BranchEntity;
import com.tms.shared.model.iam.OrganizationEntity;
import com.tms.shared.model.iam.RoleEntity;
import com.tms.shared.model.iam.UserBranchEntity;
import com.tms.shared.model.iam.UserEntity;
import com.tms.shared.model.iam.UserRoleAssignmentEntity;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final UserRoleAssignmentRepository userRoleAssignmentRepository;
    private final UserBranchRepository userBranchRepository;
    private final BranchRepository branchRepository;
    private final KeycloakService keycloakService;
    private final PasswordEncoder passwordEncoder;
    private final UserCodeGeneratorPort userCodeGeneratorPort;
    private final UserMapper userMapper;
    private final PasswordGenerator passwordGenerator;
    private final EmailSender emailSender;
    private final AuthzContextService authzContextService;

    @Transactional(rollbackFor = Exception.class)
    public String createUser(CreateUserRequestDTO request) {
        // Check uniqueness
//        if (userRepository.existsByUsername(request.getUsername())) {
//            throw new BusinessException(ErrorCode.USERNAME_ALREADY_EXISTS);
//        }
//        if (userRepository.existsByEmail(request.getEmail())) {
//            throw new BusinessException(ErrorCode.EMAIL_ALREADY_EXISTS);
//        }
//        if (userRepository.existsByUserCode(request.getUserCode())) {
//            throw new BusinessException(ErrorCode.USER_CODE_ALREADY_EXISTS);
//        }

        // check duplicate username/email in Keycloak before creating user in Keycloak to avoid unnecessary calls
//        if (keycloakService.userExistsByUsername(request.getUsername())) {
//            throw new BusinessException(ErrorCode.USERNAME_EXISTS_IN_KEYCLOAK);
//        }
//
//        if (keycloakService.userExistsByEmail(request.getEmail())) {
//            throw new BusinessException(ErrorCode.EMAIL_EXISTS_IN_KEYCLOAK);
//        }

        List<UserEntity> conflicts = userRepository.findByUsernameOrEmail(request.getUsername(), request.getEmail());

        if (!conflicts.isEmpty()) {
            for (UserEntity u : conflicts) {
                if (request.getUsername().equalsIgnoreCase(u.getUsername())) {
                    throw new BusinessException(ErrorCode.USERNAME_ALREADY_EXISTS);
                }
                if (request.getEmail().equalsIgnoreCase(u.getEmail())) {
                    throw new BusinessException(ErrorCode.EMAIL_ALREADY_EXISTS);
                }
            }
        }

        // Fetch roles
        List<RoleEntity> roles = roleRepository.findAllById(request.getRoleIds()).stream().toList();
        roles.forEach(r -> log.info("Role: {}", r.getCode()));

        if (roles.size() != request.getRoleIds().size()) {
            throw new BusinessException(ErrorCode.ROLES_NOT_FOUND);
        }

        // Fetch branches
        List<BranchEntity> branches = branchRepository.findByIdIn(request.getBranchIds());
        if (branches.size() != request.getBranchIds().size()) {
            throw new BusinessException(ErrorCode.BRANCHES_NOT_FOUND);
        }

        OrganizationEntity organization = branches.getFirst().getOrganization();

        // Create user in Keycloak
        String keycloakUserId = null;
        try {
            keycloakUserId = keycloakService.createUser(request.getUsername(), request.getEmail(), request.getFirstName(), request.getLastName());

        } catch (Exception e) {
            log.error("Failed to create user in Keycloak", e);
            throw new RuntimeException("Failed to create user");
        }

        // Save in DB
        try {

            /*
            Should place assign role and password for keycloak user here to rollback if any error occurs
            when saving user in DB, otherwise we will have orphan user in Keycloak
            without corresponding record in DB if error occurs after creating user in Keycloak
             */
            List<String> roleNames = roles.stream().map(RoleEntity::getCode).toList();

            keycloakService.setPassword(keycloakUserId, request.getPassword());
            keycloakService.assignRealmRoles(keycloakUserId, roleNames);

            UserEntity user = new UserEntity();
            user.setKeycloakUserId(UUID.fromString(keycloakUserId));
            user.setKeycloakUserName(request.getUsername());
            user.setOrganizationId(organization.getId()); // replace random organizationId by organizationId of default branch
            user.setUserCode(userCodeGeneratorPort.generateUserCode());
            user.setUsername(request.getUsername());
            user.setPassword(passwordEncoder.encode(request.getPassword()));
            user.setFirstName(request.getFirstName());
            user.setLastName(request.getLastName());
            user.setEmail(request.getEmail());
            user.setStatus(request.getStatus());
//            user.setAvatarUrl(request.getAvatarUrl());
            // first branch as default
            user.setDefaultBranchId(request.getBranchIds().get(0));


            UserEntity savedUser =  userRepository.save(user);
            log.debug("User saved in DB with ID: {}", user.getId());

            // Save user roles and user branch
            List<UserRoleAssignmentEntity> listUserRole = new ArrayList<>();
            List<UserBranchEntity> listUserBranch = new ArrayList<>();

//            for (UUID branchId : request.getBranchIds()) {
//                listUserBranch.add(new UserBranchEntity(user, new BranchEntity(branchId)));
//
//                for (RoleEntity role : roles) {
//                    UserRoleAssignmentEntity userRole = new UserRoleAssignmentEntity();
//                    userRole.setRole(role);
//                    userRole.setOrganization(new OrganizationEntity(user.getOrganizationId()));
//                    userRole.setUser(user);
//                    userRole.setBranch(new BranchEntity(branchId));
//
//                    listUserRole.add(userRole);
//                }
//            }

            for(BranchEntity branch : branches){
                listUserBranch.add(new UserBranchEntity(savedUser, branch, organization));

                for (RoleEntity role : roles) {

                    UserRoleAssignmentEntity userRole = new UserRoleAssignmentEntity();
                    userRole.setRole(role);
                    userRole.setOrganization(organization);
                    userRole.setUser(savedUser);
                    userRole.setBranch(branch);

                    if("GLOBAL".equalsIgnoreCase(role.getAllowedScopeType())){
                        log.error("Role {} has GLOBAL scope but assigned with branch {}. This should not happen.", role.getCode(), branch.getName());
                        continue;
                    } else {
                        userRole.setScopeType(
                                "ORGANIZATION".equalsIgnoreCase(role.getAllowedScopeType())?
                                        "ORGANIZATION" : "BRANCH"
                        );
                    }

                    listUserRole.add(userRole);
                }
            }

            userBranchRepository.saveAll(listUserBranch);
            userRoleAssignmentRepository.saveAll(listUserRole);

            return savedUser.getId().toString();
        } catch (Exception e) {
            log.error("Failed to save user in DB, deleting from Keycloak", e);

            try {
                keycloakService.deleteUser(keycloakUserId);
            } catch (Exception ex) {
                log.error("Failed to delete user from Keycloak", ex);
            }

            throw new RuntimeException("Failed to create user");
        }
    }

    public List<UserEntity> getAllUsers() {
        return userRepository.findAll();
    }

    public Optional<UserEntity> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    public List<RoleEntity> getAllRoles() {
        return roleRepository.findAll();
    }

    public Optional<RoleEntity> getRoleById(UUID roleId) {
        return roleRepository.findById(roleId);
    }

    public List<BranchEntity> getAllBranches() {
        return branchRepository.findAll();
    }

    public Optional<BranchEntity> getBranchById(UUID branchId) {
        return branchRepository.findById(branchId);
    }

    @Transactional
    public String toggleUserStatus(UUID userId, String newStatus) {
        // Get current user from context (assuming authentication is set up)
//        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
//
//        JwtAuthenticationToken jwtAuth = (JwtAuthenticationToken) auth;
//
//        Jwt jwt = jwtAuth.getToken();
//
//        String currentUsername = jwt.getClaim("preferred_username");
//
//        String currentUsername = jwt.getClaim("preferred_username");
//
//        Optional<UserEntity> currentUserOpt = userRepository.findByUsername(currentUsername);
//
//        if (currentUserOpt.isEmpty()) {
//            throw new BadRequestException("Current user not found");
//        }

        // 1. Use userid to find user in database
        Optional<UserEntity> currentUserOpt = userRepository.findById(userId);
        if (currentUserOpt.isEmpty()) {
            throw new BusinessException(ErrorCode.USER_NOT_FOUND);
        }

        UserEntity targetUser = currentUserOpt.get();

        // 2. Get Keycloak user ID from found user
        String keycloakUserId = targetUser.getKeycloakUserId().toString();

        // Rule: Admin cannot lock their own account
//        if (currentUserOpt.get().getId().equals(userId) && "LOCKED".equals(newStatus)) {
//            throw new BadRequestException("Cannot lock your own account");
//        }

        // Rule: If only 1 ADMIN exists and trying to lock the last admin
        if ("LOCKED".equals(newStatus) && isUserAdmin(targetUser)) {
            long activeAdminCount = countActiveAdmins();
            if (activeAdminCount <= 1) {
                throw new BusinessException(ErrorCode.CANNOT_LOCK_LAST_ADMIN);
            }
        }

        String oldStatus = targetUser.getStatus();
        targetUser.setStatus(newStatus);

        userRepository.save(targetUser);

        // 3. Lock/unlock in Keycloak using the Keycloak user ID
        if ("LOCKED".equals(newStatus)) {
            terminateUserSessions(keycloakUserId);
            return "User has been locked";
        } else {
            keycloakService.enableUser(keycloakUserId);
        }

        return "User has been unlocked";
    }

    private boolean isUserAdmin(UserEntity user) {
        // Check if user has ADMIN role
        if (user.getUserRoleAssignments() == null) {
            return false;
        }

        return user.getUserRoleAssignments().stream().anyMatch(
                userRole -> "ADMIN".equalsIgnoreCase(userRole.getRole().getCode()));
    }

    private long countActiveAdmins() {
        List<UserEntity> allUsers = userRepository.findAll();
        return allUsers.stream()
                .filter(user -> "ACTIVE".equals(user.getStatus()) && isUserAdmin(user))
                .count();
    }

    private void terminateUserSessions(String keycloakUserId) {
        // Terminate all active sessions for the user
        // This can be implemented using:
        // 1. JWT blacklist: Add token to Redis/database
        // 2. Session invalidation: Remove from session store
        // 3. Keycloak logout: Call Keycloak admin API to logout user
        try {
            // 1. Disable user in Keycloak
            keycloakService.disableUser(keycloakUserId);
            // 2. Call Keycloak API to logout user to kill active session
            keycloakService.logoutUser(keycloakUserId);
            log.info("Terminating sessions for user with keycloakUserId: {}", keycloakUserId);
        } catch (Exception e) {
            log.warn("Failed to terminate sessions for user with keycloakUserId: {}", keycloakUserId, e);
        }
    }

    @Transactional
    public String updateUser(UUID userId, UpdateUserRequestDTO request) {
        // Get the user to update
        Optional<UserEntity> userOpt = userRepository.findById(userId);
        if (userOpt.isEmpty()) {
            throw new BusinessException(ErrorCode.USER_NOT_FOUND);
        }

        UserEntity user = userOpt.get();

        // Validate email uniqueness if email changed
        if (!user.getEmail().equals(request.getEmail()) &&
                userRepository.existsByEmail(request.getEmail())) {
            throw new BusinessException(ErrorCode.EMAIL_ALREADY_EXISTS);
        }

        // Fetch new roles
        List<RoleEntity> newRoles = roleRepository.findAllById(request.getRoleIds()).stream().toList();
        if (newRoles.size() != request.getRoleIds().size()) {
            throw new BusinessException(ErrorCode.ROLES_NOT_FOUND);
        }

        // Fetch new branches
        List<BranchEntity> newBranches = branchRepository.findByIdIn(request.getBranchIds());
        if (newBranches.size() != request.getBranchIds().size()) {
            throw new BusinessException(ErrorCode.BRANCHES_NOT_FOUND);
        }

        // Rule: If only ONE ADMIN exists → cannot remove ADMIN role
        boolean currentUserHasAdminRole = isUserAdmin(user);
        boolean newRolesHaveAdmin = newRoles.stream()
                .anyMatch(role -> "ADMIN".equalsIgnoreCase(role.getCode()));

        if (currentUserHasAdminRole && !newRolesHaveAdmin) {
            long activeAdminCount = countActiveAdmins();
            if (activeAdminCount <= 1) {
                throw new BusinessException(ErrorCode.CANNOT_REMOVE_ADMIN_ROLE);
            }
        }

        // validate email and update in keycloak
        boolean isEmailChanged = !user.getEmail().equals(request.getEmail());

        if (isEmailChanged) {
            if (userRepository.existsByEmail(request.getEmail())) {
                throw new BusinessException(ErrorCode.EMAIL_ALREADY_EXISTS);
            }

            try {
                keycloakService.updateUserEmail(user.getKeycloakUserId().toString(), request.getEmail());
            } catch (Exception ex) {
                log.error("Failed to update email in Keycloak for userId: {}", userId, ex);
                throw new BusinessException(ErrorCode.INTERNAL_SERVER_ERROR, "Failed to sync email with Identity Provider");
            }
        }

        // Update user info
        user.setFirstName(request.getFirstName());
        user.setLastName(request.getLastName());
        user.setEmail(request.getEmail());
//        user.setStatusCode(request.getStatus());

        // Delete old roles and branches
        userRoleAssignmentRepository.deleteAllByUserIs(user);
        userBranchRepository.deleteAllByUserIs(user);

        // Save updated user
        UserEntity updatedUser = userRepository.save(user);

        List<UserBranchEntity> currentBranches = userBranchRepository.findAllByUserIs(user);

        // Delete branches that are not in newBranches
        List<UserBranchEntity> branchesToDelete = currentBranches.stream()
                .filter(cb -> newBranches.stream().noneMatch(nb -> nb.getId().equals(cb.getBranch().getId())))
                .toList();
        userBranchRepository.deleteAll(branchesToDelete);

        List<BranchEntity> branchesToAdd = newBranches.stream()
                .filter(nb -> currentBranches.stream().noneMatch(cb -> cb.getBranch().getId().equals(nb.getId())))
                .toList();

        List<UserBranchEntity> listUserBranchToSave = new ArrayList<>();
        for (BranchEntity branch : branchesToAdd) {
            listUserBranchToSave.add(new UserBranchEntity(updatedUser, branch, branch.getOrganization()));
        }
        userBranchRepository.saveAll(listUserBranchToSave);

        // Sync UserRoleAssignment
        List<UserRoleAssignmentEntity> currentRoles = userRoleAssignmentRepository.findAllByUserIs(user);

        // Delete roles that are not in newRoles or their branch is not in newBranches
        List<UserRoleAssignmentEntity> rolesToDelete = currentRoles.stream()
                .filter(cr -> newRoles.stream().noneMatch(nr -> nr.getId().equals(cr.getRole().getId())) ||
                        newBranches.stream().noneMatch(nb -> nb.getId().equals(cr.getBranch().getId())))
                .toList();
        userRoleAssignmentRepository.deleteAll(rolesToDelete);

        // Add new roles that do not exist in currentRoles with the corresponding branch
        List<UserRoleAssignmentEntity> rolesToAdd = new ArrayList<>();
        for (BranchEntity branch : newBranches) {
            for (RoleEntity role : newRoles) {
                boolean alreadyExists = currentRoles.stream()
                        .anyMatch(cr -> cr.getRole().getId().equals(role.getId()) && cr.getBranch().getId().equals(branch.getId()));

                if (!alreadyExists) {
                    UserRoleAssignmentEntity userRole = new UserRoleAssignmentEntity();
                    userRole.setRole(role);
                    userRole.setOrganization(new OrganizationEntity(user.getOrganizationId()));
                    userRole.setUser(updatedUser);
                    userRole.setBranch(branch);

                    if ("GLOBAL".equalsIgnoreCase(role.getAllowedScopeType())) {
                        log.error("Role {} has GLOBAL scope but assigned with branch {}", role.getCode(), branch.getName());
                        continue;
                    } else {
                        userRole.setScopeType("ORGANIZATION".equalsIgnoreCase(role.getAllowedScopeType()) ? "ORGANIZATION" : "BRANCH");
                    }
                    rolesToAdd.add(userRole);
                }
            }
        }
        userRoleAssignmentRepository.saveAll(rolesToAdd);

        return "User updated successfully";
    }

    @Transactional
    public void deleteUser(UUID userId) {
        UserEntity user = userRepository.findById(userId)
                .orElseThrow(() -> new BusinessException(ErrorCode.USER_NOT_FOUND));

        user.setDeleted(true);

        // Soft delete: set isDeleted flag to true and status to DELETED
        userRepository.save(user);

        keycloakService.disableUser(user.getKeycloakUserId().toString());
        keycloakService.logoutUser(user.getKeycloakUserId().toString());
    }

    public PageResultDTO<UserDTO> findAllUserWithRolesAndBranches(int page, int pageSize, List<String> status, List<UUID> roleIds,
                                                                  List<UUID> branchIds, String idSort, String statusSort, String search) {
        if (page < 0 || pageSize <= 0) {
            throw new BusinessException(ErrorCode.INVALID_REQUEST);
        }

        List<Sort.Order> orders = new ArrayList<>();
        if (idSort != null) {
            orders.add(new Sort.Order(parseSortDirection(idSort), "userCode"));
        }
        if (statusSort != null) {
            orders.add(new Sort.Order(parseSortDirection(statusSort), "status"));
        }

        Sort sort = orders.isEmpty() ? Sort.unsorted() : Sort.by(orders);

        // Tạo Pageable với phân trang và sắp xếp
        Pageable pageable = orders.isEmpty()
                ? PageRequest.of(page, pageSize)
                : PageRequest.of(page, pageSize, sort);

        List<UUID> validRoleIds = (roleIds != null && roleIds.isEmpty()) ? null : roleIds;
        List<UUID> validBranchIds = (branchIds != null && branchIds.isEmpty()) ? null : branchIds;

        Page<UserEntity> pageResult = userRepository.findAllWithRolesAndBranchesFiltered(
                status, roleIds, branchIds, search, pageable);

        List<UserDTO> userDtos = pageResult.getContent().stream()
                .map(userMapper::toDto)
                .toList();

        return PageResultDTO.<UserDTO>builder()
                .content(userDtos)
                .page(pageResult.getNumber())
                .size(pageResult.getSize())
                .totalElements(pageResult.getTotalElements())
                .totalPages(pageResult.getTotalPages())
                .build();
    }

    private Sort.Direction parseSortDirection(String sortDirection) {
        if (sortDirection == null) {
            return Sort.Direction.ASC;
        }
        return "desc".equalsIgnoreCase(sortDirection) ? Sort.Direction.DESC : Sort.Direction.ASC;
    }

    @Transactional
    public void resetPassword(UUID targetUserId){
//        authzContextService.
//        // get current user
//        String currentLoggedUser =
//        String emailOfCurrentUser = AuthUtils.getEmailOfCurrentUser();
//        log.info("current user: {}", currentUser);
//        log.info("email of current user: {}", emailOfCurrentUser);


        // check valid user
        UserEntity targetUser = userRepository.findById(targetUserId)
                .orElseThrow(() -> new BusinessException(ErrorCode.USER_NOT_FOUND));
//
        // check user status
        if(!"ACTIVE".equalsIgnoreCase(targetUser.getStatus())){
            throw new BusinessException(ErrorCode.USER_NOT_ACTIVE);
        }
//
//        // rule: can not reset password of current user
//        if(user.getUsername().equals(currentUser) || user.getEmail().equals(emailOfCurrentUser)){
//            throw new BusinessException(ErrorCode.CAN_NOT_RESET_OWN_PASSWORD);
//        }
//
        // generate new password
        String newPassword = passwordGenerator.generate(10);
        String targetKeycloakUserId = targetUser.getKeycloakUserId().toString();

        // update password on keycloak
        try {
            keycloakService.resetPassword(targetKeycloakUserId, newPassword);

            // logout session
            keycloakService.logoutUser(targetKeycloakUserId);
        } catch (Exception ex){
            log.error("Failed to reset password in Keycloak for userId: {}", targetUserId, ex);
            throw new BusinessException(ErrorCode.INTERNAL_SERVER_ERROR, "\"Failed to sync password with Identity Provider\"");
        }

        targetUser.setPassword(passwordEncoder.encode(newPassword));
        userRepository.save(targetUser);

        // send email
        emailSender.sendResetPasswordEmail(
                targetUser.getEmail(),
                newPassword
        );
    }
}