package com.tms.modules.iam.constants;

public final class RoleCodes {
    public static final String SUPER_ADMIN = "SUPER_ADMIN";
    public static final String ORG_ADMIN = "ADMIN";
    public static final String FINANCE_OPS = "FINANCE_OPS";
    public static final String SUPERVISOR = "SUPERVISOR";
    public static final String DISPATCHER = "DISPATCHER";
    public static final String OPERATION_STAFF = "OPERATION_STAFF";
    public static final String DRIVER = "DRIVER";

    private RoleCodes() {
    }
}
