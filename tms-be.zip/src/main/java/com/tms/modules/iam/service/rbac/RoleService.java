package com.tms.modules.iam.service.rbac;

import com.tms.shared.model.iam.RoleEntity;
import com.tms.modules.iam.repository.RoleRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class RoleService {
    private final RoleRepository roleRepository;

    public RoleService(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }

    public List<RoleEntity> getAllRoles() { return roleRepository.findAll(); }
    public RoleEntity addRole(RoleEntity role) { return roleRepository.save(role); }
    public void deleteRole(UUID id) { roleRepository.deleteById(id); }
}
