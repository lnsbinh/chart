package com.tms.modules.iam.service.rbac;

import com.tms.modules.iam.repository.RolePermissionRepository;
import com.tms.modules.iam.repository.RoleRepository;
import com.tms.shared.model.iam.RoleEntity;
import com.tms.shared.model.iam.RolePermissionEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class RoleService {
    private final RoleRepository roleRepository;

    private final RolePermissionRepository rolePermissionRepository;


//    public List<RolePermissionEntity> findPermissionsByRoleCode(String roleCode) {
//        return rolePermissionRepository.findPermissionsByRoleCode(roleCode);
//    }

    public List<RoleEntity> getAllRoles() { 
        return roleRepository.findAll().stream()
                .filter(role -> !"SUPER_ADMIN".equals(role.getCode()))
                .toList();
    }
    public RoleEntity addRole(RoleEntity role) { return roleRepository.save(role); }
    public void deleteRole(UUID id) { roleRepository.deleteById(id); }
}
