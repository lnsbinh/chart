package com.tms.modules.iam.exception;

import org.springframework.http.HttpStatus;
public enum ErrorCode {

    INVALID_REQUEST("ERR001", "Invalid request", HttpStatus.BAD_REQUEST),
    USER_NOT_FOUND("ERR002", "User not found", HttpStatus.NOT_FOUND),
    CAN_NOT_RESET_OWN_PASSWORD("ERR003", "Cannot reset own password", HttpStatus.BAD_REQUEST),
    USER_ALREAD_LOCKED("ERR004", "User already locked", HttpStatus.BAD_REQUEST),
    FILE_UPLOAD_FAILED("ERR005", "File upload failed", HttpStatus.INTERNAL_SERVER_ERROR),
    USERNAME_ALREADY_EXISTS("ERR006", "Username already exists", HttpStatus.BAD_REQUEST),
    EMAIL_ALREADY_EXISTS("ERR007", "Email already exists", HttpStatus.BAD_REQUEST),
    USERNAME_EXISTS_IN_KEYCLOAK("ERR008", "Username already exists in Keycloak", HttpStatus.BAD_REQUEST),
    EMAIL_EXISTS_IN_KEYCLOAK("ERR009", "Email already exists in Keycloak", HttpStatus.BAD_REQUEST),
    ROLES_NOT_FOUND("ERR010", "Some roles not found", HttpStatus.BAD_REQUEST),
    BRANCHES_NOT_FOUND("ERR011", "Some branches not found", HttpStatus.BAD_REQUEST),
    CANNOT_LOCK_OWN_ACCOUNT("ERR012", "Cannot lock your own account", HttpStatus.BAD_REQUEST),
    CANNOT_LOCK_LAST_ADMIN("ERR013", "Cannot lock the last active admin account", HttpStatus.BAD_REQUEST),
    CANNOT_REMOVE_ADMIN_ROLE("ERR014", "Cannot remove ADMIN role from the last active admin account", HttpStatus.BAD_REQUEST)
    ;

    private final String code;
    private final String message;
    private final HttpStatus status;

    ErrorCode(String code, String message, HttpStatus status) {
        this.code = code;
        this.message = message;
        this.status = status;
    }

    public String getCode() { return code; }
    public String getMessage() { return message; }
    public HttpStatus getStatus() { return status; }
}
