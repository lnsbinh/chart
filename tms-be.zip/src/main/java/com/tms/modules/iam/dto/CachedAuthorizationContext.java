package com.tms.modules.iam.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CachedAuthorizationContext implements Serializable {
    private String cacheKey;
    private AppSecurityContext securityContext;
}
