package com.tms.modules.iam.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ScopedRoleAssignment implements Serializable {
    private String roleCode;
    private String scopeType;
    private UUID organizationId;
    private UUID branchId;
}
