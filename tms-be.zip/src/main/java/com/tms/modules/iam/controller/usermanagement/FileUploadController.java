package com.tms.modules.iam.controller.usermanagement;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/users")
public class FileUploadController {
//    private final UploadAvatarUseCase uploadAvatarUseCase;
//
//    private final UserService userService;
//
//    public FileUploadController(UploadAvatarUseCase uploadAvatarUseCase, UserService userService) {
//        this.uploadAvatarUseCase = uploadAvatarUseCase;
//        this.userService = userService;
//    }
//
//    @PostMapping("/{userId}/avatar")
//    public ResponseEntity<?> uploadAvatar(@PathVariable(name = "userId") UUID userId, @RequestParam("file") MultipartFile file) throws IOException {
//        try {
//            byte[] fileContent = file.getBytes();
//
//            String filename = file.getOriginalFilename();
//            String fileUrl = uploadAvatarUseCase.execute(userId, filename, fileContent);
//
//            return ResponseEntity.ok(ApiResponse.success(Map.of("avatarUrl", fileUrl)));
//        } catch (Exception ex){
//            return ResponseEntity.badRequest().body(ApiResponse.error(ex.getMessage()));
//        }
//    }
}
