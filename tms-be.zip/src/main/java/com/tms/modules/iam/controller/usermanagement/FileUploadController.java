package com.tms.modules.iam.controller.usermanagement;

import com.tms.modules.iam.service.usermanagement.FileUploadService;
import com.tms.modules.iam.service.usermanagement.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Map;
import java.util.UUID;

@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/users")
public class FileUploadController {

    private final FileUploadService fileUploadService;


    @PostMapping("/{userId}/avatar")
    public ResponseEntity<?> uploadAvatar(
            @PathVariable(name = "userId") UUID userId,
            @RequestParam("file") MultipartFile file
    ) throws IOException {
        try {
            byte[] fileContent = file.getBytes();

            String filename = file.getOriginalFilename();
            String fileUrl = fileUploadService.execute(userId, filename, fileContent);

            return ResponseEntity.ok().body(
                    Map.of("avatarUrl", fileUrl)
            );
        } catch (Exception ex){
           log.error("Failed to upload avatar for user {}: {}", userId, ex.getMessage());
           return ResponseEntity.badRequest().body(Map.of("error", "Failed to upload avatar: " + ex.getMessage()));
        }
    }
}
