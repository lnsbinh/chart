package com.tms.modules.iam.controller.rbac;

import com.tms.shared.model.iam.BranchEntity;
import com.tms.modules.iam.service.rbac.BranchService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/branches")
public class BranchController {
    private final BranchService branchService;

    public BranchController(BranchService branchService) {
        this.branchService = branchService;
    }

    @GetMapping
    public List<BranchEntity> getAllBranches() {
        return branchService.getAllBranches();
    }

    @PostMapping
    public BranchEntity createBranch(@RequestBody BranchEntity branch) {
        return branchService.addBranch(branch);
    }

    @DeleteMapping("/{id}")
    public void deleteBranch(@PathVariable UUID id) {
        branchService.deleteBranch(id);
    }
}
