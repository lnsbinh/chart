package com.tms.modules.iam.repository;

import com.tms.shared.model.iam.PermissionEntity;
import com.tms.shared.model.iam.RolePermissionEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.UUID;

public interface RolePermissionRepository extends JpaRepository<RolePermissionEntity, UUID> {
//    @Query("""
//        SELECT rp
//        FROM RolePermissionEntity rp
//        LEFT JOIN JOIN rp.role r ON r.id = rp.role.id AND r.code = :roleCode
//        LEFT JOIN RoleHierarchyEntity rh ON rh.parentRole
//        LEFT JOIN FETCH parentRole.permissions parentPermissions
//        WHERE r.code = :roleCode
//    """)
//    List<RolePermissionEntity> findPermissionsByRoleCode(String roleCode);
}
