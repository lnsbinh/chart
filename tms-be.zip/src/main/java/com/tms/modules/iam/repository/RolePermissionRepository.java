package com.tms.modules.iam.repository;

import com.tms.shared.model.iam.RolePermissionEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface RolePermissionRepository extends JpaRepository<RolePermissionEntity, UUID> {
}
