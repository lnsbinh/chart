package com.tms.modules.iam.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
public class LockUserRequestDTO {
    @NotBlank(message = "Status is required")
    @Pattern(regexp = "^(ACTIVE|LOCKED)$", message = "Status must be ACTIVE or LOCKED")
    private String status;
}
