package com.tms.modules.iam.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.UUID;

@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class UserDTO {
    private UUID id;
    private String userCode;
    private String username;
    private String email;
    private String phone;
    private String firstName;
    private String lastName;
    private String statusCode;
    private String avatarUrl;
    @JsonIgnore
    private String password;

    private List<AssignedRoleDTO> roles;
    private List<AssignedBranchDTO> branches;

    public UserDTO(UUID id, String userCode, String username, String email,
                   String phone, String firstName, String lastName,
                   String statusCode, String avatarUrl, String password) {
        this.id = id;
        this.userCode = userCode;
        this.username = username;
        this.email = email;
        this.phone = phone;
        this.firstName = firstName;
        this.lastName = lastName;
        this.statusCode = statusCode;
        this.avatarUrl = avatarUrl;
        this.password = password;
    }

    public UserDTO(UUID id, String userCode, String username, String email,
                   String phone, String firstName, String lastName,
                   String status, String avatarUrl, List<AssignedRoleDTO> assignedRoleDTOSDTOS,
                   List<AssignedBranchDTO> branchDTOS) {
        this.id = id;
        this.userCode = userCode;
        this.username = username;
        this.email = email;
        this.phone = phone;
        this.firstName = firstName;
        this.lastName = lastName;
        this.statusCode = status;
        this.avatarUrl = avatarUrl;
        this.roles = assignedRoleDTOSDTOS;
        this.branches = branchDTOS;
    }
}
