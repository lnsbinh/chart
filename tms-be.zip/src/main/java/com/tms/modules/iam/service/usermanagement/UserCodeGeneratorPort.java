package com.tms.modules.iam.service.usermanagement;

import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class UserCodeGeneratorPort {
    public String generateUserCode() {
        // Simple implementation: generate a random code
        return "USR" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }
}
