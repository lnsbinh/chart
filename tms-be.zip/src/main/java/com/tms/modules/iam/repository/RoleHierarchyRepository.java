package com.tms.modules.iam.repository;

import com.tms.shared.model.iam.RoleHierarchyEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface RoleHierarchyRepository extends JpaRepository<RoleHierarchyEntity, UUID> {
}
