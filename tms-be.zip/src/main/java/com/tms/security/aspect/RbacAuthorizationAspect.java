package com.tms.security.aspect;

import com.tms.security.annotation.RequireAnyPermission;
import com.tms.security.annotation.RequireAnyRole;
import com.tms.security.config.AppSecurityContextHolder;
import com.tms.modules.iam.dto.AppSecurityContext;
import com.tms.security.exception.ForbiddenException;
import com.tms.modules.iam.service.rbac.PermissionEvaluator;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;

@Aspect
@Component
public class RbacAuthorizationAspect {

    private final PermissionEvaluator permissionEvaluator;

    public RbacAuthorizationAspect(PermissionEvaluator permissionEvaluator) {
        this.permissionEvaluator = permissionEvaluator;
    }

    @Around("@within(com.tms.security.annotation.RequireAnyRole) || @annotation(com.tms.security.annotation.RequireAnyRole) || @within(com.tms.security.annotation.RequireAnyPermission) || @annotation(com.tms.security.annotation.RequireAnyPermission)")
    public Object authorize(ProceedingJoinPoint joinPoint) throws Throwable {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        Class<?> targetClass = joinPoint.getTarget().getClass();

        RequireAnyRole roleAnnotation = AnnotatedElementUtils.findMergedAnnotation(method, RequireAnyRole.class);
        if (roleAnnotation == null) {
            roleAnnotation = AnnotatedElementUtils.findMergedAnnotation(targetClass, RequireAnyRole.class);
        }

        RequireAnyPermission permissionAnnotation = null; // AnnotatedElementUtils.findMergedAnnotation(method, RequireAnyPermission.class);
        if (permissionAnnotation == null) {
            // permissionAnnotation = AnnotatedElementUtils.findMergedAnnotation(targetClass, RequireAnyPermission.class);
        }

        if (roleAnnotation == null && permissionAnnotation == null) {
            return joinPoint.proceed();
        }

        AppSecurityContext context = AppSecurityContextHolder.getRequired();

        if (roleAnnotation != null) {
            Set<String> userRoles = context.getRoles() == null ? Set.of() : new LinkedHashSet<>(context.getRoles());
            boolean allowedRole = Arrays.stream(roleAnnotation.value()).anyMatch(userRoles::contains);
            if (!allowedRole) {
                throw new ForbiddenException("Required any role " + Arrays.toString(roleAnnotation.value()) + " but actual roles were " + userRoles);
            }
        }

        if (permissionAnnotation != null) {
            boolean allowedPermission = permissionEvaluator.evaluateAny(permissionAnnotation.value(), context);
            if (!allowedPermission) {
                throw new ForbiddenException("Required any permission " + Arrays.toString(permissionAnnotation.value()) + " for current scope");
            }
        }

        return joinPoint.proceed();
    }
}
