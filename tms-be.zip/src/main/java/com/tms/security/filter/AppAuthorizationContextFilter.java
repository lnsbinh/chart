package com.tms.security.filter;

import com.tms.security.config.AppSecurityContextHolder;
import com.tms.modules.iam.service.rbac.AuthzContextService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
public class AppAuthorizationContextFilter extends OncePerRequestFilter {

    private final AuthzContextService authzContextService;

    public AppAuthorizationContextFilter(AuthzContextService authzContextService) {
        this.authzContextService = authzContextService;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication instanceof JwtAuthenticationToken jwtAuthenticationToken) {
                AppSecurityContextHolder.set(authzContextService.buildContext(jwtAuthenticationToken.getToken()));
            }
            filterChain.doFilter(request, response);
        } finally {
            AppSecurityContextHolder.clear();
        }
    }
}
