package com.tms.security.util;

import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Component;

@Component
public class JwtUtil {
    public String getSubject(Jwt jwt) { return jwt.getSubject(); }
    public String getUsername(Jwt jwt) {
        String value = jwt.getClaimAsString("preferred_username");
        return value != null && !value.isBlank() ? value : jwt.getSubject();
    }
    public String getAuthorizedParty(Jwt jwt) { return jwt.getClaimAsString("azp"); }
    public String getSubjectType(Jwt jwt) { return jwt.getClaimAsString("subject_type"); }
    public Long getAuthzVersion(Jwt jwt) {
        Object raw = jwt.getClaims().get("authz_ver");
        if (raw instanceof Number n) return n.longValue();
        if (raw instanceof String s && !s.isBlank()) {
            try { return Long.parseLong(s); } catch (NumberFormatException ignored) { }
        }
        return null;
    }
}
