package com.tms.security.config;

import com.tms.security.filter.AppAuthorizationContextFilter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.server.resource.web.authentication.BearerTokenAuthenticationFilter;
import org.springframework.security.web.SecurityFilterChain;

import java.util.List;

@Slf4j
@Configuration
@EnableMethodSecurity
public class SecurityConfig {
    @Value("${app.security.cors.allowed-origins}")
    private final List<String> allowedOrigins;
    private final SecurityIgnoreProperties securityIgnoreProperties;
    private final AppAuthorizationContextFilter appAuthorizationContextFilter;
    private final CustomAuthenticationEntryPoint authenticationEntryPoint;
    private final CustomAccessDeniedHandler accessDeniedHandler;

    public SecurityConfig(SecurityIgnoreProperties securityIgnoreProperties,
                          AppAuthorizationContextFilter appAuthorizationContextFilter,
                          CustomAuthenticationEntryPoint authenticationEntryPoint,
                          CustomAccessDeniedHandler accessDeniedHandler,
                          @Value("${app.security.cors.allowed-origins}") List<String> allowedOrigins) {
        this.securityIgnoreProperties = securityIgnoreProperties;
        this.appAuthorizationContextFilter = appAuthorizationContextFilter;
        this.authenticationEntryPoint = authenticationEntryPoint;
        this.accessDeniedHandler = accessDeniedHandler;
        this.allowedOrigins = allowedOrigins;

        log.info("SecurityConfig loaded with origins: {}", allowedOrigins);
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        String[] ignoredPaths = securityIgnoreProperties.getPaths().toArray(new String[0]);
        http.csrf(csrf -> csrf.disable())
            .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                    .requestMatchers(ignoredPaths).permitAll()
                    .anyRequest().authenticated())
            .oauth2ResourceServer(oauth -> oauth.jwt(Customizer.withDefaults()))
            .exceptionHandling(ex -> ex
                    .authenticationEntryPoint(authenticationEntryPoint)
                    .accessDeniedHandler(accessDeniedHandler)
            )
            .addFilterAfter(appAuthorizationContextFilter, BearerTokenAuthenticationFilter.class);

        return http.build();
    }
}
