package com.tms.security.config;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties(SecurityIgnoreProperties.class)
public class SecurityPropertiesConfig {
}
