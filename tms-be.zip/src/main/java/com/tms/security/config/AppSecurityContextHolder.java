package com.tms.security.config;

import com.tms.modules.iam.dto.AppSecurityContext;

public final class AppSecurityContextHolder {

    private static final ThreadLocal<AppSecurityContext> HOLDER = new ThreadLocal<>();

    private AppSecurityContextHolder() {}

    public static void set(AppSecurityContext context) {
        HOLDER.set(context);
    }

    public static AppSecurityContext getRequired() {
        AppSecurityContext context = HOLDER.get();
        if (context == null) {
            throw new IllegalStateException("AppSecurityContext is not available");
        }
        return context;
    }

    public static void clear() {
        HOLDER.remove();
    }
}
