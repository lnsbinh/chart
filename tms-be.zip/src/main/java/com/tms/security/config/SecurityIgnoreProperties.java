package com.tms.security.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.ArrayList;
import java.util.List;

@Data
@ConfigurationProperties(prefix = "spring.security.ignore")
public class SecurityIgnoreProperties {
    private List<String> paths = new ArrayList<>();
}
