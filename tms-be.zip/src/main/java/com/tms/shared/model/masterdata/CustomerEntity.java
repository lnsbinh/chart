package com.tms.shared.model.masterdata;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.Data;
import org.hibernate.annotations.UuidGenerator;

import java.time.OffsetDateTime;
import java.util.UUID;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "customers", schema = "master_data")
public class CustomerEntity {

    @Id
    @UuidGenerator
    @Column(name = "customer_id", nullable = false, updatable = false)
    @Schema(example = "00000000-0000-0000-0000-000000000001")
    private UUID customerId;

    @Column(name = "customer_name", nullable = false, length = 100)
    @Schema(example = "Kho gia dụng Tấn Tài")
    private String customerName;

    @Column(name = "contact_person", nullable = false, length = 50)
    @Schema(example = "Nguyễn Tấn Tài")
    private String contactPerson;

    @Column(name = "customer_contact_phone", nullable = false, unique = true, length = 20)
    @Schema(example = "0987654321")
    private String customerContactPhone;

    @Column(name = "customer_email", length = 100)
    @Schema(example = "ctytantai@gmail.com")
    private String customerEmail;

    @Column(name = "address", nullable = false, length = 200)
    @Schema(example = "20 Ngõ 165, Dịch Vọng, Cầu Giấy, Hà Nội")
    private String address;

    @Column(name = "pickup_address", nullable = false, length = 200)
    @Schema(example = "2M3J+GP7, Tân Thanh, Hoàng Văn Thụ, Lạng Sơn")
    private String pickupAddress;

    @Column(name = "payment_term", nullable = false, length = 30)
    @Schema(example = "30DAYS")
    private String paymentTerm;

    @Column(name = "credit_limit", precision = 18, scale = 2)
    @Schema(example = "30000000")
    private BigDecimal creditLimit;

    @Column(name = "is_deleted", nullable = false)
    @Schema(example = "false", defaultValue = "false")
    private Boolean deleted = false;

    @Column(name = "created_at", nullable = false)
    private OffsetDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private OffsetDateTime updatedAt;

    @PrePersist
    void onCreate() {
        OffsetDateTime now = OffsetDateTime.now();

        if (deleted == null) {
            deleted = false;
        }

        createdAt = now;
        updatedAt = now;
    }

    @PreUpdate
    void onUpdate() {
        updatedAt = OffsetDateTime.now();
    }
}
