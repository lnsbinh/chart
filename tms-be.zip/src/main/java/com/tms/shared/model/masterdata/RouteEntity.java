package com.tms.shared.model.masterdata;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

import java.time.OffsetDateTime;
import java.util.UUID;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "routes", schema = "master_data")
public class RouteEntity {

    @Id
    @UuidGenerator
    @Column(name = "route_id", nullable = false, updatable = false)
    @Schema(example = "00000000-0000-0000-0000-000000000001")
    private UUID routeId;

    @Column(name = "route_name", nullable = false, length = 50)
    @Schema(example = "HCM-VT")
    private String routeName;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(
            name = "origin_location_id",
            referencedColumnName = "id",
            nullable = false,
            foreignKey = @ForeignKey(name = "fk_routes_origin_location")
    )
    private LocationEntity originLocation;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(
            name = "destination_location_id",
            referencedColumnName = "id",
            nullable = false
    )
    private LocationEntity destinationLocation;

    @Column(name = "distance_km", nullable = false, precision = 10, scale = 2)
    @Schema(example = "170.00")
    private BigDecimal distanceKm;

    @Column(name = "std_transit_time", nullable = false, length = 10)
    @Schema(example = "04:00")
    private String stdTransitTime;

    @Column(name = "toll_cost", nullable = false, precision = 18, scale = 2)
    @Schema(example = "200000")
    private BigDecimal tollCost;

    @Column(name = "route_risk_note", length = 200)
    @Schema(example = "Hay kẹt đoạn Long An")
    private String routeRiskNote;

    @Column(name = "forbidden_hours", length = 100)
    @Schema(example = "Cấm 6h-9h")
    private String forbiddenHours;

    @Column(name = "preferred_flag", nullable = false)
    @Schema(example = "true", defaultValue = "false")
    private Boolean preferredFlag = false;

    @Column(name = "active_flag", nullable = false)
    @Schema(example = "true", defaultValue = "true")
    private Boolean activeFlag = true;

    @Column(name = "created_at", nullable = false)
    private OffsetDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private OffsetDateTime updatedAt;

    @PrePersist
    void onCreate() {
        OffsetDateTime now = OffsetDateTime.now();
        if (preferredFlag == null) {
            preferredFlag = false;
        }
        if (activeFlag == null) {
            activeFlag = true;
        }
        createdAt = now;
        updatedAt = now;
    }

    @PreUpdate
    void onUpdate() {
        updatedAt = OffsetDateTime.now();
    }
}