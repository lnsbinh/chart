package com.tms.shared.model.iam;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

import java.time.OffsetDateTime;
import java.util.Set;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "users", schema = "iam")
public class UserEntity {
    @Id
    @UuidGenerator
    private UUID id;

    @Column(name = "keycloak_user_name", nullable = false, unique = true)
    private String keycloakUserName;

    @Column(name = "keycloak_user_id")
    private UUID keycloakUserId;

    @Column(name = "user_code", unique = true)
    private String userCode;

    @Column(name = "username", nullable = false)
    private String username;

    @Column(name = "password_hash")
    private String password;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    private String email;
    private String phone;

    @Column(name = "display_name")
    private String displayName;

    @Column(name = "organization_id")
    private UUID organizationId;

    @Column(nullable = false)
    private String status = "ACTIVE";

    @Column(name = "avatar_url")
    private String avatarUrl;

    @Column(name = "default_branch_id")
    private UUID defaultBranchId;

    @Column(name = "is_deleted")
    private Boolean deleted;

    @Column(name = "authz_version", nullable = false)
    private Long authzVersion = 1L;

    @Column(name = "created_at", nullable = false)
    private OffsetDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private OffsetDateTime updatedAt;

    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY)
    private Set<UserRoleAssignmentEntity> userRoleAssignments;

    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY)
    private Set<UserBranchEntity> userBranches;

    @PrePersist
    void onCreate() {
        OffsetDateTime now = OffsetDateTime.now();
        createdAt = now;
        updatedAt = now;
        if (authzVersion == null) authzVersion = 1L;
    }

    @PreUpdate
    void onUpdate() {
        updatedAt = OffsetDateTime.now();
    }
}
