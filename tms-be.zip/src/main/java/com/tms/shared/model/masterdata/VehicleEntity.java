package com.tms.shared.model.masterdata;

import com.tms.shared.model.iam.BranchEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.UUID;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "vehicles", schema = "master_data")
public class VehicleEntity {

    @Id
    @UuidGenerator
    @Column(name = "vehicle_id", nullable = false, updatable = false)
    @Schema(example = "00000000-0000-0000-0000-000000000001")
    private UUID vehicleId;

    @Column(name = "license_plate", nullable = false, length = 15)
    @Schema(example = "51C-12356")
    private String licensePlate;

    @Column(name = "vehicle_name", nullable = false, length = 50)
    @Schema(example = "Xe tải 3 tấn HCM số 1")
    private String vehicleName;

    @Column(name = "vehicle_type", nullable = false, length = 50)
    @Schema(example = "LIGHT_TRUCK")
    private String vehicleType;

    @Column(name = "brand_model", length = 30)
    @Schema(example = "Hino 300")
    private String brandModel;

    @Column(name = "production_year", nullable = false)
    @Schema(example = "2020")
    private Integer productionYear;

    @Column(name = "capacity_kg", nullable = false, precision = 18, scale = 2)
    @Schema(example = "3000")
    private BigDecimal capacityKg;

    @Column(name = "volume_m3", nullable = false, precision = 18, scale = 2)
    @Schema(example = "15")
    private BigDecimal volumeM3;

    @Column(name = "fuel_type", nullable = false, length = 30)
    @Schema(example = "DIESEL")
    private String fuelType;

    @Column(name = "fuel_norm", nullable = false, precision = 10, scale = 2)
    @Schema(example = "14")
    private BigDecimal fuelNorm;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(
            name = "owner_branch",
            referencedColumnName = "id"
    )
    private BranchEntity ownerBranch;

    @Column(name = "gps_device_code", length = 20)
    @Schema(example = "GPS_000123")
    private String gpsDeviceCode;

    @Column(name = "registry_expiry", nullable = false)
    @Schema(example = "2026-12-31")
    private LocalDate registryExpiry;

    @Column(name = "insurance_expiry", nullable = false)
    @Schema(example = "2026-06-30")
    private LocalDate insuranceExpiry;

    @Column(name = "active_flag", nullable = false)
    @Schema(example = "true", defaultValue = "true")
    private Boolean activeFlag = true;

    @Column(name = "created_at", nullable = false)
    private OffsetDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private OffsetDateTime updatedAt;

    @Column(name = "is_deleted", nullable = false)
    @Schema(example = "false", defaultValue = "false")
    private Boolean deleted = false;

    @PrePersist
    void onCreate() {
        OffsetDateTime now = OffsetDateTime.now();

        if (activeFlag == null) {
            activeFlag = true;
        }

        if (deleted == null) {
            deleted = false;
        }

        createdAt = now;
        updatedAt = now;
    }

    @PreUpdate
    void onUpdate() {
        updatedAt = OffsetDateTime.now();
    }
}