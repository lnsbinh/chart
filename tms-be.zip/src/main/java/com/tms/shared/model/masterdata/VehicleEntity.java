package com.tms.shared.model.masterdata;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

import java.time.OffsetDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "vehicles", schema = "master_data")
public class VehicleEntity {
    @Id
    @UuidGenerator
    private UUID id;
    @Column(name = "organization_id", nullable = false)
    @Schema(example = "00000000-0000-0000-0000-000000000001")
    private UUID organizationId;

    @Column(name = "vehicle_code")
    @Schema(example = "VH001")
    private String vehicleCode;

    @Column(name = "vehicle_type", nullable = false)
    @Schema(example = "TRACTOR")
    private String vehicleType;

    @Column(name = "plate_no", nullable = false)
    @Schema(example = "51D-12345")
    private String plateNo;

    @Column(name = "chassis_no")
    private String chassisNo;

    @Column(name = "engine_no")
    private String engineNo;

    @Column(name = "branch_id")
    @Schema(example = "00000000-0000-0000-0000-000000000002")
    private UUID branchId;

    @Column(name = "fleet_team_id")
    private UUID fleetTeamId;

    @Column(name = "payload_kg", precision = 18, scale = 2)
    private java.math.BigDecimal payloadKg;

    @Column(name = "volume_m3", precision = 18, scale = 2)
    private java.math.BigDecimal volumeM3;

    @Column(name = "container_capability")
    private String containerCapability;

    @Column(name = "status_code", nullable = false)
    @Schema(example = "ACTIVE", defaultValue = "ACTIVE")
    private String statusCode = "ACTIVE";

    @Column(name = "operational_state", nullable = false)
    @Schema(example = "AVAILABLE", defaultValue = "AVAILABLE")
    private String operationalState = "AVAILABLE";

    @Column(name = "created_at", nullable = false)
    private OffsetDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private OffsetDateTime updatedAt;

    @PrePersist
    void onCreate() {
        OffsetDateTime now = OffsetDateTime.now();
        if (statusCode == null) statusCode = "ACTIVE";
        if (operationalState == null) operationalState = "AVAILABLE";
        createdAt = now;
        updatedAt = now;
    }

    @PreUpdate
    void onUpdate() {
        updatedAt = OffsetDateTime.now();
    }
}