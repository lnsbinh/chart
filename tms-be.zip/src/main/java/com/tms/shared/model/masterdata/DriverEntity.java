package com.tms.shared.model.masterdata;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "drivers", schema = "master_data")
public class DriverEntity {

    @Id
    @Column(name = "driver_id", nullable = false, updatable = false)
    @UuidGenerator
    @Schema(example = "00000000-0000-0000-0000-000000000001")
    private UUID driverId;

    @Column(name = "full_name", nullable = false)
    @Schema(example = "Nguyễn Văn A")
    private String fullName;

    @Column(name = "phone_number", nullable = false)
    @Schema(example = "0903666789")
    private String phoneNumber;

    @Column(name = "id_number", nullable = false)
    @Schema(example = "052078999999")
    private String idNumber;

    @Column(name = "license_class", nullable = false)
    @Schema(example = "C")
    private String licenseClass;

    @Column(name = "license_number", nullable = false)
    @Schema(example = "991179000994")
    private String licenseNumber;

    @Column(name = "license_expiry", nullable = false)
    @Schema(example = "2028-12-08")
    private LocalDate licenseExpiry;

    @Column(name = "employment_type")
    @Schema(example = "FULL_TIME")
    private String employmentType;

    @Column(name = "driver_group", nullable = false)
    @Schema(example = "HCM_LineA")
    private String driverGroup;

    @Column(name = "familiar_routes")
    @Schema(example = "HCM-CT,HCM-VT")
    private String familiarRoutes;

    @Column(name = "join_date")
    @Schema(example = "2022-05-01")
    private LocalDate joinDate;

    @Column(name = "active_flag", nullable = false)
    @Schema(example = "true", defaultValue = "true")
    private Boolean activeFlag = true;

    @Column(name = "app_username")
    @Schema(example = "driver.nguyenvana")
    private String appUsername;

    @Column(name = "created_at", nullable = false)
    private OffsetDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private OffsetDateTime updatedAt;

    @Column(name = "is_deleted", nullable = false)
    @Schema(example = "false", defaultValue = "false")
    private Boolean deleted = false;

    @PrePersist
    void onCreate() {
        OffsetDateTime now = OffsetDateTime.now();

        if (activeFlag == null) {
            activeFlag = true;
        }

        if (deleted == null) {
            deleted = false;
        }

        createdAt = now;
        updatedAt = now;
    }

    @PreUpdate
    void onUpdate() {
        updatedAt = OffsetDateTime.now();
    }
}