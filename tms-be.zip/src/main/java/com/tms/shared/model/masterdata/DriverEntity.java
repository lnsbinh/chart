package com.tms.shared.model.masterdata;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

import java.time.OffsetDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "drivers", schema = "master_data")
public class DriverEntity {
    @Id
    @UuidGenerator
    private UUID id;
    @Column(name = "organization_id", nullable = false)
    @Schema(example = "00000000-0000-0000-0000-000000000001")
    private UUID organizationId;

    @Column(name = "driver_code")
    @Schema(example = "DRV001")
    private String driverCode;

    @Column(name = "driver_type", nullable = false)
    @Schema(example = "DRIVER", defaultValue = "DRIVER")
    private String driverType = "DRIVER";

    @Column(name = "full_name", nullable = false)
    @Schema(example = "Nguyen Van A")
    private String fullName;

    @Column(name = "phone")
    private String phone;

    @Column(name = "license_no")
    private String licenseNo;

    @Column(name = "license_expiry_date")
    private java.time.LocalDate licenseExpiryDate;

    @Column(name = "branch_id")
    @Schema(example = "00000000-0000-0000-0000-000000000002")
    private UUID branchId;

    @Column(name = "fleet_team_id")
    private UUID fleetTeamId;

    @Column(name = "employment_status", nullable = false)
    @Schema(example = "ACTIVE", defaultValue = "ACTIVE")
    private String employmentStatus = "ACTIVE";

    @Column(name = "created_at", nullable = false)
    private OffsetDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private OffsetDateTime updatedAt;

    @PrePersist
    void onCreate() {
        OffsetDateTime now = OffsetDateTime.now();
        if (driverType == null) driverType = "DRIVER";
        if (employmentStatus == null) employmentStatus = "ACTIVE";
        createdAt = now;
        updatedAt = now;
    }

    @PreUpdate
    void onUpdate() {
        updatedAt = OffsetDateTime.now();
    }
}