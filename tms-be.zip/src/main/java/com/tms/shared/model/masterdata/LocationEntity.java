package com.tms.shared.model.masterdata;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

import java.math.BigDecimal;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "locations", schema = "master_data")
public class LocationEntity {

    @Id
    @UuidGenerator
    private UUID id;

    @Column(name = "location_type", nullable = false)
    @Schema(example = "WAREHOUSE")
    private String locationType;

    @Column(name = "location_name", nullable = false)
    @Schema(example = "Main Warehouse")
    private String locationName;

    @Column(name = "address")
    @Schema(example = "30 Ao Đôi, Bình Trị Đông, Bình Tân, TP.HCM")
    private String address;

    @Column(name = "latitude", precision = 10, scale = 7)
    @Schema(example = "10.1234567")
    private java.math.BigDecimal latitude;

    @Column(name = "longitude", precision = 10, scale = 7)
    @Schema(example = "106.1234567")
    private java.math.BigDecimal longitude;

    @Column(name = "status_code", nullable = false)
    @Schema(example = "ACTIVE", defaultValue = "ACTIVE")
    private String statusCode = "ACTIVE";

    @Column(name = "gate_height", precision = 5, scale = 2)
    @Schema(example = "4.2")
    private BigDecimal gateHeight;

    @Column(name = "allowed_vehicle")
    @Schema(example = "TRUCK_8T, CONTAINER_20FT")
    private String allowedVehicle;

    @Column(name = "capacity_cont")
    @Schema(example = "50")
    private Integer capacityCont;

    @Column(name = "contact_phone")
    @Schema(example = "0987654321")
    private String contactPhone;

    @Column(name = "remark")
    @Schema(example = "Security checkpoint at gate 1")
    private String remark;

    @Column(name = "province")
    @Schema(example = "Hồ Chí Minh")
    private String province;

    @Column(name = "district")
    @Schema(example = "Bình Tân")
    private String district;

    @JsonFormat(pattern = "HH:mm")
    @Column(name = "time_window_from")
    @Schema(example = "08:00")
    private LocalTime timeWindowFrom;

    @JsonFormat(pattern = "HH:mm")
    @Column(name = "time_window_to")
    @Schema(example = "18:00")
    private LocalTime timeWindowTo;

    @Column(name = "active_flag", nullable = false)
    @Schema(example = "TRUE")
    private Boolean activeFlag = true;

    @Column(name = "created_at", nullable = false)
    @Schema(example = "2026-04-06T10:38:28.810261+07:00")
    private OffsetDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    @Schema(example = "2026-04-06T10:38:28.810261+07:00")
    private OffsetDateTime updatedAt;

    @PrePersist
    void onCreate() {
        OffsetDateTime now = OffsetDateTime.now();

        if (statusCode == null) {
            statusCode = "ACTIVE";
        }

        createdAt = now;
        updatedAt = now;
    }

    @PreUpdate
    void onUpdate() {
        updatedAt = OffsetDateTime.now();
    }
}
