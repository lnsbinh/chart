package com.tms.shared.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiResponseDTO<T> {

    private boolean success;
    private T data;
    private String message;
    private Object error;

    public static <T> ApiResponseDTO<T> success(T data) {
        return new ApiResponseDTO<>(true, data, null, null);
    }

    public static ApiResponseDTO<?> error(Object error) {
        return new ApiResponseDTO<>(false, null, null, error);
    }
}

