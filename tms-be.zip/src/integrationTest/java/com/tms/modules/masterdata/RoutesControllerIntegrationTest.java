package com.tms.modules.masterdata;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tms.BaseIntegrationTest;
import com.tms.modules.masterdata.repository.LocationRepository;
import com.tms.modules.masterdata.repository.RouteRepository;
import com.tms.shared.model.masterdata.LocationEntity;
import com.tms.shared.model.masterdata.RouteEntity;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class RoutesControllerIntegrationTest extends BaseIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private RouteRepository routeRepository;

    @Autowired
    private LocationRepository locationRepository;

    @AfterEach
    void cleanup() {
        routeRepository.deleteAll();
        locationRepository.deleteAll();
    }

    @Test
    void shouldCreateRoute() throws Exception {
        LocationEntity origin = new LocationEntity();
        origin.setLocationType("WAREHOUSE");
        origin.setLocationName("Origin");
        origin.setAddress("Origin Address");
        origin.setStatusCode("ACTIVE");
        origin.setActiveFlag(true);
        origin = locationRepository.saveAndFlush(origin);

        LocationEntity destination = new LocationEntity();
        destination.setLocationType("WAREHOUSE");
        destination.setLocationName("Destination");
        destination.setAddress("Destination Address");
        destination.setStatusCode("ACTIVE");
        destination.setActiveFlag(true);
        destination = locationRepository.saveAndFlush(destination);

        RouteEntity request = new RouteEntity();
        request.setRouteName("HCM-BD");
        request.setOriginLocation(origin);
        request.setDestinationLocation(destination);
        request.setDistanceKm(new BigDecimal("35"));
        request.setStdTransitTime("01:20");
        request.setTollCost(new BigDecimal("30000"));
        request.setPreferredFlag(true);
        request.setActiveFlag(true);

        mockMvc.perform(post("/api/v1/master-data/routes")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.routeName").value("HCM-BD"));
    }

    @Test
    void shouldSearchRoutes() throws Exception {
        LocationEntity origin = new LocationEntity();
        origin.setLocationType("WAREHOUSE");
        origin.setLocationName("Kho Bình Tân");
        origin.setAddress("Origin Address");
        origin.setStatusCode("ACTIVE");
        origin.setActiveFlag(true);
        origin = locationRepository.saveAndFlush(origin);

        LocationEntity destination = new LocationEntity();
        destination.setLocationType("WAREHOUSE");
        destination.setLocationName("Kho Bình Dương");
        destination.setAddress("Destination Address");
        destination.setStatusCode("ACTIVE");
        destination.setActiveFlag(true);
        destination = locationRepository.saveAndFlush(destination);

        RouteEntity entity = new RouteEntity();
        entity.setRouteName("HCM-BD");
        entity.setOriginLocation(origin);
        entity.setDestinationLocation(destination);
        entity.setDistanceKm(new BigDecimal("35"));
        entity.setStdTransitTime("01:20");
        entity.setTollCost(new BigDecimal("30000"));
        entity.setPreferredFlag(true);
        entity.setActiveFlag(true);
        routeRepository.saveAndFlush(entity);

        mockMvc.perform(get("/api/v1/master-data/routes")
                        .param("keyword", "HCM"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content[0].routeName").value("HCM-BD"));
    }

    @Test
    void shouldGetRouteById() throws Exception {
        LocationEntity origin = new LocationEntity();
        origin.setLocationType("WAREHOUSE");
        origin.setLocationName("Origin A");
        origin.setAddress("Address A");
        origin.setStatusCode("ACTIVE");
        origin.setActiveFlag(true);
        origin = locationRepository.saveAndFlush(origin);

        LocationEntity destination = new LocationEntity();
        destination.setLocationType("WAREHOUSE");
        destination.setLocationName("Destination A");
        destination.setAddress("Address B");
        destination.setStatusCode("ACTIVE");
        destination.setActiveFlag(true);
        destination = locationRepository.saveAndFlush(destination);

        RouteEntity entity = new RouteEntity();
        entity.setRouteName("Route A");
        entity.setOriginLocation(origin);
        entity.setDestinationLocation(destination);
        entity.setDistanceKm(new BigDecimal("50"));
        entity.setStdTransitTime("02:00");
        entity.setTollCost(new BigDecimal("50000"));
        entity.setPreferredFlag(false);
        entity.setActiveFlag(true);
        entity = routeRepository.saveAndFlush(entity);

        mockMvc.perform(get("/api/v1/master-data/routes/{id}", entity.getRouteId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.routeName").value("Route A"));
    }

    @Test
    void shouldUpdateRoute() throws Exception {
        LocationEntity origin = new LocationEntity();
        origin.setLocationType("WAREHOUSE");
        origin.setLocationName("Origin Old");
        origin.setAddress("Address O");
        origin.setStatusCode("ACTIVE");
        origin.setActiveFlag(true);
        origin = locationRepository.saveAndFlush(origin);

        LocationEntity destination = new LocationEntity();
        destination.setLocationType("WAREHOUSE");
        destination.setLocationName("Destination Old");
        destination.setAddress("Address D");
        destination.setStatusCode("ACTIVE");
        destination.setActiveFlag(true);
        destination = locationRepository.saveAndFlush(destination);

        RouteEntity entity = new RouteEntity();
        entity.setRouteName("Route Old");
        entity.setOriginLocation(origin);
        entity.setDestinationLocation(destination);
        entity.setDistanceKm(new BigDecimal("60"));
        entity.setStdTransitTime("02:15");
        entity.setTollCost(new BigDecimal("60000"));
        entity.setPreferredFlag(false);
        entity.setActiveFlag(true);
        entity = routeRepository.saveAndFlush(entity);

        RouteEntity request = new RouteEntity();
        request.setRouteName("Route New");
        request.setOriginLocation(origin);
        request.setDestinationLocation(destination);
        request.setDistanceKm(new BigDecimal("65"));
        request.setStdTransitTime("02:20");
        request.setTollCost(new BigDecimal("65000"));
        request.setPreferredFlag(true);
        request.setActiveFlag(true);

        mockMvc.perform(put("/api/v1/master-data/routes/{id}", entity.getRouteId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.routeName").value("Route New"));
    }

    @Test
    void shouldDeactivateRoute() throws Exception {
        LocationEntity origin = new LocationEntity();
        origin.setLocationType("WAREHOUSE");
        origin.setLocationName("Origin X");
        origin.setAddress("Address X");
        origin.setStatusCode("ACTIVE");
        origin.setActiveFlag(true);
        origin = locationRepository.saveAndFlush(origin);

        LocationEntity destination = new LocationEntity();
        destination.setLocationType("WAREHOUSE");
        destination.setLocationName("Destination X");
        destination.setAddress("Address Y");
        destination.setStatusCode("ACTIVE");
        destination.setActiveFlag(true);
        destination = locationRepository.saveAndFlush(destination);

        RouteEntity entity = new RouteEntity();
        entity.setRouteName("Route X");
        entity.setOriginLocation(origin);
        entity.setDestinationLocation(destination);
        entity.setDistanceKm(new BigDecimal("20"));
        entity.setStdTransitTime("01:00");
        entity.setTollCost(new BigDecimal("15000"));
        entity.setPreferredFlag(false);
        entity.setActiveFlag(true);
        entity = routeRepository.saveAndFlush(entity);

        mockMvc.perform(patch("/api/v1/master-data/routes/{id}/deactivate", entity.getRouteId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.deleted").value(false));
    }
}
