package com.tms.modules.masterdata;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tms.BaseIntegrationTest;
import com.tms.modules.masterdata.repository.DriverRepository;
import com.tms.shared.model.masterdata.DriverEntity;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class DriversControllerIntegrationTest extends BaseIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private DriverRepository driverRepository;

    @AfterEach
    void cleanup() {
        driverRepository.deleteAll();
    }

    @Test
    void shouldCreateDriver() throws Exception {
        DriverEntity request = new DriverEntity();
        request.setFullName("Nguyen Van A");
        request.setPhoneNumber("0903000001");
        request.setIdNumber("079123456700");
        request.setLicenseClass("C");
        request.setLicenseNumber("LIC001");
        request.setLicenseExpiry(LocalDate.of(2028, 12, 31));
        request.setEmploymentType("FULL_TIME");
        request.setDriverGroup("HCM_LineA");
        request.setFamiliarRoutes("HCM-BD,HCM-DN");
        request.setJoinDate(LocalDate.of(2022, 1, 1));
        request.setActiveFlag(true);
        request.setDeleted(false);
        request.setAppUsername("driver.a");

        mockMvc.perform(post("/api/v1/master-data/drivers")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.fullName").value("Nguyen Van A"));
    }

    @Test
    void shouldSearchDrivers() throws Exception {
        DriverEntity entity = new DriverEntity();
        entity.setFullName("Tran Quoc Huy");
        entity.setPhoneNumber("0903000002");
        entity.setIdNumber("079123456701");
        entity.setLicenseClass("C1");
        entity.setLicenseNumber("LIC002");
        entity.setLicenseExpiry(LocalDate.of(2029, 1, 1));
        entity.setEmploymentType("FULL_TIME");
        entity.setDriverGroup("HCM_LineB");
        entity.setActiveFlag(true);
        entity.setDeleted(false);
        driverRepository.saveAndFlush(entity);

        mockMvc.perform(get("/api/v1/master-data/drivers")
                        .param("keyword", "Huy"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content[0].fullName").value("Tran Quoc Huy"));
    }

    @Test
    void shouldGetDriverById() throws Exception {
        DriverEntity entity = new DriverEntity();
        entity.setFullName("Le Minh Tuan");
        entity.setPhoneNumber("0903000003");
        entity.setIdNumber("079123456702");
        entity.setLicenseClass("FC");
        entity.setLicenseNumber("LIC003");
        entity.setLicenseExpiry(LocalDate.of(2028, 6, 1));
        entity.setEmploymentType("CONTRACT");
        entity.setDriverGroup("HCM_LineC");
        entity.setActiveFlag(true);
        entity.setDeleted(false);
        entity = driverRepository.saveAndFlush(entity);

        mockMvc.perform(get("/api/v1/master-data/drivers/{id}", entity.getDriverId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.fullName").value("Le Minh Tuan"));
    }

    @Test
    void shouldUpdateDriver() throws Exception {
        DriverEntity entity = new DriverEntity();
        entity.setFullName("Old Driver");
        entity.setPhoneNumber("0903000004");
        entity.setIdNumber("079123456703");
        entity.setLicenseClass("C");
        entity.setLicenseNumber("LIC004");
        entity.setLicenseExpiry(LocalDate.of(2028, 7, 1));
        entity.setEmploymentType("FULL_TIME");
        entity.setDriverGroup("HCM_LineA");
        entity.setActiveFlag(true);
        entity.setDeleted(false);
        entity = driverRepository.saveAndFlush(entity);

        DriverEntity request = new DriverEntity();
        request.setFullName("New Driver");
        request.setPhoneNumber("0903000004");
        request.setIdNumber("079123456703");
        request.setLicenseClass("C1");
        request.setLicenseNumber("LIC004");
        request.setLicenseExpiry(LocalDate.of(2029, 7, 1));
        request.setEmploymentType("CONTRACT");
        request.setDriverGroup("HCM_LineD");
        request.setActiveFlag(true);
        request.setDeleted(false);

        mockMvc.perform(put("/api/v1/master-data/drivers/{id}", entity.getDriverId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.fullName").value("New Driver"))
                .andExpect(jsonPath("$.driverGroup").value("HCM_LineD"));
    }

    @Test
    void shouldDeactivateDriver() throws Exception {
        DriverEntity entity = new DriverEntity();
        entity.setFullName("Disable Driver");
        entity.setPhoneNumber("0903000005");
        entity.setIdNumber("079123456704");
        entity.setLicenseClass("C");
        entity.setLicenseNumber("LIC005");
        entity.setLicenseExpiry(LocalDate.of(2027, 10, 1));
        entity.setEmploymentType("FULL_TIME");
        entity.setDriverGroup("HCM_LineE");
        entity.setActiveFlag(true);
        entity.setDeleted(false);
        entity = driverRepository.saveAndFlush(entity);

        mockMvc.perform(patch("/api/v1/master-data/drivers/{id}/deactivate", entity.getDriverId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.deleted").value(false));
    }
}
