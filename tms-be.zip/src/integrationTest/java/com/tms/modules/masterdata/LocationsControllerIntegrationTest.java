package com.tms.modules.masterdata;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tms.BaseIntegrationTest;
import com.tms.modules.masterdata.repository.LocationRepository;
import com.tms.shared.model.masterdata.LocationEntity;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.time.LocalTime;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class LocationsControllerIntegrationTest extends BaseIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private LocationRepository locationRepository;

    @AfterEach
    void cleanup() {
        locationRepository.deleteAll();
    }

    @Test
    void shouldCreateLocation() throws Exception {
        LocationEntity request = new LocationEntity();
        request.setLocationType("WAREHOUSE");
        request.setLocationName("Kho Test");
        request.setAddress("123 Street");
        request.setLatitude(new BigDecimal("10.1234567"));
        request.setLongitude(new BigDecimal("106.1234567"));
        request.setStatusCode("ACTIVE");
        request.setActiveFlag(true);
        request.setTimeWindowFrom(LocalTime.of(8, 0));
        request.setTimeWindowTo(LocalTime.of(18, 0));

        mockMvc.perform(post("/api/v1/master-data/locations")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.locationName").value("Kho Test"));
    }

    @Test
    void shouldSearchLocations() throws Exception {
        LocationEntity entity = new LocationEntity();
        entity.setLocationType("WAREHOUSE");
        entity.setLocationName("Kho Bình Tân");
        entity.setAddress("Binh Tan");
        entity.setStatusCode("ACTIVE");
        entity.setActiveFlag(true);
        locationRepository.saveAndFlush(entity);

        mockMvc.perform(get("/api/v1/master-data/locations")
                        .param("keyword", "Bình Tân"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content[0].locationName").value("Kho Bình Tân"));
    }

    @Test
    void shouldGetLocationById() throws Exception {
        LocationEntity entity = new LocationEntity();
        entity.setLocationType("DEPOT");
        entity.setLocationName("Depot A");
        entity.setAddress("Address A");
        entity.setStatusCode("ACTIVE");
        entity.setActiveFlag(true);
        entity = locationRepository.saveAndFlush(entity);

        mockMvc.perform(get("/api/v1/master-data/locations/{id}", entity.getId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.locationName").value("Depot A"));
    }

    @Test
    void shouldUpdateLocation() throws Exception {
        LocationEntity entity = new LocationEntity();
        entity.setLocationType("DEPOT");
        entity.setLocationName("Old Depot");
        entity.setAddress("Old Address");
        entity.setStatusCode("ACTIVE");
        entity.setActiveFlag(true);
        entity = locationRepository.saveAndFlush(entity);

        LocationEntity request = new LocationEntity();
        request.setLocationType("DEPOT");
        request.setLocationName("New Depot");
        request.setAddress("New Address");
        request.setStatusCode("ACTIVE");
        request.setActiveFlag(true);

        mockMvc.perform(put("/api/v1/master-data/locations/{id}", entity.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.locationName").value("New Depot"));
    }

    @Test
    void shouldDeactivateLocation() throws Exception {
        LocationEntity entity = new LocationEntity();
        entity.setLocationType("PORT");
        entity.setLocationName("Port A");
        entity.setAddress("Port Address");
        entity.setStatusCode("ACTIVE");
        entity.setActiveFlag(true);
        entity = locationRepository.saveAndFlush(entity);

        mockMvc.perform(patch("/api/v1/master-data/locations/{id}/deactivate", entity.getId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.activeFlag").value(false));
    }
}
