package com.tms.modules.masterdata;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tms.BaseIntegrationTest;
import com.tms.modules.masterdata.repository.CustomerRepository;
import com.tms.shared.model.masterdata.CustomerEntity;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class CustomerControllerIntegrationTest extends BaseIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private CustomerRepository customerRepository;

    @AfterEach
    void cleanup() {
        customerRepository.deleteAll();
    }

    @Test
    void shouldCreateCustomer() throws Exception {
        CustomerEntity request = new CustomerEntity();
        request.setCustomerName("Test Customer");
        request.setContactPerson("Nguyen Van A");
        request.setCustomerContactPhone("0909999999");
        request.setCustomerEmail("test.customer@gmail.com");
        request.setAddress("123 Test Street");
        request.setPickupAddress("456 Pickup Street");
        request.setPaymentTerm("COD");
        request.setCreditLimit(new BigDecimal("1000000"));

        mockMvc.perform(post("/api/v1/customers")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.customerName").value("Test Customer"))
                .andExpect(jsonPath("$.customerContactPhone").value("0909999999"));
    }

    @Test
    void shouldGetCustomerById() throws Exception {
        CustomerEntity customer = new CustomerEntity();
        customer.setCustomerName("Existing Customer");
        customer.setContactPerson("Tran Van B");
        customer.setCustomerContactPhone("0908888888");
        customer.setCustomerEmail("existing@gmail.com");
        customer.setAddress("Address 1");
        customer.setPickupAddress("Pickup 1");
        customer.setPaymentTerm("30DAYS");
        customer.setCreditLimit(new BigDecimal("2000000"));
        customer.setDeleted(false);
        customer = customerRepository.saveAndFlush(customer);

        mockMvc.perform(get("/api/v1/customers/{customerId}", customer.getCustomerId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.customerId").value(customer.getCustomerId().toString()))
                .andExpect(jsonPath("$.customerName").value("Existing Customer"));
    }

    @Test
    void shouldSearchCustomers() throws Exception {
        CustomerEntity customer = new CustomerEntity();
        customer.setCustomerName("Minh Phat Logistics");
        customer.setContactPerson("Tran Van Minh");
        customer.setCustomerContactPhone("0907777777");
        customer.setCustomerEmail("minhphat@gmail.com");
        customer.setAddress("HCM");
        customer.setPickupAddress("Binh Tan");
        customer.setPaymentTerm("COD");
        customer.setCreditLimit(new BigDecimal("5000000"));
        customer.setDeleted(false);
        customerRepository.saveAndFlush(customer);

        mockMvc.perform(get("/api/v1/customers")
                        .param("keyword", "Minh Phat"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content[0].customerName").value("Minh Phat Logistics"));
    }

    @Test
    void shouldDeleteCustomer() throws Exception {
        CustomerEntity customer = new CustomerEntity();
        customer.setCustomerName("Delete Me");
        customer.setContactPerson("User A");
        customer.setCustomerContactPhone("0906666666");
        customer.setCustomerEmail("deleteme@gmail.com");
        customer.setAddress("Address");
        customer.setPickupAddress("Pickup");
        customer.setPaymentTerm("COD");
        customer.setCreditLimit(new BigDecimal("100000"));
        customer.setDeleted(false);
        customer = customerRepository.saveAndFlush(customer);

        mockMvc.perform(delete("/api/v1/customers/{customerId}", customer.getCustomerId()))
                .andExpect(status().isOk());
    }

    @Test
    void shouldUpdateCustomer() throws Exception {
        CustomerEntity customer = new CustomerEntity();
        customer.setCustomerName("Old Name");
        customer.setContactPerson("Old Person");
        customer.setCustomerContactPhone("0901111111");
        customer.setCustomerEmail("old@gmail.com");
        customer.setAddress("Old Address");
        customer.setPickupAddress("Old Pickup");
        customer.setPaymentTerm("COD");
        customer.setCreditLimit(new BigDecimal("100000"));
        customer.setDeleted(false);
        customer = customerRepository.saveAndFlush(customer);

        CustomerEntity request = new CustomerEntity();
        request.setCustomerName("New Name");
        request.setContactPerson("New Person");
        request.setCustomerContactPhone("0901111111");
        request.setCustomerEmail("new@gmail.com");
        request.setAddress("New Address");
        request.setPickupAddress("New Pickup");
        request.setPaymentTerm("30DAYS");
        request.setCreditLimit(new BigDecimal("500000"));

        mockMvc.perform(put("/api/v1/customers/{customerId}", customer.getCustomerId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.customerName").value("New Name"))
                .andExpect(jsonPath("$.paymentTerm").value("30DAYS"));
    }
}
