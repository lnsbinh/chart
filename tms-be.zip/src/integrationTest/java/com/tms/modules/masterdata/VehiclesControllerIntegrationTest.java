package com.tms.modules.masterdata;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tms.BaseIntegrationTest;
import com.tms.modules.masterdata.repository.VehicleRepository;
import com.tms.shared.model.masterdata.VehicleEntity;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class VehiclesControllerIntegrationTest extends BaseIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private VehicleRepository vehicleRepository;

    @AfterEach
    void cleanup() {
        vehicleRepository.deleteAll();
    }

    @Test
    void shouldCreateVehicle() throws Exception {
        VehicleEntity request = new VehicleEntity();
        request.setLicensePlate("51C-12345");
        request.setVehicleName("Xe tải test");
        request.setVehicleType("LIGHT_TRUCK");
        request.setBrandModel("Hino 300");
        request.setProductionYear(2022);
        request.setCapacityKg(new BigDecimal("3000"));
        request.setVolumeM3(new BigDecimal("15"));
        request.setFuelType("DIESEL");
        request.setFuelNorm(new BigDecimal("14"));
        request.setGpsDeviceCode("GPS-T1");
        request.setRegistryExpiry(LocalDate.of(2027, 12, 31));
        request.setInsuranceExpiry(LocalDate.of(2027, 6, 30));
        request.setActiveFlag(true);
        request.setDeleted(false);

        mockMvc.perform(post("/api/v1/master-data/vehicles")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.vehicleName").value("Xe tải test"));
    }

    @Test
    void shouldSearchVehicles() throws Exception {
        VehicleEntity entity = new VehicleEntity();
        entity.setLicensePlate("51C-99999");
        entity.setVehicleName("Xe tải HCM");
        entity.setVehicleType("LIGHT_TRUCK");
        entity.setProductionYear(2020);
        entity.setCapacityKg(new BigDecimal("3000"));
        entity.setVolumeM3(new BigDecimal("15"));
        entity.setFuelType("DIESEL");
        entity.setFuelNorm(new BigDecimal("14"));
        entity.setRegistryExpiry(LocalDate.of(2027, 12, 31));
        entity.setInsuranceExpiry(LocalDate.of(2027, 6, 30));
        entity.setActiveFlag(true);
        entity.setDeleted(false);
        vehicleRepository.saveAndFlush(entity);

        mockMvc.perform(get("/api/v1/master-data/vehicles")
                        .param("keyword", "HCM"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content[0].vehicleName").value("Xe tải HCM"));
    }

    @Test
    void shouldGetVehicleById() throws Exception {
        VehicleEntity entity = new VehicleEntity();
        entity.setLicensePlate("51C-88888");
        entity.setVehicleName("Xe đầu kéo");
        entity.setVehicleType("CONTAINER_TRUCK");
        entity.setProductionYear(2021);
        entity.setCapacityKg(new BigDecimal("18000"));
        entity.setVolumeM3(new BigDecimal("60"));
        entity.setFuelType("DIESEL");
        entity.setFuelNorm(new BigDecimal("28"));
        entity.setRegistryExpiry(LocalDate.of(2027, 12, 31));
        entity.setInsuranceExpiry(LocalDate.of(2027, 6, 30));
        entity.setActiveFlag(true);
        entity.setDeleted(false);
        entity = vehicleRepository.saveAndFlush(entity);

        mockMvc.perform(get("/api/v1/master-data/vehicles/{id}", entity.getVehicleId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.vehicleName").value("Xe đầu kéo"));
    }

    @Test
    void shouldUpdateVehicle() throws Exception {
        VehicleEntity entity = new VehicleEntity();
        entity.setLicensePlate("51C-77777");
        entity.setVehicleName("Old Vehicle");
        entity.setVehicleType("LIGHT_TRUCK");
        entity.setProductionYear(2020);
        entity.setCapacityKg(new BigDecimal("3000"));
        entity.setVolumeM3(new BigDecimal("15"));
        entity.setFuelType("DIESEL");
        entity.setFuelNorm(new BigDecimal("14"));
        entity.setRegistryExpiry(LocalDate.of(2027, 12, 31));
        entity.setInsuranceExpiry(LocalDate.of(2027, 6, 30));
        entity.setActiveFlag(true);
        entity.setDeleted(false);
        entity = vehicleRepository.saveAndFlush(entity);

        VehicleEntity request = new VehicleEntity();
        request.setLicensePlate("51C-77777");
        request.setVehicleName("New Vehicle");
        request.setVehicleType("MEDIUM_TRUCK");
        request.setProductionYear(2022);
        request.setCapacityKg(new BigDecimal("5000"));
        request.setVolumeM3(new BigDecimal("22"));
        request.setFuelType("DIESEL");
        request.setFuelNorm(new BigDecimal("16"));
        request.setRegistryExpiry(LocalDate.of(2028, 12, 31));
        request.setInsuranceExpiry(LocalDate.of(2028, 6, 30));
        request.setActiveFlag(true);
        request.setDeleted(false);

        mockMvc.perform(put("/api/v1/master-data/vehicles/{id}", entity.getVehicleId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.vehicleName").value("New Vehicle"))
                .andExpect(jsonPath("$.vehicleType").value("MEDIUM_TRUCK"));
    }

    @Test
    void shouldDeactivateVehicle() throws Exception {
        VehicleEntity entity = new VehicleEntity();
        entity.setLicensePlate("51C-66666");
        entity.setVehicleName("Disable Vehicle");
        entity.setVehicleType("LIGHT_TRUCK");
        entity.setProductionYear(2020);
        entity.setCapacityKg(new BigDecimal("3000"));
        entity.setVolumeM3(new BigDecimal("15"));
        entity.setFuelType("DIESEL");
        entity.setFuelNorm(new BigDecimal("14"));
        entity.setRegistryExpiry(LocalDate.of(2027, 12, 31));
        entity.setInsuranceExpiry(LocalDate.of(2027, 6, 30));
        entity.setActiveFlag(true);
        entity.setDeleted(false);
        entity = vehicleRepository.saveAndFlush(entity);

        mockMvc.perform(patch("/api/v1/master-data/vehicles/{id}/deactivate", entity.getVehicleId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.deleted").value(false));
    }
}
