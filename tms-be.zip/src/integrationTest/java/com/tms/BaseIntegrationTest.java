package com.tms;

import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@AutoConfigureMockMvc(addFilters = false)
@ActiveProfiles("test")
public abstract class BaseIntegrationTest {

    @Autowired
    protected JdbcTemplate jdbcTemplate;

    @BeforeEach
    void cleanDatabase() {
        jdbcTemplate.execute("DELETE FROM master_data.routes");
        jdbcTemplate.execute("DELETE FROM master_data.vehicles");
        jdbcTemplate.execute("DELETE FROM master_data.drivers");
        jdbcTemplate.execute("DELETE FROM master_data.customers");
        jdbcTemplate.execute("DELETE FROM master_data.locations");
        jdbcTemplate.execute("DELETE FROM iam.branches");
    }
}
