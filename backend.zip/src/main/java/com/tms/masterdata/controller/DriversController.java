package com.tms.masterdata.controller;

import com.tms.masterdata.dto.PagedResponse;
import com.tms.masterdata.model.DriverEntity;
import com.tms.masterdata.service.DriverService;
import com.tms.security.annotation.MasterDataReadAccess;
import com.tms.security.annotation.MasterDataWriteAccess;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/master-data/drivers")
@MasterDataReadAccess
@Tag(name = "Master Data - Drivers")
public class DriversController {
    private final DriverService service;

    public DriversController(DriverService service) { this.service = service; }

    @GetMapping
    @Operation(summary = "Search drivers with paging")
    public PagedResponse<DriverEntity> list(
            @Parameter(description = "Organization ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000001"))
            @RequestParam UUID organizationId,
            @Parameter(description = "Search by driver code, full name, phone, or license number", schema = @Schema(defaultValue = "nguyen"))
            @RequestParam(required = false) String keyword,
            @Parameter(description = "Driver type", schema = @Schema(defaultValue = "DRIVER"))
            @RequestParam(required = false) String driverType,
            @Parameter(description = "Branch ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000002"))
            @RequestParam(required = false) UUID branchId,
            @Parameter(description = "Employment status", schema = @Schema(defaultValue = "ACTIVE"))
            @RequestParam(required = false) String employmentStatus,
            @ParameterObject @PageableDefault(size = 20, sort = "fullName") Pageable pageable) {
        return service.search(organizationId, keyword, driverType, branchId, employmentStatus, pageable);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get driver by ID")
    public DriverEntity get(
            @Parameter(description = "Organization ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000001"))
            @RequestParam UUID organizationId,
            @Parameter(description = "Driver ID", schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id) { return service.get(organizationId, id); }

    @PostMapping
    @MasterDataWriteAccess
    @Operation(summary = "Create driver")
    public DriverEntity create(@RequestBody DriverEntity request) { return service.create(request); }

    @PutMapping("/{id}")
    @MasterDataWriteAccess
    @Operation(summary = "Update driver")
    public DriverEntity update(
            @Parameter(description = "Organization ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000001"))
            @RequestParam UUID organizationId,
            @Parameter(description = "Driver ID", schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id,
            @RequestBody DriverEntity request) { return service.update(organizationId, id, request); }

    @PatchMapping("/{id}/deactivate")
    @MasterDataWriteAccess
    @Operation(summary = "Deactivate driver")
    public DriverEntity deactivate(
            @Parameter(description = "Organization ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000001"))
            @RequestParam UUID organizationId,
            @Parameter(description = "Driver ID", schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id) { return service.deactivate(organizationId, id); }
}
