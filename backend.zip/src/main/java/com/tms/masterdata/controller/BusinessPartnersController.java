package com.tms.masterdata.controller;

import com.tms.masterdata.dto.PagedResponse;
import com.tms.masterdata.model.BusinessPartnerEntity;
import com.tms.masterdata.service.BusinessPartnerService;
import com.tms.security.annotation.MasterDataReadAccess;
import com.tms.security.annotation.MasterDataWriteAccess;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/master-data/business-partners")
@MasterDataReadAccess
@Tag(name = "Master Data - Business Partners")
public class BusinessPartnersController {
    private final BusinessPartnerService service;

    public BusinessPartnersController(BusinessPartnerService service) { this.service = service; }

    @GetMapping
    @Operation(summary = "Search business partners with paging")
    public PagedResponse<BusinessPartnerEntity> list(
            @Parameter(description = "Organization ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000001"))
            @RequestParam UUID organizationId,
            @Parameter(description = "Search by partner code, partner name, phone, or email", schema = @Schema(defaultValue = "acme"))
            @RequestParam(required = false) String keyword,
            @Parameter(description = "Business partner type", schema = @Schema(defaultValue = "CUSTOMER"))
            @RequestParam(required = false) String partnerType,
            @Parameter(description = "Lifecycle status", schema = @Schema(defaultValue = "ACTIVE"))
            @RequestParam(required = false) String statusCode,
            @ParameterObject @PageableDefault(size = 20, sort = "partnerCode") Pageable pageable) {
        return service.search(organizationId, keyword, partnerType, statusCode, pageable);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get business partner by ID")
    public BusinessPartnerEntity get(
            @Parameter(description = "Organization ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000001"))
            @RequestParam UUID organizationId,
            @Parameter(description = "Business partner ID", schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id) { return service.get(organizationId, id); }

    @PostMapping
    @MasterDataWriteAccess
    @Operation(summary = "Create business partner")
    public BusinessPartnerEntity create(@RequestBody BusinessPartnerEntity request) { return service.create(request); }

    @PutMapping("/{id}")
    @MasterDataWriteAccess
    @Operation(summary = "Update business partner")
    public BusinessPartnerEntity update(
            @Parameter(description = "Organization ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000001"))
            @RequestParam UUID organizationId,
            @Parameter(description = "Business partner ID", schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id,
            @RequestBody BusinessPartnerEntity request) { return service.update(organizationId, id, request); }

    @PatchMapping("/{id}/deactivate")
    @MasterDataWriteAccess
    @Operation(summary = "Deactivate business partner")
    public BusinessPartnerEntity deactivate(
            @Parameter(description = "Organization ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000001"))
            @RequestParam UUID organizationId,
            @Parameter(description = "Business partner ID", schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id) { return service.deactivate(organizationId, id); }
}
