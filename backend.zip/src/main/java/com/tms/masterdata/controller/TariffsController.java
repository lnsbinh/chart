package com.tms.masterdata.controller;

import com.tms.masterdata.model.TariffEntity;
import com.tms.masterdata.service.TariffService;
import com.tms.security.annotation.MasterDataReadAccess;
import com.tms.security.annotation.MasterDataWriteAccess;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/master-data/tariffs")
@MasterDataReadAccess
@Tag(name = "Master Data - Tariffs")
public class TariffsController {
    private final TariffService service;

    public TariffsController(TariffService service) { this.service = service; }

    @GetMapping
    @Operation(summary = "List tariffs")
    public List<TariffEntity> list(
            @Parameter(description = "Organization ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000001"))
            @RequestParam UUID organizationId,
            @Parameter(description = "Tariff status", schema = @Schema(defaultValue = "ACTIVE"))
            @RequestParam(required = false) String statusCode,
            @Parameter(description = "Effective date", schema = @Schema(type = "string", format = "date", defaultValue = "2026-04-01"))
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate effectiveDate) {
        return service.list(organizationId, statusCode, effectiveDate);
    }

    @PostMapping
    @MasterDataWriteAccess
    @Operation(summary = "Create tariff")
    public TariffEntity create(@RequestBody TariffEntity request) { return service.create(request); }

    @PutMapping("/{id}")
    @MasterDataWriteAccess
    @Operation(summary = "Update tariff")
    public TariffEntity update(
            @Parameter(description = "Tariff ID", schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id,
            @RequestBody TariffEntity request) { return service.update(id, request); }

    @PatchMapping("/{id}/deactivate")
    @MasterDataWriteAccess
    @Operation(summary = "Deactivate tariff")
    public TariffEntity deactivate(
            @Parameter(description = "Tariff ID", schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id) { return service.deactivate(id); }
}
