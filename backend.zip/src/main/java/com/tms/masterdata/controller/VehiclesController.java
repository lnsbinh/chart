package com.tms.masterdata.controller;

import com.tms.masterdata.dto.PagedResponse;
import com.tms.masterdata.model.VehicleEntity;
import com.tms.masterdata.service.VehicleService;
import com.tms.security.annotation.RequireAnyPermission;
import com.tms.security.annotation.RequireAnyRole;
import com.tms.security.constants.RoleCodes;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/master-data/vehicles")
@RequireAnyRole({
        RoleCodes.SUPER_ADMIN,
        RoleCodes.ORG_ADMIN,
        RoleCodes.SUPERVISOR,
        RoleCodes.DISPATCHER,
        RoleCodes.OPERATION_STAFF,
        RoleCodes.FINANCE_OPS
})
@RequireAnyPermission({"vehicle.read", "vehicle.all"})
@Tag(name = "Master Data - Vehicles")
public class VehiclesController {
    private final VehicleService service;

    public VehiclesController(VehicleService service) { this.service = service; }

    @GetMapping
    @Operation(summary = "Search vehicles with paging")
    public PagedResponse<VehicleEntity> list(
            @Parameter(description = "Organization ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000001"))
            @RequestParam UUID organizationId,
            @Parameter(description = "Search by vehicle code, plate number, chassis number, or engine number", schema = @Schema(defaultValue = "51D"))
            @RequestParam(required = false) String keyword,
            @Parameter(description = "Vehicle type", schema = @Schema(defaultValue = "TRACTOR"))
            @RequestParam(required = false) String vehicleType,
            @Parameter(description = "Branch ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000002"))
            @RequestParam(required = false) UUID branchId,
            @Parameter(description = "Operational state", schema = @Schema(defaultValue = "AVAILABLE"))
            @RequestParam(required = false) String operationalState,
            @Parameter(description = "Lifecycle status", schema = @Schema(defaultValue = "ACTIVE"))
            @RequestParam(required = false) String statusCode,
            @ParameterObject @PageableDefault(size = 20, sort = "plateNo") Pageable pageable) {
        return service.search(organizationId, keyword, vehicleType, branchId, operationalState, statusCode, pageable);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get vehicle by ID")
    public VehicleEntity get(
            @Parameter(description = "Organization ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000001"))
            @RequestParam UUID organizationId,
            @Parameter(description = "Vehicle ID", schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id) { return service.get(organizationId, id); }

    @PostMapping
    @RequireAnyRole({RoleCodes.SUPER_ADMIN, RoleCodes.ORG_ADMIN, RoleCodes.OPERATION_STAFF})
    @RequireAnyPermission({"vehicle.update", "vehicle.all"})
    @Operation(summary = "Create vehicle")
    public VehicleEntity create(@RequestBody VehicleEntity request) { return service.create(request); }

    @PutMapping("/{id}")
    @RequireAnyRole({RoleCodes.SUPER_ADMIN, RoleCodes.ORG_ADMIN, RoleCodes.OPERATION_STAFF})
    @RequireAnyPermission({"vehicle.update", "vehicle.all"})
    @Operation(summary = "Update vehicle")
    public VehicleEntity update(
            @Parameter(description = "Organization ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000001"))
            @RequestParam UUID organizationId,
            @Parameter(description = "Vehicle ID", schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id,
            @RequestBody VehicleEntity request) { return service.update(organizationId, id, request); }

    @PatchMapping("/{id}/deactivate")
    @RequireAnyRole({RoleCodes.SUPER_ADMIN, RoleCodes.ORG_ADMIN, RoleCodes.OPERATION_STAFF})
    @RequireAnyPermission({"vehicle.delete", "vehicle.all"})
    @Operation(summary = "Deactivate vehicle")
    public VehicleEntity deactivate(
            @Parameter(description = "Organization ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000001"))
            @RequestParam UUID organizationId,
            @Parameter(description = "Vehicle ID", schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id) { return service.deactivate(organizationId, id); }
}
