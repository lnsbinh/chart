package com.tms.masterdata.controller;

import com.tms.masterdata.model.ReferenceDataItemEntity;
import com.tms.masterdata.service.ReferenceDataItemService;
import com.tms.security.annotation.MasterDataReadAccess;
import com.tms.security.annotation.MasterDataWriteAccess;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/master-data/reference-data")
@Tag(name = "Master Data - Reference Data")
public class ReferenceDataItemController {

    private final ReferenceDataItemService service;

    public ReferenceDataItemController(ReferenceDataItemService service) {
        this.service = service;
    }

    @GetMapping("/groups")
    @MasterDataReadAccess
    @Operation(summary = "Get reference-data groups")
    public List<String> getGroups() {
        return service.getAllGroups();
    }

    @GetMapping("/business-partner-types")
    @MasterDataReadAccess
    @Operation(summary = "Get business-partner types")
    public List<ReferenceDataItemEntity> getBusinessPartnerTypes() {
        return service.getActiveByGroup(ReferenceDataItemService.GROUP_BUSINESS_PARTNER_TYPE);
    }

    @GetMapping("/location-types")
    @MasterDataReadAccess
    @Operation(summary = "Get location types")
    public List<ReferenceDataItemEntity> getLocationTypes() {
        return service.getActiveByGroup(ReferenceDataItemService.GROUP_LOCATION_TYPE);
    }

    @GetMapping("/vehicle-types")
    @MasterDataReadAccess
    @Operation(summary = "Get vehicle types")
    public List<ReferenceDataItemEntity> getVehicleTypes() {
        return service.getActiveByGroup(ReferenceDataItemService.GROUP_VEHICLE_TYPE);
    }

    @GetMapping("/driver-types")
    @MasterDataReadAccess
    @Operation(summary = "Get driver types")
    public List<ReferenceDataItemEntity> getDriverTypes() {
        return service.getActiveByGroup(ReferenceDataItemService.GROUP_DRIVER_TYPE);
    }

    @GetMapping("/container-types")
    @MasterDataReadAccess
    @Operation(summary = "Get container types")
    public List<ReferenceDataItemEntity> getContainerTypes() {
        return service.getActiveByGroup(ReferenceDataItemService.GROUP_CONTAINER_TYPE);
    }

    @GetMapping("/surcharge-charge-methods")
    @MasterDataReadAccess
    @Operation(summary = "Get surcharge charge methods")
    public List<ReferenceDataItemEntity> getSurchargeChargeMethods() {
        return service.getActiveByGroup(ReferenceDataItemService.GROUP_SURCHARGE_CHARGE_METHOD);
    }

    @GetMapping("/{groupCode}")
    @MasterDataReadAccess
    @Operation(summary = "Get all items by group")
    public List<ReferenceDataItemEntity> getAllByGroup(
            @Parameter(description = "Reference-data group code", schema = @Schema(defaultValue = "BUSINESS_PARTNER_TYPE"))
            @PathVariable String groupCode) {
        return service.getAllByGroup(groupCode);
    }

    @GetMapping("/{groupCode}/{itemCode}")
    @MasterDataReadAccess
    @Operation(summary = "Get reference-data item by group and code")
    public ReferenceDataItemEntity getByGroupAndCode(
            @Parameter(description = "Reference-data group code", schema = @Schema(defaultValue = "BUSINESS_PARTNER_TYPE"))
            @PathVariable String groupCode,
            @Parameter(description = "Reference-data item code", schema = @Schema(defaultValue = "CUSTOMER"))
            @PathVariable String itemCode
    ) {
        return service.getByGroupAndCode(groupCode, itemCode);
    }

    @PostMapping
    @MasterDataWriteAccess
    @Operation(summary = "Create reference-data item")
    public ReferenceDataItemEntity create(@RequestBody ReferenceDataItemEntity request) {
        return service.create(request);
    }

    @PutMapping("/{groupCode}/{itemCode}")
    @MasterDataWriteAccess
    @Operation(summary = "Update reference-data item")
    public ReferenceDataItemEntity update(
            @Parameter(description = "Reference-data group code", schema = @Schema(defaultValue = "BUSINESS_PARTNER_TYPE"))
            @PathVariable String groupCode,
            @Parameter(description = "Reference-data item code", schema = @Schema(defaultValue = "CUSTOMER"))
            @PathVariable String itemCode,
            @RequestBody ReferenceDataItemEntity request
    ) {
        return service.update(groupCode, itemCode, request);
    }

    @PatchMapping("/{groupCode}/{itemCode}/activate")
    @MasterDataWriteAccess
    @Operation(summary = "Activate reference-data item")
    public ReferenceDataItemEntity activate(
            @Parameter(description = "Reference-data group code", schema = @Schema(defaultValue = "BUSINESS_PARTNER_TYPE"))
            @PathVariable String groupCode,
            @Parameter(description = "Reference-data item code", schema = @Schema(defaultValue = "CUSTOMER"))
            @PathVariable String itemCode
    ) {
        return service.activate(groupCode, itemCode);
    }

    @PatchMapping("/{groupCode}/{itemCode}/deactivate")
    @MasterDataWriteAccess
    @Operation(summary = "Deactivate reference-data item")
    public ReferenceDataItemEntity deactivate(
            @Parameter(description = "Reference-data group code", schema = @Schema(defaultValue = "BUSINESS_PARTNER_TYPE"))
            @PathVariable String groupCode,
            @Parameter(description = "Reference-data item code", schema = @Schema(defaultValue = "CUSTOMER"))
            @PathVariable String itemCode
    ) {
        return service.deactivate(groupCode, itemCode);
    }
}
