package com.tms.masterdata.controller;

import com.tms.masterdata.dto.PagedResponse;
import com.tms.masterdata.model.RouteEntity;
import com.tms.masterdata.service.RouteService;
import com.tms.security.annotation.MasterDataReadAccess;
import com.tms.security.annotation.MasterDataWriteAccess;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/master-data/routes")
@MasterDataReadAccess
@Tag(name = "Master Data - Routes")
public class RoutesController {
    private final RouteService service;

    public RoutesController(RouteService service) { this.service = service; }

    @GetMapping
    @Operation(summary = "Search routes with paging")
    public PagedResponse<RouteEntity> list(
            @Parameter(description = "Organization ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000001"))
            @RequestParam UUID organizationId,
            @Parameter(description = "Search by route code or route name", schema = @Schema(defaultValue = "HCM"))
            @RequestParam(required = false) String keyword,
            @Parameter(description = "Lifecycle status", schema = @Schema(defaultValue = "ACTIVE"))
            @RequestParam(required = false) String statusCode,
            @Parameter(description = "Origin location ID")
            @RequestParam(required = false) UUID originLocationId,
            @Parameter(description = "Destination location ID")
            @RequestParam(required = false) UUID destinationLocationId,
            @ParameterObject @PageableDefault(size = 20, sort = "routeCode") Pageable pageable) {
        return service.search(organizationId, keyword, statusCode, originLocationId, destinationLocationId, pageable);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get route by ID")
    public RouteEntity get(
            @Parameter(description = "Organization ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000001"))
            @RequestParam UUID organizationId,
            @Parameter(description = "Route ID", schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id) { return service.get(organizationId, id); }

    @PostMapping
    @MasterDataWriteAccess
    @Operation(summary = "Create route")
    public RouteEntity create(@RequestBody RouteEntity request) { return service.create(request); }

    @PutMapping("/{id}")
    @MasterDataWriteAccess
    @Operation(summary = "Update route")
    public RouteEntity update(
            @Parameter(description = "Organization ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000001"))
            @RequestParam UUID organizationId,
            @Parameter(description = "Route ID", schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id,
            @RequestBody RouteEntity request) { return service.update(organizationId, id, request); }

    @PatchMapping("/{id}/deactivate")
    @MasterDataWriteAccess
    @Operation(summary = "Deactivate route")
    public RouteEntity deactivate(
            @Parameter(description = "Organization ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000001"))
            @RequestParam UUID organizationId,
            @Parameter(description = "Route ID", schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id) { return service.deactivate(organizationId, id); }
}
