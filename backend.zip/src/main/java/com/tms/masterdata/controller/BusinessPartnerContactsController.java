package com.tms.masterdata.controller;

import com.tms.masterdata.model.BusinessPartnerContactEntity;
import com.tms.masterdata.service.BusinessPartnerContactService;
import com.tms.security.annotation.MasterDataReadAccess;
import com.tms.security.annotation.MasterDataWriteAccess;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/master-data/business-partner-contacts")
@MasterDataReadAccess
@Tag(name = "Master Data - Business Partner Contacts")
public class BusinessPartnerContactsController {
    private final BusinessPartnerContactService service;

    public BusinessPartnerContactsController(BusinessPartnerContactService service) { this.service = service; }

    @GetMapping
    @Operation(summary = "List contacts by business partner")
    public List<BusinessPartnerContactEntity> list(
            @Parameter(description = "Business partner ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000011"))
            @RequestParam UUID businessPartnerId) { return service.listByPartner(businessPartnerId); }

    @PostMapping
    @MasterDataWriteAccess
    @Operation(summary = "Create contact")
    public BusinessPartnerContactEntity create(@RequestBody BusinessPartnerContactEntity request) { return service.create(request); }

    @DeleteMapping("/{id}")
    @MasterDataWriteAccess
    @Operation(summary = "Delete contact")
    public void delete(
            @Parameter(description = "Contact ID", schema = @Schema(example = "00000000-0000-0000-0000-000000000013"))
            @PathVariable UUID id) { service.delete(id); }
}
