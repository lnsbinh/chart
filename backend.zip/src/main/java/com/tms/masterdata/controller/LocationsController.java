package com.tms.masterdata.controller;

import com.tms.masterdata.dto.PagedResponse;
import com.tms.masterdata.model.LocationEntity;
import com.tms.masterdata.service.LocationService;
import com.tms.security.annotation.MasterDataReadAccess;
import com.tms.security.annotation.MasterDataWriteAccess;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/master-data/locations")
@MasterDataReadAccess
@Tag(name = "Master Data - Locations")
public class LocationsController {
    private final LocationService service;

    public LocationsController(LocationService service) { this.service = service; }

    @GetMapping
    @Operation(summary = "Search locations with paging")
    public PagedResponse<LocationEntity> list(
            @Parameter(description = "Organization ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000001"))
            @RequestParam UUID organizationId,
            @Parameter(description = "Search by location code, name, or address", schema = @Schema(defaultValue = "warehouse"))
            @RequestParam(required = false) String keyword,
            @Parameter(description = "Location type", schema = @Schema(defaultValue = "WAREHOUSE"))
            @RequestParam(required = false) String locationType,
            @Parameter(description = "Lifecycle status", schema = @Schema(defaultValue = "ACTIVE"))
            @RequestParam(required = false) String statusCode,
            @ParameterObject @PageableDefault(size = 20, sort = "locationCode") Pageable pageable) {
        return service.search(organizationId, keyword, locationType, statusCode, pageable);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get location by ID")
    public LocationEntity get(
            @Parameter(description = "Organization ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000001"))
            @RequestParam UUID organizationId,
            @Parameter(description = "Location ID", schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id) { return service.get(organizationId, id); }

    @PostMapping
    @MasterDataWriteAccess
    @Operation(summary = "Create location")
    public LocationEntity create(@RequestBody LocationEntity request) { return service.create(request); }

    @PutMapping("/{id}")
    @MasterDataWriteAccess
    @Operation(summary = "Update location")
    public LocationEntity update(
            @Parameter(description = "Organization ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000001"))
            @RequestParam UUID organizationId,
            @Parameter(description = "Location ID", schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id,
            @RequestBody LocationEntity request) { return service.update(organizationId, id, request); }

    @PatchMapping("/{id}/deactivate")
    @MasterDataWriteAccess
    @Operation(summary = "Deactivate location")
    public LocationEntity deactivate(
            @Parameter(description = "Organization ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000001"))
            @RequestParam UUID organizationId,
            @Parameter(description = "Location ID", schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id) { return service.deactivate(organizationId, id); }
}
