package com.tms.masterdata.service;

import com.tms.masterdata.model.TariffEntity;
import com.tms.masterdata.repository.TariffRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Service
public class TariffService {
    private final TariffRepository repository;

    public TariffService(TariffRepository repository) { this.repository = repository; }

    public List<TariffEntity> list(UUID organizationId, String statusCode, LocalDate effectiveDate) {
        if (statusCode != null && !statusCode.isBlank()) {
            return repository.findByOrganizationIdAndStatusCodeOrderByEffectiveFromDesc(organizationId, statusCode);
        }
        if (effectiveDate != null) {
            return repository.findByOrganizationIdAndEffectiveFromLessThanEqualOrderByEffectiveFromDesc(organizationId, effectiveDate);
        }
        return repository.findByOrganizationIdOrderByEffectiveFromDesc(organizationId);
    }

    public TariffEntity create(TariffEntity entity) { return repository.save(entity); }

    public TariffEntity update(UUID id, TariffEntity request) {
        TariffEntity entity = repository.findById(id).orElseThrow();
        entity.setCustomerId(request.getCustomerId());
        entity.setRouteId(request.getRouteId());
        entity.setVehicleType(request.getVehicleType());
        entity.setContainerType(request.getContainerType());
        entity.setCurrencyCode(request.getCurrencyCode());
        entity.setBasePrice(request.getBasePrice());
        entity.setEffectiveFrom(request.getEffectiveFrom());
        entity.setEffectiveTo(request.getEffectiveTo());
        entity.setStatusCode(request.getStatusCode());
        return repository.save(entity);
    }

    public TariffEntity deactivate(UUID id) {
        TariffEntity entity = repository.findById(id).orElseThrow();
        entity.setStatusCode("INACTIVE");
        return repository.save(entity);
    }
}
