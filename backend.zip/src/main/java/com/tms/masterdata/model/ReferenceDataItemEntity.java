package com.tms.masterdata.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import lombok.Data;

import java.time.OffsetDateTime;
import java.util.UUID;

@Data
@Entity
@Table(name = "reference_data_items", schema = "master_data",
        uniqueConstraints = @UniqueConstraint(name = "uk_reference_data_items", columnNames = {"group_code", "item_code"}))
public class ReferenceDataItemEntity {

    @Id
    @GeneratedValue
    @Column(name = "id", nullable = false)
    private UUID id;

    @Column(name = "group_code", nullable = false, length = 50)
    @Schema(example = "BUSINESS_PARTNER_TYPE")
    private String groupCode;

    @Column(name = "item_code", nullable = false, length = 50)
    @Schema(example = "CUSTOMER")
    private String itemCode;

    @Column(name = "name_vi", nullable = false, length = 255)
    @Schema(example = "Khach hang")
    private String nameVi;

    @Column(name = "name_en", nullable = false, length = 255)
    @Schema(example = "Customer")
    private String nameEn;

    @Column(name = "description")
    private String description;

    @Column(name = "sort_order", nullable = false)
    @Schema(example = "10", defaultValue = "0")
    private Integer sortOrder = 0;

    @Column(name = "is_system", nullable = false)
    @Schema(example = "true", defaultValue = "true")
    private Boolean isSystem = true;

    @Column(name = "status_code", nullable = false, length = 30)
    @Schema(example = "ACTIVE", defaultValue = "ACTIVE")
    private String statusCode = "ACTIVE";

    @Column(name = "created_at", nullable = false)
    private OffsetDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private OffsetDateTime updatedAt;

    @PrePersist
    public void prePersist() {
        OffsetDateTime now = OffsetDateTime.now();
        createdAt = now;
        updatedAt = now;
        if (sortOrder == null) sortOrder = 0;
        if (isSystem == null) isSystem = true;
        if (statusCode == null || statusCode.isBlank()) statusCode = "ACTIVE";
        groupCode = normalize(groupCode);
        itemCode = normalize(itemCode);
        statusCode = normalize(statusCode);
    }

    @PreUpdate
    public void preUpdate() {
        updatedAt = OffsetDateTime.now();
        groupCode = normalize(groupCode);
        itemCode = normalize(itemCode);
        statusCode = normalize(statusCode);
    }

    private String normalize(String s) {
        return s == null ? null : s.trim().toUpperCase();
    }
}