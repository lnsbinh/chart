package com.tms.masterdata.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

import java.time.OffsetDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "business_partners", schema = "master_data")
public class BusinessPartnerEntity {
    @Id
    @UuidGenerator
    private UUID id;
    @Column(name = "organization_id", nullable = false)
    @Schema(example = "00000000-0000-0000-0000-000000000001")
    private UUID organizationId;

    @Column(name = "partner_type", nullable = false)
    @Schema(example = "CUSTOMER")
    private String partnerType;

    @Column(name = "partner_code", nullable = false)
    @Schema(example = "CUST001")
    private String partnerCode;

    @Column(name = "partner_name", nullable = false)
    @Schema(example = "ACME Logistics")
    private String partnerName;

    @Column(name = "tax_code")
    private String taxCode;

    @Column(name = "phone")
    private String phone;

    @Column(name = "email")
    private String email;

    @Column(name = "address")
    private String address;

    @Column(name = "payment_term_days")
    private Integer paymentTermDays;

    @Column(name = "credit_limit_amount", precision = 18, scale = 2)
    private java.math.BigDecimal creditLimitAmount;

    @Column(name = "status_code", nullable = false)
    @Schema(example = "ACTIVE", defaultValue = "ACTIVE")
    private String statusCode = "ACTIVE";

    @Column(name = "created_at", nullable = false)
    private OffsetDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private OffsetDateTime updatedAt;

    @PrePersist
    void onCreate() {
        OffsetDateTime now = OffsetDateTime.now();
        if (statusCode == null) statusCode = "ACTIVE";
        createdAt = now;
        updatedAt = now;
    }

    @PreUpdate
    void onUpdate() {
        updatedAt = OffsetDateTime.now();
    }
}