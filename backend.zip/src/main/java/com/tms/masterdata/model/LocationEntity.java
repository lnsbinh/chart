package com.tms.masterdata.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

import java.time.OffsetDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "locations", schema = "master_data")
public class LocationEntity {
    @Id
    @UuidGenerator
    private UUID id;
    @Column(name = "organization_id", nullable = false)
    @Schema(example = "00000000-0000-0000-0000-000000000001")
    private UUID organizationId;

    @Column(name = "location_type", nullable = false)
    @Schema(example = "WAREHOUSE")
    private String locationType;

    @Column(name = "location_code", nullable = false)
    @Schema(example = "LOC001")
    private String locationCode;

    @Column(name = "location_name", nullable = false)
    @Schema(example = "Main Warehouse")
    private String locationName;

    @Column(name = "address")
    private String address;

    @Column(name = "latitude", precision = 10, scale = 7)
    private java.math.BigDecimal latitude;

    @Column(name = "longitude", precision = 10, scale = 7)
    private java.math.BigDecimal longitude;

    @Column(name = "status_code", nullable = false)
    @Schema(example = "ACTIVE", defaultValue = "ACTIVE")
    private String statusCode = "ACTIVE";

    @Column(name = "created_at", nullable = false)
    private OffsetDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private OffsetDateTime updatedAt;

    @PrePersist
    void onCreate() {
        OffsetDateTime now = OffsetDateTime.now();
        if (statusCode == null) statusCode = "ACTIVE";
        createdAt = now;
        updatedAt = now;
    }

    @PreUpdate
    void onUpdate() {
        updatedAt = OffsetDateTime.now();
    }
}