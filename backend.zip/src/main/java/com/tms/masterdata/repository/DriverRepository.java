package com.tms.masterdata.repository;

import com.tms.masterdata.model.DriverEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;
import java.util.UUID;

public interface DriverRepository extends JpaRepository<DriverEntity, UUID> {
    @Query("""
    select d
    from DriverEntity d
    where d.organizationId = :organizationId
      and (
            :keywordLike is null
            or lower(coalesce(d.driverCode, '')) like :keywordLike
            or lower(coalesce(d.fullName, '')) like :keywordLike
            or lower(coalesce(d.phone, '')) like :keywordLike
            or lower(coalesce(d.licenseNo, '')) like :keywordLike
          )
      and (:driverType is null or d.driverType = :driverType)
      and (:branchId is null or d.branchId = :branchId)
      and (:employmentStatus is null or d.employmentStatus = :employmentStatus)
    """)
    Page<DriverEntity> search(
            @Param("organizationId") UUID organizationId,
            @Param("keywordLike") String keywordLike,
            @Param("driverType") String driverType,
            @Param("branchId") UUID branchId,
            @Param("employmentStatus") String employmentStatus,
            Pageable pageable
    );

    Optional<DriverEntity> findByIdAndOrganizationId(UUID id, UUID organizationId);
}
