package com.tms.masterdata.repository;

import com.tms.masterdata.model.RouteEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;
import java.util.UUID;

public interface RouteRepository extends JpaRepository<RouteEntity, UUID> {
    @Query("""
            select r
            from RouteEntity r
            where r.organizationId = :organizationId
              and (:keyword is null or lower(r.routeCode) like lower(concat('%', :keyword, '%'))
                   or lower(r.routeName) like lower(concat('%', :keyword, '%')))
              and (:statusCode is null or r.statusCode = :statusCode)
              and (:originLocationId is null or r.originLocationId = :originLocationId)
              and (:destinationLocationId is null or r.destinationLocationId = :destinationLocationId)
            """)
    Page<RouteEntity> search(
            @Param("organizationId") UUID organizationId,
            @Param("keyword") String keyword,
            @Param("statusCode") String statusCode,
            @Param("originLocationId") UUID originLocationId,
            @Param("destinationLocationId") UUID destinationLocationId,
            Pageable pageable
    );

    Optional<RouteEntity> findByIdAndOrganizationId(UUID id, UUID organizationId);
}
