package com.tms.masterdata.repository;

import com.tms.masterdata.model.VehicleEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;
import java.util.UUID;

public interface VehicleRepository extends JpaRepository<VehicleEntity, UUID> {
    @Query("""
    select v
    from VehicleEntity v
    where v.organizationId = :organizationId
      and (
           :keywordLike is null
           or lower(coalesce(v.vehicleCode, '')) like :keywordLike
           or lower(v.plateNo) like :keywordLike
           or lower(coalesce(v.chassisNo, '')) like :keywordLike
           or lower(coalesce(v.engineNo, '')) like :keywordLike
      )
      and (:vehicleType is null or v.vehicleType = :vehicleType)
      and (:branchId is null or v.branchId = :branchId)
      and (:operationalState is null or v.operationalState = :operationalState)
      and (:statusCode is null or v.statusCode = :statusCode)
""")
    Page<VehicleEntity> search(
            @Param("organizationId") UUID organizationId,
            @Param("keywordLike") String keywordLike,
            @Param("vehicleType") String vehicleType,
            @Param("branchId") UUID branchId,
            @Param("operationalState") String operationalState,
            @Param("statusCode") String statusCode,
            Pageable pageable
    );

    Optional<VehicleEntity> findByIdAndOrganizationId(UUID id, UUID organizationId);
}
