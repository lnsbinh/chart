package com.tms.masterdata.repository;

import com.tms.masterdata.model.TariffEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

public interface TariffRepository extends JpaRepository<TariffEntity, UUID> {
    List<TariffEntity> findByOrganizationIdOrderByEffectiveFromDesc(UUID organizationId);
    List<TariffEntity> findByOrganizationIdAndStatusCodeOrderByEffectiveFromDesc(UUID organizationId, String statusCode);
    List<TariffEntity> findByOrganizationIdAndEffectiveFromLessThanEqualOrderByEffectiveFromDesc(UUID organizationId, LocalDate effectiveDate);
}
