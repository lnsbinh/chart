package com.tms.masterdata.repository;

import com.tms.masterdata.model.BusinessPartnerEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;
import java.util.UUID;

public interface BusinessPartnerRepository extends JpaRepository<BusinessPartnerEntity, UUID> {
    @Query("""
            select bp
            from BusinessPartnerEntity bp
            where bp.organizationId = :organizationId
              and (:keyword is null or lower(bp.partnerCode) like lower(concat('%', :keyword, '%'))
                   or lower(bp.partnerName) like lower(concat('%', :keyword, '%'))
                   or lower(coalesce(bp.phone, '')) like lower(concat('%', :keyword, '%'))
                   or lower(coalesce(bp.email, '')) like lower(concat('%', :keyword, '%')))
              and (:partnerType is null or bp.partnerType = :partnerType)
              and (:statusCode is null or bp.statusCode = :statusCode)
            """)
    Page<BusinessPartnerEntity> search(
            @Param("organizationId") UUID organizationId,
            @Param("keyword") String keyword,
            @Param("partnerType") String partnerType,
            @Param("statusCode") String statusCode,
            Pageable pageable
    );

    Optional<BusinessPartnerEntity> findByIdAndOrganizationId(UUID id, UUID organizationId);
}
