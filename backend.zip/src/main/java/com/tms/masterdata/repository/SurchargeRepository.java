package com.tms.masterdata.repository;

import com.tms.masterdata.model.SurchargeEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface SurchargeRepository extends JpaRepository<SurchargeEntity, UUID> {
    List<SurchargeEntity> findByOrganizationIdOrderBySurchargeCode(UUID organizationId);
    List<SurchargeEntity> findByOrganizationIdAndStatusCodeOrderBySurchargeCode(UUID organizationId, String statusCode);
    Optional<SurchargeEntity> findByIdAndOrganizationId(UUID id, UUID organizationId);
}
