package com.tms.masterdata.repository;

import com.tms.masterdata.model.ReferenceDataItemEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface ReferenceDataItemRepository extends JpaRepository<ReferenceDataItemEntity, UUID> {

    List<ReferenceDataItemEntity> findByGroupCodeAndStatusCodeOrderBySortOrderAscItemCodeAsc(
            String groupCode, String statusCode
    );

    List<ReferenceDataItemEntity> findByGroupCodeOrderBySortOrderAscItemCodeAsc(String groupCode);

    Optional<ReferenceDataItemEntity> findByGroupCodeAndItemCode(String groupCode, String itemCode);

    boolean existsByGroupCodeAndItemCode(String groupCode, String itemCode);

    @Query("""
        SELECT  distinct r.groupCode
        FROM    ReferenceDataItemEntity r
        ORDER by r.groupCode
    """)
    List<String> findDistinctGroupCodes();
}