package com.tms.all.config;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeIn;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
@OpenAPIDefinition(
        info = @Info(
                title = "TMS Master Data RBAC API",
                version = "v1",
                description = "Swagger / OpenAPI for the TMS backend with Keycloak-protected master data APIs. Default parameter values follow the Postman environment and collection used for local testing.",
                contact = @Contact(name = "TMS API")
        ),
        security = @SecurityRequirement(name = "bearerAuth")
)
@SecurityScheme(
        name = "bearerAuth",
        type = SecuritySchemeType.HTTP,
        scheme = "bearer",
        bearerFormat = "JWT",
        in = SecuritySchemeIn.HEADER,
        description = "Paste an access token from Keycloak. Local Postman defaults use the TMS realm and tms-api-client."
)
public class OpenApiConfig {

    @Bean
    public OpenAPI tmsOpenApi(
            @Value("${app.openapi.server-url:http://localhost:8081}") String serverUrl
    ) {
        return new OpenAPI()
                .servers(List.of(new Server()
                        .url(serverUrl)
                        .description("Local server")));
    }
}
