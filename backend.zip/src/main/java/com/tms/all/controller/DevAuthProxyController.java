package com.tms.all.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@RestController
@Profile("dev")
@RequestMapping("/api/public/dev/auth")
public class DevAuthProxyController {
    @Value("${keycloak.base-url}")
    private String keycloakBaseUrl;

    @Value("${app.dev-token.realm}")
    private String realm;

    @Value("${app.dev-token.client-id}")
    private String clientId = "tms-api-client";

    @Value("${app.dev-token.client-secret}")
    private String clientSecret = "";

    @Value("${app.dev-token.username}")
    private String username = "superadmin";

    @Value("${app.dev-token.password}")
    private String password;

    @Value("${app.dev-token.scope}")
    private String scope;

    @Value("${app.dev-token.grant-type}")
    private String grantType;

    private final RestTemplate restTemplate;

    public DevAuthProxyController(RestTemplateBuilder restTemplateBuilder) {
        this.restTemplate = restTemplateBuilder
                .build();
    }

    @GetMapping("/defaults")
    public Map<String, Object> defaults() {
        return Map.of(
                "keycloakBaseUrl", keycloakBaseUrl,
                "realm", realm,
                "clientId", clientId,
                "username", username,
                "scope", scope,
                "grantType", grantType
        );
    }

    @PostMapping("/token")
    @Operation(
            summary = "Get access token through dev proxy",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = false,
                    content = @Content(
                            mediaType = "application/json",
                            examples = @ExampleObject(
                                    name = "default-dev-request",
                                    value = """
                                            {
                                              "keycloakBaseUrl": "http://localhost:8080",
                                              "realm": "TMS",
                                              "clientId": "tms-backend-api",
                                              "clientSecret": "",
                                              "username": "backend",
                                              "password": "backend",
                                              "grantType": "password",
                                              "scope": "openid profile email"
                                            }
                                            """
                            )
                    )
            )
    )
    public Map<String, Object> token(@RequestBody(required = false) DevTokenProxyRequest request) {
        MultiValueMap<String, String> form = new LinkedMultiValueMap<>();
        form.add("client_id", coalesce(request != null ? request.getClientId() : null, clientId));

//        String clientSecret = coalesce(request != null ? request.getClientSecret() : null, clientSecret);
//
//        if (clientSecret != null && !clientSecret.isBlank()) {
//            form.add("client_secret", clientSecret);
//
//        }
        form.add("username", coalesce(request != null ? request.getUsername() : null, username));
        form.add("password", coalesce(request != null ? request.getPassword() : null, password));
        form.add("grant_type", coalesce(request != null ? request.getGrantType() : null, grantType));
        form.add("scope", coalesce(request != null ? request.getScope() : null, scope));

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(form, headers);

        String tokenUrl = keycloakBaseUrl + "/realms/" + realm + "/protocol/openid-connect/token";
        try {
            ResponseEntity<Map> response = restTemplate.exchange(tokenUrl, HttpMethod.POST, entity, Map.class);
            Map<String, Object> rs = response.getBody();

            return rs;
        } catch (HttpStatusCodeException ex) {
            throw new IllegalStateException("Keycloak token request failed: " + ex.getResponseBodyAsString(), ex);
        }

    }

    private String coalesce(String preferred, String fallback) {
        return preferred != null && !preferred.isBlank() ? preferred : fallback;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    static class DevTokenProxyRequest {

        private String clientId;
        private String clientSecret;
        private String username;
        private String password;
        private String scope;
        private String grantType;

        public String getClientId() {
            return clientId;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public String getClientSecret() {
            return clientSecret;
        }

        public void setClientSecret(String clientSecret) {
            this.clientSecret = clientSecret;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public String getScope() {
            return scope;
        }

        public void setScope(String scope) {
            this.scope = scope;
        }

        public String getGrantType() {
            return grantType;
        }

        public void setGrantType(String grantType) {
            this.grantType = grantType;
        }
    }
}
