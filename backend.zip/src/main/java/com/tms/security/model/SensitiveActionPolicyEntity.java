package com.tms.security.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

import java.time.OffsetDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "sensitive_action_policies", schema = "iam", uniqueConstraints = @UniqueConstraint(name = "uk_sensitive_action_policies", columnNames = {"action_code", "param_key"}))
public class SensitiveActionPolicyEntity {
    @Id
    @UuidGenerator
    private UUID id;

    @Column(name = "action_code", nullable = false)
    private String actionCode;

    @Column(name = "param_key", nullable = false)
    private String paramKey;

    @Column(name = "param_type", nullable = false)
    private String paramType;

    @Column(name = "param_value", nullable = false)
    private String paramValue;

    private String description;

    @Column(nullable = false)
    private String status = "ACTIVE";

    @Column(name = "created_at", nullable = false)
    private OffsetDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private OffsetDateTime updatedAt;

    @PrePersist
    void onCreate() {
        OffsetDateTime now = OffsetDateTime.now();
        createdAt = now;
        updatedAt = now;
    }

    @PreUpdate
    void onUpdate() {
        updatedAt = OffsetDateTime.now();
    }
}
