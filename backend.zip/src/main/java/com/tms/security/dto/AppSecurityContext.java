package com.tms.security.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;
import java.util.Set;
import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AppSecurityContext implements Serializable {
    private String subjectId;
    private String subjectType;
    private String username;
    private String clientId;
    private Long authzVersion;
    private Set<String> roles;
    private Set<String> permissions;
    private List<ScopedRoleAssignment> roleAssignments;
    private Set<UUID> accessibleOrganizationIds;
    private Set<UUID> accessibleBranchIds;
    private List<BranchMembership> branchMemberships;

    public boolean hasPermission(String permission) {
        return permissions != null && permissions.contains(permission);
    }
}
