package com.tms.security.aspect;

import com.tms.security.annotation.RequireAnyRole;
import com.tms.security.config.AppSecurityContextHolder;
import com.tms.security.dto.AppSecurityContext;
import com.tms.security.exception.ForbiddenException;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;

@Aspect
@Component
public class RbacAuthorizationAspect {

    @Around("@within(com.tms.security.annotation.RequireAnyRole) || @annotation(com.tms.security.annotation.RequireAnyRole)")
    public Object authorizeAnyRole(ProceedingJoinPoint joinPoint) throws Throwable {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();

        RequireAnyRole annotation = AnnotatedElementUtils.findMergedAnnotation(method, RequireAnyRole.class);
        if (annotation == null) {
            annotation = AnnotatedElementUtils.findMergedAnnotation(joinPoint.getTarget().getClass(), RequireAnyRole.class);
        }
        if (annotation == null) {
            return joinPoint.proceed();
        }

        AppSecurityContext context = AppSecurityContextHolder.getRequired();
        Set<String> userRoles = context.getRoles() == null ? Set.of() : new LinkedHashSet<>(context.getRoles());
        boolean allowed = Arrays.stream(annotation.value()).anyMatch(userRoles::contains);
        if (!allowed) {
            throw new ForbiddenException("Required any role " + Arrays.toString(annotation.value()) + " but actual roles were " + userRoles);
        }
        return joinPoint.proceed();
    }
}
