package com.tms.security.controller;

import com.tms.security.model.PermissionEntity;
import com.tms.security.service.PermissionService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/permissions")
public class PermissionController {
    private final PermissionService permissionService;

    public PermissionController(PermissionService permissionService) {
        this.permissionService = permissionService;
    }

    @GetMapping
    public List<PermissionEntity> getAllPermissions() { return permissionService.getAllPermissions(); }

    @PostMapping
    public PermissionEntity createPermission(@RequestBody PermissionEntity permission) { return permissionService.addPermission(permission); }

    @DeleteMapping("/{id}")
    public void deletePermission(@PathVariable UUID id) { permissionService.deletePermission(id); }
}
