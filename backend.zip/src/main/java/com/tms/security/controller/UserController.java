package com.tms.security.controller;

import com.tms.security.model.UserEntity;
import com.tms.security.service.UserService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/users")
public class UserController {
    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping
    public List<UserEntity> getAllUsers() { return userService.getAllUsers(); }

    @PostMapping
    public UserEntity createUser(@RequestBody UserEntity user) { return userService.addUser(user); }

    @DeleteMapping("/{id}")
    public void deleteUser(@PathVariable UUID id) { userService.deleteUser(id); }
}
