package com.tms.security.controller;

import com.tms.security.model.RoleEntity;
import com.tms.security.service.RoleService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/roles")
public class RoleController {
    private final RoleService roleService;

    public RoleController(RoleService roleService) {
        this.roleService = roleService;
    }

    @GetMapping
    public List<RoleEntity> getAllRoles() { return roleService.getAllRoles(); }

    @PostMapping
    public RoleEntity createRole(@RequestBody RoleEntity role) { return roleService.addRole(role); }

    @DeleteMapping("/{id}")
    public void deleteRole(@PathVariable UUID id) { roleService.deleteRole(id); }
}
