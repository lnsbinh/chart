package com.tms.security.repository;

import com.tms.security.model.UserEffectivePermissionEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;

public interface UserEffectivePermissionRepository extends JpaRepository<UserEffectivePermissionEntity, UUID> {

    @Query("""
            select uep from UserEffectivePermissionEntity uep
            join fetch uep.permission p
            left join fetch uep.organization o
            left join fetch uep.branch b
            where uep.user.id = :userId
            order by p.code, uep.scopeType
            """)
    List<UserEffectivePermissionEntity> findByUserIdWithRefs(@Param("userId") UUID userId);

    void deleteByUserId(UUID userId);
}
