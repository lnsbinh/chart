package com.tms.security.repository;

import com.tms.security.model.BranchEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

public interface BranchRepository extends JpaRepository<BranchEntity, UUID> {
    Optional<BranchEntity> findByIdAndOrganizationId(UUID id, UUID organizationId);
}
