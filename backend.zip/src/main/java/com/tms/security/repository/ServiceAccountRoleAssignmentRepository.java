package com.tms.security.repository;

import com.tms.security.model.ServiceAccountRoleAssignmentEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;

public interface ServiceAccountRoleAssignmentRepository extends JpaRepository<ServiceAccountRoleAssignmentEntity, UUID> {
    @Query("""
            select sara from ServiceAccountRoleAssignmentEntity sara
            join fetch sara.role r
            left join fetch sara.organization o
            left join fetch sara.branch b
            where sara.serviceAccount.id = :serviceAccountId
              and sara.status = 'ACTIVE'
              and (sara.validFrom is null or sara.validFrom <= CURRENT_TIMESTAMP)
              and (sara.validTo is null or sara.validTo >= CURRENT_TIMESTAMP)
            order by r.code, sara.scopeType
            """)
    List<ServiceAccountRoleAssignmentEntity> findActiveByServiceAccountId(@Param("serviceAccountId") UUID serviceAccountId);
}
