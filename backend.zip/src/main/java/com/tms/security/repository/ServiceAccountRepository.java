package com.tms.security.repository;

import com.tms.security.model.ServiceAccountEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

public interface ServiceAccountRepository extends JpaRepository<ServiceAccountEntity, UUID> {
    Optional<ServiceAccountEntity> findByClientIdAndStatus(String clientId, String status);
}
