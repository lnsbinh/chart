package com.tms.security.repository;

import com.tms.security.model.RoleHierarchyEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface RoleHierarchyRepository extends JpaRepository<RoleHierarchyEntity, UUID> {
}
