package com.tms.security.config;

import com.tms.security.filter.AppAuthorizationContextFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.server.resource.web.authentication.BearerTokenAuthenticationFilter;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableMethodSecurity
public class SecurityConfig {
    private final SecurityIgnoreProperties securityIgnoreProperties;
    private final AppAuthorizationContextFilter appAuthorizationContextFilter;

    public SecurityConfig(SecurityIgnoreProperties securityIgnoreProperties, AppAuthorizationContextFilter appAuthorizationContextFilter) {
        this.securityIgnoreProperties = securityIgnoreProperties;
        this.appAuthorizationContextFilter = appAuthorizationContextFilter;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        String[] ignoredPaths = securityIgnoreProperties.getPaths().toArray(new String[0]);
        http.csrf(csrf -> csrf.disable())
            .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                    .requestMatchers(ignoredPaths).permitAll()
                    .anyRequest().authenticated())
            .oauth2ResourceServer(oauth -> oauth.jwt(Customizer.withDefaults()))
            .addFilterAfter(appAuthorizationContextFilter, BearerTokenAuthenticationFilter.class);

        return http.build();
    }
}
