package com.tms.security.service;

import com.tms.security.dto.AppSecurityContext;
import org.springframework.stereotype.Service;

@Service
public class PermissionEvaluator {
    public boolean evaluate(String permission, AppSecurityContext context) {
        return context != null && context.hasPermission(permission);
    }
}
