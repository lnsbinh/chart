package com.tms.security.service;

import com.tms.security.dto.AppSecurityContext;
import com.tms.security.dto.BranchMembership;
import com.tms.security.dto.ScopedRoleAssignment;
import com.tms.security.model.PermissionEntity;
import com.tms.security.model.ServiceAccountEntity;
import com.tms.security.model.ServiceAccountRoleAssignmentEntity;
import com.tms.security.model.UserBranchEntity;
import com.tms.security.model.UserEntity;
import com.tms.security.model.UserRoleAssignmentEntity;
import com.tms.security.repository.PermissionRepository;
import com.tms.security.repository.ServiceAccountRepository;
import com.tms.security.repository.ServiceAccountRoleAssignmentRepository;
import com.tms.security.repository.UserBranchRepository;
import com.tms.security.repository.UserRepository;
import com.tms.security.repository.UserRoleAssignmentRepository;
import com.tms.security.util.JwtUtil;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class AuthzContextService {

    private final UserRepository userRepository;
    private final ServiceAccountRepository serviceAccountRepository;
    private final UserRoleAssignmentRepository userRoleAssignmentRepository;
    private final ServiceAccountRoleAssignmentRepository serviceAccountRoleAssignmentRepository;
    private final UserBranchRepository userBranchRepository;
    private final PermissionRepository permissionRepository;
    private final JwtUtil jwtUtil;
    private final RedisTemplate<String, Object> redisTemplate;

    public AuthzContextService(
            UserRepository userRepository,
            ServiceAccountRepository serviceAccountRepository,
            UserRoleAssignmentRepository userRoleAssignmentRepository,
            ServiceAccountRoleAssignmentRepository serviceAccountRoleAssignmentRepository,
            UserBranchRepository userBranchRepository,
            PermissionRepository permissionRepository,
            JwtUtil jwtUtil,
            RedisTemplate<String, Object> redisTemplate
    ) {
        this.userRepository = userRepository;
        this.serviceAccountRepository = serviceAccountRepository;
        this.userRoleAssignmentRepository = userRoleAssignmentRepository;
        this.serviceAccountRoleAssignmentRepository = serviceAccountRoleAssignmentRepository;
        this.userBranchRepository = userBranchRepository;
        this.permissionRepository = permissionRepository;
        this.jwtUtil = jwtUtil;
        this.redisTemplate = redisTemplate;
    }

    public AppSecurityContext buildContext(Jwt jwt) {
        String subjectType = coalesce(jwtUtil.getSubjectType(jwt), "human_user");
        if ("service_account".equalsIgnoreCase(subjectType)) {
            return buildServiceAccountContext(jwt);
        }
        return buildHumanContext(jwt);
    }

    private AppSecurityContext buildHumanContext(Jwt jwt) {
//        String subject = jwtUtil.getSubject(jwt);
        String subject = jwtUtil.getUsername(jwt);
        UserEntity user = userRepository.findByExternalSubjectAndStatus(subject, "ACTIVE")
                .orElseThrow(() -> new IllegalStateException("Active local user not found for subject=" + subject));

        String cacheKey = "authz:user:" + user.getId() + ":v:" + user.getAuthzVersion();
        AppSecurityContext cached = getCached(cacheKey);
        if (cached != null) {
            return cached;
        }

        List<UserRoleAssignmentEntity> assignments = userRoleAssignmentRepository.findActiveByUserId(user.getId());
        List<UserBranchEntity> branches = userBranchRepository.findActiveByUserId(user.getId());

        Set<String> roleCodes = assignments.stream()
                .map(a -> a.getRole().getCode())
                .collect(Collectors.toCollection(LinkedHashSet::new));

        Set<String> permissionCodes = resolveEffectivePermissionCodes(
                assignments.stream().map(UserRoleAssignmentEntity::getRole).map(r -> r.getId()).toList()
        );

        AppSecurityContext context = AppSecurityContext.builder()
                .subjectId(user.getId().toString())
                .subjectType("human_user")
                .username(user.getUsername())
                .clientId(jwtUtil.getAuthorizedParty(jwt))
                .authzVersion(user.getAuthzVersion())
                .roles(roleCodes)
                .permissions(permissionCodes)
                .roleAssignments(assignments.stream().map(a -> new ScopedRoleAssignment(
                        a.getRole().getCode(),
                        a.getScopeType(),
                        a.getOrganization() != null ? a.getOrganization().getId() : null,
                        a.getBranch() != null ? a.getBranch().getId() : null
                )).toList())
                .accessibleOrganizationIds(assignments.stream()
                        .map(a -> a.getOrganization() != null ? a.getOrganization().getId() : null)
                        .filter(java.util.Objects::nonNull)
                        .collect(Collectors.toCollection(LinkedHashSet::new)))
                .accessibleBranchIds(assignments.stream()
                        .map(a -> a.getBranch() != null ? a.getBranch().getId() : null)
                        .filter(java.util.Objects::nonNull)
                        .collect(Collectors.toCollection(LinkedHashSet::new)))
                .branchMemberships(branches.stream().map(b -> new BranchMembership(
                        b.getOrganization().getId(),
                        b.getBranch().getId(),
                        b.getBranch().getCode(),
                        b.getBranch().getName(),
                        b.isPrimary()
                )).toList())
                .build();

        putCached(cacheKey, context);
        return context;
    }

    private AppSecurityContext buildServiceAccountContext(Jwt jwt) {
        String clientId = jwtUtil.getAuthorizedParty(jwt);
        if (clientId == null || clientId.isBlank()) {
            throw new IllegalStateException("Missing azp/client id for service account token");
        }

        ServiceAccountEntity serviceAccount = serviceAccountRepository.findByClientIdAndStatus(clientId, "ACTIVE")
                .orElseThrow(() -> new IllegalStateException("Active local service account not found for clientId=" + clientId));

        String cacheKey = "authz:service-account:" + serviceAccount.getId() + ":v:" + serviceAccount.getAuthzVersion();
        AppSecurityContext cached = getCached(cacheKey);
        if (cached != null) {
            return cached;
        }

        List<ServiceAccountRoleAssignmentEntity> assignments =
                serviceAccountRoleAssignmentRepository.findActiveByServiceAccountId(serviceAccount.getId());

        Set<String> roleCodes = assignments.stream()
                .map(a -> a.getRole().getCode())
                .collect(Collectors.toCollection(LinkedHashSet::new));

        Set<String> permissionCodes = resolveEffectivePermissionCodes(
                assignments.stream().map(ServiceAccountRoleAssignmentEntity::getRole).map(r -> r.getId()).toList()
        );

        AppSecurityContext context = AppSecurityContext.builder()
                .subjectId(serviceAccount.getId().toString())
                .subjectType("service_account")
                .username(serviceAccount.getDisplayName())
                .clientId(serviceAccount.getClientId())
                .authzVersion(serviceAccount.getAuthzVersion())
                .roles(roleCodes)
                .permissions(permissionCodes)
                .roleAssignments(assignments.stream().map(a -> new ScopedRoleAssignment(
                        a.getRole().getCode(),
                        a.getScopeType(),
                        a.getOrganization() != null ? a.getOrganization().getId() : null,
                        a.getBranch() != null ? a.getBranch().getId() : null
                )).toList())
                .accessibleOrganizationIds(assignments.stream()
                        .map(a -> a.getOrganization() != null ? a.getOrganization().getId() : null)
                        .filter(java.util.Objects::nonNull)
                        .collect(Collectors.toCollection(LinkedHashSet::new)))
                .accessibleBranchIds(assignments.stream()
                        .map(a -> a.getBranch() != null ? a.getBranch().getId() : null)
                        .filter(java.util.Objects::nonNull)
                        .collect(Collectors.toCollection(LinkedHashSet::new)))
                .branchMemberships(List.of())
                .build();

        putCached(cacheKey, context);
        return context;
    }

    private Set<String> resolveEffectivePermissionCodes(List<java.util.UUID> assignedRoleIds) {
        LinkedHashSet<String> codes = new LinkedHashSet<>();
        for (java.util.UUID roleId : assignedRoleIds) {
            List<PermissionEntity> permissions = permissionRepository.findActiveEffectiveByAssignedRoleId(roleId);
            for (PermissionEntity permission : permissions) {
                codes.add(permission.getCode());
            }
        }
        return codes;
    }

    private void putCached(String key, AppSecurityContext context) {
        redisTemplate.opsForValue().set(key, context, Duration.ofMinutes(10));
    }

    private AppSecurityContext getCached(String key) {
        Object value = redisTemplate.opsForValue().get(key);
        return value instanceof AppSecurityContext c ? c : null;
    }

    private String coalesce(String a, String b) {
        return a != null && !a.isBlank() ? a : b;
    }
}
