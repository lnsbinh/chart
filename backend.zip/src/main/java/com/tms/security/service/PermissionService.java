package com.tms.security.service;

import com.tms.security.model.PermissionEntity;
import com.tms.security.repository.PermissionRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class PermissionService {
    private final PermissionRepository permissionRepository;

    public PermissionService(PermissionRepository permissionRepository) {
        this.permissionRepository = permissionRepository;
    }

    public List<PermissionEntity> getAllPermissions() { return permissionRepository.findAll(); }
    public PermissionEntity addPermission(PermissionEntity permission) { return permissionRepository.save(permission); }
    public void deletePermission(UUID id) { permissionRepository.deleteById(id); }
}
