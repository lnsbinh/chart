package com.tms.security.service;

import com.tms.security.model.UserEntity;
import com.tms.security.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class UserService {
    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public List<UserEntity> getAllUsers() { return userRepository.findAll(); }
    public UserEntity addUser(UserEntity user) { return userRepository.save(user); }
    public void deleteUser(UUID id) { userRepository.deleteById(id); }
}
