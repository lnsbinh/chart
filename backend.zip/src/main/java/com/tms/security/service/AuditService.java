package com.tms.security.service;

import com.tms.security.model.AuditLogEntity;
import com.tms.security.repository.AuditLogRepository;
import org.springframework.stereotype.Service;

@Service
public class AuditService {
    private final AuditLogRepository auditLogRepository;

    public AuditService(AuditLogRepository auditLogRepository) {
        this.auditLogRepository = auditLogRepository;
    }

    public AuditLogEntity save(AuditLogEntity entity) {
        return auditLogRepository.save(entity);
    }
}
