package com.tms.security.service;

import com.tms.security.dto.AppSecurityContext;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class ScopeEvaluator {
    public boolean hasOrganizationAccess(AppSecurityContext context, UUID organizationId) {
        return context != null && context.getAccessibleOrganizationIds() != null && context.getAccessibleOrganizationIds().contains(organizationId);
    }

    public boolean hasBranchAccess(AppSecurityContext context, UUID branchId) {
        return context != null && context.getAccessibleBranchIds() != null && context.getAccessibleBranchIds().contains(branchId);
    }
}
