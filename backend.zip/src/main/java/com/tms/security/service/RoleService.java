package com.tms.security.service;

import com.tms.security.model.RoleEntity;
import com.tms.security.repository.RoleRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class RoleService {
    private final RoleRepository roleRepository;

    public RoleService(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }

    public List<RoleEntity> getAllRoles() { return roleRepository.findAll(); }
    public RoleEntity addRole(RoleEntity role) { return roleRepository.save(role); }
    public void deleteRole(UUID id) { roleRepository.deleteById(id); }
}
