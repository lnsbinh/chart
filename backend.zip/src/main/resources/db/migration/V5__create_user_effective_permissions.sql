CREATE TABLE IF NOT EXISTS iam.user_effective_permissions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID NOT NULL REFERENCES iam.users(id) ON DELETE CASCADE,
    permission_id   UUID NOT NULL REFERENCES iam.permissions(id) ON DELETE RESTRICT,
    scope_type      TEXT NOT NULL
        CHECK (scope_type IN ('GLOBAL', 'ORGANIZATION', 'BRANCH')),
    organization_id UUID REFERENCES iam.organizations(id) ON DELETE RESTRICT,
    branch_id       UUID REFERENCES iam.branches(id) ON DELETE RESTRICT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uk_user_effective_permissions
        UNIQUE NULLS NOT DISTINCT (
            user_id,
            permission_id,
            organization_id,
            branch_id
        )
);

CREATE INDEX IF NOT EXISTS idx_uep_user_id
    ON iam.user_effective_permissions(user_id);

CREATE INDEX IF NOT EXISTS idx_uep_user_permission
    ON iam.user_effective_permissions(user_id, permission_id);

CREATE INDEX IF NOT EXISTS idx_uep_user_scope
    ON iam.user_effective_permissions(user_id, organization_id, branch_id);
