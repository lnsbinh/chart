
BEGIN;

CREATE SCHEMA IF NOT EXISTS iam;
--CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS iam.organizations (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code            TEXT NOT NULL UNIQUE,
    name            TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'ACTIVE'
                        CHECK (status IN ('ACTIVE', 'DISABLED')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS iam.branches (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES iam.organizations(id) ON DELETE RESTRICT,
    code            TEXT NOT NULL,
    name            TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'ACTIVE'
                        CHECK (status IN ('ACTIVE', 'DISABLED')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uk_branches_org_code UNIQUE (organization_id, code)
);

CREATE INDEX IF NOT EXISTS idx_branches_org_id ON iam.branches (organization_id);

CREATE TABLE IF NOT EXISTS iam.users (
    id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    external_subject     TEXT NOT NULL UNIQUE,
    username             TEXT NOT NULL,
    email                TEXT,
    display_name         TEXT,
    home_organization_id UUID REFERENCES iam.organizations(id) ON DELETE SET NULL,
    status               TEXT NOT NULL DEFAULT 'ACTIVE'
                             CHECK (status IN ('ACTIVE', 'DISABLED', 'LOCKED', 'DELETED')),
    authz_version        BIGINT NOT NULL DEFAULT 1,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_users_username ON iam.users (username);
CREATE INDEX IF NOT EXISTS idx_users_home_org ON iam.users (home_organization_id);

CREATE TABLE IF NOT EXISTS iam.user_branches (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID NOT NULL REFERENCES iam.users(id) ON DELETE CASCADE,
    organization_id UUID NOT NULL REFERENCES iam.organizations(id) ON DELETE RESTRICT,
    branch_id       UUID NOT NULL REFERENCES iam.branches(id) ON DELETE RESTRICT,
    is_primary      BOOLEAN NOT NULL DEFAULT FALSE,
    status          TEXT NOT NULL DEFAULT 'ACTIVE'
                        CHECK (status IN ('ACTIVE', 'DISABLED')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_by      UUID,
    updated_by      UUID,
    CONSTRAINT uk_user_branches UNIQUE (user_id, branch_id)
);

CREATE INDEX IF NOT EXISTS idx_user_branches_user_id ON iam.user_branches (user_id);
CREATE INDEX IF NOT EXISTS idx_user_branches_org_branch ON iam.user_branches (organization_id, branch_id);
CREATE UNIQUE INDEX IF NOT EXISTS uk_user_branches_one_primary
    ON iam.user_branches (user_id)
    WHERE is_primary = TRUE;

CREATE TABLE IF NOT EXISTS iam.roles (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code                TEXT NOT NULL UNIQUE,
    name                TEXT NOT NULL,
    description         TEXT,
    allowed_scope_type  TEXT NOT NULL
                            CHECK (allowed_scope_type IN (
                                'GLOBAL',
                                'ORGANIZATION',
                                'BRANCH',
                                'ORGANIZATION_AND_BRANCH'
                            )),
    is_system           BOOLEAN NOT NULL DEFAULT FALSE,
    status              TEXT NOT NULL DEFAULT 'ACTIVE'
                            CHECK (status IN ('ACTIVE', 'DISABLED', 'DEPRECATED')),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS iam.role_hierarchy (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    parent_role_id   UUID NOT NULL REFERENCES iam.roles(id) ON DELETE CASCADE,
    child_role_id    UUID NOT NULL REFERENCES iam.roles(id) ON DELETE CASCADE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uk_role_hierarchy UNIQUE (parent_role_id, child_role_id),
    CONSTRAINT chk_role_hierarchy_no_self CHECK (parent_role_id <> child_role_id)
);

CREATE INDEX IF NOT EXISTS idx_role_hierarchy_parent ON iam.role_hierarchy (parent_role_id);
CREATE INDEX IF NOT EXISTS idx_role_hierarchy_child ON iam.role_hierarchy (child_role_id);

CREATE TABLE IF NOT EXISTS iam.permissions (
    id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code                  TEXT NOT NULL UNIQUE,
    name                  TEXT NOT NULL,
    display_name_vi       TEXT NOT NULL,
    display_name_en       TEXT NOT NULL,
    description_vi        TEXT,
    description_en        TEXT,
    module_code           TEXT NOT NULL,
    resource_code         TEXT NOT NULL,
    action_code           TEXT NOT NULL,
    assignment_scope_hint TEXT NOT NULL
                              CHECK (assignment_scope_hint IN (
                                  'GLOBAL',
                                  'ORGANIZATION',
                                  'BRANCH',
                                  'ORGANIZATION_AND_BRANCH'
                              )),
    is_sensitive          BOOLEAN NOT NULL DEFAULT FALSE,
    status                TEXT NOT NULL DEFAULT 'ACTIVE'
                              CHECK (status IN ('ACTIVE', 'DISABLED', 'DEPRECATED')),
    created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at            TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_permissions_module ON iam.permissions (module_code);
CREATE INDEX IF NOT EXISTS idx_permissions_resource_action ON iam.permissions (resource_code, action_code);
CREATE INDEX IF NOT EXISTS idx_permissions_status ON iam.permissions (status);

CREATE TABLE IF NOT EXISTS iam.role_permissions (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    role_id       UUID NOT NULL REFERENCES iam.roles(id) ON DELETE CASCADE,
    permission_id UUID NOT NULL REFERENCES iam.permissions(id) ON DELETE CASCADE,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uk_role_permissions UNIQUE (role_id, permission_id)
);

CREATE INDEX IF NOT EXISTS idx_role_permissions_role_id ON iam.role_permissions (role_id);
CREATE INDEX IF NOT EXISTS idx_role_permissions_permission_id ON iam.role_permissions (permission_id);

CREATE TABLE IF NOT EXISTS iam.user_role_assignments (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID NOT NULL REFERENCES iam.users(id) ON DELETE CASCADE,
    role_id         UUID NOT NULL REFERENCES iam.roles(id) ON DELETE RESTRICT,
    scope_type      TEXT NOT NULL
                        CHECK (scope_type IN ('GLOBAL', 'ORGANIZATION', 'BRANCH')),
    organization_id UUID REFERENCES iam.organizations(id) ON DELETE RESTRICT,
    branch_id       UUID REFERENCES iam.branches(id) ON DELETE RESTRICT,
    status          TEXT NOT NULL DEFAULT 'ACTIVE'
                        CHECK (status IN ('ACTIVE', 'DISABLED')),
    valid_from      TIMESTAMPTZ,
    valid_to        TIMESTAMPTZ,
    source_type     TEXT NOT NULL DEFAULT 'MANUAL',
    source_ref      TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_by      UUID,
    updated_by      UUID,
    CONSTRAINT chk_user_role_assignments_shape
        CHECK (
            (scope_type = 'GLOBAL' AND organization_id IS NULL AND branch_id IS NULL)
            OR
            (scope_type = 'ORGANIZATION' AND organization_id IS NOT NULL AND branch_id IS NULL)
            OR
            (scope_type = 'BRANCH' AND organization_id IS NOT NULL AND branch_id IS NOT NULL)
        ),
    CONSTRAINT uk_user_role_assignments_unique
        UNIQUE NULLS NOT DISTINCT (user_id, role_id, scope_type, organization_id, branch_id)
);

CREATE INDEX IF NOT EXISTS idx_user_role_assignments_user_id ON iam.user_role_assignments (user_id);
CREATE INDEX IF NOT EXISTS idx_user_role_assignments_role_id ON iam.user_role_assignments (role_id);
CREATE INDEX IF NOT EXISTS idx_user_role_assignments_org_branch ON iam.user_role_assignments (organization_id, branch_id);

CREATE TABLE iam.user_effective_permissions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    user_id         UUID NOT NULL REFERENCES iam.users(id) ON DELETE CASCADE,
    permission_id   UUID NOT NULL REFERENCES iam.permissions(id) ON DELETE RESTRICT,

    scope_type      TEXT NOT NULL
        CHECK (scope_type IN ('GLOBAL', 'ORGANIZATION', 'BRANCH')),
    organization_id UUID REFERENCES iam.organizations(id) ON DELETE RESTRICT,
    branch_id       UUID REFERENCES iam.branches(id) ON DELETE RESTRICT,

    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),


    CONSTRAINT uk_user_effective_permissions
        UNIQUE NULLS NOT DISTINCT (
            user_id,
            permission_id,
            organization_id,
            branch_id
            )
);

CREATE INDEX idx_uep_user_id
    ON iam.user_effective_permissions(user_id);



CREATE TABLE IF NOT EXISTS iam.sensitive_action_policies (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    action_code     TEXT NOT NULL,
    param_key       TEXT NOT NULL,
    param_type      TEXT NOT NULL
                        CHECK (param_type IN ('BOOLEAN', 'INTEGER', 'TEXT', 'JSON')),
    param_value     TEXT NOT NULL,
    description     TEXT,
    status          TEXT NOT NULL DEFAULT 'ACTIVE'
                        CHECK (status IN ('ACTIVE', 'DISABLED')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uk_sensitive_action_policies UNIQUE (action_code, param_key)
);

CREATE INDEX IF NOT EXISTS idx_sensitive_action_policies_action_code ON iam.sensitive_action_policies (action_code);

CREATE TABLE IF NOT EXISTS iam.audit_logs (
    id              BIGSERIAL PRIMARY KEY,
    event_code      TEXT NOT NULL,
    category        TEXT NOT NULL,
    subject_type    TEXT,
    subject_id      TEXT,
    username        TEXT,
    client_id       TEXT,
    organization_id UUID,
    branch_id       UUID,
    target_type     TEXT,
    target_id       TEXT,
    action_code     TEXT,
    result          TEXT NOT NULL,
    reason          TEXT,
    trace_id        TEXT,
    ip_address      TEXT,
    user_agent      TEXT,
    metadata_json   JSONB NOT NULL DEFAULT '{}'::jsonb,
    occurred_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_audit_logs_occurred_at ON iam.audit_logs (occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_subject ON iam.audit_logs (subject_type, subject_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_trace_id ON iam.audit_logs (trace_id);


INSERT INTO iam.users (external_subject,username,email,display_name,home_organization_id,status,authz_version,created_at,updated_at)
VALUES
    ('superadmin','superadmin','superadmin@gmail.com','Super Admin',cast(NULL as uuid),'ACTIVE',1,'2026-04-02 06:05:43.618272 +0000'::timestamptz,'2026-04-02 06:05:43.618272 +0000'::timestamptz);

COMMIT;
