
BEGIN;

CREATE SCHEMA IF NOT EXISTS iam;
--CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS iam.organizations (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code            TEXT NOT NULL UNIQUE,
    name            TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'ACTIVE'
                        CHECK (status IN ('ACTIVE', 'DISABLED')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS iam.branches (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES iam.organizations(id) ON DELETE RESTRICT,
    code            TEXT NOT NULL,
    name            TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'ACTIVE'
                        CHECK (status IN ('ACTIVE', 'DISABLED')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uk_branches_org_code UNIQUE (organization_id, code)
);

CREATE INDEX IF NOT EXISTS idx_branches_org_id ON iam.branches (organization_id);

CREATE TABLE IF NOT EXISTS iam.users (
    id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    external_subject     TEXT NOT NULL UNIQUE,
    username             TEXT NOT NULL,
    email                TEXT,
    display_name         TEXT,
    home_organization_id UUID REFERENCES iam.organizations(id) ON DELETE SET NULL,
    status               TEXT NOT NULL DEFAULT 'ACTIVE'
                             CHECK (status IN ('ACTIVE', 'DISABLED', 'LOCKED', 'DELETED')),
    authz_version        BIGINT NOT NULL DEFAULT 1,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_users_username ON iam.users (username);
CREATE INDEX IF NOT EXISTS idx_users_home_org ON iam.users (home_organization_id);

CREATE TABLE IF NOT EXISTS iam.user_branches (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID NOT NULL REFERENCES iam.users(id) ON DELETE CASCADE,
    organization_id UUID NOT NULL REFERENCES iam.organizations(id) ON DELETE RESTRICT,
    branch_id       UUID NOT NULL REFERENCES iam.branches(id) ON DELETE RESTRICT,
    is_primary      BOOLEAN NOT NULL DEFAULT FALSE,
    status          TEXT NOT NULL DEFAULT 'ACTIVE'
                        CHECK (status IN ('ACTIVE', 'DISABLED')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_by      UUID,
    updated_by      UUID,
    CONSTRAINT uk_user_branches UNIQUE (user_id, branch_id)
);

CREATE INDEX IF NOT EXISTS idx_user_branches_user_id ON iam.user_branches (user_id);
CREATE INDEX IF NOT EXISTS idx_user_branches_org_branch ON iam.user_branches (organization_id, branch_id);
CREATE UNIQUE INDEX IF NOT EXISTS uk_user_branches_one_primary
    ON iam.user_branches (user_id)
    WHERE is_primary = TRUE;

CREATE TABLE IF NOT EXISTS iam.service_accounts (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id       TEXT NOT NULL UNIQUE,
    display_name    TEXT,
    status          TEXT NOT NULL DEFAULT 'ACTIVE'
                        CHECK (status IN ('ACTIVE', 'DISABLED', 'LOCKED', 'DELETED')),
    authz_version   BIGINT NOT NULL DEFAULT 1,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS iam.roles (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code                TEXT NOT NULL UNIQUE,
    name                TEXT NOT NULL,
    description         TEXT,
    allowed_scope_type  TEXT NOT NULL
                            CHECK (allowed_scope_type IN (
                                'GLOBAL',
                                'ORGANIZATION',
                                'BRANCH',
                                'ORGANIZATION_AND_BRANCH'
                            )),
    is_system           BOOLEAN NOT NULL DEFAULT FALSE,
    status              TEXT NOT NULL DEFAULT 'ACTIVE'
                            CHECK (status IN ('ACTIVE', 'DISABLED', 'DEPRECATED')),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS iam.role_hierarchy (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    parent_role_id   UUID NOT NULL REFERENCES iam.roles(id) ON DELETE CASCADE,
    child_role_id    UUID NOT NULL REFERENCES iam.roles(id) ON DELETE CASCADE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uk_role_hierarchy UNIQUE (parent_role_id, child_role_id),
    CONSTRAINT chk_role_hierarchy_no_self CHECK (parent_role_id <> child_role_id)
);

CREATE INDEX IF NOT EXISTS idx_role_hierarchy_parent ON iam.role_hierarchy (parent_role_id);
CREATE INDEX IF NOT EXISTS idx_role_hierarchy_child ON iam.role_hierarchy (child_role_id);

CREATE TABLE IF NOT EXISTS iam.permissions (
    id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code                  TEXT NOT NULL UNIQUE,
    name                  TEXT NOT NULL,
    display_name_vi       TEXT NOT NULL,
    display_name_en       TEXT NOT NULL,
    description_vi        TEXT,
    description_en        TEXT,
    module_code           TEXT NOT NULL,
    resource_code         TEXT NOT NULL,
    action_code           TEXT NOT NULL,
    assignment_scope_hint TEXT NOT NULL
                              CHECK (assignment_scope_hint IN (
                                  'GLOBAL',
                                  'ORGANIZATION',
                                  'BRANCH',
                                  'ORGANIZATION_AND_BRANCH'
                              )),
    is_sensitive          BOOLEAN NOT NULL DEFAULT FALSE,
    status                TEXT NOT NULL DEFAULT 'ACTIVE'
                              CHECK (status IN ('ACTIVE', 'DISABLED', 'DEPRECATED')),
    created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at            TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_permissions_module ON iam.permissions (module_code);
CREATE INDEX IF NOT EXISTS idx_permissions_resource_action ON iam.permissions (resource_code, action_code);
CREATE INDEX IF NOT EXISTS idx_permissions_status ON iam.permissions (status);

CREATE TABLE IF NOT EXISTS iam.role_permissions (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    role_id       UUID NOT NULL REFERENCES iam.roles(id) ON DELETE CASCADE,
    permission_id UUID NOT NULL REFERENCES iam.permissions(id) ON DELETE CASCADE,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uk_role_permissions UNIQUE (role_id, permission_id)
);

CREATE INDEX IF NOT EXISTS idx_role_permissions_role_id ON iam.role_permissions (role_id);
CREATE INDEX IF NOT EXISTS idx_role_permissions_permission_id ON iam.role_permissions (permission_id);

CREATE TABLE IF NOT EXISTS iam.user_role_assignments (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID NOT NULL REFERENCES iam.users(id) ON DELETE CASCADE,
    role_id         UUID NOT NULL REFERENCES iam.roles(id) ON DELETE RESTRICT,
    scope_type      TEXT NOT NULL
                        CHECK (scope_type IN ('GLOBAL', 'ORGANIZATION', 'BRANCH')),
    organization_id UUID REFERENCES iam.organizations(id) ON DELETE RESTRICT,
    branch_id       UUID REFERENCES iam.branches(id) ON DELETE RESTRICT,
    status          TEXT NOT NULL DEFAULT 'ACTIVE'
                        CHECK (status IN ('ACTIVE', 'DISABLED')),
    valid_from      TIMESTAMPTZ,
    valid_to        TIMESTAMPTZ,
    source_type     TEXT NOT NULL DEFAULT 'MANUAL',
    source_ref      TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_by      UUID,
    updated_by      UUID,
    CONSTRAINT chk_user_role_assignments_shape
        CHECK (
            (scope_type = 'GLOBAL' AND organization_id IS NULL AND branch_id IS NULL)
            OR
            (scope_type = 'ORGANIZATION' AND organization_id IS NOT NULL AND branch_id IS NULL)
            OR
            (scope_type = 'BRANCH' AND organization_id IS NOT NULL AND branch_id IS NOT NULL)
        ),
    CONSTRAINT uk_user_role_assignments_unique
        UNIQUE NULLS NOT DISTINCT (user_id, role_id, scope_type, organization_id, branch_id)
);

CREATE INDEX IF NOT EXISTS idx_user_role_assignments_user_id ON iam.user_role_assignments (user_id);
CREATE INDEX IF NOT EXISTS idx_user_role_assignments_role_id ON iam.user_role_assignments (role_id);
CREATE INDEX IF NOT EXISTS idx_user_role_assignments_org_branch ON iam.user_role_assignments (organization_id, branch_id);

CREATE TABLE IF NOT EXISTS iam.service_account_role_assignments (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    service_account_id  UUID NOT NULL REFERENCES iam.service_accounts(id) ON DELETE CASCADE,
    role_id             UUID NOT NULL REFERENCES iam.roles(id) ON DELETE RESTRICT,
    scope_type          TEXT NOT NULL
                            CHECK (scope_type IN ('GLOBAL', 'ORGANIZATION', 'BRANCH')),
    organization_id     UUID REFERENCES iam.organizations(id) ON DELETE RESTRICT,
    branch_id           UUID REFERENCES iam.branches(id) ON DELETE RESTRICT,
    status              TEXT NOT NULL DEFAULT 'ACTIVE'
                            CHECK (status IN ('ACTIVE', 'DISABLED')),
    valid_from          TIMESTAMPTZ,
    valid_to            TIMESTAMPTZ,
    source_type         TEXT NOT NULL DEFAULT 'MANUAL',
    source_ref          TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_by          UUID,
    updated_by          UUID,
    CONSTRAINT chk_service_account_role_assignments_shape
        CHECK (
            (scope_type = 'GLOBAL' AND organization_id IS NULL AND branch_id IS NULL)
            OR
            (scope_type = 'ORGANIZATION' AND organization_id IS NOT NULL AND branch_id IS NULL)
            OR
            (scope_type = 'BRANCH' AND organization_id IS NOT NULL AND branch_id IS NOT NULL)
        ),
    CONSTRAINT uk_service_account_role_assignments_unique
        UNIQUE NULLS NOT DISTINCT (service_account_id, role_id, scope_type, organization_id, branch_id)
);

CREATE INDEX IF NOT EXISTS idx_service_account_role_assignments_sa_id ON iam.service_account_role_assignments (service_account_id);
CREATE INDEX IF NOT EXISTS idx_service_account_role_assignments_role_id ON iam.service_account_role_assignments (role_id);
CREATE INDEX IF NOT EXISTS idx_service_account_role_assignments_org_branch ON iam.service_account_role_assignments (organization_id, branch_id);

CREATE TABLE IF NOT EXISTS iam.sensitive_action_policies (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    action_code     TEXT NOT NULL,
    param_key       TEXT NOT NULL,
    param_type      TEXT NOT NULL
                        CHECK (param_type IN ('BOOLEAN', 'INTEGER', 'TEXT', 'JSON')),
    param_value     TEXT NOT NULL,
    description     TEXT,
    status          TEXT NOT NULL DEFAULT 'ACTIVE'
                        CHECK (status IN ('ACTIVE', 'DISABLED')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uk_sensitive_action_policies UNIQUE (action_code, param_key)
);

CREATE INDEX IF NOT EXISTS idx_sensitive_action_policies_action_code ON iam.sensitive_action_policies (action_code);

CREATE TABLE IF NOT EXISTS iam.audit_logs (
    id              BIGSERIAL PRIMARY KEY,
    event_code      TEXT NOT NULL,
    category        TEXT NOT NULL,
    subject_type    TEXT,
    subject_id      TEXT,
    username        TEXT,
    client_id       TEXT,
    organization_id UUID,
    branch_id       UUID,
    target_type     TEXT,
    target_id       TEXT,
    action_code     TEXT,
    result          TEXT NOT NULL,
    reason          TEXT,
    trace_id        TEXT,
    ip_address      TEXT,
    user_agent      TEXT,
    metadata_json   JSONB NOT NULL DEFAULT '{}'::jsonb,
    occurred_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_audit_logs_occurred_at ON iam.audit_logs (occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_subject ON iam.audit_logs (subject_type, subject_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_trace_id ON iam.audit_logs (trace_id);

-- =========================================================
-- SEED CORE DATA
-- =========================================================
INSERT INTO iam.organizations (code, name, status)
VALUES ('ORG_TMS_TMA', 'Logis Organization', 'ACTIVE')
ON CONFLICT (code) DO NOTHING;

INSERT INTO iam.branches (organization_id, code, name, status)
SELECT o.id, x.code, x.name, 'ACTIVE'
FROM iam.organizations o
JOIN (VALUES
    ('HCM', 'Ho Chi Minh Branch'),
    ('HN',  'Ha Noi Branch'),
    ('DN',  'Da Nang Branch')
) AS x(code, name) ON TRUE
WHERE o.code = 'ORG_TMS_TMA'
ON CONFLICT (organization_id, code) DO NOTHING;

INSERT INTO iam.roles (code, name, description, allowed_scope_type, is_system, status)
VALUES
('SUPER_ADMIN', 'Super Admin', 'Full global platform access', 'GLOBAL', TRUE, 'ACTIVE'),
('ORG_ADMIN', 'Organization Admin', 'Administrative role inside an organization', 'ORGANIZATION_AND_BRANCH', TRUE, 'ACTIVE'),
('FINANCE_OPS', 'Finance Ops', 'Finance and audit related role', 'ORGANIZATION_AND_BRANCH', TRUE, 'ACTIVE'),
('SUPERVISOR', 'Supervisor', 'Branch supervisor role', 'BRANCH', TRUE, 'ACTIVE'),
('DISPATCHER', 'Dispatcher', 'Branch dispatcher role', 'BRANCH', TRUE, 'ACTIVE'),
('OPERATION_STAFF', 'Operation Staff', 'Branch operation staff role', 'BRANCH', TRUE, 'ACTIVE'),
('DRIVER', 'Driver', 'Driver role', 'BRANCH', TRUE, 'ACTIVE')
ON CONFLICT (code) DO NOTHING;

-- Hierarchy: parent inherits child
INSERT INTO iam.role_hierarchy (parent_role_id, child_role_id)
SELECT p.id, c.id
FROM iam.roles p
JOIN iam.roles c ON c.code = 'ORG_ADMIN'
WHERE p.code = 'SUPER_ADMIN'
ON CONFLICT DO NOTHING;

INSERT INTO iam.role_hierarchy (parent_role_id, child_role_id)
SELECT p.id, c.id
FROM iam.roles p
JOIN iam.roles c ON c.code = 'FINANCE_OPS'
WHERE p.code = 'ORG_ADMIN'
ON CONFLICT DO NOTHING;

INSERT INTO iam.role_hierarchy (parent_role_id, child_role_id)
SELECT p.id, c.id
FROM iam.roles p
JOIN iam.roles c ON c.code = 'SUPERVISOR'
WHERE p.code = 'ORG_ADMIN'
ON CONFLICT DO NOTHING;

INSERT INTO iam.role_hierarchy (parent_role_id, child_role_id)
SELECT p.id, c.id
FROM iam.roles p
JOIN iam.roles c ON c.code = 'DISPATCHER'
WHERE p.code = 'SUPERVISOR'
ON CONFLICT DO NOTHING;

INSERT INTO iam.role_hierarchy (parent_role_id, child_role_id)
SELECT p.id, c.id
FROM iam.roles p
JOIN iam.roles c ON c.code = 'OPERATION_STAFF'
WHERE p.code = 'SUPERVISOR'
ON CONFLICT DO NOTHING;

INSERT INTO iam.permissions (
    code, name, display_name_vi, display_name_en,
    description_vi, description_en, module_code, resource_code, action_code,
    assignment_scope_hint, is_sensitive, status
)
VALUES
('customer.read', 'Customer View', 'Quyền xem danh mục khách hàng', 'Customer View Permission', 'Cho phép xem danh mục khách hàng', 'Allows viewing customer catalog', 'MASTER_DATA', 'CUSTOMER', 'READ', 'ORGANIZATION_AND_BRANCH', FALSE, 'ACTIVE'),
('customer.create', 'Customer Create', 'Quyền tạo danh mục khách hàng', 'Customer Create Permission', 'Cho phép tạo danh mục khách hàng', 'Allows creating customer records', 'MASTER_DATA', 'CUSTOMER', 'CREATE', 'ORGANIZATION_AND_BRANCH', TRUE, 'ACTIVE'),
('customer.update', 'Customer Update', 'Quyền sửa danh mục khách hàng', 'Customer Update Permission', 'Cho phép sửa danh mục khách hàng', 'Allows updating customer records', 'MASTER_DATA', 'CUSTOMER', 'UPDATE', 'ORGANIZATION_AND_BRANCH', TRUE, 'ACTIVE'),
('customer.disable', 'Customer Disable', 'Quyền khóa/ngưng sử dụng danh mục khách hàng', 'Customer Disable Permission', 'Cho phép khóa hoặc ngưng sử dụng danh mục khách hàng', 'Allows disabling customer records', 'MASTER_DATA', 'CUSTOMER', 'DISABLE', 'ORGANIZATION', TRUE, 'ACTIVE'),

('vehicle.read', 'Vehicle View', 'Quyền xem danh mục phương tiện', 'Vehicle View Permission', 'Cho phép xem danh mục phương tiện', 'Allows viewing vehicle catalog', 'MASTER_DATA', 'VEHICLE', 'READ', 'ORGANIZATION_AND_BRANCH', FALSE, 'ACTIVE'),
('vehicle.create', 'Vehicle Create', 'Quyền tạo danh mục phương tiện', 'Vehicle Create Permission', 'Cho phép tạo danh mục phương tiện', 'Allows creating vehicle records', 'MASTER_DATA', 'VEHICLE', 'CREATE', 'ORGANIZATION', TRUE, 'ACTIVE'),
('vehicle.update', 'Vehicle Update', 'Quyền sửa danh mục phương tiện', 'Vehicle Update Permission', 'Cho phép sửa danh mục phương tiện', 'Allows updating vehicle records', 'MASTER_DATA', 'VEHICLE', 'UPDATE', 'ORGANIZATION', TRUE, 'ACTIVE'),
('vehicle.disable', 'Vehicle Disable', 'Quyền khóa/ngưng sử dụng danh mục phương tiện', 'Vehicle Disable Permission', 'Cho phép khóa hoặc ngưng sử dụng danh mục phương tiện', 'Allows disabling vehicle records', 'MASTER_DATA', 'VEHICLE', 'DISABLE', 'ORGANIZATION', TRUE, 'ACTIVE'),

('driver.read', 'Driver View', 'Quyền xem danh mục tài xế', 'Driver View Permission', 'Cho phép xem danh mục tài xế', 'Allows viewing driver catalog', 'MASTER_DATA', 'DRIVER', 'READ', 'ORGANIZATION_AND_BRANCH', FALSE, 'ACTIVE'),
('driver.create', 'Driver Create', 'Quyền tạo danh mục tài xế', 'Driver Create Permission', 'Cho phép tạo danh mục tài xế', 'Allows creating driver records', 'MASTER_DATA', 'DRIVER', 'CREATE', 'ORGANIZATION', TRUE, 'ACTIVE'),
('driver.update', 'Driver Update', 'Quyền sửa danh mục tài xế', 'Driver Update Permission', 'Cho phép sửa danh mục tài xế', 'Allows updating driver records', 'MASTER_DATA', 'DRIVER', 'UPDATE', 'ORGANIZATION', TRUE, 'ACTIVE'),
('driver.disable', 'Driver Disable', 'Quyền khóa/ngưng sử dụng danh mục tài xế', 'Driver Disable Permission', 'Cho phép khóa hoặc ngưng sử dụng danh mục tài xế', 'Allows disabling driver records', 'MASTER_DATA', 'DRIVER', 'DISABLE', 'ORGANIZATION', TRUE, 'ACTIVE'),

('route.read', 'Route View', 'Quyền xem danh mục tuyến đường', 'Route View Permission', 'Cho phép xem danh mục tuyến đường', 'Allows viewing route catalog', 'MASTER_DATA', 'ROUTE', 'READ', 'ORGANIZATION_AND_BRANCH', FALSE, 'ACTIVE'),
('route.create', 'Route Create', 'Quyền tạo danh mục tuyến đường', 'Route Create Permission', 'Cho phép tạo danh mục tuyến đường', 'Allows creating route records', 'MASTER_DATA', 'ROUTE', 'CREATE', 'ORGANIZATION', TRUE, 'ACTIVE'),
('route.update', 'Route Update', 'Quyền sửa danh mục tuyến đường', 'Route Update Permission', 'Cho phép sửa danh mục tuyến đường', 'Allows updating route records', 'MASTER_DATA', 'ROUTE', 'UPDATE', 'ORGANIZATION', TRUE, 'ACTIVE'),
('route.disable', 'Route Disable', 'Quyền khóa/ngưng sử dụng danh mục tuyến đường', 'Route Disable Permission', 'Cho phép khóa hoặc ngưng sử dụng danh mục tuyến đường', 'Allows disabling route records', 'MASTER_DATA', 'ROUTE', 'DISABLE', 'ORGANIZATION', TRUE, 'ACTIVE'),

('workflow.read', 'Workflow View', 'Quyền xem cấu hình workflow', 'Workflow Configuration View Permission', 'Cho phép xem cấu hình workflow', 'Allows viewing workflow configuration', 'CONFIG', 'WORKFLOW', 'READ', 'ORGANIZATION', FALSE, 'ACTIVE'),
('workflow.update', 'Workflow Update', 'Quyền sửa cấu hình workflow', 'Workflow Configuration Update Permission', 'Cho phép sửa cấu hình workflow', 'Allows updating workflow configuration', 'CONFIG', 'WORKFLOW', 'UPDATE', 'ORGANIZATION', TRUE, 'ACTIVE'),
('integration.read', 'Integration View', 'Quyền xem cấu hình tích hợp', 'Integration Configuration View Permission', 'Cho phép xem cấu hình tích hợp', 'Allows viewing integration configuration', 'CONFIG', 'INTEGRATION', 'READ', 'ORGANIZATION', FALSE, 'ACTIVE'),
('integration.update', 'Integration Update', 'Quyền sửa cấu hình tích hợp', 'Integration Configuration Update Permission', 'Cho phép sửa cấu hình tích hợp', 'Allows updating integration configuration', 'CONFIG', 'INTEGRATION', 'UPDATE', 'ORGANIZATION', TRUE, 'ACTIVE'),

('iam.user.read', 'User View', 'Quyền xem người dùng', 'User View Permission', 'Cho phép xem người dùng', 'Allows viewing users', 'IAM', 'USER', 'READ', 'ORGANIZATION', FALSE, 'ACTIVE'),
('iam.user.update', 'User Update', 'Quyền sửa người dùng', 'User Update Permission', 'Cho phép sửa người dùng', 'Allows updating users', 'IAM', 'USER', 'UPDATE', 'ORGANIZATION', TRUE, 'ACTIVE'),
('iam.role.assign', 'Role Assign', 'Quyền gán role', 'Role Assign Permission', 'Cho phép gán role cho user hoặc service account', 'Allows assigning roles', 'IAM', 'ROLE', 'ASSIGN', 'ORGANIZATION', TRUE, 'ACTIVE'),

('audit.read', 'Audit View', 'Quyền xem audit log', 'Audit View Permission', 'Cho phép xem audit log', 'Allows viewing audit log', 'AUDIT', 'AUDIT_LOG', 'READ', 'ORGANIZATION', TRUE, 'ACTIVE'),
('audit.export', 'Audit Export', 'Quyền export audit log', 'Audit Export Permission', 'Cho phép export audit log', 'Allows exporting audit log', 'AUDIT', 'AUDIT_LOG', 'EXPORT', 'ORGANIZATION', TRUE, 'ACTIVE')
ON CONFLICT (code) DO NOTHING;

-- Direct role permissions. Inherited permissions come from role_hierarchy.
INSERT INTO iam.role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM iam.roles r
JOIN iam.permissions p ON p.code IN (
    'customer.read','vehicle.read','driver.read','route.read'
)
WHERE r.code = 'OPERATION_STAFF'
ON CONFLICT DO NOTHING;

INSERT INTO iam.role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM iam.roles r
JOIN iam.permissions p ON p.code IN (
    'customer.read','vehicle.read','driver.read','route.read'
)
WHERE r.code = 'DISPATCHER'
ON CONFLICT DO NOTHING;

INSERT INTO iam.role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM iam.roles r
JOIN iam.permissions p ON p.code IN (
    'customer.create','customer.update',
    'vehicle.create','vehicle.update',
    'driver.create','driver.update',
    'route.create','route.update'
)
WHERE r.code = 'SUPERVISOR'
ON CONFLICT DO NOTHING;

INSERT INTO iam.role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM iam.roles r
JOIN iam.permissions p ON p.code IN (
    'audit.read','audit.export'
)
WHERE r.code = 'FINANCE_OPS'
ON CONFLICT DO NOTHING;

INSERT INTO iam.role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM iam.roles r
JOIN iam.permissions p ON p.code IN (
    'customer.disable','vehicle.disable','driver.disable','route.disable',
    'workflow.read','workflow.update','integration.read','integration.update',
    'iam.user.read','iam.user.update','iam.role.assign'
)
WHERE r.code = 'ORG_ADMIN'
ON CONFLICT DO NOTHING;

INSERT INTO iam.role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM iam.roles r
JOIN iam.permissions p ON p.code IN (
    'audit.read','audit.export'
)
WHERE r.code = 'SUPER_ADMIN'
ON CONFLICT DO NOTHING;

INSERT INTO iam.users (external_subject, username, email, display_name, status)
VALUES
('kc-sub-superadmin', 'superadmin', 'superadmin@example.com', 'Super Admin', 'ACTIVE'),
('kc-sub-orgadmin', 'orgadmin', 'orgadmin@example.com', 'Organization Admin', 'ACTIVE'),
('kc-sub-finops', 'financeops', 'financeops@example.com', 'Finance Ops', 'ACTIVE'),
('kc-sub-supervisor', 'supervisor1', 'supervisor1@example.com', 'Supervisor 1', 'ACTIVE'),
('kc-sub-dispatcher', 'dispatcher1', 'dispatcher1@example.com', 'Dispatcher 1', 'ACTIVE'),
('kc-sub-opsstaff', 'opsstaff1', 'opsstaff1@example.com', 'Operation Staff 1', 'ACTIVE'),
('kc-sub-driver', 'driver1', 'driver1@example.com', 'Driver 1', 'ACTIVE')
ON CONFLICT (external_subject) DO NOTHING;

INSERT INTO iam.service_accounts (client_id, display_name, status)
VALUES
('tms-api-client', 'TMS API Client', 'ACTIVE'),
('tms-integration-client', 'TMS Integration Client', 'ACTIVE')
ON CONFLICT (client_id) DO NOTHING;

INSERT INTO iam.user_branches (user_id, organization_id, branch_id, is_primary)
SELECT u.id, o.id, b.id, TRUE
FROM iam.users u
JOIN iam.organizations o ON o.code = 'ORG_TMS_TMA'
JOIN iam.branches b ON b.organization_id = o.id AND b.code = 'HCM'
WHERE u.external_subject IN ('kc-sub-orgadmin','kc-sub-finops','kc-sub-supervisor','kc-sub-dispatcher','kc-sub-opsstaff','kc-sub-driver')
ON CONFLICT (user_id, branch_id) DO NOTHING;

INSERT INTO iam.user_branches (user_id, organization_id, branch_id, is_primary)
SELECT u.id, o.id, b.id, FALSE
FROM iam.users u
JOIN iam.organizations o ON o.code = 'ORG_TMS_TMA'
JOIN iam.branches b ON b.organization_id = o.id AND b.code = 'HN'
WHERE u.external_subject IN ('kc-sub-finops','kc-sub-dispatcher')
ON CONFLICT (user_id, branch_id) DO NOTHING;

INSERT INTO iam.user_role_assignments (user_id, role_id, scope_type, organization_id, branch_id, source_type)
SELECT u.id, r.id, 'GLOBAL', NULL, NULL, 'SEED'
FROM iam.users u
JOIN iam.roles r ON r.code = 'SUPER_ADMIN'
WHERE u.external_subject = 'kc-sub-superadmin'
ON CONFLICT (user_id, role_id, scope_type, organization_id, branch_id) DO NOTHING;

INSERT INTO iam.user_role_assignments (user_id, role_id, scope_type, organization_id, branch_id, source_type)
SELECT u.id, r.id, 'ORGANIZATION', o.id, NULL, 'SEED'
FROM iam.users u
JOIN iam.roles r ON r.code IN ('ORG_ADMIN','FINANCE_OPS')
JOIN iam.organizations o ON o.code = 'ORG_TMS_TMA'
WHERE (u.external_subject = 'kc-sub-orgadmin' AND r.code = 'ORG_ADMIN')
   OR (u.external_subject = 'kc-sub-finops' AND r.code = 'FINANCE_OPS')
ON CONFLICT (user_id, role_id, scope_type, organization_id, branch_id) DO NOTHING;

INSERT INTO iam.user_role_assignments (user_id, role_id, scope_type, organization_id, branch_id, source_type)
SELECT u.id, r.id, 'BRANCH', o.id, b.id, 'SEED'
FROM iam.users u
JOIN iam.roles r ON r.code IN ('SUPERVISOR','DISPATCHER','OPERATION_STAFF','DRIVER')
JOIN iam.organizations o ON o.code = 'ORG_TMS_TMA'
JOIN iam.branches b ON b.organization_id = o.id AND b.code = 'HCM'
WHERE (u.external_subject = 'kc-sub-supervisor' AND r.code = 'SUPERVISOR')
   OR (u.external_subject = 'kc-sub-dispatcher' AND r.code = 'DISPATCHER')
   OR (u.external_subject = 'kc-sub-opsstaff' AND r.code = 'OPERATION_STAFF')
   OR (u.external_subject = 'kc-sub-driver' AND r.code = 'DRIVER')
ON CONFLICT (user_id, role_id, scope_type, organization_id, branch_id) DO NOTHING;

INSERT INTO iam.service_account_role_assignments (service_account_id, role_id, scope_type, organization_id, branch_id, source_type)
SELECT sa.id, r.id, 'GLOBAL', NULL, NULL, 'SEED'
FROM iam.service_accounts sa
JOIN iam.roles r ON r.code = 'SUPER_ADMIN'
WHERE sa.client_id = 'tms-api-client'
ON CONFLICT (service_account_id, role_id, scope_type, organization_id, branch_id) DO NOTHING;

INSERT INTO iam.service_account_role_assignments (service_account_id, role_id, scope_type, organization_id, branch_id, source_type)
SELECT sa.id, r.id, 'ORGANIZATION', o.id, NULL, 'SEED'
FROM iam.service_accounts sa
JOIN iam.roles r ON r.code = 'FINANCE_OPS'
JOIN iam.organizations o ON o.code = 'ORG_TMS_TMA'
WHERE sa.client_id = 'tms-integration-client'
ON CONFLICT (service_account_id, role_id, scope_type, organization_id, branch_id) DO NOTHING;

INSERT INTO iam.sensitive_action_policies (action_code, param_key, param_type, param_value, description)
VALUES
('shipment.reopen', 'require_reason', 'BOOLEAN', 'true', 'Require reason when reopening shipment'),
('shipment.reopen', 'require_audit', 'BOOLEAN', 'true', 'Audit shipment reopen'),
('shipment.reopen', 'allowed_time_window_minutes', 'INTEGER', '1440', 'Allow reopen within 24 hours'),
('audit.export', 'require_reason', 'BOOLEAN', 'true', 'Require reason when exporting audit'),
('audit.export', 'require_audit', 'BOOLEAN', 'true', 'Audit export'),
('audit.export', 'require_mfa', 'BOOLEAN', 'true', 'Require MFA for export')
ON CONFLICT (action_code, param_key) DO NOTHING;

INSERT INTO iam.users (external_subject,username,email,display_name,home_organization_id,status,authz_version,created_at,updated_at)
VALUES
    ('backend','backend','test@gmail.com','Super Admin',cast(NULL as uuid),'ACTIVE',1,'2026-04-02 06:05:43.618272 +0000'::timestamptz,'2026-04-02 06:05:43.618272 +0000'::timestamptz);


COMMIT;
