
BEGIN;

CREATE SCHEMA IF NOT EXISTS master_data;

CREATE TABLE IF NOT EXISTS master_data.business_partners (
                                                             id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id uuid NOT NULL,
    partner_type varchar(40) NOT NULL,
    partner_code varchar(40) NOT NULL,
    partner_name varchar(255) NOT NULL,
    tax_code varchar(50),
    phone varchar(50),
    email varchar(255),
    address text,
    payment_term_days int,
    credit_limit_amount numeric(18,2),
    status_code varchar(30) NOT NULL DEFAULT 'ACTIVE',
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (organization_id, partner_code)
    );

COMMENT ON TABLE master_data.business_partners IS 'Customers, outsourced carriers, fuel suppliers, garages, insurers, and other business counterparties.';
CREATE INDEX IF NOT EXISTS ix_business_partners_org_type ON master_data.business_partners (organization_id, partner_type);

CREATE TABLE IF NOT EXISTS master_data.business_partner_contacts (
                                                                     id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    business_partner_id uuid NOT NULL,
    full_name varchar(255) NOT NULL,
    phone varchar(50),
    email varchar(255),
    job_title varchar(255),
    is_default boolean NOT NULL DEFAULT false,
    created_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT fk_partner_contacts_partner FOREIGN KEY (business_partner_id) REFERENCES master_data.business_partners(id)
    );

COMMENT ON TABLE master_data.business_partner_contacts IS 'Contact people per business partner.';

CREATE TABLE IF NOT EXISTS master_data.locations (
                                                     id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id uuid NOT NULL,
    location_type varchar(40) NOT NULL,
    location_code varchar(40) NOT NULL,
    location_name varchar(255) NOT NULL,
    address text,
    latitude numeric(10,7),
    longitude numeric(10,7),
    status_code varchar(30) NOT NULL DEFAULT 'ACTIVE',
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (organization_id, location_code)
    );

COMMENT ON TABLE master_data.locations IS 'Pickup, delivery, port, CY, depot, warehouse, or other operational point.';
CREATE INDEX IF NOT EXISTS ix_locations_org_type ON master_data.locations (organization_id, location_type);

CREATE TABLE IF NOT EXISTS master_data.vehicles (
                                                    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id uuid NOT NULL,
    vehicle_code varchar(40),
    vehicle_type varchar(30) NOT NULL,
    plate_no varchar(30) NOT NULL,
    chassis_no varchar(60),
    engine_no varchar(60),
    branch_id uuid,
    fleet_team_id uuid,
    payload_kg numeric(18,2),
    volume_m3 numeric(18,2),
    container_capability varchar(60),
    status_code varchar(30) NOT NULL DEFAULT 'ACTIVE',
    operational_state varchar(30) NOT NULL DEFAULT 'AVAILABLE',
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (organization_id, plate_no)
    );

COMMENT ON TABLE master_data.vehicles IS 'Vehicle master. Phase 1 keeps only the fields required for dispatch and reporting.';
CREATE INDEX IF NOT EXISTS ix_vehicles_org_state ON master_data.vehicles (organization_id, operational_state);

CREATE TABLE IF NOT EXISTS master_data.drivers (
                                                   id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id uuid NOT NULL,
    driver_code varchar(40),
    driver_type varchar(20) NOT NULL DEFAULT 'DRIVER',
    full_name varchar(255) NOT NULL,
    phone varchar(50),
    license_no varchar(60),
    license_expiry_date date,
    branch_id uuid,
    fleet_team_id uuid,
    employment_status varchar(30) NOT NULL DEFAULT 'ACTIVE',
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (organization_id, driver_code)
    );

COMMENT ON TABLE master_data.drivers IS 'Driver and co-driver master data.';
CREATE INDEX IF NOT EXISTS ix_drivers_org_status ON master_data.drivers (organization_id, employment_status);

CREATE TABLE IF NOT EXISTS master_data.routes (
                                                  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id uuid NOT NULL,
    route_code varchar(40) NOT NULL,
    route_name varchar(255) NOT NULL,
    origin_location_id uuid,
    destination_location_id uuid,
    standard_km numeric(12,2),
    standard_duration_minutes int,
    status_code varchar(30) NOT NULL DEFAULT 'ACTIVE',
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (organization_id, route_code)
    );

COMMENT ON TABLE master_data.routes IS 'Standard route setup used in planning, pricing, and later fuel norms.';
CREATE INDEX IF NOT EXISTS ix_routes_org ON master_data.routes (organization_id);

CREATE TABLE IF NOT EXISTS master_data.tariffs (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id uuid NOT NULL,
    customer_id uuid,
    route_id uuid,
    vehicle_type varchar(30),
    container_type varchar(30),
    currency_code varchar(10) NOT NULL DEFAULT 'VND',
    base_price numeric(18,2) NOT NULL,
    effective_from date NOT NULL,
    effective_to date,
    status_code varchar(30) NOT NULL DEFAULT 'ACTIVE',
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
    );

COMMENT ON TABLE master_data.tariffs IS 'Pricing rule table. Phase 1 keeps structure simple and defers complex pricing engines.';
CREATE INDEX IF NOT EXISTS ix_tariffs_org_effective ON master_data.tariffs (organization_id, effective_from, effective_to);

CREATE TABLE IF NOT EXISTS master_data.surcharges (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id uuid NOT NULL,
    surcharge_code varchar(40) NOT NULL,
    surcharge_name varchar(255) NOT NULL,
    charge_method varchar(30) NOT NULL,
    default_amount numeric(18,2),
    currency_code varchar(10) NOT NULL DEFAULT 'VND',
    status_code varchar(30) NOT NULL DEFAULT 'ACTIVE',
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (organization_id, surcharge_code)
    );

COMMENT ON TABLE master_data.surcharges IS 'Charge and fee catalogue for quoting and later finance lines.';
CREATE INDEX IF NOT EXISTS ix_surcharges_org ON master_data.surcharges (organization_id);

CREATE TABLE IF NOT EXISTS master_data.reference_data_items (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    group_code      VARCHAR(50) NOT NULL,
    item_code       VARCHAR(50) NOT NULL,
    name_vi         VARCHAR(255) NOT NULL,
    name_en         VARCHAR(255) NOT NULL,
    description     TEXT,
    sort_order      INT NOT NULL DEFAULT 0,
    is_system       BOOLEAN NOT NULL DEFAULT TRUE,
    status_code     VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uk_reference_data_items UNIQUE (group_code, item_code),
    CONSTRAINT chk_reference_data_items_status
    CHECK (status_code IN ('ACTIVE', 'INACTIVE'))
    );

CREATE INDEX IF NOT EXISTS ix_reference_data_items_group_status_sort
    ON master_data.reference_data_items (group_code, status_code, sort_order, item_code);

INSERT INTO master_data.reference_data_items (
    group_code,
    item_code,
    name_vi,
    name_en,
    description,
    sort_order,
    is_system,
    status_code
)
VALUES
-- BUSINESS_PARTNER_TYPE
('BUSINESS_PARTNER_TYPE', 'CUSTOMER', 'Khách hàng', 'Customer', 'Đối tác mua dịch vụ', 10, TRUE, 'ACTIVE'),
('BUSINESS_PARTNER_TYPE', 'OUTSOURCED_CARRIER', 'Nhà xe thuê ngoài', 'Outsourced Carrier', 'Đơn vị vận tải thuê ngoài', 20, TRUE, 'ACTIVE'),
('BUSINESS_PARTNER_TYPE', 'FUEL_SUPPLIER', 'Nhà cung cấp nhiên liệu', 'Fuel Supplier', 'Đơn vị cung cấp nhiên liệu', 30, TRUE, 'ACTIVE'),
('BUSINESS_PARTNER_TYPE', 'GARAGE', 'Garage / Xưởng sửa chữa', 'Garage / Workshop', 'Đơn vị sửa chữa bảo trì', 40, TRUE, 'ACTIVE'),
('BUSINESS_PARTNER_TYPE', 'INSURANCE_PROVIDER', 'Đơn vị bảo hiểm', 'Insurance Provider', 'Công ty bảo hiểm', 50, TRUE, 'ACTIVE'),
('BUSINESS_PARTNER_TYPE', 'PORT', 'Cảng', 'Port', 'Đơn vị cảng', 60, TRUE, 'ACTIVE'),
('BUSINESS_PARTNER_TYPE', 'WAREHOUSE', 'Kho', 'Warehouse', 'Kho vận', 70, TRUE, 'ACTIVE'),
('BUSINESS_PARTNER_TYPE', 'CY', 'Bãi CY', 'Container Yard', 'Container Yard', 80, TRUE, 'ACTIVE'),
('BUSINESS_PARTNER_TYPE', 'DEPOT', 'Depot', 'Depot', 'Bãi chứa container', 90, TRUE, 'ACTIVE'),
('BUSINESS_PARTNER_TYPE', 'OTHER', 'Khác', 'Other', 'Loại khác', 999, TRUE, 'ACTIVE'),

-- LOCATION_TYPE
('LOCATION_TYPE', 'PICKUP', 'Điểm lấy hàng', 'Pickup Point', 'Điểm lấy hàng', 10, TRUE, 'ACTIVE'),
('LOCATION_TYPE', 'DELIVERY', 'Điểm giao hàng', 'Delivery Point', 'Điểm giao hàng', 20, TRUE, 'ACTIVE'),
('LOCATION_TYPE', 'PORT', 'Cảng', 'Port', 'Cảng', 30, TRUE, 'ACTIVE'),
('LOCATION_TYPE', 'CY', 'Bãi CY', 'Container Yard', 'Bãi container', 40, TRUE, 'ACTIVE'),
('LOCATION_TYPE', 'DEPOT', 'Depot', 'Depot', 'Bãi/depot', 50, TRUE, 'ACTIVE'),
('LOCATION_TYPE', 'WAREHOUSE', 'Kho', 'Warehouse', 'Kho', 60, TRUE, 'ACTIVE'),
('LOCATION_TYPE', 'OTHER', 'Khác', 'Other', 'Loại khác', 999, TRUE, 'ACTIVE'),

-- VEHICLE_TYPE
('VEHICLE_TYPE', 'TRACTOR', 'Đầu kéo', 'Tractor Head', 'Đầu kéo', 10, TRUE, 'ACTIVE'),
('VEHICLE_TYPE', 'TRAILER', 'Rơ-moóc', 'Trailer', 'Rơ-moóc', 20, TRUE, 'ACTIVE'),
('VEHICLE_TYPE', 'TRUCK', 'Xe tải', 'Truck', 'Xe tải', 30, TRUE, 'ACTIVE'),
('VEHICLE_TYPE', 'SUPPORT_VEHICLE', 'Xe phụ trợ', 'Support Vehicle', 'Xe phụ trợ', 40, TRUE, 'ACTIVE'),

-- DRIVER_TYPE
('DRIVER_TYPE', 'DRIVER', 'Tài xế', 'Driver', 'Tài xế chính', 10, TRUE, 'ACTIVE'),
('DRIVER_TYPE', 'CO_DRIVER', 'Phụ xế', 'Co-driver', 'Phụ xế', 20, TRUE, 'ACTIVE'),

-- CONTAINER_TYPE
('CONTAINER_TYPE', '20DC', 'Container 20DC', '20DC Container', 'Loại 20DC', 10, TRUE, 'ACTIVE'),
('CONTAINER_TYPE', '40DC', 'Container 40DC', '40DC Container', 'Loại 40DC', 20, TRUE, 'ACTIVE'),
('CONTAINER_TYPE', '40HC', 'Container 40HC', '40HC Container', 'Loại 40HC', 30, TRUE, 'ACTIVE'),

-- SURCHARGE_CHARGE_METHOD
('SURCHARGE_CHARGE_METHOD', 'FIXED', 'Cố định', 'Fixed', 'Tính cố định', 10, TRUE, 'ACTIVE'),
('SURCHARGE_CHARGE_METHOD', 'PER_TRIP', 'Theo chuyến', 'Per Trip', 'Tính theo chuyến', 20, TRUE, 'ACTIVE'),
('SURCHARGE_CHARGE_METHOD', 'PER_CONTAINER', 'Theo container', 'Per Container', 'Tính theo container', 30, TRUE, 'ACTIVE'),
('SURCHARGE_CHARGE_METHOD', 'PER_VEHICLE', 'Theo xe', 'Per Vehicle', 'Tính theo xe', 40, TRUE, 'ACTIVE'),

-- VEHICLE_OPERATIONAL_STATE
('VEHICLE_OPERATIONAL_STATE', 'AVAILABLE', 'Sẵn sàng', 'Available', null, 10, true, 'ACTIVE'),
('VEHICLE_OPERATIONAL_STATE', 'IN_OPERATION', 'Đang vận hành', 'In Operation', null, 20, true, 'ACTIVE'),
('VEHICLE_OPERATIONAL_STATE', 'MAINTENANCE', 'Bảo trì', 'Maintenance', null, 30, true, 'ACTIVE'),
('VEHICLE_OPERATIONAL_STATE', 'BREAKDOWN', 'Hỏng', 'Breakdown', null, 40, true, 'ACTIVE'),
('VEHICLE_OPERATIONAL_STATE', 'INACTIVE', 'Ngưng khai thác', 'Inactive', null, 50, true, 'ACTIVE')
    ON CONFLICT (group_code, item_code) DO NOTHING;

-- Minimal seed data for local dev
INSERT INTO master_data.business_partners (
    organization_id, partner_type, partner_code, partner_name, tax_code, phone, email, address, payment_term_days, credit_limit_amount, status_code
)
SELECT o.id, 'CUSTOMER', 'CUST001', 'ACME Logistics', '0312345678', '0901000001', 'acme@example.com', 'HCMC', 30, 100000000, 'ACTIVE'
FROM iam.organizations o
WHERE o.code = 'ORG_TMS_TMA'
    ON CONFLICT (organization_id, partner_code) DO NOTHING;

INSERT INTO master_data.locations (
    organization_id, location_type, location_code, location_name, address, status_code
)
SELECT o.id, 'WAREHOUSE', 'LOC001', 'Main Warehouse', 'Thu Duc, HCMC', 'ACTIVE'
FROM iam.organizations o
WHERE o.code = 'ORG_TMS_TMA'
    ON CONFLICT (organization_id, location_code) DO NOTHING;

INSERT INTO master_data.vehicles (
    organization_id, vehicle_code, vehicle_type, plate_no, status_code, operational_state
)
SELECT o.id, 'VH001', 'TRACTOR', '51D-12345', 'ACTIVE', 'AVAILABLE'
FROM iam.organizations o
WHERE o.code = 'ORG_TMS_TMA'
    ON CONFLICT (organization_id, plate_no) DO NOTHING;

INSERT INTO master_data.drivers (
    organization_id, driver_code, driver_type, full_name, phone, employment_status
)
SELECT o.id, 'DRV001', 'DRIVER', 'Nguyen Van A', '0901000002', 'ACTIVE'
FROM iam.organizations o
WHERE o.code = 'ORG_TMS_TMA'
    ON CONFLICT (organization_id, driver_code) DO NOTHING;

INSERT INTO master_data.routes (
    organization_id, route_code, route_name, status_code
)
SELECT o.id, 'R001', 'HCM-HN', 'ACTIVE'
FROM iam.organizations o
WHERE o.code = 'ORG_TMS_TMA'
    ON CONFLICT (organization_id, route_code) DO NOTHING;

INSERT INTO master_data.surcharges (
    organization_id, surcharge_code, surcharge_name, charge_method, default_amount, currency_code, status_code
)
SELECT o.id, 'SUR001', 'Waiting Fee', 'FIXED', 500000, 'VND', 'ACTIVE'
FROM iam.organizations o
WHERE o.code = 'ORG_TMS_TMA'
    ON CONFLICT (organization_id, surcharge_code) DO NOTHING;

-- =========================================================
-- FULL MASTER DATA SEED
-- Assumption:
-- - iam.organizations already contains code = 'ORG_TMS_TMA'
-- - master_data.reference_data_items already seeded
-- =========================================================

-- ---------------------------------------------------------
-- BUSINESS PARTNERS
-- ---------------------------------------------------------
INSERT INTO master_data.business_partners (
    organization_id,
    partner_type,
    partner_code,
    partner_name,
    tax_code,
    phone,
    email,
    address,
    payment_term_days,
    credit_limit_amount,
    status_code
)
SELECT o.id, 'CUSTOMER', 'CUST001', 'ACME Logistics', '0312345678', '0901000001', 'acme@example.com', 'HCMC', 30, 100000000, 'ACTIVE'
FROM iam.organizations o
WHERE o.code = 'ORG_TMS_TMA'
    ON CONFLICT (organization_id, partner_code) DO NOTHING;

INSERT INTO master_data.business_partners (
    organization_id,
    partner_type,
    partner_code,
    partner_name,
    tax_code,
    phone,
    email,
    address,
    payment_term_days,
    credit_limit_amount,
    status_code
)
SELECT o.id, 'OUTSOURCED_CARRIER', 'CARRIER001', 'Thanh Cong Transport', '0309988776', '0901000003', 'carrier@example.com', 'Binh Duong', 15, 50000000, 'ACTIVE'
FROM iam.organizations o
WHERE o.code = 'ORG_TMS_TMA'
    ON CONFLICT (organization_id, partner_code) DO NOTHING;

INSERT INTO master_data.business_partners (
    organization_id,
    partner_type,
    partner_code,
    partner_name,
    tax_code,
    phone,
    email,
    address,
    payment_term_days,
    credit_limit_amount,
    status_code
)
SELECT o.id, 'FUEL_SUPPLIER', 'FUEL001', 'Petro South', '0311122233', '0901000004', 'fuel@example.com', 'Nha Be, HCMC', 7, 20000000, 'ACTIVE'
FROM iam.organizations o
WHERE o.code = 'ORG_TMS_TMA'
    ON CONFLICT (organization_id, partner_code) DO NOTHING;

INSERT INTO master_data.business_partners (
    organization_id,
    partner_type,
    partner_code,
    partner_name,
    tax_code,
    phone,
    email,
    address,
    payment_term_days,
    credit_limit_amount,
    status_code
)
SELECT o.id, 'GARAGE', 'GARAGE001', 'Sai Gon Garage', '0315566778', '0901000005', 'garage@example.com', 'District 12, HCMC', 10, 15000000, 'ACTIVE'
FROM iam.organizations o
WHERE o.code = 'ORG_TMS_TMA'
    ON CONFLICT (organization_id, partner_code) DO NOTHING;

INSERT INTO master_data.business_partners (
    organization_id,
    partner_type,
    partner_code,
    partner_name,
    tax_code,
    phone,
    email,
    address,
    payment_term_days,
    credit_limit_amount,
    status_code
)
SELECT o.id, 'INSURANCE_PROVIDER', 'INS001', 'Bao Viet Logistics Insurance', '0312233445', '0901000006', 'insurance@example.com', 'District 1, HCMC', 30, 30000000, 'ACTIVE'
FROM iam.organizations o
WHERE o.code = 'ORG_TMS_TMA'
    ON CONFLICT (organization_id, partner_code) DO NOTHING;

-- ---------------------------------------------------------
-- BUSINESS PARTNER CONTACTS
-- ---------------------------------------------------------
INSERT INTO master_data.business_partner_contacts (
    business_partner_id,
    full_name,
    phone,
    email,
    job_title,
    is_default
)
SELECT bp.id, 'Tran Thi Mai', '0902000001', 'mai@acme.com', 'Logistics Coordinator', TRUE
FROM master_data.business_partners bp
         JOIN iam.organizations o ON o.id = bp.organization_id
WHERE o.code = 'ORG_TMS_TMA'
  AND bp.partner_code = 'CUST001'
  AND NOT EXISTS (
    SELECT 1
    FROM master_data.business_partner_contacts c
    WHERE c.business_partner_id = bp.id
      AND c.email = 'mai@acme.com'
);

INSERT INTO master_data.business_partner_contacts (
    business_partner_id,
    full_name,
    phone,
    email,
    job_title,
    is_default
)
SELECT bp.id, 'Nguyen Van Binh', '0902000002', 'dispatch@carrier.com', 'Dispatch Manager', TRUE
FROM master_data.business_partners bp
         JOIN iam.organizations o ON o.id = bp.organization_id
WHERE o.code = 'ORG_TMS_TMA'
  AND bp.partner_code = 'CARRIER001'
  AND NOT EXISTS (
    SELECT 1
    FROM master_data.business_partner_contacts c
    WHERE c.business_partner_id = bp.id
      AND c.email = 'dispatch@carrier.com'
);

INSERT INTO master_data.business_partner_contacts (
    business_partner_id,
    full_name,
    phone,
    email,
    job_title,
    is_default
)
SELECT bp.id, 'Le Hoang Nam', '0902000003', 'service@garage.com', 'Service Advisor', TRUE
FROM master_data.business_partners bp
         JOIN iam.organizations o ON o.id = bp.organization_id
WHERE o.code = 'ORG_TMS_TMA'
  AND bp.partner_code = 'GARAGE001'
  AND NOT EXISTS (
    SELECT 1
    FROM master_data.business_partner_contacts c
    WHERE c.business_partner_id = bp.id
      AND c.email = 'service@garage.com'
);

-- ---------------------------------------------------------
-- LOCATIONS
-- ---------------------------------------------------------
INSERT INTO master_data.locations (
    organization_id,
    location_type,
    location_code,
    location_name,
    address,
    latitude,
    longitude,
    status_code
)
SELECT o.id, 'WAREHOUSE', 'LOC001', 'Main Warehouse', 'Thu Duc, HCMC', 10.8490000, 106.7710000, 'ACTIVE'
FROM iam.organizations o
WHERE o.code = 'ORG_TMS_TMA'
    ON CONFLICT (organization_id, location_code) DO NOTHING;

INSERT INTO master_data.locations (
    organization_id,
    location_type,
    location_code,
    location_name,
    address,
    latitude,
    longitude,
    status_code
)
SELECT o.id, 'PORT', 'PORT001', 'Cat Lai Port', 'Thu Duc, HCMC', 10.7695000, 106.8081000, 'ACTIVE'
FROM iam.organizations o
WHERE o.code = 'ORG_TMS_TMA'
    ON CONFLICT (organization_id, location_code) DO NOTHING;

INSERT INTO master_data.locations (
    organization_id,
    location_type,
    location_code,
    location_name,
    address,
    latitude,
    longitude,
    status_code
)
SELECT o.id, 'DELIVERY', 'DEL001', 'Ha Noi Delivery Hub', 'Long Bien, Ha Noi', 21.0463000, 105.9155000, 'ACTIVE'
FROM iam.organizations o
WHERE o.code = 'ORG_TMS_TMA'
    ON CONFLICT (organization_id, location_code) DO NOTHING;

-- ---------------------------------------------------------
-- VEHICLES
-- ---------------------------------------------------------
INSERT INTO master_data.vehicles (
    organization_id,
    vehicle_code,
    vehicle_type,
    plate_no,
    chassis_no,
    engine_no,
    payload_kg,
    volume_m3,
    container_capability,
    status_code,
    operational_state
)
SELECT o.id, 'VH001', 'TRACTOR', '51D-12345', 'CHS-VH001', 'ENG-VH001', 18000, 60, '20DC,40DC,40HC', 'ACTIVE', 'AVAILABLE'
FROM iam.organizations o
WHERE o.code = 'ORG_TMS_TMA'
    ON CONFLICT (organization_id, plate_no) DO NOTHING;

INSERT INTO master_data.vehicles (
    organization_id,
    vehicle_code,
    vehicle_type,
    plate_no,
    chassis_no,
    engine_no,
    payload_kg,
    volume_m3,
    container_capability,
    status_code,
    operational_state
)
SELECT o.id, 'VH002', 'TRUCK', '51C-67890', 'CHS-VH002', 'ENG-VH002', 8000, 30, 'NON_CONTAINER', 'ACTIVE', 'AVAILABLE'
FROM iam.organizations o
WHERE o.code = 'ORG_TMS_TMA'
    ON CONFLICT (organization_id, plate_no) DO NOTHING;

-- ---------------------------------------------------------
-- DRIVERS
-- ---------------------------------------------------------
INSERT INTO master_data.drivers (
    organization_id,
    driver_code,
    driver_type,
    full_name,
    phone,
    license_no,
    license_expiry_date,
    employment_status
)
SELECT o.id, 'DRV001', 'DRIVER', 'Nguyen Van A', '0901000002', 'B2-123456', DATE '2028-12-31', 'ACTIVE'
FROM iam.organizations o
WHERE o.code = 'ORG_TMS_TMA'
    ON CONFLICT (organization_id, driver_code) DO NOTHING;

INSERT INTO master_data.drivers (
    organization_id,
    driver_code,
    driver_type,
    full_name,
    phone,
    license_no,
    license_expiry_date,
    employment_status
)
SELECT o.id, 'DRV002', 'CO_DRIVER', 'Tran Quoc Huy', '0901000007', 'C-998877', DATE '2027-06-30', 'ACTIVE'
FROM iam.organizations o
WHERE o.code = 'ORG_TMS_TMA'
    ON CONFLICT (organization_id, driver_code) DO NOTHING;

-- ---------------------------------------------------------
-- ROUTES
-- ---------------------------------------------------------
INSERT INTO master_data.routes (
    organization_id,
    route_code,
    route_name,
    origin_location_id,
    destination_location_id,
    standard_km,
    standard_duration_minutes,
    status_code
)
SELECT
    o.id,
    'R001',
    'HCM-HN',
    lo.id,
    ld.id,
    1720.50,
    2160,
    'ACTIVE'
FROM iam.organizations o
         JOIN master_data.locations lo ON lo.organization_id = o.id AND lo.location_code = 'PORT001'
         JOIN master_data.locations ld ON ld.organization_id = o.id AND ld.location_code = 'DEL001'
WHERE o.code = 'ORG_TMS_TMA'
    ON CONFLICT (organization_id, route_code) DO NOTHING;

INSERT INTO master_data.routes (
    organization_id,
    route_code,
    route_name,
    origin_location_id,
    destination_location_id,
    standard_km,
    standard_duration_minutes,
    status_code
)
SELECT
    o.id,
    'R002',
    'HCM-HCMC INNER',
    lo.id,
    ld.id,
    35.00,
    180,
    'ACTIVE'
FROM iam.organizations o
         JOIN master_data.locations lo ON lo.organization_id = o.id AND lo.location_code = 'PORT001'
         JOIN master_data.locations ld ON ld.organization_id = o.id AND ld.location_code = 'LOC001'
WHERE o.code = 'ORG_TMS_TMA'
    ON CONFLICT (organization_id, route_code) DO NOTHING;

-- ---------------------------------------------------------
-- TARIFFS
-- ---------------------------------------------------------
INSERT INTO master_data.tariffs (
    organization_id,
    customer_id,
    route_id,
    vehicle_type,
    container_type,
    currency_code,
    base_price,
    effective_from,
    effective_to,
    status_code
)
SELECT
    o.id,
    bp.id,
    r.id,
    'TRACTOR',
    '20DC',
    'VND',
    5000000,
    DATE '2026-01-01',
    NULL,
    'ACTIVE'
FROM iam.organizations o
         JOIN master_data.business_partners bp
              ON bp.organization_id = o.id
                  AND bp.partner_code = 'CUST001'
         JOIN master_data.routes r
              ON r.organization_id = o.id
                  AND r.route_code = 'R001'
WHERE o.code = 'ORG_TMS_TMA'
  AND NOT EXISTS (
    SELECT 1
    FROM master_data.tariffs t
    WHERE t.organization_id = o.id
      AND t.customer_id = bp.id
      AND t.route_id = r.id
      AND COALESCE(t.vehicle_type, '') = 'TRACTOR'
      AND COALESCE(t.container_type, '') = '20DC'
      AND t.effective_from = DATE '2026-01-01'
);

INSERT INTO master_data.tariffs (
    organization_id,
    customer_id,
    route_id,
    vehicle_type,
    container_type,
    currency_code,
    base_price,
    effective_from,
    effective_to,
    status_code
)
SELECT
    o.id,
    bp.id,
    r.id,
    'TRUCK',
    NULL,
    'VND',
    1200000,
    DATE '2026-01-01',
    NULL,
    'ACTIVE'
FROM iam.organizations o
         JOIN master_data.business_partners bp
              ON bp.organization_id = o.id
                  AND bp.partner_code = 'CUST001'
         JOIN master_data.routes r
              ON r.organization_id = o.id
                  AND r.route_code = 'R002'
WHERE o.code = 'ORG_TMS_TMA'
  AND NOT EXISTS (
    SELECT 1
    FROM master_data.tariffs t
    WHERE t.organization_id = o.id
      AND t.customer_id = bp.id
      AND t.route_id = r.id
      AND COALESCE(t.vehicle_type, '') = 'TRUCK'
      AND t.container_type IS NULL
      AND t.effective_from = DATE '2026-01-01'
);

-- ---------------------------------------------------------
-- SURCHARGES
-- ---------------------------------------------------------
INSERT INTO master_data.surcharges (
    organization_id,
    surcharge_code,
    surcharge_name,
    charge_method,
    default_amount,
    currency_code,
    status_code
)
SELECT o.id, 'SUR001', 'Waiting Fee', 'FIXED', 500000, 'VND', 'ACTIVE'
FROM iam.organizations o
WHERE o.code = 'ORG_TMS_TMA'
    ON CONFLICT (organization_id, surcharge_code) DO NOTHING;

INSERT INTO master_data.surcharges (
    organization_id,
    surcharge_code,
    surcharge_name,
    charge_method,
    default_amount,
    currency_code,
    status_code
)
SELECT o.id, 'SUR002', 'Lift On / Lift Off', 'PER_CONTAINER', 350000, 'VND', 'ACTIVE'
FROM iam.organizations o
WHERE o.code = 'ORG_TMS_TMA'
    ON CONFLICT (organization_id, surcharge_code) DO NOTHING;

COMMIT;
