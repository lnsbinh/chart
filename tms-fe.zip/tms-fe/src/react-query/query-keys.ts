export const queryKeys = {
  users: 'users',
  roles: 'roles',
  branches: 'branches',
  customers: 'customers',
  vehicles: 'vehicles',
  drivers: 'drivers',
  routes: 'routes',
};
