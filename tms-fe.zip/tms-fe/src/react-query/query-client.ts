import { QueryClient } from '@tanstack/react-query';

export function generateQueryClient() {
  return new QueryClient({
    defaultOptions: {
      queries: {
        staleTime: 60 * 1000, // 1 minute
        gcTime: 5 * 60 * 1000, // 5 minutes (gcTime should always be > staleTime)
        retry: 1, // retry once on failure
        refetchOnMount: true, // refetch if data is stale when component mounts
        refetchOnWindowFocus: false,
        refetchOnReconnect: true, // refetch when internet reconnects
      },
      mutations: {
        retry: 0, // don't retry mutations
      },
    },
  });
}

export const queryClient = generateQueryClient();
