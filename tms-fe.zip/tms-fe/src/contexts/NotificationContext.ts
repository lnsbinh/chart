import { createContext } from 'react';
import type { useNotificationInstance } from '@/hooks/useNotify.tsx';

type NotificationContextValue = Omit<ReturnType<typeof useNotificationInstance>, 'contextHolder'>;

export const NotificationContext = createContext<NotificationContextValue | null>(null);
