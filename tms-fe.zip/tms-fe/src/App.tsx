import { ConfigProvider } from 'antd';
import { QueryClientProvider } from '@tanstack/react-query';
import { queryClient } from '@/react-query/query-client';
import AppRouter from '@/routers/router';
import { I18nLanguageProvider } from '@/i18n/I18nLanguageProvider';
import { NotificationProvider } from '@/components/common/NotificationProvider/NotificationProvider';
import { KeycloakProvider } from '@/auth/KeycloakProvider';

const App = () => {
  return (
    <KeycloakProvider>
      <QueryClientProvider client={queryClient}>
        <I18nLanguageProvider>
          <ConfigProvider
            theme={{
              token: {
                colorPrimary: '#1ea0ff',
                colorPrimaryHover: '#1b90e6',
                colorPrimaryActive: '#007ad2',
                colorText: '#090909',
                colorError: '#DE0000',
                colorSuccess: '#00A307',
              },
            }}>
            <NotificationProvider>
              <AppRouter />
            </NotificationProvider>
          </ConfigProvider>
        </I18nLanguageProvider>
        {/* <ReactQueryDevtools initialIsOpen={false} /> */}
      </QueryClientProvider>
    </KeycloakProvider>
  );
};

export default App;
