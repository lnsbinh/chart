import { ROLES } from '@/constants';
import { type SortOrder } from '@/types/api';

export const getRoles = (msg: {
  admin: string;
  supervisor: string;
  dispatcher: string;
  opsStaff: string;
  finance: string;
  driver: string;
}) => [
  { label: msg.admin, value: ROLES.ADMIN },
  { label: msg.supervisor, value: ROLES.SUPERVISOR },
  { label: msg.dispatcher, value: ROLES.DISPATCHER },
  { label: msg.opsStaff, value: ROLES.OPS_STAFF },
  { label: msg.finance, value: ROLES.FINANCE },
  { label: msg.driver, value: ROLES.DRIVER },
];

export const toSortOrder = (order?: 'ascend' | 'descend' | null): SortOrder => {
  if (order === 'ascend') return 'asc';
  if (order === 'descend') return 'desc';
  return undefined;
};
