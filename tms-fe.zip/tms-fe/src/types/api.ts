export interface BaseResponse<T> {
  data: T;
  message: string;
  success: boolean;
}
export interface ServerError {
  message: string;
  code: number;
}
export type SortOrder = 'asc' | 'desc' | undefined;
