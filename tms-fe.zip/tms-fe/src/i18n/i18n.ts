import { createIntl, createIntlCache } from 'react-intl';

// Import messages
import enMessages from './messages/en';

export const LOCALES = {
  ENGLISH: 'en',
};

export type Locale = typeof LOCALES[keyof typeof LOCALES];

/**
 * Flattens a nested object structure into a flat object with dot notation keys
 * This is important for react-intl which requires flat message objects
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const flattenMessages = (nestedMessages: Record<string, any>, prefix = '') => {
  return Object.keys(nestedMessages).reduce((messages: Record<string, string>, key) => {
    const value = nestedMessages[key];
    const prefixedKey = prefix ? `${prefix}.${key}` : key;
    
    if (typeof value === 'string') {
      messages[prefixedKey] = value;
    } else {
      Object.assign(messages, flattenMessages(value, prefixedKey));
    }
    
    return messages;
  }, {});
};

// Flatten all message objects
const flatEnMessages = flattenMessages(enMessages);

// Message files mapped to locales (using flattened message structure)
export const messages: Record<Locale, Record<string, string>> = {
  [LOCALES.ENGLISH]: flatEnMessages,
};

// Create the cache for better performance
const cache = createIntlCache();

// Default locale
export const defaultLocale = LOCALES.ENGLISH;

// Create the intl instance
export const createAppIntl = (locale: Locale = defaultLocale) => {
  return createIntl(
    {
      locale,
      defaultLocale,
      messages: messages[locale],
    },
    cache
  );
};

// Export a default intl instance
export const intl = createAppIntl();

// Helper function to format message
export const formatMessage = (id: string, values?: Record<string, string | number | boolean>) => {
  try {
    return intl.formatMessage({ id }, values);
  } catch (error) {
    console.error(`Error formatting message with id: ${id}`, error);
    return id;
  }
}; 