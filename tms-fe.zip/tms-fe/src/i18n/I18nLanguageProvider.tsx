import { type ReactNode, createContext, useCallback, useMemo, useState } from 'react';
import { IntlProvider } from 'react-intl';
import { type Locale, LOCALES, defaultLocale, messages } from './i18n';

interface I18nContextType {
  locale: Locale;
  changeLocale: (locale: Locale) => void;
}

const I18nContext = createContext<I18nContextType>({
  locale: defaultLocale,
  changeLocale: () => {},
});

interface I18nLanguageProviderProps {
  children: ReactNode;
}

export const I18nLanguageProvider = ({ children }: I18nLanguageProviderProps) => {
  const [locale, setLocale] = useState<Locale>(() => {
    // Try to get locale from localStorage or use default
    const savedLocale = localStorage.getItem('locale') as Locale;
    return savedLocale && Object.values(LOCALES).includes(savedLocale) 
      ? savedLocale 
      : defaultLocale;
  });

  const changeLocale = useCallback((newLocale: Locale) => {
    setLocale(newLocale);
    localStorage.setItem('locale', newLocale);
  }, []);

  const contextValue = useMemo(() => ({
    locale,
    changeLocale,
  }), [locale, changeLocale]);

  return (
    <I18nContext.Provider value={contextValue}>
      <IntlProvider 
        locale={locale}
        defaultLocale={defaultLocale}
        messages={messages[locale]}
      >
        {children}
      </IntlProvider>
    </I18nContext.Provider>
  );
};
