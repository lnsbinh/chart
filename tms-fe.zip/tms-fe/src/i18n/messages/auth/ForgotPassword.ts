export const forgotPasswordMessage = {
  // Step 1: Enter email
  title: 'Forgot Password?',
  description: 'Don\'t worry! It happens. Please enter the email address linked to your account.',
  emailLabel: 'Email',
  emailPlaceholder: 'Enter your email',
  sendCode: 'Send code',
  rememberPassword: 'Remember your password?',
  backToLogin: 'Login',
  emailRequired: 'Please enter your email',
  emailInvalid: 'Please enter a valid email address',

  // Step 2: OTP
  otpTitle: 'OTP Verification',
  otpDescription: 'Enter the verification code we just sent to your email address.',
  verify: 'Verify',
  didNotReceiveCode: 'Didn\'t receive code?',
  resend: 'Resend',
  otpRequired: 'Please enter OTP',
  otpLength: 'OTP must be 4 digits',

  // Step 3: Reset password
  resetTitle: 'Create New Password',
  resetDescription: 'Your new password must be different from previously used passwords.',
  newPasswordLabel: 'New password',
  newPasswordPlaceholder: 'Enter new password',
  confirmPasswordLabel: 'Confirm password',
  confirmPasswordPlaceholder: 'Enter your password again',
  resetPassword: 'Reset password',
  newPasswordRequired: 'Please enter your new password',
  newPasswordLength: 'Password must be at least 8 characters',
  confirmPasswordRequired: 'Please confirm your new password',
  confirmPasswordMismatch: 'The two passwords that you entered do not match',

  // Step 4: Success
  passwordChangedTitle: 'Password Changed!',
  passwordChangedDescription: 'Your password has been changed successfully.',
  redirectToLogin: 'Redirecting to login page...',
};