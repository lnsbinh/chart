export const signInMessage = {
  title: 'Sign in',
  subtitle: 'Sign in to your account below',
  usernameLabel: 'Username',
  usernamePlaceholder: 'Enter username',
  passwordLabel: 'Password',
  passwordPlaceholder: 'Enter password',
  rememberMe: 'Remember me',
  forgotPassword: 'Forgot password?',
  signInButton: 'Sign in',
  noAccount: "Don't have an account?",
  createAccount: 'Create account',
};
