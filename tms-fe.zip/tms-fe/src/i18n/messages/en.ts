import { forgotPasswordMessage } from './auth/ForgotPassword';
import { signInMessage } from '@/i18n/messages/auth/SignIn';
import { userManagementMessage } from '@/i18n/messages/admin/UserManagement/UserManagement';
import { commonMessage } from '@/i18n/messages/common/common';
import { apiErrorMessage } from '@/i18n/messages/common/apiError';
import { customerMessage } from './masterData/Customer';
import { vehicleMessage } from './masterData/Vehicle';
import { driverMessage } from './masterData/Driver';
// import { routeMessage } from './masterData/Route';

const en = {
  commonMessage,
  signInMessage,
  forgotPasswordMessage,
  userManagementMessage,
  customerMessage,
  vehicleMessage,
  driverMessage,
  apiErrorMessage,
  // routeMessage,
};
export default en;
