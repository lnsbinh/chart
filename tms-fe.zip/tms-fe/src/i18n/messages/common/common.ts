export const commonMessage = {
  // Pagination & Table
  itemsPerPage: 'Items per page',
  total: 'Total',
  records: 'Records',
  record: 'Record',

  // Role labels
  roleLabel: 'Role',
  admin: 'Admin',
  supervisor: 'Supervisor',
  dispatcher: 'Dispatcher',
  opsStaff: 'Ops Staff',
  finance: 'Finance',
  driver: 'Driver',

  // General messages
  view: 'View',
  viewDetails: 'View details',
  cancel: 'Cancel',
  edit: 'Edit',
  save: 'Save',
  confirm: 'Confirm',
  action: 'Action',
  deactivate: 'Deactivate',
  status: 'Status',
  active: 'Active',
  inactive: 'Inactive',
  lock: 'Lock',
  unlock: 'Unlock',
  resetPassword: 'Reset password',
  delete: 'Delete',
  true: 'True',
  false: 'False',
  deleteActionWarning: 'This action cannot be undone.',
};
