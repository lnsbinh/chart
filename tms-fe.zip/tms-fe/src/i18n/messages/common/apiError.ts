export const apiErrorMessage = {
  UNAUTHORIZED: 'You are not authorized to perform this action.',
  FORBIDDEN: 'Access denied.',
  TOKEN_EXPIRED: 'Your session has expired. Please log in again.',

  INTERNAL_SERVER_ERROR: 'A server error occurred. Please try again later.',
  SERVICE_UNAVAILABLE: 'Service is currently unavailable. Please try again later.',
  UNKNOWN_ERROR: 'An unexpected error occurred.',
};
