export const userManagementMessage = {
  title: 'User Management',
  userId: 'User ID',
  user: 'User',
  roles: 'Roles',
  branches: 'Branches',
  status: 'Status',
  action: 'Action',
  search: 'Search',
  allRoles: 'All Roles',
  allStatus: 'All Status',
  allBranches: 'All Branch',
  addUser: 'Add User',
  email: 'Email',

  // Status options
  active: 'Active',
  locked: 'Locked',

  // Modal
  addNewUser: 'Add New User',
  updateUser: 'Update User',
  createUser: 'Create User',
  save: 'Save',
  titleCreate: 'Fill in the information to create a new system user.',
  titleUpdate: 'Update user information.',

  // Form labels
  userCode: 'User Code',
  firstName: 'First Name',
  lastName: 'Last Name',
  username: 'Username',
  password: 'Password',
  confirmPassword: 'Confirm Password',
  avatar: 'Avatar',

  // Placeholders
  passwordPlaceholder: 'Password',
  confirmPasswordPlaceholder: 'Confirm password',

  // Validation
  firstNameRequired: 'First name is required',
  lastNameRequired: 'Last name is required',
  usernameRequired: 'Username is required',
  emailRequired: 'Email is required',
  emailInvalid: 'Invalid email format',
  passwordRequired: 'Password is required',
  confirmPasswordRequired: 'Confirm password is required',
  confirmPasswordMismatch: 'Passwords do not match',
  passwordMinLength: 'Password must be at least 8 characters',
  passwordUppercase: 'Password must contain at least one uppercase letter',
  passwordLowercase: 'Password must contain at least one lowercase letter',
  passwordNumber: 'Password must contain at least one number',
  passwordSpecial: 'Password must contain at least one special character',
  rolesRequired: 'Roles is required',
  branchesRequired: 'Branches is required',

  // modal confirm
  lockAccountTitle: 'Lock Account?',
  lockAccountDescription:
    'This user will no longer be able to sign in or access the system until the account is unlocked.',
  unlockAccountTitle: 'Unlock Account?',
  unlockAccountDescription: 'The user will regain access and be able to sign in to the system.',
  resetPasswordTitle: 'Reset Password',
  resetPasswordDescription: 'Are you sure you want to reset password for this user?',
  deleteAccountTitle: 'Delete Account?',
  deleteAccountDescription: 'Are you sure you want to delete account for this user?',

  // upload
  supportFormats: 'Support formats',
  upload: 'Upload',

  userCreatedSuccess: 'User created successfully',
  userUpdatedSuccess: 'User updated successfully',

  userLocked: 'User has been locked',
  userUnlocked: 'User has been unlocked',

  passwordResetSuccess: 'Password has been reset successfully',
  passwordResetError: 'Failed to reset password. Please try again',

  deleteUserSuccess: 'User has been deleted successfully',
  deleteUserError: 'Failed to delete user. Please try again',

  avatarUploadError: 'Failed to upload avatar. Please try again',
};
