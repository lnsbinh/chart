export const customerMessage = {
    title: 'Customers Master',
    search: 'Search customers...',
    addCustomer: 'Add Customer',

    customerId: 'Customer ID',
    customerName: 'Customer Name',
    contactPerson: 'Contact Person',
    contactPhone: 'Contact Phone',
    email: 'Email',
    paymentTerm: 'Payment Term',
    creditLimit: 'Credit Limit',

    addNewCustomer: 'Add New Customer',
    editCustomer: 'Edit Customer',
    viewCustomer: 'View Details Customer',

    createCustomer: 'Create Customer',

    description: 'Fill in the information to create a new customer.',
    editDescription: 'Update customer information.',

    customerCode: 'Customer ID',

    customerNameLabel: 'Customer Name',
    customerNamePlaceholder: 'e.g. Kho gia dụng Tấn Tài',
    customerNameRequired: 'Please enter the customer name',

    emailLabel: 'Email',
    emailPlaceholder: 'e.g. ctytantai@gmail.com',
    emailRequired: 'Please enter email',
    emailInvalid: 'Invalid email format',

    contactPersonLabel: 'Contact Person',
    contactPersonPlaceholder: 'e.g. Nguyễn Tấn Tài',
    contactPersonRequired: 'Please enter contact person',

    contactPhoneLabel: 'Contact Phone',
    contactPhonePlaceholder: 'e.g. 0987654321',
    contactPhoneRequired: 'Please enter phone number',

    companyAddressLabel: 'Company Address',
    companyAddressPlaceholder: 'e.g. 20 Ngõ 165, Dịch Vọng, Cầu Giấy, Hà Nội',
    companyAddressRequired: 'Please enter company address',

    pickupAddressLabel: 'Pickup Address',
    pickupAddressPlaceholder: 'e.g. 2M3J+GP7, Tân Thanh, Lạng Sơn',
    pickupAddressRequired: 'Please enter pickup address',

    paymentTermLabel: 'Payment Term',
    paymentTermPlaceholder: 'e.g. 30 days',
    paymentTermRequired: 'Please enter payment term',

    creditLimitLabel: 'Credit Limit',
    creditLimitPlaceholder: 'e.g. 30,000,000',
    creditLimitRequired: 'Please enter credit limit',

    deleteCustomer: 'Delete Customer',
    deleteCustomerDescription: 'Are you sure you want to delete this customer?',
    deleteCustomerSuccess: 'Customer deleted successfully',

    addCustomerSuccess: 'Customer created successfully',
    updateCustomerSuccess: 'Customer updated successfully',
};