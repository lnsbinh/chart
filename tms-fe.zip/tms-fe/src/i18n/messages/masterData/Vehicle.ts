export const vehicleMessage = {
    // Page
    title: "Vehicles",
    search: "Search vehicles...",
    addVehicle: "Add Vehicle",

    // Table columns
    vehicleId: "Vehicle ID",
    licensePlate: "License Plate",
    vehicleName: "Vehicle Name",
    vehicleType: "Vehicle Type",
    brandModel: "Brand Model",
    productionYear: "Production Year",
    capacityKg: "Capacity (KG)",
    volumeM3: "Volume (M3)",
    fuelType: "Fuel Type",
    fuelNorm: "Fuel Norm",
    ownerBranch: "Owner Branch",
    baseDepot: "Base Depot",
    gpsDeviceCode: "GPS Device Code",
    registryExpiry: "Registry Expiry",
    insuranceExpiry: "Insurance Expiry",

    // Add / Edit form
    description: "Fill in the information to create a new vehicle.",
    editVehicle: "Edit Vehicle",
    editVehicleDescription: "Change the information of the vehicle.",
    createVehicle: "Create Vehicle",
    viewVehicle: "View Details Vehicle",

    // Validation messages
    vehicleNameRequired: "Please enter the vehicle name",
    licensePlateRequired: "Please enter the license plate",
    vehicleTypeRequired: "Please enter the vehicle type",
    brandModelRequired: "Please enter the brand model",
    productionYearRequired: "Please enter the production year",
    capacityRequired: "Please enter the capacity",
    volumeRequired: "Please enter the volume",
    fuelTypeRequired: "Please enter the fuel type",
    fuelNormRequired: "Please enter the fuel norm",
    ownerBranchRequired: "Please enter the owner branch",
    gpsDeviceCodeRequired: "Please enter the GPS device code",
    registryExpiryRequired: "Please select registry expiry date",
    insuranceExpiryRequired: "Please select insurance expiry date",

    // Placeholders (helps UX + consistency)
    vehicleNamePlaceholder: "e.g. 3.5 ton truck - HCM route 1",
    licensePlatePlaceholder: "e.g. 30A-234.56",
    vehicleTypePlaceholder: "e.g. Truck 3 tons",
    brandModelPlaceholder: "e.g. Hino 300",
    productionYearPlaceholder: "e.g. 2020",
    capacityPlaceholder: "e.g. 3000",
    volumePlaceholder: "e.g. 15",
    fuelTypePlaceholder: "e.g. Diesel",
    fuelNormPlaceholder: "e.g. 14",
    ownerBranchPlaceholder: "e.g. HCM_DC",
    gpsDeviceCodePlaceholder: "e.g. GPS_000123",
    capacityUnit: "KG",
    volumeUnit: "M3",
    fuelNormUnit: "liter/100km",
    registryExpiryPlaceholder: "e.g. 01/01/2026",
    insuranceExpiryPlaceholder: "e.g. 01/01/2026",

    // Success
    addVehicleSuccess: "Vehicle created successfully",
    updateVehicleSuccess: "Vehicle updated successfully",

    // Delete modal
    deleteVehicle: "Delete Vehicle?",
    deleteVehicleDescription:
        "Are you sure you want to delete this vehicle?",
    deleteVehicleSuccess: "Vehicle deleted successfully.",
};
