import { Layout, Flex, Image, Button, Avatar, Space } from 'antd';

import TMALogo from '@/assets/images/tma-logo.png';
import avatarDefault from '@/assets/images/avatar-default.jpg';
import { NotifyIcon } from '@/assets';
import { useAuth } from '@/hooks/useAuth';
import './style.less';

const { Header } = Layout;
const CustomHeader = () => {
  const { username } = useAuth();
  return (
    <Header className='custom-header'>
      <Flex
        align='center'
        justify='space-between'>
        <Image
          src={TMALogo}
          alt='tma-logo'
          preview={false}
        />
        <Flex
          align='center'
          gap={24}>
          <Button
            className='custom-header-notify'
            icon={
              <NotifyIcon
                width={24}
                height={24}
              />
            }
          />
          <Space>
            <Avatar
              className='custom-header-avatar'
              src={avatarDefault}
              size={40}
            />
            <span className='custom-header-username'>{username}</span>
          </Space>
        </Flex>
      </Flex>
    </Header>
  );
};

export default CustomHeader;
