import { useState, useMemo } from 'react';
import { Layout, Button, Menu, type MenuProps, Typography, Flex, Divider, Avatar, Space } from 'antd';
import { useLocation, useNavigate } from 'react-router';
import { CloseIcon, MenuIcon, LogoutIcon } from '@/assets';
import avatarDefault from '@/assets/images/avatar-default.jpg';
import { useAuth } from '@/hooks/useAuth';
import { menuList } from './MenuConfig';
import { ROLES } from '@/constants';

const { Sider } = Layout;

const CustomMenu = () => {
  const [collapsed, setCollapsed] = useState(false);
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const { username, roles, hasRole, logout } = useAuth();

  // match pathname to menu item key via path field
  const selectedKey = useMemo(() => {
    for (const group of menuList) {
      const match = group.children?.find((item) => item.path === pathname);
      if (match) return match.key;
    }
    return '';
  }, [pathname]);

  const items: MenuProps['items'] = useMemo(
    () =>
      menuList
        .filter(
          (group) =>
            group.isShow &&
            (group.allowedRoles.length === 0 || group.allowedRoles.some((allowedRole) => hasRole(allowedRole))),
        )
        .map((group) => ({
          key: group.key,
          label: collapsed ? null : group.label,
          type: 'group' as const,
          children: group.children
            ?.filter(
              (item) =>
                item.isShow &&
                (item.allowedRoles.length === 0 || item.allowedRoles.some((allowedRole) => hasRole(allowedRole))),
            )
            .map((item) => ({
              key: item.key,
              label: item.label,
              icon: item.icon || undefined,
            })),
        })),
    [collapsed, hasRole],
  );

  const handleMenuClick: MenuProps['onClick'] = ({ key }) => {
    const allItems = menuList.flatMap((group) => group.children ?? []);
    const target = allItems.find((item) => item.key === key);
    if (target?.path) navigate(target.path);
  };

  return (
    <Sider
      width={248}
      collapsedWidth={80}
      collapsed={collapsed}
      className='custom-sider'>
      <div className='custom-menu'>
        <Flex
          justify='space-between'
          align='center'>
          {collapsed ? null : (
            <Typography.Title
              className='custom-menu-title'
              level={3}>
              Menu
            </Typography.Title>
          )}

          <Button
            className='custom-menu-collapsed__btn'
            type='primary'
            icon={
              collapsed ? (
                <MenuIcon
                  width={24}
                  height={24}
                />
              ) : (
                <CloseIcon
                  width={24}
                  height={24}
                />
              )
            }
            onClick={() => setCollapsed((prev) => !prev)}
          />
        </Flex>
        <Menu
          selectedKeys={[selectedKey]}
          items={items}
          mode='inline'
          inlineCollapsed={collapsed}
          tooltip={{ placement: 'left' }}
          onClick={handleMenuClick}
        />
        <div className='custom-menu-avatar__group'>
          <Divider />
          <Flex
            justify={collapsed ? 'center' : 'space-between'}
            align='center'>
            {!collapsed && (
              <Space>
                <Avatar
                  className='avatar'
                  src={avatarDefault}
                  size={40}
                />
                <Space
                  orientation='vertical'
                  size={2}>
                  <span className='username'>{username}</span>
                  <span className='role'>
                    {roles.find((role) => Object.values(ROLES).includes(role as (typeof ROLES)[keyof typeof ROLES]))}
                  </span>
                </Space>
              </Space>
            )}
            <Button
              type='primary'
              onClick={logout}
              icon={
                <LogoutIcon
                  width={20}
                  height={20}
                />
              }
            />
          </Flex>
        </div>
      </div>
    </Sider>
  );
};

export default CustomMenu;
