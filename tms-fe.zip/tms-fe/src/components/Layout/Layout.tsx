import { Layout } from 'antd';
import { Outlet } from 'react-router';

import Header from './Header';
import Menu from './Menu';
import './style.less';

const { Footer, Content } = Layout;

const CustomLayout = () => {
  return (
    <Layout className='custom-layout'>
      <Header />
      <Layout className='custom-layout-inner'>
        <Menu />
        <Content className='custom-content'>
          <div className='custom-content-wrapper'>
            <Outlet />
          </div>
          <Footer className='custom-footer'>TMA Solutions CO., LTD. © 2026 All Rights Reserved</Footer>
        </Content>
      </Layout>
    </Layout>
  );
};

export default CustomLayout;
