import { Row, Col, Carousel, Flex, Typography, Select } from 'antd';
import classNames from 'classnames';
import carouselImageFirst from '@/assets/images/car-1.png';
import carouselImageSecond from '@/assets/images/car-2.png';
import { ENIcon } from '@/assets';
import subImgTop from '@/assets/images/sub-img-top.png';
import subImgBottom from '@/assets/images/sub-img-bottom.png';
import './style.less';

const { Title } = Typography;

interface IAuthLayoutProps {
  children: React.ReactNode;
}

const slides = [
  {
    subtitle: 'Smart Logistics Management',
    desc: 'Stay in control of your deliveries with live updates, smart routing, and full visibility across your logistics network.',
    image: carouselImageFirst,
    class: 'custom-image',
  },
  {
    subtitle: 'Real-Time Shipment Tracking',
    desc: 'Manage your shipments, track deliveries in real time, and streamline your entire logistics operation with ease and efficiency.',
    image: carouselImageSecond,
  },
];

export default function AuthLayout({ children }: IAuthLayoutProps) {
  return (
    <div className='auth-layout'>
      <div className='lang'>
        <Select
          size='large'
          prefix={
            <ENIcon
              width={32}
              height={24}
            />
          }
          defaultValue='en'
          options={[{ value: 'en', label: 'ENG' }]}
        />
      </div>
      <Row>
        <Col
          flex='auto'
          className='auth-layout__left'>
          {children}
          <img
            className='background-image-top'
            src={subImgTop}
            alt=''
          />
          <img
            className='background-image-bottom'
            src={subImgBottom}
            alt=''
          />
        </Col>

        <Col className='auth-layout__right'>
          <img
            className='background-image-top'
            src={subImgTop}
            alt=''
          />
          <img
            className='background-image-bottom'
            src={subImgBottom}
            alt=''
          />
          <Title>OnRoute TMS</Title>

          <Carousel
            autoplay
            autoplaySpeed={5000}
            dots
            effect='fade'
            className='carousel'>
            {slides.map((slide, index) => (
              <div key={index}>
                <div className='slide-item'>
                  <div className={classNames('carousel-image', slide.class)}>
                    <img
                      src={slide.image}
                      alt='image'
                    />
                  </div>
                  <Flex justify='center'>
                    <div className='carousel-info'>
                      <Title level={3}>{slide.subtitle}</Title>
                      <p>{slide.desc}</p>
                    </div>
                  </Flex>
                </div>
              </div>
            ))}
          </Carousel>
        </Col>
      </Row>
    </div>
  );
}
