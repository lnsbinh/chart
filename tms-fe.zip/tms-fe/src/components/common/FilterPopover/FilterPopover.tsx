import { Popover, Checkbox } from 'antd';
import type { CheckboxChangeEvent } from 'antd/es/checkbox';
import ButtonTMS from '../Button/ButtonTMS';
import './FilterPopover.less';

interface FilterOption {
  label: string;
  value: string;
}

interface FilterPopoverProps {
  title: string;
  options: FilterOption[];
  selectedValues: string[];
  onChange: (values: string[]) => void;
}

const FilterPopover = ({ title, options, selectedValues, onChange }: FilterPopoverProps) => {
  const handleSelectAll = (e: CheckboxChangeEvent) => {
    if (e.target.checked) {
      onChange(options.map((opt) => opt.value));
    } else {
      onChange([]);
    }
  };

  const handleOptionChange = (values: string[]) => {
    onChange(values);
  };

  const content = (
    <div className='filter-popover'>
      <Checkbox
        indeterminate={selectedValues.length > 0 && selectedValues.length < options.length}
        onChange={handleSelectAll}
        checked={selectedValues.length === options.length}>
        {title}
      </Checkbox>
      <Checkbox.Group
        options={options}
        value={selectedValues}
        onChange={handleOptionChange}
      />
    </div>
  );

  return (
    <Popover
      content={content}
      placement='bottomLeft'
      arrow={false}
      trigger='click'>
      <ButtonTMS>{title}</ButtonTMS>
    </Popover>
  );
};

export default FilterPopover;
