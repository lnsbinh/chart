import { Tag } from 'antd';
import classNames from 'classnames';
import type { ReactNode } from 'react';
import './CheckableTagTMS.less';

const { CheckableTag } = Tag;

type CheckableTagValue = string | number;

type TagOption = {
  label: ReactNode;
  value: CheckableTagValue;
  icon?: ReactNode;
};

interface CheckableTagBaseProps {
  options: TagOption[];
  className?: string;
}

interface SingleProps extends CheckableTagBaseProps {
  multiple?: false;
  value?: CheckableTagValue | null;
  onChange?: (value: CheckableTagValue | null) => void;
}

interface MultipleProps extends CheckableTagBaseProps {
  multiple: true;
  value?: CheckableTagValue[];
  onChange?: (value: CheckableTagValue[]) => void;
}

type CheckableTagTMSProps = SingleProps | MultipleProps;

const CheckableTagTMS = (props: CheckableTagTMSProps) => {
  const { options, className } = props;

  const isChecked = (tagValue: CheckableTagValue): boolean => {
    if (props.multiple) return (props.value ?? []).includes(tagValue);
    return (props.value ?? null) === tagValue;
  };

  const handleChange = (tagValue: CheckableTagValue, checked: boolean) => {
    if (props.multiple) {
      const current = props.value ?? [];
      const next = checked ? [...current, tagValue] : current.filter((v) => v !== tagValue);
      props.onChange?.(next);
    } else {
      props.onChange?.(checked ? tagValue : null);
    }
  };

  return (
    <div className={classNames('checkable-tag-tms', className)}>
      {options.map((option) => (
        <CheckableTag
          key={option.value}
          icon={option.icon}
          checked={isChecked(option.value)}
          onChange={(checked) => handleChange(option.value, checked)}
          className='checkable-tag-tms__item'>
          {option.label}
        </CheckableTag>
      ))}
    </div>
  );
};

export default CheckableTagTMS;
