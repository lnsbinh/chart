import { Tag } from 'antd';
import cn from 'classnames';
import './StatusTag.less';

interface IStatusTagProps {
  status: 'active' | 'locked' | 'true' | 'false';
}
const StatusTag = ({ status }: IStatusTagProps) => {
  return (
    <Tag
      className={cn('status-tag', {
        [`status-tag__${status}`]: status,
      })}>
      {status}
    </Tag>
  );
};

export default StatusTag;
