import type { ReactNode } from 'react';
import { Modal, type ModalProps } from 'antd';
import classNames from 'classnames';
import warning from '@/assets/images/warning.png';
import info from '@/assets/images/info.png';
import danger from '@/assets/images/danger.png';
import './ModalConfirm.less';
import type { commonMessage } from '@/i18n/messages/common/common';
import { useMessageProxy } from '@/hooks/useMessageProxy';

interface IModalConfirmProps extends ModalProps {
  children?: ReactNode;
  description?: string;
  type: 'warning' | 'info' | 'danger';
}

const ModalConfirm = ({ children, className, title, description, type, ...modalProps }: IModalConfirmProps) => {
  const commonMsg = useMessageProxy<typeof commonMessage>('commonMessage');
  return (
    <Modal
      className={classNames('modal-confirm', className)}
      okText={commonMsg.confirm}
      centered
      {...modalProps}>
      <div className='modal-confirm__header'>
        <div className='modal-confirm__icon'>
          <img
            src={type === 'warning' ? warning : type === 'danger' ? danger : info}
            alt='icon'
          />
        </div>
      </div>
      <div className='modal-confirm__body'>
        <p className='modal-confirm__title'>{title}</p>
        <p className='modal-confirm__description'>{description}</p>
        {children}
      </div>
    </Modal>
  );
};

export default ModalConfirm;
