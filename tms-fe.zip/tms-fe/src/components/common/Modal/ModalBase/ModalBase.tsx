import type { ReactNode } from 'react';
import { Modal, type ModalProps } from 'antd';
import classNames from 'classnames';
import './ModalBase.less';

interface IModalBaseProps extends ModalProps {
  children: ReactNode;
}

const ModalBase = ({ children, className, ...modalProps }: IModalBaseProps) => {
  return (
    <Modal
      className={classNames('modal-base', className)}
      mask={{ closable: false }}
      {...modalProps}>
      {children}
    </Modal>
  );
};

export default ModalBase;
