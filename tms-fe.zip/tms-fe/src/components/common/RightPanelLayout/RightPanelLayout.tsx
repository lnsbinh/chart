import { Button } from 'antd';
import cn from 'classnames';
import React from 'react';
import { useNavigate } from 'react-router';
import './RightPanelLayout.less';

interface RightPanelLayoutProps {
  title: string;
  showBackButton?: boolean;
  actionButtons?: React.ReactNode;
  onBackClick?: () => void;
  backPath?: string;
  children?: React.ReactNode;
  loading?: boolean;
  className?: string;
}

const RightPanelLayout: React.FC<RightPanelLayoutProps> = ({
  title,
  showBackButton = false,
  actionButtons,
  onBackClick,
  children,
  backPath,
  loading = false,
  className,
}) => {
  const navigate = useNavigate();

  const handleBack = () => {
    if (onBackClick) {
      onBackClick();
    } else if (backPath) {
      navigate(backPath);
    } else {
      return;
    }
  };

  return (
    <div className={cn('rightPanelLayout', className)}>
      <div className='rightPanelLayout-header'>
        <div className='rightPanelLayout-header-left'>
          {showBackButton && (
            <Button
              className='rightPanelLayout-btn'
              onClick={handleBack}>
              Back
            </Button>
          )}
          <div className='rightPanelLayout-title'>{title}</div>
        </div>
        <div className='rightPanelLayout-header-right'>{actionButtons}</div>
      </div>
      <div className='rightPanelLayout-divider' />
      <div className='rightPanelLayout-content'>
        {loading ? <div className='rightPanelLayout-loading'>loading</div> : children}
      </div>
    </div>
  );
};

export default RightPanelLayout;
