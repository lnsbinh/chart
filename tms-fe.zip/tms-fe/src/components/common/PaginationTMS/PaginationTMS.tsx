import React from 'react';
import { Flex, Space, Select, Pagination, Button, type PaginationProps } from 'antd';
import type { SelectProps, FlexProps } from 'antd';
import { useMessageProxy } from '@/hooks/useMessageProxy';
import { commonMessage } from '@/i18n/messages/common/common';
import { DoubleNextIcon, DoublePrevIcon, PrevIcon, NextIcon } from '@/assets';
import './PaginationTMS.less';

interface IPaginationTMSProps {
  current: number;
  total: number;
  pageSize: number;
  onChange: (page: number, pageSize: number) => void;
  pageSizeOptions?: (string | number)[];
  hidePageSize?: boolean;
  hideTotal?: boolean;
  flexProps?: FlexProps;
}

const PaginationTMS = ({
  current,
  total,
  pageSize,
  onChange,
  pageSizeOptions = [10, 20, 50, 100],
  hidePageSize = false,
  hideTotal = false,
  flexProps,
}: IPaginationTMSProps) => {
  const msg = useMessageProxy<typeof commonMessage>('commonMessage');
  const lastPage = Math.ceil(total / pageSize);
  const selectOptions: SelectProps['options'] = pageSizeOptions.map((size) => ({
    label: size.toString(),
    value: size,
  }));

  const handlePageSizeChange = (value: number) => {
    onChange(1, value);
  };

  const handlePageChange: PaginationProps['onChange'] = (page) => {
    onChange(page, pageSize);
  };

  const handleGoToFirstPage = () => {
    onChange(1, pageSize);
  };

  const handleGoToLastPage = () => {
    onChange(lastPage, pageSize);
  };

  return (
    <Flex
      justify='space-between'
      align='center'
      className='pagination-tms'
      {...flexProps}>
      {!hidePageSize && (
        <Space style={{ gap: '12px' }}>
          <span>{msg.itemsPerPage}</span>
          <Select
            value={pageSize}
            onChange={handlePageSizeChange}
            options={selectOptions}
            style={{ width: 80 }}
          />
          {!hideTotal && (
            <span>
              {msg.total}: {total} {msg.records}
            </span>
          )}
        </Space>
      )}
      <Flex
        align='center'
        className='pagination-tms-controls'>
        <Button
          icon={
            <DoublePrevIcon
              width={16}
              height={16}
            />
          }
          onClick={handleGoToFirstPage}
          disabled={current === 1}
        />
        <Pagination
          current={current}
          total={total}
          pageSize={pageSize}
          onChange={handlePageChange}
          showSizeChanger={false}
          showQuickJumper={false}
          itemRender={(_page, type, originalElement) => {
            if (type === 'prev' && React.isValidElement(originalElement)) {
              return React.cloneElement(
                originalElement,
                {},
                <PrevIcon
                  width={24}
                  height={24}
                />,
              );
            }
            if (type === 'next' && React.isValidElement(originalElement)) {
              return React.cloneElement(
                originalElement,
                {},
                <NextIcon
                  width={24}
                  height={24}
                />,
              );
            }
            return originalElement;
          }}
        />
        <Button
          icon={
            <DoubleNextIcon
              width={16}
              height={16}
            />
          }
          onClick={handleGoToLastPage}
          disabled={current === lastPage}
        />
      </Flex>
    </Flex>
  );
};

export default PaginationTMS;
