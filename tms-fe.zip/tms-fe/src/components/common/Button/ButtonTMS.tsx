import { Button } from 'antd';
import type { ButtonHTMLType, ButtonProps } from 'antd/es/button';
import cn from 'classnames';
import './ButtonTMS.less';

type IButtonTMSVariant = 'solid' | 'outlined';

interface IButtonTMSProps extends ButtonProps {
  onClick?: (event: React.MouseEvent<HTMLElement, MouseEvent>) => void;
  htmlType?: ButtonHTMLType;
  variant?: IButtonTMSVariant;
}

const ButtonTMS = (props: IButtonTMSProps) => {
  const { className, children, variant = 'solid', onClick, ...other } = props;

  return (
    <Button
      className={cn('button-tms', variant, className)}
      {...other}
      onClick={onClick}>
      {children}
    </Button>
  );
};

export default ButtonTMS;
