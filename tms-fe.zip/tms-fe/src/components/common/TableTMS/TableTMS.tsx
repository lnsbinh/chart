import { Table, type TableProps, type TablePaginationConfig } from 'antd';
import type { SorterResult } from 'antd/es/table/interface';
import PaginationTMS from '../PaginationTMS/PaginationTMS';
import './TableTMS.less';

const DEFAULT_HEIGHT_CONFIG = {
  rowHeight: 56,
  visibleRows: 10,
};

interface HeightConfig {
  rowHeight?: number;
  visibleRows?: number;
}

interface ITableTMSProps<T> extends TableProps<T> {
  pagination?: TablePaginationConfig;
  onPaginationChange?: (page: number, pageSize: number) => void;
  pageSizeOptions?: (string | number)[];
  hidePageSize?: boolean;
  hideTotal?: boolean;
  heightConfig?: HeightConfig;
  forceScroll?: boolean;
}

const TableTMS = <T,>({
  pagination,
  onPaginationChange,
  pageSizeOptions = [10, 20, 50, 100],
  hidePageSize = false,
  hideTotal = false,
  heightConfig,
  forceScroll = false,
  onChange,
  ...props
}: ITableTMSProps<T>) => {
  const current = pagination?.current ?? 1;
  const total = pagination?.total ?? 0;
  const pageSize = pagination?.pageSize ?? 10;

  const { rowHeight, visibleRows } = { ...DEFAULT_HEIGHT_CONFIG, ...heightConfig };
  const maxHeight = rowHeight * visibleRows;

  const dataLength = Array.isArray(props.dataSource) ? props.dataSource.length : 0;
  const shouldScroll = forceScroll || dataLength > visibleRows;

  return (
    <div className='table-tms'>
      <Table
        {...props}
        pagination={false}
        onChange={(pag, filters, sorter, extra) => {
          onChange?.(pag, filters, sorter as SorterResult<T> | SorterResult<T>[], extra);
        }}
        scroll={{
          x: 'max-content',
          y: shouldScroll ? maxHeight : undefined,
          ...props.scroll,
        }}
        style={{ ...props.style }}
      />
      {total > 0 && (
        <PaginationTMS
          current={current}
          total={total}
          pageSize={pageSize}
          onChange={(page, size) => onPaginationChange?.(page, size)}
          pageSizeOptions={pageSizeOptions}
          hidePageSize={hidePageSize}
          hideTotal={hideTotal}
        />
      )}
    </div>
  );
};

export default TableTMS;
