import { type ReactNode } from 'react';
import { useNotificationInstance } from '@/hooks/useNotify.tsx';
import { NotificationContext } from '@/contexts/NotificationContext';

export const NotificationProvider = ({ children }: { children: ReactNode }) => {
  const { contextHolder, ...methods } = useNotificationInstance();

  return (
    <NotificationContext.Provider value={methods}>
      {contextHolder}
      {children}
    </NotificationContext.Provider>
  );
};
