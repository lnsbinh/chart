import { createBrowserRouter, RouterProvider } from 'react-router';
import { Suspense } from 'react';
import { routesConfig } from './routesConfig';
import { buildRoutes } from './buildRoutes';
import { useAuth } from '@/hooks/useAuth';

const router = createBrowserRouter(buildRoutes(routesConfig));

export default function AppRouter() {
  const { isLoading } = useAuth();

  if (isLoading) return null;

  return (
    <Suspense fallback={null}>
      <RouterProvider router={router} />
    </Suspense>
  );
}
