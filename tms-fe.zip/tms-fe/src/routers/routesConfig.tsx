import { lazy, type JSX } from 'react';
import { ROUTE_PATHS } from './paths';
import { Navigate, Outlet } from 'react-router';
import Layout from '@/components/Layout/Layout';
import AuthLayout from '@/components/Layout/AuthLayout/AuthLayout';
import RoleBasedRedirect from '@/auth/RoleBasedRedirect';
import { ROLES } from '@/constants';

const SignIn = lazy(() => import('@/pages/SignIn/SignIn'));
const ForgotPassword = lazy(() => import('@/pages/ForgotPassword/ForgotPassword'));
const OTPVerification = lazy(() => import('@/pages/ForgotPassword/OTPVerification'));
const CreateNewPassword = lazy(() => import('@/pages/ForgotPassword/CreateNewPassword'));
const PasswordChanged = lazy(() => import('@/pages/ForgotPassword/PasswordChanged'));
const NotFound = lazy(() => import('@/pages/NotFound/NotFound'));

const UserManagement = lazy(() => import('@/pages/Administration/UserManagement/UserManagement'));
const MasterDataVehicle = lazy(() => import('@/pages/MasterData/Vehicle/Vehicle'));
const MasterDataCustomer = lazy(() => import('@/pages/MasterData/Customer/Customer'));
const MasterDataDriver = lazy(() => import('@/pages/MasterData/Driver/Driver'));
// const MasterDataRoute = lazy(() => import('@/pages/MasterData/RouteMaster/RouteMaster'));

export interface AppRoute {
  path: string;
  element: JSX.Element;
  children?: AppRoute[];
  allowedRoles?: string[];
}

export const routesConfig: AppRoute[] = [
  {
    path: '/',
    element: <Layout />,
    children: [
      { path: '', element: <RoleBasedRedirect /> },
      {
        path: ROUTE_PATHS.USER_MANAGEMENT.path,
        element: <UserManagement />,
        allowedRoles: [ROLES.ADMIN, ROLES.SUPERVISOR],
      },

      {
        path: ROUTE_PATHS.MASTER_DATA_CUSTOMER.path,
        element: <MasterDataCustomer />,
        allowedRoles: [ROLES.ADMIN, ROLES.SUPERVISOR, ROLES.DISPATCHER],
      },

      {
        path: ROUTE_PATHS.MASTER_DATA_VEHICLE.path,
        element: <MasterDataVehicle />,
        allowedRoles: [ROLES.ADMIN, ROLES.SUPERVISOR, ROLES.DISPATCHER],
      },

      {
        path: ROUTE_PATHS.MASTER_DATA_DRIVER.path,
        element: <MasterDataDriver />,
        allowedRoles: [ROLES.ADMIN, ROLES.SUPERVISOR, ROLES.DISPATCHER],
      },
      // { path: ROUTE_PATHS.MASTER_DATA_ROUTE.path, element: <MasterDataRoute /> },
      { path: '*', element: <NotFound /> },
    ],
  },
  {
    path: ROUTE_PATHS.SIGNIN.path,
    element: (
      <AuthLayout>
        <SignIn />
      </AuthLayout>
    ),
  },
  {
    path: ROUTE_PATHS.FORGOT_PASSWORD.path,
    element: (
      <AuthLayout>
        <Outlet />
      </AuthLayout>
    ),
    children: [
      { path: '', element: <ForgotPassword /> },
      { path: ROUTE_PATHS.FORGOT_PASSWORD_OTP.path, element: <OTPVerification /> },
      { path: ROUTE_PATHS.FORGOT_PASSWORD_NEW.path, element: <CreateNewPassword /> },
      { path: ROUTE_PATHS.FORGOT_PASSWORD_SUCCESS.path, element: <PasswordChanged /> },
    ],
  },
  {
    path: '*',
    element: (
      <Navigate
        to={ROUTE_PATHS.SIGNIN.path}
        replace
      />
    ),
  },
];
