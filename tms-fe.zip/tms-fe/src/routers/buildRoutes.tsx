import ProtectedRoute from '@/auth/ProtectedRoute';
import type { AppRoute } from './routesConfig';
import type { RouteObject } from 'react-router';

export const buildRoutes = (routes: AppRoute[]): RouteObject[] => {
  return routes.map(({ path, element, children, allowedRoles }) => ({
    path,
    element: allowedRoles?.length ? <ProtectedRoute allowedRoles={allowedRoles}>{element}</ProtectedRoute> : element,
    children: children ? buildRoutes(children) : undefined,
  }));
};
