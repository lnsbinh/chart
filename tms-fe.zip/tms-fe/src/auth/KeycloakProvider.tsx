import { useEffect, useState, type ReactNode } from 'react';
import keycloak from '@/lib/keycloak';
import { AuthContext } from '@/contexts/KeycloakContext';

export const KeycloakProvider = ({ children }: { children: ReactNode }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [roles, setRoles] = useState<string[]>([]);
  const [username, setUsername] = useState<string | undefined>();

  useEffect(() => {
    keycloak
      .init({
        onLoad: 'login-required',
        checkLoginIframe: false,
        pkceMethod: 'S256',
      })
      .then((authenticated) => {
        setIsAuthenticated(authenticated);
        if (authenticated) {
          const realmRoles = keycloak.realmAccess?.roles ?? [];
          const clientRoles = keycloak.resourceAccess?.[import.meta.env.VITE_KEYCLOAK_CLIENT_ID]?.roles ?? [];
          setRoles([...new Set([...realmRoles, ...clientRoles])]);
          setUsername(keycloak.tokenParsed?.name);
        }
      })
      .catch((err) => {
        console.error('Keycloak init error:', err);
      })
      .finally(() => {
        setIsLoading(false);
      });

    keycloak.onTokenExpired = () => {
      keycloak
        .updateToken(60)
        .then(() => {
          const realmRoles = keycloak.realmAccess?.roles ?? [];
          const clientRoles = keycloak.resourceAccess?.[import.meta.env.VITE_KEYCLOAK_CLIENT_ID]?.roles ?? [];
          setRoles([...new Set([...realmRoles, ...clientRoles])]);
        })
        .catch(() => keycloak.logout());
    };
  }, []);

  const logout = () => {
    keycloak.logout({ redirectUri: window.location.origin });
  };

  const hasRole = (role: string) => roles.includes(role);

  return (
    <AuthContext.Provider
      value={{ isAuthenticated, isLoading, token: keycloak.token, roles, username, hasRole, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
