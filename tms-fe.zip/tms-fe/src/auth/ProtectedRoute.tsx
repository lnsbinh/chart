import { Navigate } from 'react-router';
import { useAuth } from '@/hooks/useAuth';
import { ROUTE_PATHS } from '@/routers/paths';

interface Props {
  allowedRoles: string[];
  children: React.ReactNode;
}

const ProtectedRoute = ({ allowedRoles, children }: Props) => {
  const { hasRole } = useAuth();

  const isAllowed = allowedRoles.some((role) => hasRole(role));

  return isAllowed ? (
    <>{children}</>
  ) : (
    <Navigate
      to={ROUTE_PATHS.NOT_PERMISSION.path}
      replace
    />
  );
};

export default ProtectedRoute;
