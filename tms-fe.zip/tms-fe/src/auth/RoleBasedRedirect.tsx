import { Navigate } from 'react-router';
import { useAuth } from '@/hooks/useAuth';
import { ROUTE_PATHS } from '@/routers/paths';

const ROLE_REDIRECT_MAP: Record<string, string> = {
  ADMIN: ROUTE_PATHS.USER_MANAGEMENT.path,
};

const DEFAULT_REDIRECT = ROUTE_PATHS.NOT_FOUND.path;

const RoleBasedRedirect = () => {
  const { roles } = useAuth();

  const redirectPath = ROLE_REDIRECT_MAP[roles.find((role) => ROLE_REDIRECT_MAP[role]) ?? ''] ?? DEFAULT_REDIRECT;

  return (
    <Navigate
      to={redirectPath}
      replace
    />
  );
};

export default RoleBasedRedirect;
