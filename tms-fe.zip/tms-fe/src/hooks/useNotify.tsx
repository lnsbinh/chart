import { useContext } from 'react';
import { notification, type NotificationArgsProps } from 'antd';
import { NotificationContext } from '@/contexts/NotificationContext';
import { ErrorNotifyIcon, SuccessNotifyIcon, WarningNotifyIcon, InfoNotifyIcon, CloseIcon } from '@/assets';

type NotificationType = 'success' | 'error' | 'info' | 'warning';

const NOTIFICATION_ICONS: Record<NotificationType, React.ReactNode> = {
  success: (
    <SuccessNotifyIcon
      width={20}
      height={20}
    />
  ),
  error: (
    <ErrorNotifyIcon
      width={20}
      height={20}
    />
  ),
  info: (
    <InfoNotifyIcon
      width={20}
      height={20}
    />
  ),
  warning: (
    <WarningNotifyIcon
      width={20}
      height={20}
    />
  ),
};

const NOTIFICATION_CLASSES: Record<NotificationType, string> = {
  success: 'notification-success',
  error: 'notification-error',
  info: 'notification-info',
  warning: 'notification-warning',
};

const defaultConfig: Partial<NotificationArgsProps> = {
  placement: 'topRight',
  duration: 3,
  closeIcon: (
    <CloseIcon
      width={20}
      height={20}
    />
  ),
};

export const useNotificationInstance = () => {
  const [api, contextHolder] = notification.useNotification();

  const notify = (
    type: NotificationType,
    title: string,
    description?: string,
    config?: Partial<NotificationArgsProps>,
  ) => {
    api[type]({
      ...defaultConfig,
      title,
      description,
      icon: NOTIFICATION_ICONS[type],
      className: NOTIFICATION_CLASSES[type],
      ...config,
    });
  };

  return {
    contextHolder,
    success: (title: string, description?: string, config?: Partial<NotificationArgsProps>) =>
      notify('success', title, description, config),
    error: (title: string, description?: string, config?: Partial<NotificationArgsProps>) =>
      notify('error', title, description, config),
    info: (title: string, description?: string, config?: Partial<NotificationArgsProps>) =>
      notify('info', title, description, config),
    warning: (title: string, description?: string, config?: Partial<NotificationArgsProps>) =>
      notify('warning', title, description, config),
  };
};

export const useNotify = () => {
  const ctx = useContext(NotificationContext);
  if (!ctx) throw new Error('useNotify must be used inside <NotificationProvider>');
  return ctx;
};
