import { useIntl } from 'react-intl';

export function useMessageProxy<T extends Record<string, string>>(scope: string) {
  const intl = useIntl();

  return new Proxy({} as Record<keyof T, string>, {
    get(_, prop: string) {
      return intl.formatMessage({ id: `${scope}.${prop}` });
    },
  });
}
