import { useMessageProxy } from '@/hooks/useMessageProxy';
import { useNotify } from '@/hooks/useNotify';
import { apiErrorMessage } from '@/i18n/messages/common/apiError';

interface ApiErrorResponse {
  response?: {
    data?: {
      success: boolean;
      messageCode?: string;
      message?: string;
      error?: string;
    };
  };
  message?: string;
}

export const useApiError = () => {
  const msg = useMessageProxy<typeof apiErrorMessage>('apiErrorMessage');
  const { error } = useNotify();

  const handleApiError = (err: unknown) => {
    const apiErr = err as ApiErrorResponse;
    const messageCode = apiErr?.response?.data?.messageCode;
    const fallbackMessage = apiErr?.response?.data?.error ?? apiErr?.message;

    const errorText = (messageCode && msg[messageCode as keyof typeof msg]) ?? fallbackMessage ?? msg.UNKNOWN_ERROR;

    error(errorText);
  };

  return { handleApiError };
};
