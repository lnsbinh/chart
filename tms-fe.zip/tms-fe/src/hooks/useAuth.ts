import { useContext } from 'react';
import { AuthContext } from '@/contexts/KeycloakContext';

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within KeycloakProvider');
  return ctx;
};
