import ENIcon from './icons/en-icon.svg?react';
import NotifyIcon from './icons/notify-icon.svg?react';
import UserIcon from './icons/user-icon.svg?react';
import CustomerIcon from './icons/customer-icon.svg?react';
import DispatchIcon from './icons/dispatch-icon.svg?react';
import DriverIcon from './icons/driver-icon.svg?react';
import IncidentIcon from './icons/incident-icon.svg?react';
import ReportIcon from './icons/report-icon.svg?react';
import SettingIcon from './icons/setting-icon.svg?react';
import TripIcon from './icons/trip-icon.svg?react';
import VehicleIcon from './icons/vehicle-icon.svg?react';
import RouteIcon from './icons/route-icon.svg?react';
import OrderIcon from './icons/order-icon.svg?react';
import CloseIcon from './icons/close-icon.svg?react';
import MenuIcon from './icons/menu-icon.svg?react';
import LogoutIcon from './icons/logout-icon.svg?react';
import PlusIcon from './icons/plus-icon.svg?react';
import SearchIcon from './icons/search-icon.svg?react';
import DoubleNextIcon from './icons/chevrons-right-icon.svg?react';
import DoublePrevIcon from './icons/chevrons-left-icon.svg?react';
import NextIcon from './icons/chevron-right-icon.svg?react';
import PrevIcon from './icons/chevron-left-icon.svg?react';
import TrashIcon from './icons/trash-icon.svg?react';
import EditIcon from './icons/edit-icon.svg?react';
import LockIcon from './icons/lock-icon.svg?react';
import UnlockIcon from './icons/unlock-icon.svg?react';
import KeyIcon from './icons/key-icon.svg?react';
import AdminRoleIcon from './icons/admin-role-icon.svg?react';
import UserRoleIcon from './icons/user-role-icon.svg?react';
import BranchIcon from './icons/branch-icon.svg?react';
import ErrorNotifyIcon from './icons/error-notify-icon.svg?react';
import SuccessNotifyIcon from './icons/success-notify-icon.svg?react';
import WarningNotifyIcon from './icons/warning-notify-icon.svg?react';
import InfoNotifyIcon from './icons/info-notify-icon.svg?react';
import UploadIcon from './icons/upload-icon.svg?react';
import SuccessMarkIcon from './icons/success-mark-icon.svg?react';
import MoreIcon from './icons/more-icon.svg?react';
import CalendarIcon from './icons/calendar-icon.svg?react';

export {
  ENIcon,
  NotifyIcon,
  CustomerIcon,
  DispatchIcon,
  DriverIcon,
  IncidentIcon,
  ReportIcon,
  SettingIcon,
  UserIcon,
  TripIcon,
  VehicleIcon,
  RouteIcon,
  OrderIcon,
  CloseIcon,
  MenuIcon,
  LogoutIcon,
  PlusIcon,
  SearchIcon,
  DoubleNextIcon,
  DoublePrevIcon,
  NextIcon,
  PrevIcon,
  TrashIcon,
  EditIcon,
  LockIcon,
  KeyIcon,
  AdminRoleIcon,
  UserRoleIcon,
  BranchIcon,
  ErrorNotifyIcon,
  SuccessNotifyIcon,
  WarningNotifyIcon,
  InfoNotifyIcon,
  UnlockIcon,
  UploadIcon,
  SuccessMarkIcon,
  MoreIcon,
  CalendarIcon,
};
