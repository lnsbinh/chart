import { useQuery, useMutation, type UseQueryOptions } from '@tanstack/react-query';
import { request } from '@/api/request';
import { queryKeys } from '@/react-query/query-keys';
import { queryClient } from '@/react-query/query-client';
import { useApiError } from '@/hooks';

export interface Driver {
  driverId: string;
  fullName: string;
  phoneNumber: string;
  idNumber: string;
  licenseClass: string;
  licenseNumber: string;
  licenseExpiry: string;
  employmentType: string;
  driverGroup: string;
  familiarRoutes: string;
  joinDate: string;
  activeFlag: boolean;
}

export interface DriversResponse {
  content: Driver[];
  page: number;
  size: number;
  totalElements: number;
  totalPages: number;
  first: boolean;
  last: boolean;
  sort: string[];
}

export interface GetDriversParams {
  keyword?: string;
  driverType?: string;
  branchId?: string;
  employmentStatus?: string;
  page?: number;
  size?: number;
  sort?: string;
}

const apiGetDrivers = (params: GetDriversParams) => {
  const { keyword, page = 0, size = 20, sort } = params;

  const query = new URLSearchParams();
  query.set('page', String(page));
  query.set('size', String(size));
  if (sort) query.set('sort', sort);
  if (keyword) query.set('keyword', keyword);

  return request<DriversResponse>('get', `/master-data/drivers?${query.toString()}`);
};

const apiCreateDriver = (data: Partial<Driver>) => request<Driver>('post', '/master-data/drivers', data);

const apiUpdateDriver = (driverId: string, data: Partial<Driver>) =>
  request<Driver>('put', `/master-data/drivers/${driverId}`, data);

const apiDeleteDriver = (driverId: string) => request<Driver>('patch', `/master-data/drivers/${driverId}/deactivate`);

export const useGetDrivers = (
  params: GetDriversParams,
  options?: Omit<UseQueryOptions<DriversResponse>, 'queryKey' | 'queryFn'>,
) =>
  useQuery({
    queryKey: [queryKeys.drivers, params],
    queryFn: () => apiGetDrivers(params),
    ...options,
  });

export const useCreateDriver = () => {
  const { handleApiError } = useApiError();
  return useMutation({
    mutationFn: (data: Partial<Driver>) => apiCreateDriver(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [queryKeys.drivers] });
    },
    onError: handleApiError,
  });
};

export const useUpdateDriver = () => {
  const { handleApiError } = useApiError();
  return useMutation({
    mutationFn: ({ driverId, data }: { driverId: string; data: Partial<Driver> }) => apiUpdateDriver(driverId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [queryKeys.drivers] });
    },
    onError: handleApiError,
  });
};

export const useDeleteDriver = () => {
  const { handleApiError } = useApiError();
  return useMutation({
    mutationFn: ({ driverId }: { driverId: string }) => apiDeleteDriver(driverId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [queryKeys.drivers] });
    },
    onError: handleApiError,
  });
};
