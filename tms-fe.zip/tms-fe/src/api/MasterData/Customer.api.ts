import { useMutation, useQuery, useQueryClient, type UseQueryOptions } from '@tanstack/react-query';
import { request } from '../requestMasterData';
import { queryKeys } from '@/react-query/query-keys';
import type { PaginatedResponse } from './PaginatedResponse';

export interface Customer {
    id: string;
    customerId: string;
    customerName: string;
    email: string;
    contactPerson: string;
    contactPhone: string;
    companyAddress: string;
    pickupAddress: string;
    paymentTerm: string;
    creditLimit: number;
}

export interface GetCustomersParams {
    organizationId: string; // TODO: May get deleted

    keyword?: string;
    page?: number;
    size?: number;
    sort?: string;
}

export interface CustomerPayloadBase {
    organizationId: string; // TODO: May get deleted

    customerName: string;
    email: string;
    contactPerson: string;
    contactPhone: string;
    companyAddress: string;
    pickupAddress: string;
    paymentTerm: string;
    creditLimit: number;
}

export type CreateCustomerPayload = CustomerPayloadBase

export interface UpdateCustomerPayload extends CreateCustomerPayload {
    id: string;
}

/* ======================
   API
====================== */

const apiGetCustomers = (params: GetCustomersParams) => {
    const {
        organizationId,
        keyword,
        page = 0,
        size = 20,
        sort = 'id,asc',
    } = params;

    const query = new URLSearchParams({
        ...({ organizationId }),
        ...(keyword && { keyword }),
        page: String(page),
        size: String(size),
        sort,
    }).toString();

    return request<PaginatedResponse<Customer>>('get', `/master-data/customers?${query}`);
};

const apiCreateCustomer = (data: CreateCustomerPayload) => {
    return request<Customer>('post', '/master-data/customers', data);
};

const apiUpdateCustomer = (data: UpdateCustomerPayload) => {
    const { id, organizationId, ...body } = data;

    return request<Customer>(
        'put',
        `/master-data/customers/${id}?organizationId=${organizationId}`,
        {
            ...body,
            id,
            organizationId,
        }
    );
};

const apiDeactivateCustomer = (params: {
    id: string;
    organizationId: string;
}) => {
    const { id, organizationId } = params;

    return request<void>(
        'patch',
        `/master-data/customers/${id}/deactivate?organizationId=${organizationId}`
    );
};

const apiDeleteCustomer = (params: {
    id: string;
    organizationId: string;
}) => {
    const { id, organizationId } = params;

    return request<void>(
        'delete',
        `/master-data/customers/${id}?organizationId=${organizationId}`
    );
};

/* ======================
   Hooks
====================== */

export const useGetCustomers = (
    params: GetCustomersParams,
    options?: Omit<UseQueryOptions<PaginatedResponse<Customer>>, 'queryKey' | 'queryFn'>,
) =>
    useQuery({
        queryKey: [queryKeys.customers, params],
        queryFn: () => apiGetCustomers(params),
        enabled: !!params.organizationId, // avoid calling API if missing required param
        ...options,
    });

export const useCreateCustomer = () => {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: apiCreateCustomer,

        onSuccess: () => {
            // refetch customer list
            queryClient.invalidateQueries({
                queryKey: [queryKeys.customers],
            });
        },
    });
};

export const useUpdateCustomer = () => {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: apiUpdateCustomer,

        onSuccess: () => {
            queryClient.invalidateQueries({
                queryKey: [queryKeys.customers],
            });
        },
    });
};

export const useDeactivateCustomer = () => {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: apiDeactivateCustomer,

        onSuccess: () => {
            queryClient.invalidateQueries({
                queryKey: [queryKeys.customers],
            });
        },
    });
};

export const useDeleteCustomer = () => {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: apiDeleteCustomer,

        onSuccess: () => {
            queryClient.invalidateQueries({
                queryKey: [queryKeys.customers],
            });
        },
    });
};
