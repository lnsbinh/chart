import { useMutation, useQuery, useQueryClient, type UseQueryOptions } from '@tanstack/react-query';
import { request } from '../requestMasterData';
import { queryKeys } from '@/react-query/query-keys';
import type { PaginatedResponse } from './PaginatedResponse';

/* ======================
   Types
====================== */

export interface Vehicle {
    id: string;
    organizationId: string;
    vehicleCode: string;
    vehicleType: string;
    plateNo: string;
    chassisNo: string;
    engineNo: string;
    branchId: string;
    fleetTeamId: string;
    payloadKg: number;
    volumeM3: number;
    containerCapability: string;
    statusCode: 'ACTIVE' | 'INACTIVE';
    operationalState: 'AVAILABLE' | 'IN_USE' | 'MAINTENANCE';
    createdAt: string;
    updatedAt: string;
}

export interface GetVehiclesParams {
    organizationId: string;
    keyword?: string;
    vehicleType?: string;
    branchId?: string;
    operationalState?: string;
    statusCode?: string;
    page?: number;
    size?: number;
    sort?: string;
}

interface VehiclePayloadBase {
    organizationId: string;
    vehicleCode: string;
    vehicleType: string;
    plateNo: string;
    chassisNo?: string;
    engineNo?: string;
    branchId: string;
    fleetTeamId?: string;
    payloadKg: number;
    volumeM3: number;
    containerCapability?: string;
    statusCode: 'ACTIVE' | 'INACTIVE';
    operationalState?: 'AVAILABLE' | 'IN_USE' | 'MAINTENANCE';
}

export type CreateVehiclePayload = VehiclePayloadBase

export interface UpdateVehiclePayload extends Omit<VehiclePayloadBase, 'id' | 'branchId'> {
    id: string;
    branchId: string | null; // allow null to remove branch association
}

/* ======================
   API
====================== */

const apiGetVehicles = (params: GetVehiclesParams) => {
    const {
        organizationId,
        keyword,
        vehicleType,
        branchId,
        operationalState,
        statusCode,
        page = 0,
        size = 20,
        sort = 'plateNo,asc',
    } = params;

    const query = new URLSearchParams({
        organizationId,
        ...(keyword && { keyword }),
        ...(vehicleType && { vehicleType }),
        ...(branchId && { branchId }),
        ...(operationalState && { operationalState }),
        ...(statusCode && { statusCode }),
        page: String(page),
        size: String(size),
        sort,
    }).toString();

    return request<PaginatedResponse<Vehicle>>('get', `/master-data/vehicles?${query}`);
};

const apiCreateVehicle = (data: CreateVehiclePayload) => {
    return request<Vehicle>('post', '/master-data/vehicles', data);
};

const apiUpdateVehicle = (data: UpdateVehiclePayload) => {
    const { id, organizationId, ...body } = data;

    return request<Vehicle>(
        'put',
        `/master-data/vehicles/${id}?organizationId=${organizationId}`,
        {
            ...body,
            id,
            organizationId,
        }
    );
};

const apiDeactivateVehicle = (params: {
    id: string;
    organizationId: string;
}) => {
    const { id, organizationId } = params;

    return request<void>(
        'patch',
        `/master-data/vehicles/${id}/deactivate?organizationId=${organizationId}`
    );
};

const apiDeleteVehicle = (params: {
    id: string;
    organizationId: string;
}) => {
    const { id, organizationId } = params;

    return request<void>(
        'delete',
        `/master-data/vehicles/${id}?organizationId=${organizationId}`
    );
};

/* ======================
   Hooks
====================== */

export const useGetVehicles = (
    params: GetVehiclesParams,
    options?: Omit<UseQueryOptions<PaginatedResponse<Vehicle>>, 'queryKey' | 'queryFn'>,
) =>
    useQuery({
        queryKey: [queryKeys.vehicles, params],
        queryFn: () => apiGetVehicles(params),
        enabled: !!params.organizationId, // avoid calling API if missing required param
        ...options,
    });

export const useCreateVehicle = () => {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: apiCreateVehicle,

        onSuccess: () => {
            // refetch vehicle list
            queryClient.invalidateQueries({
                queryKey: [queryKeys.vehicles],
            });
        },
    });
};

export const useUpdateVehicle = () => {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: apiUpdateVehicle,

        onSuccess: () => {
            queryClient.invalidateQueries({
                queryKey: [queryKeys.vehicles],
            });
        },
    });
};

export const useDeactivateVehicle = () => {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: apiDeactivateVehicle,

        onSuccess: () => {
            queryClient.invalidateQueries({
                queryKey: [queryKeys.vehicles],
            });
        },
    });
};

export const useDeleteVehicle = () => {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: apiDeleteVehicle,

        onSuccess: () => {
            queryClient.invalidateQueries({
                queryKey: [queryKeys.vehicles],
            });
        },
    });
};
