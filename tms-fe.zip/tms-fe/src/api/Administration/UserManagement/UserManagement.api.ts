import { useQuery, useMutation, type UseQueryOptions } from '@tanstack/react-query';
import { request } from '@/api/request';
import { queryKeys } from '@/react-query/query-keys';
import { queryClient } from '@/react-query/query-client';
import { useApiError } from '@/hooks/useApiError';
import { ROLES } from '@/constants';

/* ======================
   Types
====================== */
export type RoleCode = (typeof ROLES)[keyof typeof ROLES];

export interface Role {
  id: string;
  code: RoleCode;
  name: string;
  description: string;
  activeFrom: Date;
  activeTo: Date | null;
}
export interface Branch {
  id: string;
  code: string;
  name: string;
  address: string;
  statusCode: 'ACTIVE' | 'INACTIVE';
}
export interface User {
  id: string;
  userCode: string;
  username: string;
  email: string;
  phone: string | null;
  firstName: string;
  lastName: string;
  statusCode: 'ACTIVE' | 'LOCKED';
  avatarUrl: string;
  roles: Role[];
  branches: Branch[];
}

export interface PaginatedResponse<T> {
  success: boolean;
  data: {
    content: T[];
    page: number;
    size: number;
    totalElements: number;
    totalPages: number;
  };
}
export interface RolesResponse<T> {
  success: boolean;
  data: T[];
}

export interface BranchesResponse<T> {
  success: boolean;
  data: T[];
}

export interface CreateUserPayload {
  username: string;
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  roleIds: string[];
  branchIds: string[];
  avatarUrl?: string;
  status: string;
}
export interface CreateUserResponse {
  success: boolean;
  data: {
    userId: string;
  };
}

export interface UpdateUserPayload {
  firstName?: string;
  lastName?: string;
  email?: string;
  roleIds?: string[];
  branchIds?: string[];
}

export interface ToggleStatusPayload {
  status: 'ACTIVE' | 'LOCKED';
}

export type SortOrder = 'asc' | 'desc' | undefined;

export interface GetUsersParams {
  page?: number;
  size?: number;
  status?: string[];
  roleIds?: string[];
  branchIds?: string[];
  idSort?: SortOrder;
  statusSort?: SortOrder;
  search?: string;
}

export interface UploadAvatarResponse {
  success: boolean;
  data: {
    avatarUrl: string;
  };
}

/* ======================
   API
====================== */

const apiGetUsers = (params: GetUsersParams = {}) => {
  const { page = 0, size = 10, status, roleIds, branchIds, idSort, statusSort, search } = params;

  const query = new URLSearchParams();
  query.set('page', String(page));
  query.set('size', String(size));
  if (status?.length) query.set('status', status.join(','));
  if (roleIds?.length) query.set('roleIds', roleIds.join(','));
  if (branchIds?.length) query.set('branchIds', branchIds.join(','));
  if (idSort) query.set('idSort', idSort);
  if (statusSort) query.set('statusSort', statusSort);
  if (search) query.set('search', search);

  return request<PaginatedResponse<User>>('get', `/users?${query.toString()}`);
};

const apiCreateUser = (data: CreateUserPayload) => request<CreateUserResponse>('post', '/users', data);

const apiUpdateUser = (userId: string, data: UpdateUserPayload) => request<User>('put', `/users/${userId}`, data);

const apiChangeUserStatus = (userId: string, data: ToggleStatusPayload) =>
  request<void>('patch', `/users/${userId}/status`, data);

const apiGetRoles = () => request<RolesResponse<Role>>('get', '/roles');

const apiGetBranches = () => request<BranchesResponse<Branch>>('get', '/branches');

const apiResetPassword = (userId: string) => request<User>('post', `/users/${userId}/reset-password`);

const apiDeleteUser = (userId: string) => request<User>('patch', `/users/${userId}/delete`);

const apiUploadAvatar = (userId: string, file: File) => {
  const formData = new FormData();
  formData.append('file', file);
  return request<UploadAvatarResponse>('post', `/users/${userId}/avatar`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
};

/* ======================
   Hooks
====================== */

export const useGetUsers = (
  params: GetUsersParams = {},
  options?: Omit<UseQueryOptions<PaginatedResponse<User>>, 'queryKey' | 'queryFn'>,
) =>
  useQuery({
    queryKey: [queryKeys.users, params],
    queryFn: () => apiGetUsers(params),
    ...options,
  });

export const useCreateUser = () => {
  const { handleApiError } = useApiError();
  return useMutation({
    mutationFn: (data: CreateUserPayload) => apiCreateUser(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [queryKeys.users] });
    },
    onError: handleApiError,
  });
};

export const useUpdateUser = () => {
  const { handleApiError } = useApiError();
  return useMutation({
    mutationFn: ({ userId, data }: { userId: string; data: UpdateUserPayload }) => apiUpdateUser(userId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [queryKeys.users] });
    },
    onError: handleApiError,
  });
};

export const useChangeUserStatus = () => {
  const { handleApiError } = useApiError();
  return useMutation({
    mutationFn: ({ userId, status }: { userId: string; status: 'ACTIVE' | 'LOCKED' }) =>
      apiChangeUserStatus(userId, { status }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [queryKeys.users] });
    },
    onError: handleApiError,
  });
};

export const useGetRoles = (options?: Omit<UseQueryOptions<RolesResponse<Role>>, 'queryKey' | 'queryFn'>) =>
  useQuery({
    queryKey: [queryKeys.roles],
    queryFn: apiGetRoles,
    ...options,
  });

export const useGetBranches = (options?: Omit<UseQueryOptions<BranchesResponse<Branch>>, 'queryKey' | 'queryFn'>) =>
  useQuery({
    queryKey: [queryKeys.branches],
    queryFn: apiGetBranches,
    ...options,
  });

export const useResetPassword = () => {
  return useMutation({
    mutationFn: ({ userId }: { userId: string }) => apiResetPassword(userId),
  });
};

export const useDeleteUser = () => {
  const { handleApiError } = useApiError();
  return useMutation({
    mutationFn: ({ userId }: { userId: string }) => apiDeleteUser(userId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [queryKeys.users] });
    },
    onError: handleApiError,
  });
};

export const useUploadAvatar = () => {
  return useMutation({
    mutationFn: ({ userId, file }: { userId: string; file: File }) => apiUploadAvatar(userId, file),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [queryKeys.users] });
    },
  });
};
