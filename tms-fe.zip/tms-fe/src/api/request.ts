import axios from 'axios';
import type { AxiosError, AxiosRequestConfig, Method, InternalAxiosRequestConfig } from 'axios';
import keycloak from '@/lib/keycloak';

const axiosInstance = axios.create({
  baseURL: `${import.meta.env.VITE_API_BASE_URL}/api/v1`,
  timeout: 15000,
  headers: {
    'Content-Type': 'application/json',
  },
});

axiosInstance.interceptors.request.use(
  async (config: InternalAxiosRequestConfig) => {
    if (keycloak.isTokenExpired(60)) {
      await keycloak.updateToken(60).catch(() => keycloak.logout());
    }

    if (keycloak.token) {
      config.headers.Authorization = `Bearer ${keycloak.token}`;
    }

    return config;
  },
  (error) => Promise.reject(error),
);

axiosInstance.interceptors.response.use(
  (response) => response.data,
  (error: AxiosError) => {
    if (error.response?.status === 401) {
      keycloak.logout({ redirectUri: window.location.origin });
    }

    return Promise.reject(error);
  },
);

export function request<T>(method: Method, url: string, data?: unknown, config?: AxiosRequestConfig): Promise<T> {
  return axiosInstance({
    method,
    url,
    data,
    ...config,
  });
}
