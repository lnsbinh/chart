import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { request } from '../request';
import { queryKeys } from "@/react-query/query-keys";

export interface User {
  id: number;
  name: string;
  email: string;
}

/* ======================
   API
====================== */

const apiGetUsers = () => request<User[]>('get', '/users');

const apiCreateUser = (data: Partial<User>) => request<User>('post', '/users', data);

const apiUpdateUser = (id: number, data: Partial<User>) => request<User>('put', `/users/${id}`, data);

const apiDeleteUser = (id: number) => request<void>('delete', `/users/${id}`);

/* ======================
   Hooks
====================== */

// GET users
export const useUsers = () =>
  useQuery({
    queryKey: [queryKeys.users],
    queryFn: apiGetUsers,
  });

// CREATE
export const useCreateUser = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: apiCreateUser,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [queryKeys.users] });
    },
  });
};

// UPDATE
export const useUpdateUser = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, data }: { id: number; data: Partial<User> }) => apiUpdateUser(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [queryKeys.users] });
    },
  });
};

// DELETE
export const useDeleteUser = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: apiDeleteUser,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [queryKeys.users] });
    },
  });
};
