import { useMemo } from 'react';
import { Form, Row, Col, Select, Flex, Upload } from 'antd';
import type { UploadFile, UploadProps } from 'antd';
import { useEffect, useState } from 'react';
import ModalBase from '@/components/common/Modal/ModalBase/ModalBase';
import AppInput from '@/components/common/Input/Input';
import CheckableTagTMS from '@/components/common/CheckableTag/CheckableTagTMS';
import type { userManagementMessage } from '@/i18n/messages/admin/UserManagement/UserManagement';
import { useMessageProxy } from '@/hooks/useMessageProxy';
import { AdminRoleIcon, UserRoleIcon, BranchIcon, UploadIcon } from '@/assets';
import { ROLES, USER_STATUS, type UserStatus } from '@/constants';
import { useNotify } from '@/hooks/useNotify';
import imageDefault from '@/assets/images/image-default.png';
import { useGetBranches, useGetRoles } from '@/api/Administration/UserManagement/UserManagement.api';
import './UserFormModal.less';

const { Dragger } = Upload;

export interface IUserForm {
  userCode?: string;
  firstName: string;
  lastName: string;
  username: string;
  email: string;
  password: string;
  confirmPassword: string;
  status: UserStatus;
  roles: string[];
  branches: string[];
  avatar?: UploadFile;
  avatarUrl?: string;
}

interface IUserFormModalProps {
  open: boolean;
  isUpdateMode: boolean;
  loadingSubmit?: boolean;
  initialValues?: Partial<IUserForm>;
  onSubmit: (values: IUserForm) => void;
  onCancel: () => void;
}

const defaultValues: Partial<IUserForm> = {
  status: USER_STATUS.ACTIVE,
};

const UserFormModal = ({
  open,
  isUpdateMode,
  initialValues,
  loadingSubmit = false,
  onSubmit,
  onCancel,
}: IUserFormModalProps) => {
  const [form] = Form.useForm<IUserForm>();
  const [avatarFile, setAvatarFile] = useState<UploadFile | null>(null);
  const msg = useMessageProxy<typeof userManagementMessage>('userManagementMessage');
  const { error } = useNotify();

  const { data: roles, isLoading: loadingRoles } = useGetRoles({ enabled: open });
  const { data: branches, isLoading: loadingBranches } = useGetBranches({ enabled: open });
  useEffect(() => {
    if (!open) return;
    form.resetFields();
    form.setFieldsValue(initialValues ? { ...defaultValues, ...initialValues } : defaultValues);
  }, [open, form, initialValues]);

  const previewUrl = useMemo(() => {
    if (avatarFile?.originFileObj) return URL.createObjectURL(avatarFile.originFileObj);
    if (avatarFile?.url) return avatarFile.url;
    return null;
  }, [avatarFile]);

  useEffect(() => {
    return () => {
      if (previewUrl?.startsWith('blob:')) URL.revokeObjectURL(previewUrl);
    };
  }, [previewUrl]);

  const handleOk = async () => {
    try {
      const values = await form.validateFields();
      onSubmit({ ...values, avatar: avatarFile ?? undefined });
    } catch (err) {
      console.error(err);
    }
  };

  const uploadProps: UploadProps = {
    name: 'file',
    multiple: false,
    accept: '.jpg,.jpeg,.png',
    showUploadList: false,
    maxCount: 1,
    customRequest: ({ onSuccess }) => {
      onSuccess?.('ok');
    },
    beforeUpload: (file) => {
      const isImage = ['image/jpeg', 'image/png'].includes(file.type);
      const isLt2M = file.size / 1024 / 1024 < 2;
      if (!isImage) error('Only JPG/PNG files are allowed');
      if (!isLt2M) error('Image must be smaller than 2MB');
      return isImage && isLt2M;
    },
    onChange: ({ file }) => {
      if (file.status === 'done') setAvatarFile(file);
    },
  };

  const rolesWithIcon = (roles?.data ?? []).map((role) => ({
    ...role,
    label: role.name,
    value: role.id,
    icon:
      role.name === ROLES.ADMIN ? (
        <AdminRoleIcon
          width={20}
          height={20}
        />
      ) : (
        <UserRoleIcon
          width={20}
          height={20}
        />
      ),
  }));

  const branchesWithIcon = (branches?.data ?? []).map((branch) => ({
    ...branch,
    label: branch.name,
    value: branch.id,
    icon: (
      <BranchIcon
        width={20}
        height={20}
      />
    ),
  }));

  const passwordRules = [
    { required: true, message: msg.passwordRequired },
    {
      validator(_: unknown, value: string) {
        if (!value) return Promise.resolve();
        if (value.length < 8) return Promise.reject(new Error(msg.passwordMinLength));
        if (!/[A-Z]/.test(value)) return Promise.reject(new Error(msg.passwordUppercase));
        if (!/[a-z]/.test(value)) return Promise.reject(new Error(msg.passwordLowercase));
        if (!/[0-9]/.test(value)) return Promise.reject(new Error(msg.passwordNumber));
        if (!/[^A-Za-z0-9]/.test(value)) return Promise.reject(new Error(msg.passwordSpecial));
        return Promise.resolve();
      },
    },
  ];

  const loadingModal = loadingRoles || loadingBranches;

  return (
    <ModalBase
      open={open}
      title={!isUpdateMode ? msg.addNewUser : msg.updateUser}
      okText={!isUpdateMode ? msg.createUser : msg.save}
      onOk={handleOk}
      onCancel={onCancel}
      loading={loadingModal}
      confirmLoading={loadingSubmit}
      className='user-form-modal'>
      <Form
        form={form}
        layout='vertical'
        requiredMark={(label, { required }) => (
          <>
            {label}
            {required && <span className='required-mark'>*</span>}
          </>
        )}>
        <p className='user-form-modal__title'>{!isUpdateMode ? msg.titleCreate : msg.titleUpdate}</p>
        <Row gutter={[16, 16]}>
          <Col span={12}>
            <div className='ant-form-item-label ant-form-item-label__dragger'>
              <label>{msg.avatar}</label>
            </div>
            <div className='ant-form-item'>
              <Dragger
                {...uploadProps}
                className='user-form-modal__dragger'>
                <img
                  src={previewUrl ?? initialValues?.avatarUrl ?? imageDefault}
                  alt='avatar'
                  className='user-form-modal__avatar-preview'
                />
                <p className='ant-upload-hint'>{msg.supportFormats}: JPG, PNG</p>
                <Flex
                  gap={8}
                  align='center'
                  justify='center'>
                  <UploadIcon
                    width={24}
                    height={24}
                  />
                  <span className='user-form-modal__upload'>{msg.upload}</span>
                </Flex>
              </Dragger>
            </div>
          </Col>
          <Col span={12}>
            <Flex
              vertical
              gap={16}>
              <Form.Item
                name='userCode'
                label={msg.userCode}>
                <AppInput disabled />
              </Form.Item>
              <Form.Item
                name='status'
                label={msg.status}>
                <Select
                  disabled={isUpdateMode}
                  options={[
                    { value: USER_STATUS.ACTIVE, label: msg.active },
                    { value: USER_STATUS.LOCKED, label: msg.locked },
                  ]}
                />
              </Form.Item>
            </Flex>
          </Col>
          <Col span={12}>
            <Form.Item
              name='firstName'
              label={msg.firstName ?? 'First Name'}
              rules={[{ required: true, message: msg.firstNameRequired ?? 'First name is required' }]}>
              <AppInput placeholder='e.g. Van A' />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              name='lastName'
              label={msg.lastName ?? 'Last Name'}
              rules={[{ required: true, message: msg.lastNameRequired ?? 'Last name is required' }]}>
              <AppInput placeholder='e.g. Nguyen' />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              name='username'
              label={msg.username}
              rules={[{ required: true, message: msg.usernameRequired }]}>
              <AppInput
                placeholder='e.g. nguyenvana'
                disabled={isUpdateMode}
              />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              name='email'
              label={msg.email}
              rules={[
                { required: true, message: msg.emailRequired },
                { type: 'email', message: msg.emailInvalid },
              ]}>
              <AppInput placeholder='e.g. nguyenvana@gmail.com' />
            </Form.Item>
          </Col>
          {!isUpdateMode && (
            <>
              <Col span={12}>
                <Form.Item
                  name='password'
                  label={msg.password}
                  rules={passwordRules}>
                  <AppInput
                    type='password'
                    placeholder={msg.passwordPlaceholder}
                    visibilityToggle={false}
                  />
                </Form.Item>
              </Col>
              <Col span={12}>
                <Form.Item
                  name='confirmPassword'
                  label={msg.confirmPassword}
                  rules={[
                    { required: true, message: msg.confirmPasswordRequired },
                    ({ getFieldValue }) => ({
                      validator(_, value) {
                        if (!value || getFieldValue('password') === value) return Promise.resolve();
                        return Promise.reject(new Error(msg.confirmPasswordMismatch));
                      },
                    }),
                  ]}>
                  <AppInput
                    type='password'
                    placeholder={msg.confirmPasswordPlaceholder}
                    visibilityToggle={false}
                  />
                </Form.Item>
              </Col>
            </>
          )}
          <Col span={24}>
            <Form.Item
              name='roles'
              label={msg.roles}
              htmlFor={undefined}
              rules={[{ required: true, message: msg.rolesRequired }]}>
              <CheckableTagTMS
                multiple
                options={rolesWithIcon}
              />
            </Form.Item>
          </Col>
          <Col span={24}>
            <Form.Item
              name='branches'
              label={msg.branches}
              htmlFor={undefined}
              rules={[{ required: true, message: msg.branchesRequired }]}>
              <CheckableTagTMS
                multiple
                options={branchesWithIcon}
              />
            </Form.Item>
          </Col>
        </Row>
      </Form>
    </ModalBase>
  );
};

export default UserFormModal;
