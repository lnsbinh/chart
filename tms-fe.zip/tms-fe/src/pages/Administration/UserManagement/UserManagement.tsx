import { useState } from 'react';
import { Button, Space, Avatar, Flex, Dropdown } from 'antd';
import type { TablePaginationConfig } from 'antd';
import type { ColumnsType, SorterResult } from 'antd/es/table/interface';
import { userManagementMessage } from '@/i18n/messages/admin/UserManagement/UserManagement';
import type { commonMessage } from '@/i18n/messages/common/common';
import { useMessageProxy, useApiError, useDebounce, useNotify } from '@/hooks';
import RightBannerLayout from '@/components/common/RightPanelLayout/RightPanelLayout';
import ButtonTMS from '@/components/common/Button/ButtonTMS';
import TableTMS from '@/components/common/TableTMS/TableTMS';
import FilterPopover from '@/components/common/FilterPopover/FilterPopover';
import StatusTag from '@/components/common/StatusTag/StatusTag';
import InputTMS from '@/components/common/Input/Input';
import ModalConfirm from '@/components/common/Modal/ModalConfirm/ModalConfirm';
import { PlusIcon, SearchIcon, MoreIcon } from '@/assets';
import defaultAvatar from '@/assets/images/avatar-default.jpg';
import { USER_STATUS } from '@/constants';
import {
  useGetUsers,
  useCreateUser,
  useUpdateUser,
  useChangeUserStatus,
  useResetPassword,
  useDeleteUser,
  useGetRoles,
  useGetBranches,
  useUploadAvatar,
  type User,
  type SortOrder,
} from '@/api/Administration/UserManagement/UserManagement.api';
import UserFormModal, { type IUserForm } from './UserFormModal/UserFormModal';
import './UserManagement.less';

const icon = (Icon: React.FC<{ width: number; height: number }>) => (
  <Icon
    width={20}
    height={20}
  />
);

type ModalType = 'edit' | 'lock' | 'unlock' | 'reset' | 'delete' | null;

// Map antd sorter order → API sort order
const toSortOrder = (order?: 'ascend' | 'descend' | null): SortOrder => {
  if (order === 'ascend') return 'asc';
  if (order === 'descend') return 'desc';
  return undefined;
};

const ViewUserManagement = () => {
  const msg = useMessageProxy<typeof userManagementMessage>('userManagementMessage');
  const commonMsg = useMessageProxy<typeof commonMessage>('commonMessage');
  const { handleApiError } = useApiError();
  const { success, error } = useNotify();

  const [pagination, setPagination] = useState<TablePaginationConfig>({
    current: 1,
    pageSize: 10,
  });

  const [selectedStatuses, setSelectedStatuses] = useState<string[]>([]);
  const [selectedRoles, setSelectedRoles] = useState<string[]>([]);
  const [selectedBranches, setSelectedBranches] = useState<string[]>([]);

  const [idSort, setIdSort] = useState<SortOrder>(undefined);
  const [statusSort, setStatusSort] = useState<SortOrder>(undefined);

  const [selectedRow, setSelectedRow] = useState<string | null>(null);
  const [modalType, setModalType] = useState<ModalType>(null);
  const [search, setSearch] = useState('');
  const debouncedSearch = useDebounce(search, 500);
  const { data: userData, isLoading } = useGetUsers({
    page: (pagination.current ?? 1) - 1,
    size: pagination.pageSize ?? 10,
    status: selectedStatuses,
    roleIds: selectedRoles ?? [],
    branchIds: selectedBranches ?? [],
    idSort,
    statusSort,
    search: debouncedSearch,
  });

  const { data: rolesData } = useGetRoles();
  const { data: branchesData } = useGetBranches();

  const users = userData?.data.content ?? [];
  const totalItems = userData?.data.totalElements ?? 0;

  const { mutate: createUser, isPending: isCreating } = useCreateUser();
  const { mutate: updateUser, isPending: isUpdating } = useUpdateUser();
  const { mutate: changeStatus } = useChangeUserStatus();
  const { mutate: resetPassword } = useResetPassword();
  const { mutate: deleteUser } = useDeleteUser();
  const { mutateAsync: uploadAvatar, isPending: isUploading } = useUploadAvatar();

  const handleOpenModal = (id: string, type: ModalType) => {
    setSelectedRow(id);
    setModalType(type);
  };

  const handleCancel = () => {
    setSelectedRow(null);
    setModalType(null);
  };

  // Reset to page 1 whenever filter/sort changes
  const resetPage = () => setPagination((prev) => ({ ...prev, current: 1 }));

  const handleRoleChange = (values: string[]) => {
    setSelectedRoles(values);
    resetPage();
  };

  const handleBranchChange = (values: string[]) => {
    setSelectedBranches(values);
    resetPage();
  };

  const handleStatusChange = (values: string[]) => {
    setSelectedStatuses(values);
    resetPage();
  };

  const handleTableChange = (
    _: TablePaginationConfig,
    __: unknown,
    sorter: SorterResult<TableRow> | SorterResult<TableRow>[],
  ) => {
    const s = Array.isArray(sorter) ? sorter[0] : sorter;

    if (!s.order) {
      setIdSort(undefined);
      setStatusSort(undefined);
    } else if (s.columnKey === 'userId') {
      setIdSort(toSortOrder(s.order));
      setStatusSort(undefined);
    } else if (s.columnKey === 'status') {
      setStatusSort(toSortOrder(s.order));
      setIdSort(undefined);
    }
    resetPage();
  };

  const handleAvatarUpload = async (userId: string, avatar?: IUserForm['avatar']) => {
    if (!avatar?.originFileObj) return;
    try {
      await uploadAvatar({ userId, file: avatar.originFileObj as File });
    } catch {
      error(msg.avatarUploadError);
    }
  };

  const handleSubmit = (value: IUserForm) => {
    if (selectedRow) {
      updateUser(
        {
          userId: selectedRow,
          data: {
            firstName: value.firstName,
            lastName: value.lastName,
            email: value.email,
            roleIds: value.roles,
            branchIds: value.branches,
          },
        },
        {
          onSuccess: async () => {
            await handleAvatarUpload(selectedRow, value.avatar);
            success(msg.userUpdatedSuccess);
            handleCancel();
          },
          onError: handleApiError,
        },
      );
    } else {
      createUser(
        {
          username: value.username,
          firstName: value.firstName,
          lastName: value.lastName,
          email: value.email,
          password: value.password,
          roleIds: value.roles,
          branchIds: value.branches,
          status: value.status,
        },
        {
          onSuccess: async (res) => {
            await handleAvatarUpload(res.data.userId, value.avatar);
            success(msg.userCreatedSuccess);
            handleCancel();
          },
          onError: handleApiError,
        },
      );
    }
  };

  const handleLock = () => {
    if (!selectedRow) return;
    changeStatus(
      { userId: selectedRow, status: USER_STATUS.LOCKED },
      {
        onSuccess: () => {
          success(msg.userLocked);
          handleCancel();
        },
      },
    );
  };

  const handleUnlock = () => {
    if (!selectedRow) return;
    changeStatus(
      { userId: selectedRow, status: USER_STATUS.ACTIVE },
      {
        onSuccess: () => {
          success(msg.userUnlocked);
          handleCancel();
        },
      },
    );
  };

  const handleResetPassword = () => {
    if (!selectedRow) return;
    resetPassword(
      { userId: selectedRow },
      {
        onSuccess: () => {
          success(msg.passwordResetSuccess);
          handleCancel();
        },
        onError: () => error(msg.passwordResetError),
      },
    );
  };

  const handleDeleteUser = () => {
    if (!selectedRow) return;
    deleteUser(
      { userId: selectedRow },
      {
        onSuccess: () => {
          success(msg.deleteUserSuccess);
          handleCancel();
        },
        onError: () => error(msg.deleteUserError),
      },
    );
  };

  const handleSearch = (value: string) => {
    setSearch(value);
    resetPage();
  };

  const roleOptions = (rolesData?.data ?? []).map((r) => ({
    label: r.name,
    value: r.id,
  }));

  const branchOptions = (branchesData?.data ?? []).map((b) => ({
    label: b.name,
    value: b.id,
  }));

  const statusOptions = [
    { label: msg.active, value: USER_STATUS.ACTIVE },
    { label: msg.locked, value: USER_STATUS.LOCKED },
  ];

  const tableData = users.map((u: User) => ({
    ...u,
    fullName: `${u.firstName} ${u.lastName}`,
    status: u.statusCode,
    roles: u.roles.map((role) => role.name).join(', '),
    branches: u.branches.map((branch) => branch.name).join(', '),
  }));

  type TableRow = (typeof tableData)[number];

  const selectedUser = users.find((u) => u.id === selectedRow);
  const editInitialValues: Partial<IUserForm> = selectedUser
    ? {
        ...selectedUser,
        status: selectedUser.statusCode,
        roles: selectedUser.roles?.map((r) => r.id) ?? [],
        branches: selectedUser.branches?.map((b) => b.id) ?? [],
      }
    : {};

  const columns: ColumnsType<TableRow> = [
    {
      title: msg.userId,
      dataIndex: 'userCode',
      key: 'userId',
      width: 180,
      sorter: true,
      sortOrder: idSort === 'asc' ? 'ascend' : idSort === 'desc' ? 'descend' : null,
    },
    {
      title: msg.user,
      dataIndex: 'fullName',
      key: 'user',
      render: (text: string, record: TableRow) => (
        <Space>
          <Avatar
            src={record.avatarUrl ?? defaultAvatar}
            size={32}>
            {text.charAt(0)}
          </Avatar>
          <div>
            <div style={{ fontWeight: 500, color: '#454545' }}>{text}</div>
            <div style={{ fontSize: 14, color: '#9F9F9F' }}>{record.email}</div>
          </div>
        </Space>
      ),
    },
    { title: msg.email, dataIndex: 'email', key: 'email' },
    {
      title: msg.roles,
      dataIndex: 'roles',
      key: 'roles',
      width: 250,
    },
    {
      title: msg.branches,
      dataIndex: 'branches',
      key: 'branches',
      width: 300,
    },
    {
      title: msg.status,
      dataIndex: 'status',
      key: 'status',
      sorter: true,
      sortOrder: statusSort === 'asc' ? 'ascend' : statusSort === 'desc' ? 'descend' : null,
      width: 130,
      render: (status) => <StatusTag status={status.toLocaleLowerCase()} />,
    },
    {
      title: commonMsg.action,
      key: 'action',
      width: 77,
      align: 'center',
      render: (_: unknown, record: TableRow) => (
        <Dropdown
          trigger={['click']}
          menu={{
            className: 'user-management-menu',
            items: [
              {
                key: 'edit',
                label: commonMsg.edit,
                onClick: () => handleOpenModal(record.id, 'edit'),
              },
              {
                key: 'lock',
                label: record.status === USER_STATUS.ACTIVE ? commonMsg.lock : commonMsg.unlock,
                onClick: () => handleOpenModal(record.id, record.status === USER_STATUS.ACTIVE ? 'lock' : 'unlock'),
              },
              {
                key: 'resetPassword',
                label: commonMsg.resetPassword,
                onClick: () => handleOpenModal(record.id, 'reset'),
              },
              {
                key: 'delete',
                label: commonMsg.delete,
                onClick: () => handleOpenModal(record.id, 'delete'),
              },
            ],
          }}>
          <Button
            type='text'
            size='small'
            icon={
              <MoreIcon
                width={20}
                height={20}
              />
            }
          />
        </Dropdown>
      ),
    },
  ];

  return (
    <RightBannerLayout
      title={msg.title}
      className='user-management'>
      <Flex
        justify='space-between'
        align='center'
        style={{ marginBottom: 24 }}>
        <Space className='user-management-filter'>
          <InputTMS
            prefix={icon(SearchIcon)}
            placeholder={msg.search}
            onChange={(e) => handleSearch(e.target.value)}
            className='search'
          />
          <FilterPopover
            title={msg.allRoles}
            options={roleOptions}
            selectedValues={selectedRoles}
            onChange={handleRoleChange}
          />
          <FilterPopover
            title={msg.allBranches}
            options={branchOptions}
            selectedValues={selectedBranches}
            onChange={handleBranchChange}
          />
          <FilterPopover
            title={msg.allStatus}
            options={statusOptions}
            selectedValues={selectedStatuses}
            onChange={handleStatusChange}
          />
        </Space>
        <ButtonTMS
          type='primary'
          onClick={() => handleOpenModal('', 'edit')}>
          {msg.addUser}
          {icon(PlusIcon)}
        </ButtonTMS>
      </Flex>

      <TableTMS
        columns={columns}
        dataSource={tableData}
        loading={isLoading}
        pagination={{ ...pagination, total: totalItems }}
        rowKey={(record) => record.id}
        onChange={handleTableChange}
        onPaginationChange={(page, pageSize) => setPagination({ current: page, pageSize })}
        pageSizeOptions={[10, 20, 50, 100]}
        className='user-management-table'
        heightConfig={{ rowHeight: 69, visibleRows: 7 }}
      />

      <UserFormModal
        key={selectedRow ?? 'create'}
        open={modalType === 'edit'}
        initialValues={editInitialValues}
        isUpdateMode={!!selectedRow}
        loadingSubmit={isCreating || isUpdating || isUploading}
        onSubmit={handleSubmit}
        onCancel={handleCancel}
      />
      <ModalConfirm
        open={modalType === 'lock'}
        type='warning'
        title={msg.lockAccountTitle}
        description={msg.lockAccountDescription}
        onOk={handleLock}
        onCancel={handleCancel}
      />
      <ModalConfirm
        open={modalType === 'unlock'}
        type='info'
        title={msg.unlockAccountTitle}
        description={msg.unlockAccountDescription}
        onOk={handleUnlock}
        onCancel={handleCancel}
      />
      <ModalConfirm
        open={modalType === 'reset'}
        type='info'
        title={msg.resetPasswordTitle}
        description={msg.resetPasswordDescription}
        onOk={handleResetPassword}
        onCancel={handleCancel}
      />
      <ModalConfirm
        open={modalType === 'delete'}
        type='danger'
        title={msg.deleteAccountTitle}
        description={msg.deleteAccountDescription}
        onOk={handleDeleteUser}
        onCancel={handleCancel}
      />
    </RightBannerLayout>
  );
};

export default ViewUserManagement;
