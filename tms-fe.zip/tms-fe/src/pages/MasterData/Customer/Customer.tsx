import "@/pages/MasterData/common/MasterData.less";
import "./Customer.less";

import { Button, Dropdown, Flex, Space } from "antd";
import type { FilterValue, SorterResult } from "antd/es/table/interface";
import { MoreIcon, PlusIcon, SearchIcon } from "@/assets";
import type { TableColumnsType, TablePaginationConfig } from "antd";

import ButtonTMS from "@/components/common/Button/ButtonTMS";
import {
    useCreateCustomer,
    useDeleteCustomer,
    useGetCustomers,
    useUpdateCustomer,
    type Customer,
} from "@/api/MasterData/Customer.api";
import CustomerFormModal, { type ICustomerForm } from "./CustomerFormModal/CustomerFormModal";
import type { FormType } from "../common/MasterDataFormModal";
import InputTMS from "@/components/common/Input/Input";
import ModalConfirm from "@/components/common/Modal/ModalConfirm/ModalConfirm";
import RightBannerLayout from "@/components/common/RightPanelLayout/RightPanelLayout";
import TableTMS from "@/components/common/TableTMS/TableTMS";
import type { commonMessage } from "@/i18n/messages/common/common";
import type { customerMessage } from "@/i18n/messages/masterData/Customer";
import { useApiError } from "@/hooks/useApiError";
import { useDebounce } from "@/hooks/useDebounce";
import { useMessageProxy } from "@/hooks/useMessageProxy";
import { useNotify } from "@/hooks/useNotify";
import { useState } from "react";

type CustomerModalType = "create" | "edit" | "delete" | "view" | null;

// const useGetCustomers = (params: unknown) => {
//     console.log("API CALL (stub):", params);

//     return {
//         data: {
//             content: Array.from({ length: 10 }).map((_, i) => ({
//                 id: String(i + 1),
//                 customerId: "USR001",
//                 customerName: "Kho gia dụng Tấn Tài",
//                 contactPerson: "Nguyễn Tấn Tài",
//                 phone: "0987654321",
//                 email: "ctytantai@gmail.com",
//                 paymentTerm: "30 days",
//                 creditLimit: 30000000,
//             })),
//             totalElements: 15458,
//         },
//         isLoading: false,
//     };
// };

const MasterDataCustomer = () => {
    const commonMsg = useMessageProxy<typeof commonMessage>("commonMessage");
    const msg = useMessageProxy<typeof customerMessage>("customerMessage");
    const { success } = useNotify();
    const { handleApiError } = useApiError();

    const [pagination, setPagination] = useState<TablePaginationConfig>({
        current: 1,
        pageSize: 10,
    });

    const DEFAULT_SORT = "customerId,asc";
    const [sort, setSort] = useState(DEFAULT_SORT);
    const [keyword, setKeyword] = useState("");
    const debouncedKeyword = useDebounce(keyword, 500);

    const [modalType, setModalType] = useState<CustomerModalType>(null);
    const [selectedRow, setSelectedRow] = useState<string | null>(null);

    const { data, isLoading } = useGetCustomers({
        organizationId: "a14100e4-fd2b-4313-bb23-498feb4aa2ed", // TODO: find out how to get organizationId
        keyword: debouncedKeyword,
        sort,
        page: (pagination.current ?? 1) - 1,
        size: pagination.pageSize ?? 10,
    });

    const { mutate: createCustomer, isPending: loadingCreate } =
        useCreateCustomer();
    const { mutate: updateCustomer, isPending: loadingUpdate } =
        useUpdateCustomer();
    const { mutate: deleteCustomer, isPending: loadingDelete } =
        useDeleteCustomer();

    const customers = data?.content ?? [];
    const totalItems = data?.totalElements ?? 0;
    const selectedCustomer = customers.find((v) => v.customerId === selectedRow);

    const resetPage = () => setPagination((prev) => ({ ...prev, current: 1 }));

    const handleOpenModal = (
        type: CustomerModalType,
        id: string | null = null,
    ) => {
        setModalType(type);
        setSelectedRow(id);
    };

    const handleCloseModal = () => {
        setModalType(null);
        setSelectedRow(null);
    };

    const handleAddCustomer = (formData: ICustomerForm) => {
        const payload = {
            organizationId: "",
            ...formData
        };
        createCustomer(payload, {
            onSuccess: () => {
                success(msg.addCustomerSuccess);
                handleCloseModal();
            },
            onError: (error) => {
                handleApiError(error);
            },
        });
    };

    const handleUpdateCustomer = (formData: ICustomerForm) => {
        if (!selectedCustomer) return;

        const payload = {
            id: selectedCustomer.id,
            organizationId: "a14100e4-fd2b-4313-bb23-498feb4aa2ed", // TODO: may get removed
            ...formData
        };

        updateCustomer(payload, {
            onSuccess: () => {
                success(msg.updateCustomerSuccess);
                handleCloseModal();
            },
            onError: (error) => {
                handleApiError(error);
            },
        });
    };

    const handleDeleteCustomer = () => {
        if (!selectedCustomer) return;
        console.log(selectedCustomer);

        deleteCustomer(
            {
                id: selectedCustomer.id,
                organizationId: "a14100e4-fd2b-4313-bb23-498feb4aa2ed", // TODO: may get removed
            },
            {
                onSuccess: () => {
                    success(msg.deleteCustomerSuccess);
                },
                onError: (error) => {
                    handleApiError(error);
                },
            },
        );
        handleCloseModal();
    };


    const columns: TableColumnsType<Customer> = [
        {
            title: "Customer ID",
            dataIndex: "customerId",
            key: "customerId",
            width: 150,
            sorter: true,
        },
        {
            title: "Customer Name",
            dataIndex: "customerName",
            key: "customerName",
            width: 250,
        },
        {
            title: "Contact Person",
            dataIndex: "contactPerson",
            key: "contactPerson",
            width: 200,
        },
        {
            title: "Contact Phone",
            dataIndex: "phone",
            key: "phone",
            width: 180,
        },
        {
            title: "Email",
            dataIndex: "email",
            key: "email",
            width: 220,
        },
        {
            title: "Payment Term",
            dataIndex: "paymentTerm",
            key: "paymentTerm",
            width: 140,
        },
        {
            title: "Credit Limit",
            dataIndex: "creditLimit",
            key: "creditLimit",
            width: 160,
            render: (value: number) => value.toLocaleString("vi-VN"),
        },
        {
            title: commonMsg.action,
            key: "action",
            width: 80,
            align: "center",
            fixed: "right",
            render: (record: Customer) => (
                <Dropdown
                    trigger={["click"]}
                    menu={{
                        className: "data-table-menu",
                        items: [
                            {
                                key: "view",
                                label: commonMsg.viewDetails,
                                onClick: () => handleOpenModal("view", record.id),
                            },
                            {
                                key: "edit",
                                label: commonMsg.edit,
                                onClick: () => handleOpenModal("edit", record.id),
                            },
                            {
                                key: "delete",
                                label: commonMsg.delete,
                                onClick: () => handleOpenModal("delete", record.id),
                            },
                        ],
                    }}
                >
                    <Button
                        type="text"
                        size="small"
                        icon={<MoreIcon width={20} height={20} />}
                    />
                </Dropdown>
            ),
        },
    ];

    return (
        <RightBannerLayout title={msg.title} className="data-table">
            <Flex justify="space-between" align="center" style={{ marginBottom: 24 }}>
                <Space>
                    <InputTMS
                        className="search"
                        prefix={<SearchIcon width={20} height={20} />}
                        placeholder={msg.search}
                        value={keyword}
                        onChange={(e) => setKeyword(e.target.value)}
                    />
                </Space>

                <ButtonTMS type="primary" onClick={() => handleOpenModal("create")}>
                    {msg.addCustomer}
                    <PlusIcon width={20} height={20} />
                </ButtonTMS>
            </Flex>

            {/* Table */}
            <TableTMS
                columns={columns}
                dataSource={customers}
                loading={isLoading}
                rowKey={(record) => record.id}
                pagination={{ ...pagination, total: totalItems }}
                onPaginationChange={(page, pageSize) =>
                    setPagination({ current: page, pageSize })
                }
                onChange={(
                    pagination: TablePaginationConfig,
                    filters: Record<string, FilterValue | null>,
                    sorter: SorterResult<Customer> | SorterResult<Customer>[],
                ) => {
                    const s = Array.isArray(sorter) ? sorter[0] : sorter;

                    if (!s?.order) {
                        setSort(DEFAULT_SORT);
                        resetPage();
                        return;
                    }

                    const field = s.column?.key as string;
                    const order = s.order === "ascend" ? "asc" : "desc";

                    setSort(`${field},${order}`);
                    resetPage();
                }}
                pageSizeOptions={[10, 20, 50, 100]}
            />

            <CustomerFormModal
                key={selectedRow ?? "create"}
                open={
                    modalType === "create" || modalType === "edit" || modalType === "view"
                }
                type={modalType as FormType}
                initialValues={
                    modalType && ["edit", "view"].includes(modalType) && selectedRow
                        ? customers.find((c) => c.id === selectedRow)
                        : undefined
                }
                confirmLoading={loadingCreate || loadingUpdate}
                onCancel={handleCloseModal}
                onSubmit={
                    modalType === "create"
                        ? handleAddCustomer
                        : modalType === "edit"
                            ? handleUpdateCustomer
                            : () => handleOpenModal("edit", selectedRow)
                }
            />

            <ModalConfirm
                open={modalType === "delete"}
                type="danger"
                title={msg.deleteCustomer}
                confirmLoading={loadingDelete}
                okText={commonMsg.delete}
                onOk={handleDeleteCustomer}
                onCancel={handleCloseModal}
            >
                <p className="modal-confirm__description">
                    {msg.deleteCustomerDescription}
                </p>
                <p className="modal-confirm__description">
                    {commonMsg.deleteActionWarning}
                </p>
            </ModalConfirm>
        </RightBannerLayout>
    );
};

export default MasterDataCustomer;
