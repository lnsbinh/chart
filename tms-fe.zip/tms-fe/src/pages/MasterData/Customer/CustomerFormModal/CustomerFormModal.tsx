import type { commonMessage } from "@/i18n/messages/common/common";
import { useMessageProxy } from "@/hooks/useMessageProxy";
import type { customerMessage } from "@/i18n/messages/masterData/Customer";
import type { IFormModalProps, IMasterFormField } from "@/pages/MasterData/common/MasterDataFormModal";
import MasterDataFormModal from "@/pages/MasterData/common/MasterDataFormModal";
import '@/pages/MasterData/common/MasterData.less';
import "./CustomerFormModal.less";

export interface ICustomerForm {
  customerId: string;
  customerName: string;
  email: string;
  contactPerson: string;
  contactPhone: string;
  companyAddress: string;
  pickupAddress: string;
  paymentTerm: string;
  creditLimit: number;
}

const CustomerFormModal = (props: IFormModalProps<ICustomerForm>) => {
  const commonMsg = useMessageProxy<typeof commonMessage>("commonMessage");
  const msg = useMessageProxy<typeof customerMessage>(
    "customerMessage",
  );

  const fields: IMasterFormField[] = [
    {
      name: "customerId",
      label: msg.customerId,
      disabled: true,
    },
    {
      name: "customerName",
      label: msg.customerNameLabel,
      rules: [{ required: true, message: msg.customerNameRequired }],
      placeholder: msg.customerNamePlaceholder,
    },
    {
      name: "email",
      label: msg.emailLabel,
      rules: [
        { required: true, message: msg.emailRequired },
        { type: "email", message: msg.emailInvalid },
      ],
      placeholder: msg.emailPlaceholder,
    },
    {
      name: "contactPerson",
      label: msg.contactPersonLabel,
      span: 12,
      rules: [{ required: true, message: msg.contactPersonRequired }],
      placeholder: msg.contactPersonPlaceholder,
    },
    {
      name: "contactPhone",
      label: msg.contactPhoneLabel,
      span: 12,
      rules: [{ required: true, message: msg.contactPhoneRequired }],
      placeholder: msg.contactPhonePlaceholder,
    },
    {
      name: "companyAddress",
      label: msg.companyAddressLabel,
      rules: [{ required: true, message: msg.companyAddressRequired }],
      placeholder: msg.companyAddressPlaceholder,
    },
    {
      name: "pickupAddress",
      label: msg.pickupAddressLabel,
      rules: [{ required: true, message: msg.pickupAddressRequired }],
      placeholder: msg.pickupAddressPlaceholder,
    },
    {
      name: "paymentTerm",
      label: msg.paymentTermLabel,
      span: 12,
      rules: [{ required: true, message: msg.paymentTermRequired }],
      placeholder: msg.paymentTermPlaceholder,
    },
    {
      name: "creditLimit",
      label: msg.creditLimitLabel,
      type: "number",
      span: 12,
      rules: [{ required: true, message: msg.creditLimitRequired }],
      placeholder: msg.creditLimitPlaceholder,
    },
  ];

  return (
    <MasterDataFormModal<ICustomerForm>
      {...props}
      className="form-modal"
      titleMap={{
        create: msg.addCustomer,
        edit: msg.editCustomer,
        view: msg.viewCustomer,
      }}
      okTextMap={{
        create: msg.createCustomer,
        edit: commonMsg.save,
        view: commonMsg.edit,
      }}
      cancelText={commonMsg.cancel}
      description={
        <p className="form-modal__title">
          {props.type === "create"
            ? msg.description
            : props.type === "edit"
              ? msg.editDescription
              : ""}
        </p>
      }
      fields={fields}
    />
  );
};

export default CustomerFormModal;
