import type { ReactNode } from "react";
import type { Rule } from "antd/es/form";
import { Form, Row, Col, Select } from "antd";
import { useEffect } from "react";
import ModalBase from "@/components/common/Modal/ModalBase/ModalBase";
import AppInput from "@/components/common/Input/Input";
import { useNotify } from "@/hooks/useNotify";
import './MasterData.less';
import './MasterDataFormModal.less';

export type FormType = "create" | "edit" | "view";

export interface IFormModalProps<T> {
    open: boolean;
    loading?: boolean;
    confirmLoading?: boolean;
    initialValues?: Partial<T>;
    onSubmit: (values: T) => void;
    onCancel: () => void;
    type?: FormType;
}

export interface IMasterFormField {
    name: string;
    label: string;
    type?: "text" | "number" | "select" | "date";
    placeholder?: string;
    rules?: Rule[];
    span?: number;

    disabled?: boolean;
    addonAfter?: ReactNode;

    options?: { value: string | number; label: string }[];

    // allow custom render override
    render?: () => ReactNode;
}

interface IMasterDataFormModalProps<T> {
    open: boolean;
    initialValues?: Partial<T>;
    loading?: boolean;
    confirmLoading?: boolean;
    onSubmit: (values: T) => void;
    onCancel: () => void;
    type?: "create" | "edit" | "view";

    titleMap: {
        create: string;
        edit: string;
        view: string;
    };

    okTextMap: {
        create: string;
        edit: string;
        view: string;
    };

    cancelText: string;

    description?: ReactNode;
    className?: string;

    fields: IMasterFormField[];
    defaultValues?: Partial<T>;
}

const MasterDataFormModal = <T extends object>({
    open,
    initialValues,
    loading = false,
    confirmLoading = false,
    onSubmit,
    onCancel,
    type = "create",
    titleMap,
    okTextMap,
    cancelText,
    description,
    className,
    fields,
    defaultValues,
}: IMasterDataFormModalProps<T>) => {
    const [form] = Form.useForm<T>();
    const { error } = useNotify();

    useEffect(() => {
        if (open) {
            form.resetFields();

            const values = initialValues
                ? { ...defaultValues, ...initialValues }
                : defaultValues;

            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            form.setFieldsValue((values ?? {}) as any);
        }
    }, [open, initialValues, form]);

    const handleOk = async () => {
        try {
            if (type === "view") {
                onSubmit(form.getFieldsValue());
                return;
            }

            const values = await form.validateFields();
            onSubmit(values);
            form.resetFields();
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
        } catch (err: any) {
            error(err.message);
        }
    };

    const renderField = (field: IMasterFormField) => {
        if (field.render) return field.render();

        switch (field.type) {
            case "select":
                return <Select options={field.options} />;

            default:
                return (
                    <AppInput
                        type={field.type}
                        placeholder={field.placeholder}
                        addonAfter={field.addonAfter}
                        disabled={field.disabled}
                    />
                );
        }
    };

    return (
        <ModalBase
            open={open}
            title={titleMap[type]}
            okText={okTextMap[type]}
            cancelText={cancelText}
            confirmLoading={confirmLoading}
            onOk={handleOk}
            onCancel={onCancel}
            loading={loading}
            className={className}
        >
            <Form form={form} layout="vertical" disabled={type === "view"}>
                {description}

                <Row gutter={[16, 16]}>
                    {fields.map((field) => (
                        <Col span={field.span || 24} key={field.name}>
                            <Form.Item
                                name={field.name}
                                label={field.label}
                                rules={field.rules}
                            >
                                {renderField(field)}
                            </Form.Item>
                        </Col>
                    ))}
                </Row>
            </Form>
        </ModalBase>
    );
};

export default MasterDataFormModal;