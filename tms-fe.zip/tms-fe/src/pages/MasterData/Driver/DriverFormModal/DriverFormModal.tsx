import { Form, Row, Col, Select } from 'antd';
import { useEffect, useState } from 'react';
import dayjs, { Dayjs } from 'dayjs';
import ModalBase from '@/components/common/Modal/ModalBase/ModalBase';
import InputTMS from '@/components/common/Input/Input';
import type { driverMessage } from '@/i18n/messages/masterData/Driver';
import type { commonMessage } from '@/i18n/messages/common/common';
import { useMessageProxy } from '@/hooks/useMessageProxy';
import { useNotify } from '@/hooks/useNotify';
import { type ModalType, MODAL_TYPE, DRIVER_STATUS } from '@/constants';
import { type Driver } from '@/api/MasterData/Driver/Driver.api';
import './DriverFormModal.less';

export interface IDriverForm extends Omit<Driver, 'licenseExpiry' | 'joinDate'> {
  licenseExpiry: Dayjs | null;
  joinDate: Dayjs | null;
}
interface IDriverFormModalProps {
  open: boolean;
  loading?: boolean;
  loadingSubmit?: boolean;
  initialValues?: Partial<Driver>;
  type: ModalType | null;
  onSubmit: (values: Driver) => void;
  onCancel: () => void;
}

const defaultValues: Partial<Driver> = {
  activeFlag: true,
};

const DriverFormModal = ({
  open,
  initialValues,
  loading = false,
  type,
  loadingSubmit = false,
  onSubmit,
  onCancel,
}: IDriverFormModalProps) => {
  const [form] = Form.useForm<IDriverForm>();
  const msg = useMessageProxy<typeof driverMessage>('driverMessage');
  const commonMsg = useMessageProxy<typeof commonMessage>('commonMessage');

  const [mode, setMode] = useState<ModalType | null>(type);

  const { error } = useNotify();
  const isView = mode === MODAL_TYPE.VIEW;

  useEffect(() => {
    if (!open) return;
    form.resetFields();
    const mappedValues = initialValues
      ? {
          ...defaultValues,
          ...initialValues,
          licenseExpiry: initialValues.licenseExpiry ? dayjs(initialValues.licenseExpiry) : null,
          joinDate: initialValues.joinDate ? dayjs(initialValues.joinDate) : null,
        }
      : defaultValues;
    form.setFieldsValue(mappedValues);
  }, [open, form, initialValues]);

  useEffect(() => {
    setMode(type);
  }, [type]);

  const handleOk = async () => {
    if (mode === MODAL_TYPE.VIEW) {
      setMode(MODAL_TYPE.EDIT);
      return;
    }
    try {
      const values = await form.validateFields();
      const payload = {
        ...values,
        licenseExpiry: values.licenseExpiry?.format('YYYY-MM-DD') ?? '',
        joinDate: values.joinDate?.format('YYYY-MM-DD') ?? '',
      };
      onSubmit(payload);
    } catch (err) {
      console.error(err);
      error('All required fields must be filled');
    }
  };

  const getModalConfig = () => {
    switch (mode) {
      case MODAL_TYPE.CREATE:
        return {
          title: msg.addNewDriver,
          okText: msg.createDriver,
        };
      case MODAL_TYPE.EDIT:
        return {
          title: msg.editDriver,
          okText: commonMsg.save,
        };
      case MODAL_TYPE.VIEW:
        return {
          title: msg.viewDetailsDriver,
          okText: commonMsg.edit,
        };
      default:
        return {
          title: '',
          okText: '',
        };
    }
  };

  const config = getModalConfig();

  return (
    <ModalBase
      open={open}
      title={config.title}
      okText={config.okText}
      onOk={handleOk}
      onCancel={onCancel}
      loading={loading}
      confirmLoading={loadingSubmit}
      className='driver-form-modal'>
      <Form
        form={form}
        layout='vertical'
        requiredMark={
          mode === MODAL_TYPE.VIEW
            ? false
            : (label, { required }) => (
                <>
                  {label}
                  {required && <span className='required-mark'>*</span>}
                </>
              )
        }>
        <Row gutter={[16, 16]}>
          <Col span={12}>
            <Form.Item
              name='driverId'
              label={msg.driverId}>
              <InputTMS disabled />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              name='activeFlag'
              label={commonMsg.status}>
              <Select
                disabled={isView}
                options={[
                  { value: true, label: commonMsg.true },
                  { value: false, label: commonMsg.false },
                ]}
              />
            </Form.Item>
          </Col>
          <Col span={24}>
            <Form.Item
              name='fullName'
              label={msg.fullName}
              rules={[{ required: true, message: msg.driverNameRequired }]}>
              <InputTMS
                disabled={isView}
                placeholder='e.g. Nguyen Van A'
              />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              name='phoneNumber'
              label={msg.phoneNumber}
              getValueFromEvent={(e) => e.target.value.replace(/\D/g, '')}
              rules={[
                { required: true, message: msg.phoneNumberRequired },
                {
                  pattern: /^0\d{9}$/,
                  message: msg.phoneNumberInvalid,
                },
              ]}>
              <InputTMS
                inputMode='numeric'
                disabled={isView}
                placeholder='e.g. 0903666789'
              />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              name='idNumber'
              label={msg.iIdentityDocumentNumber}
              rules={[{ required: true, message: msg.iIdentityDocumentNumberRequired }]}>
              <InputTMS
                disabled={isView}
                placeholder='e.g. 0520 789 99'
              />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              name='licenseClass'
              label={msg.licenseClass}
              rules={[{ required: true, message: msg.licenseClassRequired }]}>
              <InputTMS
                disabled={isView}
                placeholder='e.g. C1'
              />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              name='licenseNumber'
              label={msg.licenseNumber}
              rules={[{ required: true, message: msg.licenseNumberRequired }]}>
              <InputTMS
                disabled={isView}
                placeholder='e.g. 991179000994'
              />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              name='licenseExpiry'
              label={msg.licenseExpiry}
              rules={[{ required: true, message: msg.licenseExpiryRequired }]}>
              <InputTMS
                disabled={isView}
                type='date'
                placeholder='e.g. 08/12/2028'
              />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              name='employmentType'
              label={msg.employmentType}
              rules={[{ required: true, message: msg.employmentTypeRequired }]}>
              <Select
                disabled={isView}
                placeholder='e.g. Full-time'
                options={[
                  { value: DRIVER_STATUS.FULL_TIME, label: msg.fulltime },
                  { value: DRIVER_STATUS.CONTRACT, label: msg.contract },
                ]}
              />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              name='driverGroup'
              label={msg.driverGroup}
              rules={[{ required: true, message: msg.driverGroupRequired }]}>
              <InputTMS
                disabled={isView}
                placeholder='e.g. HCM_LineA'
              />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              name='joinDate'
              label={msg.joinDate}
              rules={[{ required: true, message: msg.joinDateRequired }]}>
              <InputTMS
                disabled={isView}
                type='date'
                placeholder='e.g. 01/05/2022'
              />
            </Form.Item>
          </Col>
        </Row>
      </Form>
    </ModalBase>
  );
};

export default DriverFormModal;
