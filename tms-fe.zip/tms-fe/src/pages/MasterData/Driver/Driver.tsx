import { useState } from 'react';
import { Button, Space, Flex, Dropdown } from 'antd';
import type { TableColumnsType, TablePaginationConfig } from 'antd';
import type { SorterResult } from 'antd/es/table/interface';
import { driverMessage } from '@/i18n/messages/masterData/Driver';
import { commonMessage } from '@/i18n/messages/common/common';
import { useMessageProxy } from '@/hooks/useMessageProxy';
import { useDebounce, useNotify } from '@/hooks';
import RightBannerLayout from '@/components/common/RightPanelLayout/RightPanelLayout';
import ButtonTMS from '@/components/common/Button/ButtonTMS';
import TableTMS from '@/components/common/TableTMS/TableTMS';
import StatusTag from '@/components/common/StatusTag/StatusTag';
import InputTMS from '@/components/common/Input/Input';
import ModalConfirm from '@/components/common/Modal/ModalConfirm/ModalConfirm';
import { PlusIcon, SearchIcon, MoreIcon } from '@/assets';
import { MODAL_TYPE, type ModalType } from '@/constants';
import { toSortOrder } from '@/utils';
import {
  useGetDrivers,
  useCreateDriver,
  useUpdateDriver,
  useDeleteDriver,
  type Driver,
} from '@/api/MasterData/Driver/Driver.api';
import DriverFormModal from './DriverFormModal/DriverFormModal';
import './Driver.less';

const icon = (Icon: React.FC<{ width: number; height: number }>) => (
  <Icon
    width={20}
    height={20}
  />
);

const DriverManagement = () => {
  const msg = useMessageProxy<typeof driverMessage>('driverMessage');
  const commonMsg = useMessageProxy<typeof commonMessage>('commonMessage');
  const { success } = useNotify();

  const [search, setSearch] = useState('');
  const debouncedSearch = useDebounce(search, 500);
  const [pagination, setPagination] = useState<TablePaginationConfig>({ current: 1, pageSize: 10 });
  const [selectedRow, setSelectedRow] = useState<string | null>(null);
  const [modalType, setModalType] = useState<ModalType | null>(null);
  const [sort, setSort] = useState<string | undefined>(undefined);

  const { mutate: createDriver, isPending: isCreating } = useCreateDriver();
  const { mutate: updateDriver, isPending: isUpdating } = useUpdateDriver();
  const { mutate: deleteDriver, isPending: isDeleting } = useDeleteDriver();

  const { data: driverData, isLoading } = useGetDrivers({
    keyword: debouncedSearch,
    page: (pagination.current ?? 1) - 1,
    size: pagination.pageSize ?? 10,
    sort,
  });

  const drivers = driverData?.content ?? [];
  const totalItems = driverData?.totalElements ?? 0;

  const resetPage = () => setPagination((prev) => ({ ...prev, current: 1 }));

  const handleOpenModal = (id: string, type: ModalType) => {
    setSelectedRow(id);
    setModalType(type);
  };

  const handleCancel = () => {
    setSelectedRow(null);
    setModalType(null);
  };

  const handleSubmit = (value: Driver) => {
    if (selectedRow) {
      updateDriver(
        {
          driverId: selectedRow,
          data: value,
        },
        {
          onSuccess: async () => {
            success(msg.driverUpdatedSuccess);
            handleCancel();
          },
        },
      );
    } else {
      createDriver(value, {
        onSuccess: async () => {
          success(msg.driverCreatedSuccess);
          handleCancel();
        },
      });
    }
  };

  const handleDelete = () => {
    if (!selectedRow) return;
    deleteDriver(
      { driverId: selectedRow },
      {
        onSuccess: () => {
          success(msg.driverDeleteSuccess);
          handleCancel();
        },
      },
    );
  };

  const handleSearch = (value: string) => {
    setSearch(value);
    resetPage();
  };

  const handleTableChange = (
    _: TablePaginationConfig,
    __: unknown,
    sorter: SorterResult<Driver> | SorterResult<Driver>[],
  ) => {
    const s = Array.isArray(sorter) ? sorter[0] : sorter;

    if (!s.order) {
      setSort(undefined);
    } else {
      const sortOrder = toSortOrder(s.order);
      setSort(`${s.columnKey},${sortOrder}`);
    }
    resetPage();
  };

  const selectedDriver = drivers.find((d) => d.driverId === selectedRow);

  const isOpenFormModal =
    modalType === MODAL_TYPE.CREATE || modalType === MODAL_TYPE.EDIT || modalType === MODAL_TYPE.VIEW;
  const columns: TableColumnsType<Driver> = [
    {
      title: msg.driverId,
      dataIndex: 'driverId',
      key: 'driverId',
      width: 180,
      sorter: true,
    },
    {
      title: msg.fullName,
      dataIndex: 'fullName',
      key: 'fullName',
      width: 200,
    },
    { title: msg.phoneNumber, dataIndex: 'phoneNumber', key: 'phoneNumber', width: 250 },
    { title: msg.licenseClass, dataIndex: 'licenseClass', key: 'licenseClass', width: 250 },
    { title: msg.driverGroup, dataIndex: 'driverGroup', key: 'driverGroup' },
    { title: msg.familiarRoutes, dataIndex: 'familiarRoutes', key: 'familiarRoutes' },
    {
      title: commonMsg.status,
      dataIndex: 'activeFlag',
      key: 'activeFlag',
      sorter: true,
      width: 150,
      render: (activeFlag) => <StatusTag status={activeFlag ? 'true' : 'false'} />,
    },
    {
      title: commonMsg.action,
      key: 'action',
      width: 77,
      align: 'center',
      render: (_: unknown, record: Driver) => (
        <Dropdown
          trigger={['click']}
          menu={{
            items: [
              {
                key: MODAL_TYPE.VIEW,
                label: commonMsg.viewDetails,
                onClick: () => handleOpenModal(record.driverId, MODAL_TYPE.VIEW),
              },
              {
                key: MODAL_TYPE.EDIT,
                label: commonMsg.edit,
                onClick: () => handleOpenModal(record.driverId, MODAL_TYPE.EDIT),
              },
              {
                key: MODAL_TYPE.DELETE,
                label: commonMsg.delete,
                onClick: () => handleOpenModal(record.driverId, MODAL_TYPE.DELETE),
              },
            ],
          }}>
          <Button
            type='text'
            size='small'
            icon={
              <MoreIcon
                width={20}
                height={20}
              />
            }
          />
        </Dropdown>
      ),
    },
  ];

  return (
    <RightBannerLayout
      title={msg.title}
      className='driver'>
      <Flex
        justify='space-between'
        align='center'
        style={{ marginBottom: 24 }}>
        <Space className='driver-filter'>
          <InputTMS
            value={search}
            prefix={icon(SearchIcon)}
            placeholder={msg.search}
            className='search'
            onChange={(e) => handleSearch(e.target.value)}
          />
        </Space>
        <ButtonTMS
          type='primary'
          onClick={() => handleOpenModal('', MODAL_TYPE.CREATE)}>
          {msg.addDriver}
          {icon(PlusIcon)}
        </ButtonTMS>
      </Flex>

      <TableTMS
        columns={columns}
        dataSource={drivers}
        loading={isLoading}
        pagination={{ ...pagination, total: totalItems }}
        rowKey={(record) => record.driverId}
        onChange={handleTableChange}
        onPaginationChange={(page, pageSize) => setPagination({ current: page, pageSize })}
        pageSizeOptions={[10, 20, 50, 100]}
        className='driver-table'
        heightConfig={{ rowHeight: 69, visibleRows: 7 }}
      />

      <DriverFormModal
        key={selectedRow ?? MODAL_TYPE.CREATE}
        open={isOpenFormModal}
        initialValues={selectedDriver}
        type={modalType}
        loadingSubmit={isCreating || isUpdating}
        onSubmit={handleSubmit}
        onCancel={handleCancel}
      />
      <ModalConfirm
        open={modalType === MODAL_TYPE.DELETE}
        type='danger'
        title={msg.deleteDriver}
        description={msg.deleteDriverDescription}
        onOk={handleDelete}
        onCancel={handleCancel}
        confirmLoading={isDeleting}
      />
    </RightBannerLayout>
  );
};

export default DriverManagement;
