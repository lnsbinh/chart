import type { commonMessage } from "@/i18n/messages/common/common";
import { useMessageProxy } from "@/hooks/useMessageProxy";
import { GENERIC_STATUS, type GenericStatus } from "@/constants";
import type { vehicleMessage } from "@/i18n/messages/masterData/Vehicle";
import type { IFormModalProps, IMasterFormField } from "@/pages/MasterData/common/MasterDataFormModal";
import MasterDataFormModal from "@/pages/MasterData/common/MasterDataFormModal";
import '@/pages/MasterData/common/MasterData.less';
import "./VehicleFormModal.less";


export interface IVehicleForm {
    vehicleId: string;
    status: GenericStatus;
    vehicleName: string;

    licensePlate: string;
    vehicleType: string;
    brandModel: string;

    productionYear: number;
    capacity: number;
    volume: number;

    fuelType: string;
    fuelNorm: string;
    ownerBranch: string;

    gpsCode: string;
    registryExpiry: string;
    insuranceExpiry: string;
}

const defaultValues: Partial<IVehicleForm> = {
    status: GENERIC_STATUS.ACTIVE,
};

const VehicleFormModal = (props: IFormModalProps<IVehicleForm>) => {
    const commonMsg = useMessageProxy<typeof commonMessage>("commonMessage");
    const msg = useMessageProxy<typeof vehicleMessage>(
        "vehicleMessage",
    );

    const fields: IMasterFormField[] = [
        { name: "vehicleId", label: msg.vehicleId, disabled: true, span: 12 },
        {
            name: "status",
            label: commonMsg.status,
            type: "select",
            span: 12,
            options: [
                { value: GENERIC_STATUS.ACTIVE, label: commonMsg.active },
                { value: GENERIC_STATUS.INACTIVE, label: commonMsg.inactive },
            ],
        },

        {
            name: "vehicleName",
            label: msg.vehicleName,
            rules: [{ required: true, message: msg.vehicleNameRequired }],
            placeholder: msg.vehicleNamePlaceholder,
        },

        // row 1
        {
            name: "licensePlate",
            label: msg.licensePlate,
            span: 8,
            rules: [{ required: true, message: msg.licensePlateRequired }],
            placeholder: msg.licensePlatePlaceholder,
        },
        {
            name: "vehicleType",
            label: msg.vehicleType,
            span: 8,
            rules: [{ required: true, message: msg.vehicleTypeRequired }],
            placeholder: msg.vehicleTypePlaceholder,
        },
        {
            name: "brandModel",
            label: msg.brandModel,
            span: 8,
            rules: [{ required: true, message: msg.brandModelRequired }],
            placeholder: msg.brandModelPlaceholder,
        },

        // row 2
        {
            name: "productionYear",
            label: msg.productionYear,
            type: "number",
            span: 8,
            rules: [{ required: true, message: msg.productionYearRequired }],
            placeholder: msg.productionYearPlaceholder,
        },
        {
            name: "capacity",
            label: msg.capacityKg,
            type: "number",
            span: 8,
            addonAfter: msg.capacityUnit,
            rules: [{ required: true, message: msg.capacityRequired }],
            placeholder: msg.capacityPlaceholder,
        },
        {
            name: "volume",
            label: msg.volumeM3,
            type: "number",
            span: 8,
            addonAfter: msg.volumeUnit,
            rules: [{ required: true, message: msg.volumeRequired }],
            placeholder: msg.volumePlaceholder,
        },

        // row 3
        {
            name: "fuelType",
            label: msg.fuelType,
            span: 8,
            rules: [{ required: true, message: msg.fuelTypeRequired }],
            placeholder: msg.fuelTypePlaceholder,
        },
        {
            name: "fuelNorm",
            label: msg.fuelNorm,
            type: "number",
            span: 8,
            addonAfter: msg.fuelNormUnit,
            rules: [{ required: true, message: msg.fuelNormRequired }],
            placeholder: msg.fuelNormPlaceholder,
        },
        {
            name: "ownerBranch",
            label: msg.ownerBranch,
            span: 8,
            rules: [{ required: true, message: msg.ownerBranchRequired }],
            placeholder: msg.ownerBranchPlaceholder,
        },

        // row 4
        {
            name: "gpsCode",
            label: msg.gpsDeviceCode,
            span: 8,
            rules: [{ required: true, message: msg.gpsDeviceCodeRequired }],
            placeholder: msg.gpsDeviceCodePlaceholder,
        },
        {
            name: "registryExpiry",
            label: msg.registryExpiry,
            type: "date",
            span: 8,
            rules: [{ required: true, message: msg.registryExpiryRequired }],
            placeholder: msg.registryExpiryPlaceholder,
        },
        {
            name: "insuranceExpiry",
            label: msg.insuranceExpiry,
            type: "date",
            span: 8,
            rules: [{ required: true, message: msg.insuranceExpiryRequired }],
            placeholder: msg.insuranceExpiryPlaceholder,
        },
    ];

    return (
        <MasterDataFormModal<IVehicleForm>
            {...props}
            className="form-modal vehicle-form-modal"
            defaultValues={defaultValues}
            titleMap={{
                create: msg.addVehicle,
                edit: msg.editVehicle,
                view: msg.viewVehicle,
            }}
            okTextMap={{
                create: msg.createVehicle,
                edit: commonMsg.save,
                view: commonMsg.edit,
            }}
            cancelText={commonMsg.cancel}
            description={
                <p className="form-modal__title">
                    {props.type === "create"
                        ? msg.description
                        : props.type === "edit"
                            ? msg.editVehicleDescription
                            : ""}
                </p>
            }
            fields={fields}
        />
    );
};

export default VehicleFormModal;
