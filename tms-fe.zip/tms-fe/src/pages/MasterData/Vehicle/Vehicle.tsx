import { useState } from "react";
import { Button, Space, Flex, Dropdown } from "antd";
import type { TableColumnsType, TablePaginationConfig } from "antd";
import { useMessageProxy } from "@/hooks/useMessageProxy";
import RightBannerLayout from "@/components/common/RightPanelLayout/RightPanelLayout";
import ButtonTMS from "@/components/common/Button/ButtonTMS";
import TableTMS from "@/components/common/TableTMS/TableTMS";
import StatusTag from "@/components/common/StatusTag/StatusTag";
import InputTMS from "@/components/common/Input/Input";
import { PlusIcon, SearchIcon, MoreIcon } from "@/assets";
import "./Vehicle.less";
import VehicleFormModal, {
    type IVehicleForm,
} from "./VehicleFormModal/VehicleFormModal";
import ModalConfirm from "@/components/common/Modal/ModalConfirm/ModalConfirm";
import { useNotify } from "@/hooks/useNotify";
import { useApiError } from "@/hooks/useApiError";

import {
    useCreateVehicle,
    useDeleteVehicle,
    useGetVehicles,
    useUpdateVehicle,
    type CreateVehiclePayload,
    type UpdateVehiclePayload,
    type Vehicle,
} from "@/api/MasterData/Vehicle.api";

import type { vehicleMessage } from "@/i18n/messages/masterData/Vehicle";
import type { commonMessage } from "@/i18n/messages/common/common";
import type { FilterValue, SorterResult } from "antd/es/table/interface";
import { useDebounce } from "@/hooks/useDebounce";
import type { GenericStatus } from "@/constants";
import type { FormType } from "../common/MasterDataFormModal";

type VehicleModalTypes = "create" | "edit" | "delete" | "view" | null;

const MasterDataVehicle = () => {
    const commonMsg = useMessageProxy<typeof commonMessage>("commonMessage");
    const msg = useMessageProxy<typeof vehicleMessage>(
        "vehicleMessage",
    );
    const { success } = useNotify();
    const { handleApiError } = useApiError();

    const [pagination, setPagination] = useState<TablePaginationConfig>({
        current: 1,
        pageSize: 10,
    });
    const DEFAULT_SORT = "plateNo,asc";
    const [sort, setSort] = useState<string>(DEFAULT_SORT);
    const [keyword, setKeyword] = useState("");
    const debouncedKeyword = useDebounce(keyword, 500);

    const [modalType, setModalType] = useState<VehicleModalTypes>(null);
    const [selectedRow, setSelectedRow] = useState<string | null>(null);

    const { data, isLoading } = useGetVehicles({
        organizationId: "a14100e4-fd2b-4313-bb23-498feb4aa2ed", // TODO: find out how to get organizationId
        keyword: debouncedKeyword,
        sort,
        page: (pagination.current ?? 1) - 1,
        size: pagination.pageSize ?? 10,
    });

    const { mutate: createVehicle, isPending: loadingCreate } =
        useCreateVehicle();
    const { mutate: updateVehicle, isPending: loadingUpdate } =
        useUpdateVehicle();
    const { mutate: deleteVehicle, isPending: loadingDelete } =
        useDeleteVehicle();

    const vehicles = data?.content ?? [];
    const totalItems = data?.totalElements ?? 0;
    const selectedVehicle = vehicles.find((v) => v.vehicleCode === selectedRow);

    const resetPage = () => setPagination((prev) => ({ ...prev, current: 1 }));

    const handleOpenModal = (
        type: VehicleModalTypes = "create",
        id: string | null = null,
    ) => {
        setModalType(type);
        setSelectedRow(id);
    };

    const handleCloseModal = () => {
        setModalType(null);
        setSelectedRow(null);
    };

    const handleAddVehicle = (formData: IVehicleForm) => {
        const payload = mapFormToPayload(formData);
        createVehicle(payload, {
            onSuccess: () => {
                success(msg.addVehicleSuccess);
                handleCloseModal();
            },
            onError: (error) => {
                handleApiError(error);
            },
        });
    };

    const handleUpdateVehicle = (formData: IVehicleForm) => {
        if (!selectedVehicle) return;

        console.log(selectedVehicle.id);

        const payload = mapFormToUpdatePayload(formData);

        updateVehicle(payload, {
            onSuccess: () => {
                success(msg.updateVehicleSuccess);
                handleCloseModal();
            },
            onError: (error) => {
                handleApiError(error);
            },
        });
    };

    const handleDeleteVehicle = () => {
        if (!selectedVehicle) return;
        console.log(selectedVehicle);

        deleteVehicle(
            {
                id: selectedVehicle.id,
                organizationId: "a14100e4-fd2b-4313-bb23-498feb4aa2ed", // TODO: find out how to get organizationId
            },
            {
                onSuccess: () => {
                    success(msg.deleteVehicleSuccess);
                },
                onError: (error) => {
                    handleApiError(error);
                },
            },
        );
        handleCloseModal();
    };

    const tableData = vehicles.map((v: Vehicle) => ({
        id: v.id,
        vehicleId: v.vehicleCode,
        licensePlate: v.plateNo,
        vehicleName: v.vehicleCode, // TODO: replace when API supports
        vehicleType: v.vehicleType,
        brandModel: "Hino 300", // TODO: replace when API supports
        productionYear: new Date(v.createdAt).getFullYear(), // TODO: replace when API supports
        capacity: v.payloadKg,
        volume: v.volumeM3,
        fuelType: "Diesel", // TODO: replace
        fuelNorm: "14 (L/100km)", // TODO: replace when API supports
        ownerBranch: v.branchId, // TODO: replace when API supports
        baseDepot: v.branchId, // TODO: replace when API supports
        gpsCode: "GPS_000123", // TODO: replace when API supports
        registryExpiry: new Date(v.createdAt).toLocaleDateString("en-GB", {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
        }), // TODO: replace when API supports
        insuranceExpiry: new Date(v.updatedAt).toLocaleDateString("en-GB", {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
        }), // TODO: replace when API supports
        status: v.statusCode.toLowerCase(),
    }));

    type TableRow = (typeof tableData)[number];

    // TODO: Remove when API return fields that match the design
    const mapFormToPayload = (values: IVehicleForm): CreateVehiclePayload => {
        return {
            organizationId: "a14100e4-fd2b-4313-bb23-498feb4aa2ed",

            vehicleCode: values.vehicleName, // 👈 temporary mapping (adjust later)
            vehicleType: values.vehicleType,
            plateNo: values.licensePlate,

            payloadKg: Number(values.capacity),
            volumeM3: Number(values.volume),

            branchId: "",

            statusCode: values.status.toUpperCase() as "ACTIVE" | "INACTIVE",

            // optional / not in UI yet
            chassisNo: "",
            engineNo: "",
            containerCapability: values.fuelType, // 👈 temporary mapping (adjust later)

            operationalState: "AVAILABLE",
        };
    };

    // TODO: Remove when API return fields that match the design
    const mapPayloadToForm = (payload: Vehicle): IVehicleForm => {
        return {
            vehicleName: payload.vehicleCode,
            licensePlate: payload.plateNo,
            vehicleType: payload.vehicleType,

            brandModel: "",
            productionYear: payload.createdAt
                ? new Date(payload.createdAt).getFullYear()
                : 0,

            capacity: payload.payloadKg,
            volume: payload.volumeM3,

            fuelType: "Diesel",
            fuelNorm: "14 (L/100km)",

            ownerBranch: payload.branchId,
            gpsCode: "GPS_000123",

            // ⚠️ important: AntD DatePicker expects dayjs, not Date
            registryExpiry: "",
            insuranceExpiry: "",

            status: payload.statusCode.toLowerCase() as GenericStatus,

            vehicleId: payload.vehicleCode,
        };
    };

    // TODO: Remove when API return fields that match the design
    const mapFormToUpdatePayload = (
        values: IVehicleForm,
    ): UpdateVehiclePayload => {
        return {
            id: values.vehicleId,
            organizationId: "a14100e4-fd2b-4313-bb23-498feb4aa2ed",

            vehicleCode: values.vehicleId,
            vehicleType: values.vehicleType,
            plateNo: values.licensePlate,

            payloadKg: Number(values.capacity),
            volumeM3: Number(values.volume),

            branchId: null,

            statusCode: values.status === "active" ? "ACTIVE" : "INACTIVE",

            // optional
            chassisNo: "",
            engineNo: "",
            containerCapability: values.fuelType,
            operationalState: "AVAILABLE",
        };
    };

    // TODO: Update columns key when API return fields that match the design
    const columns: TableColumnsType<TableRow> = [
        {
            title: msg.vehicleId,
            dataIndex: "vehicleId",
            key: "vehicleCode",
            width: 180,
            sorter: true,
        },
        {
            title: msg.licensePlate,
            dataIndex: "licensePlate",
            key: "plateNo",
            width: 125,
            defaultSortOrder: "ascend",
        },
        {
            title: msg.vehicleName,
            dataIndex: "vehicleName",
            key: "vehicleName",
            width: 270,
        },
        {
            title: msg.vehicleType,
            dataIndex: "vehicleType",
            key: "vehicleType",
            width: 120,
        },
        {
            title: msg.ownerBranch,
            dataIndex: "ownerBranch",
            key: "ownerBranch",
            width: 130,
        },
        {
            title: msg.baseDepot,
            dataIndex: "baseDepot",
            key: "baseDepot",
            width: 110,
        },
        {
            title: msg.gpsDeviceCode,
            dataIndex: "gpsCode",
            key: "gpsCode",
            width: 150,
        },
        {
            title: msg.registryExpiry,
            dataIndex: "registryExpiry",
            key: "createdAt",
            width: 140,
        },
        {
            title: msg.insuranceExpiry,
            dataIndex: "insuranceExpiry",
            key: "updatedAt",
            width: 150,
        },
        {
            title: commonMsg.status,
            dataIndex: "status",
            key: "statusCode",
            width: 120,
            sorter: true,
            render: (status) => <StatusTag status={status} />,
        },
        {
            title: commonMsg.action,
            key: "action",
            width: 80,
            align: "center",
            fixed: "right",
            render: (record: TableRow) => (
                <Dropdown
                    trigger={["click"]}
                    menu={{
                        className: "data-table-menu",
                        items: [
                            {
                                key: "view",
                                label: commonMsg.viewDetails,
                                onClick: () => handleOpenModal("view", record.vehicleId),
                            },
                            {
                                key: "edit",
                                label: commonMsg.edit,
                                onClick: () => handleOpenModal("edit", record.vehicleId),
                            },
                            {
                                key: "delete",
                                label: commonMsg.delete,
                                onClick: () => handleOpenModal("delete", record.vehicleId),
                            },
                        ],
                    }}
                >
                    <Button
                        type="text"
                        size="small"
                        icon={<MoreIcon width={20} height={20} />}
                    />
                </Dropdown>
            ),
        },
    ];

    return (
        <RightBannerLayout title={msg.title} className="data-table">
            <Flex justify="space-between" align="center" style={{ marginBottom: 24 }}>
                <Space>
                    <InputTMS
                        className="search"
                        prefix={<SearchIcon width={20} height={20} />}
                        placeholder={msg.search}
                        value={keyword}
                        onChange={(e) => setKeyword(e.target.value)}
                    />
                </Space>

                <ButtonTMS type="primary" onClick={() => handleOpenModal("create")}>
                    {msg.addVehicle}
                    <PlusIcon width={20} height={20} />
                </ButtonTMS>
            </Flex>

            <TableTMS
                columns={columns}
                dataSource={tableData}
                loading={isLoading}
                pagination={{ ...pagination, total: totalItems }}
                rowKey={(record) => record.id}
                onPaginationChange={(page, pageSize) =>
                    setPagination({ current: page, pageSize })
                }
                onChange={(
                    pagination: TablePaginationConfig,
                    filters: Record<string, FilterValue | null>,
                    sorter: SorterResult<TableRow> | SorterResult<TableRow>[],
                ) => {
                    const s = Array.isArray(sorter) ? sorter[0] : sorter;

                    // Reset sort when user clears sorting
                    if (!s?.order) {
                        setSort(DEFAULT_SORT); // default sort
                        resetPage();
                        return;
                    }

                    const field = s.column?.key as string;
                    const order = s.order === "ascend" ? "asc" : "desc";

                    setSort(`${field},${order}`);
                    resetPage();
                }}
                pageSizeOptions={[10, 20, 50, 100]}
            />

            <VehicleFormModal
                key={selectedRow ?? "create"}
                open={
                    modalType === "create" || modalType === "edit" || modalType === "view"
                }
                type={modalType as FormType}
                initialValues={
                    modalType && ["edit", "view"].includes(modalType) && selectedVehicle
                        ? mapPayloadToForm(selectedVehicle)
                        : undefined
                }
                confirmLoading={loadingCreate || loadingUpdate}
                onCancel={handleCloseModal}
                onSubmit={
                    modalType === "create"
                        ? handleAddVehicle
                        : modalType === "edit"
                            ? handleUpdateVehicle
                            : () => handleOpenModal("edit", selectedRow)
                }
            />

            <ModalConfirm
                open={modalType === "delete"}
                type="danger"
                title={msg.deleteVehicle}
                confirmLoading={loadingDelete}
                onOk={handleDeleteVehicle}
                onCancel={handleCloseModal}
            >
                <p className="modal-confirm__description">
                    {msg.deleteVehicleDescription}
                </p>
                <p className="modal-confirm__description">
                    {commonMsg.deleteActionWarning}
                </p>
            </ModalConfirm>
        </RightBannerLayout>
    );
};

export default MasterDataVehicle;
