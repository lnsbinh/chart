import { Form, Button, Checkbox, Row, Col, Typography } from 'antd';
import { Link } from 'react-router';
import { useMessageProxy } from '@/hooks/useMessageProxy';
import { signInMessage } from '@/i18n/messages/auth/SignIn';
import TMALogo from '@/assets/images/tma-logo.png';
import Input from '@/components/common/Input/Input';
import './style.less';
import { ROUTE_PATHS } from '@/routers/paths';

const { Title, Text } = Typography;

const SignIn = () => {
  const msg = useMessageProxy<typeof signInMessage>('signInMessage');
  const [form] = Form.useForm();

  const handleSubmit = () => {};

  return (
    <div className='sign-in-container'>
      <div className='sign-in-logo'>
        <img
          src={TMALogo}
          alt='logo'
        />
      </div>

      <Title
        level={1}
        className='sign-in-title'>
        {msg.title}
      </Title>

      <Text className='sign-in-subtitle'>{msg.subtitle}</Text>

      <Form
        form={form}
        layout='vertical'
        onFinish={handleSubmit}
        className='sign-in-form'
        noValidate
        requiredMark={(label, { required }) => (
          <>
            {label}
            {required && <span className='required-mark'>*</span>}
          </>
        )}>
        <Form.Item
          label={msg.usernameLabel}
          name='username'
          required
          rules={[{ required: true, message: 'Please enter your username' }]}>
          <Input placeholder={msg.usernamePlaceholder} />
        </Form.Item>

        <Form.Item
          label={msg.passwordLabel}
          name='password'
          required
          rules={[
            { required: true, message: 'Please enter your password' },
            { min: 8, message: 'Password must be at least 8 characters' },
          ]}>
          <Input
            type='password'
            placeholder={msg.passwordPlaceholder}
            visibilityToggle={false}
          />
        </Form.Item>

        <Row
          justify='space-between'
          align='middle'
          className='sign-in-row'>
          <Col>
            <Form.Item
              name='rememberMe'
              valuePropName='checked'
              noStyle>
              <Checkbox>{msg.rememberMe}</Checkbox>
            </Form.Item>
          </Col>
          <Col>
            <Link
              className='forgot-password-link'
              to={ROUTE_PATHS.FORGOT_PASSWORD.path}>
              {msg.forgotPassword}
            </Link>
          </Col>
        </Row>

        <Form.Item>
          <Button
            type='primary'
            htmlType='submit'
            block
            className='sign-in-button'>
            {msg.signInButton}
          </Button>
        </Form.Item>
      </Form>

      <div className='sign-in-footer'>
        <Text>
          {msg.noAccount} <Link to='#'>{msg.createAccount}</Link>
        </Text>
      </div>
    </div>
  );
};

export default SignIn;
