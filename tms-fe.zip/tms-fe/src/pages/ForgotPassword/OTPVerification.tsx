import { useNavigate } from 'react-router';
import { Form, Button, Typography } from 'antd';
import { useMessageProxy } from '@/hooks/useMessageProxy';
import { forgotPasswordMessage } from '@/i18n/messages/auth/ForgotPassword';
import TMALogo from '@/assets/images/tma-logo.png';
import '../SignIn/style.less';
import './style.less';
import { ROUTE_PATHS } from '@/routers/paths';
import OTPInput from './components/OTPInput';

const { Title, Text } = Typography;

const ForgotPassword = () => {
  const msg = useMessageProxy<typeof forgotPasswordMessage>('forgotPasswordMessage');
  const [form] = Form.useForm();
  const navigate = useNavigate();

  const handleSubmit = () => {
    form.validateFields().then(() => {
      console.log('OTP: ', form.getFieldValue('otp'));
      navigate('../' + ROUTE_PATHS.FORGOT_PASSWORD_NEW.path, { replace: true });
    });
    form.resetFields();
  };

  return (
    <div className='sign-in-container'>
      <div className='sign-in-logo'>
        <img
          src={TMALogo}
          alt='logo'
        />
      </div>

      <Title
        level={1}
        className='sign-in-title'>
        {msg.otpTitle}
      </Title>

      <Text className='sign-in-subtitle'>{msg.otpDescription}</Text>

      <Form
        form={form}
        layout='vertical'
        onFinish={handleSubmit}
        className='sign-in-form'
        noValidate
        requiredMark={(label, { required }) => (
          <>
            {label}
            {required && <span className='required'>*</span>}
          </>
        )}>
        <Form.Item
          name='otp'
          required
          validateTrigger='onSubmit'
          className='otp-input-form-item'
          rules={[
            { required: true, message: msg.otpRequired },
            { len: 4, message: msg.otpLength },
          ]}>
          <OTPInput length={4} />
        </Form.Item>

        <Form.Item>
          <Button
            type='primary'
            htmlType='submit'
            block
            className='forgot-password-button'>
            {msg.verify}
          </Button>
        </Form.Item>
      </Form>

      <div className='sign-in-footer'>
        <Text>
          {msg.didNotReceiveCode}
          <Button
            type='link'
            className='resend-otp-button'
            onClick={() => console.log('Resend OTP')}
          >
            {msg.resend}
          </Button>
        </Text>
      </div>
    </div>
  );
};

export default ForgotPassword;