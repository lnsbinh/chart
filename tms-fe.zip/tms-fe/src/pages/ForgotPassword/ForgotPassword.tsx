import { Form, Button, Typography } from 'antd';
import { useMessageProxy } from '@/hooks/useMessageProxy';
import { forgotPasswordMessage } from '@/i18n/messages/auth/ForgotPassword';
import TMALogo from '@/assets/images/tma-logo.png';
import Input from '@/components/common/Input/Input';
import '../SignIn/style.less';
import './style.less';
import { ROUTE_PATHS } from '@/routers/paths';
import { useNavigate } from 'react-router';

const { Title, Text, Link } = Typography;

const ForgotPassword = () => {
  const msg = useMessageProxy<typeof forgotPasswordMessage>('forgotPasswordMessage');
  const [form] = Form.useForm();
  const navigate = useNavigate();

  const handleSubmit = () => {
    navigate(ROUTE_PATHS.FORGOT_PASSWORD_OTP.path);
  };

  return (
    <div className='sign-in-container'>
      <div className='sign-in-logo'>
        <img
          src={TMALogo}
          alt='logo'
        />
      </div>

      <Title
        level={1}
        className='sign-in-title'>
        {msg.title}
      </Title>

      <Text className='sign-in-subtitle'>{msg.description}</Text>

      <Form
        form={form}
        layout='vertical'
        onFinish={handleSubmit}
        className='sign-in-form'
        noValidate
        requiredMark={(label, { required }) => (
          <>
            {label}
            {required && <span className='required'>*</span>}
          </>
        )}>
        <Form.Item
          label={msg.emailLabel}
          name='email'
          required
          rules={[{ required: true, message: msg.emailRequired }, { type: 'email', message: msg.emailInvalid }]}>
          <Input placeholder={msg.emailPlaceholder} />
        </Form.Item>

        <Form.Item>
          <Button
            type='primary'
            htmlType='submit'
            block
            className='forgot-password-button'>
            {msg.sendCode}
          </Button>
        </Form.Item>
      </Form>

      <div className='sign-in-footer'>
        <Text>
          {msg.rememberPassword} <Link href={ROUTE_PATHS.SIGNIN.path}>{msg.backToLogin}</Link>
        </Text>
      </div>
    </div>
  );
};

export default ForgotPassword;