import { useNavigate } from 'react-router';
import { Form, Button, Typography } from 'antd';
import { useMessageProxy } from '@/hooks/useMessageProxy';
import { forgotPasswordMessage } from '@/i18n/messages/auth/ForgotPassword';
import TMALogo from '@/assets/images/tma-logo.png';
import Input from '@/components/common/Input/Input';
import '../SignIn/style.less';
import './style.less';
import { ROUTE_PATHS } from '@/routers/paths';

const { Title, Text } = Typography;

const CreateNewPassword = () => {
  const msg = useMessageProxy<typeof forgotPasswordMessage>('forgotPasswordMessage');
  const [form] = Form.useForm();
  const navigate = useNavigate();

  const handleSubmit = () => {
    form.validateFields().then(() => {
      console.log('New Password: ', form.getFieldValue('password'));
      navigate('../' + ROUTE_PATHS.FORGOT_PASSWORD_SUCCESS.path, { replace: true });
    });
  };

  return (
    <div className='sign-in-container'>
      <div className='sign-in-logo'>
        <img
          src={TMALogo}
          alt='logo'
        />
      </div>

      <Title
        level={1}
        className='sign-in-title'>
        {msg.resetTitle}
      </Title>

      <Text className='sign-in-subtitle'>{msg.resetDescription}</Text>

      <Form
        form={form}
        layout='vertical'
        onFinish={handleSubmit}
        className='sign-in-form'
        noValidate
        requiredMark={(label, { required }) => (
          <>
            {label}
            {required && <span className='required'>*</span>}
          </>
        )}>
        <Form.Item
          label={msg.newPasswordLabel}
          name='password'
          required
          rules={[
            { required: true, message: msg.newPasswordRequired },
            { min: 8, message: msg.newPasswordLength },
          ]}>
          <Input
            type='password'
            placeholder={msg.newPasswordPlaceholder}
            visibilityToggle={false}
          />
        </Form.Item>

        <Form.Item
          label={msg.confirmPasswordLabel}
          name='confirmPassword'
          required
          dependencies={['password']}
          rules={[
            { required: true, message: msg.confirmPasswordRequired },
            { min: 8, message: msg.newPasswordLength },
            {
              validator: (_, value) => {
                if (!value || form.getFieldValue('password') === value) {
                  return Promise.resolve();
                }
                return Promise.reject(new Error(msg.confirmPasswordMismatch));
              }
            }
          ]}>
          <Input
            type='password'
            placeholder={msg.confirmPasswordPlaceholder}
            visibilityToggle={false}
          />
        </Form.Item>

        <Form.Item>
          <Button
            type='primary'
            htmlType='submit'
            block
            className='forgot-password-button'>
            {msg.resetPassword}
          </Button>
        </Form.Item>
      </Form>

    </div>
  );
};

export default CreateNewPassword;