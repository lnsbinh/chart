import { useRef, useEffect } from 'react';
import './otp-input.less';

interface OTPInputProps {
  length?: number;
  value?: string;
  onChange?: (value: string) => void;
}

const OTPInput = ({ length = 6, value = '', onChange }: OTPInputProps) => {
  const inputsRef = useRef<(HTMLInputElement | null)[]>([]);

  // Auto focus first input
  useEffect(() => {
    inputsRef.current[0]?.focus();
  }, []);

  const handleChange = (index: number, val: string) => {
    if (!/^\d?$/.test(val)) return;

    const newValue = value.split('');
    newValue[index] = val;
    const otp = newValue.join('');
    onChange?.(otp);

    // Move to next input
    if (val && index < length - 1) {
      inputsRef.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace') {
      if (value[index]) {
        const newValue = value.split('');
        newValue[index] = '';
        onChange?.(newValue.join(''));
      } else if (index > 0) {
        inputsRef.current[index - 1]?.focus();
      }
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    const paste = e.clipboardData.getData('text').slice(0, length);
    if (!/^\d+$/.test(paste)) return;

    onChange?.(paste);
    inputsRef.current[paste.length - 1]?.focus();
  };

  const handleClick = () => {
    const firstEmptyIndex = value.length < length ? value.length : length - 1;
    inputsRef.current[firstEmptyIndex]?.focus();
  };

  return (
    <div className="otp-container" onPaste={handlePaste} onClick={handleClick}>
      {Array.from({ length }).map((_, index) => (
        <input
          key={index}
          ref={(el) => {
            inputsRef.current[index] = el;
          }}
          type="text"
          maxLength={1}
          placeholder=''
          className="otp-input"
          value={value[index] || ''}
          onChange={(e) => handleChange(index, e.target.value)}
          onKeyDown={(e) => handleKeyDown(index, e)}
        />
      ))}
    </div>
  );
};

export default OTPInput;