import { Typography } from 'antd';
import { useMessageProxy } from '@/hooks/useMessageProxy';
import { forgotPasswordMessage } from '@/i18n/messages/auth/ForgotPassword';
import TMALogo from '@/assets/images/tma-logo.png';
import '../SignIn/style.less';
import './style.less';
import { useNavigate } from 'react-router';
import { SuccessMarkIcon } from '@/assets';
import { useEffect } from 'react';
import { ROUTE_PATHS } from '@/routers/paths';

const { Title, Text } = Typography;

const PasswordChanged = () => {
    const msg = useMessageProxy<typeof forgotPasswordMessage>('forgotPasswordMessage');
    const navigate = useNavigate();
    useEffect(() => {
        const timer = setTimeout(() => {
            navigate(ROUTE_PATHS.SIGNIN.path, { replace: true });
        }, 5000);

        return () => clearTimeout(timer);
    }, [navigate]);

    return (
        <div className='sign-in-container'>
            <div className='sign-in-logo'>
                <img
                    src={TMALogo}
                    alt='logo'
                />
            </div>

            <Title
                level={1}
                className='sign-in-title'>
                {msg.passwordChangedTitle}
            </Title>

            <Text className='sign-in-subtitle'>{msg.passwordChangedDescription}</Text>

            <div className='success-mark-container'>
                <SuccessMarkIcon width={100} height={100} />
            </div>

            <div className='sign-in-footer'>
                <Text>
                    {msg.redirectToLogin}
                </Text>
            </div>
        </div>
    );
};

export default PasswordChanged;