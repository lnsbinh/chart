import { useNavigate } from 'react-router';
import { Button } from 'antd';

export default function NotFound() {
  const navigate = useNavigate();
  return (
    <div>
      <p>The page you're looking for doesn't exist.</p>
      <Button type="primary" onClick={() => navigate('/')}>Go Home</Button>
    </div>
  );
}
