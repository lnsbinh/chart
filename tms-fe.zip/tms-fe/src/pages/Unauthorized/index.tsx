import { useNavigate } from 'react-router';

export function Unauthorized() {
  const navigate = useNavigate();
  return (
    <div>
      <p>You don't have permission to view this page.</p>
      <button onClick={() => navigate(-1)}>Go Back</button>
    </div>
  );
}
