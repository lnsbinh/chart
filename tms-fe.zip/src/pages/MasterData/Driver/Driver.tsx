import { useState } from 'react';
import { Button, Space, Flex, Dropdown } from 'antd';
import type { TableColumnsType, TablePaginationConfig } from 'antd';
import { driverMessage } from '@/i18n/messages/masterData/Driver';
import { commonMessage } from '@/i18n/messages/common/common';
import { useMessageProxy } from '@/hooks/useMessageProxy';
import { useDebounce } from '@/hooks/useDebounce';
import RightBannerLayout from '@/components/common/RightPanelLayout/RightPanelLayout';
import ButtonTMS from '@/components/common/Button/ButtonTMS';
import TableTMS from '@/components/common/TableTMS/TableTMS';
import StatusTag from '@/components/common/StatusTag/StatusTag';
import InputTMS from '@/components/common/Input/Input';
import ModalConfirm from '@/components/common/Modal/ModalConfirm/ModalConfirm';
import { PlusIcon, SearchIcon, MoreIcon } from '@/assets';
import { GENERIC_STATUS, type GenericStatus, MODAL_TYPE, type ModalType } from '@/constants';
import { useGetDrivers } from '@/api/MasterData/Driver/Driver.api';
import DriverFormModal, { type IDriverForm } from './DriverFormModal/DriverFormModal';
import './Driver.less';

const icon = (Icon: React.FC<{ width: number; height: number }>) => (
  <Icon
    width={20}
    height={20}
  />
);

interface DriverRecord {
  id: string;
  driverId: string;
  fullName: string;
  contact: string;
  license: string;
  status: GenericStatus;
}

const DriverManagement = () => {
  const msg = useMessageProxy<typeof driverMessage>('driverMessage');
  const commonMsg = useMessageProxy<typeof commonMessage>('commonMessage');

  const [search, setSearch] = useState('');
  const debouncedSearch = useDebounce(search, 500);
  const [pagination, setPagination] = useState<TablePaginationConfig>({ current: 1, pageSize: 10 });
  const [selectedRow, setSelectedRow] = useState<string | null>(null);
  const [modalType, setModalType] = useState<ModalType | null>(null);

  const { data: driverData, isLoading } = useGetDrivers({
    organizationId: 'a14100e4-fd2b-4313-bb23-498feb4aa2ed',
    keyword: debouncedSearch,
    page: (pagination.current ?? 1) - 1,
    size: pagination.pageSize ?? 10,
  });

  const drivers = driverData?.content ?? [];
  const totalItems = driverData?.totalElements ?? 0;

  const resetPage = () => setPagination((prev) => ({ ...prev, current: 1 }));

  const handleOpenModal = (id: string, type: ModalType) => {
    setSelectedRow(id);
    setModalType(type);
  };

  const handleCancel = () => {
    setSelectedRow(null);
    setModalType(null);
  };

  const handleSubmit = (value: IDriverForm) => {
    console.log('🚀 ~ handleSubmit ~ value:', value);
    handleCancel();
  };

  const handleDelete = () => {};

  const handleSearch = (value: string) => {
    setSearch(value);
    resetPage();
  };

  const tableData = drivers.map((d) => ({
    id: d.id,
    driverId: d.driverCode ?? '',
    fullName: d.fullName ?? '',
    contact: d.phone ?? '',
    license: d.licenseNo ?? '',
    status: (d.employmentStatus?.toLowerCase() ?? GENERIC_STATUS.INACTIVE) as GenericStatus,
  }));

  const selectedDriver = tableData.find((d) => d.id === selectedRow);

  const isOpenFormModal =
    modalType === MODAL_TYPE.CREATE || modalType === MODAL_TYPE.EDIT || modalType === MODAL_TYPE.VIEW;
  const columns: TableColumnsType<DriverRecord> = [
    {
      title: msg.driverId,
      dataIndex: 'driverId',
      key: 'driverId',
      width: 180,
      sorter: true,
    },
    {
      title: msg.fullName,
      dataIndex: 'fullName',
      key: 'fullName',
      width: 200,
    },
    { title: msg.contact, dataIndex: 'contact', key: 'contact', width: 250 },
    { title: msg.licenseClass, dataIndex: 'license', key: 'license', width: 250 },
    { title: msg.driverGroup, dataIndex: 'driverGroup', key: 'driverGroup' },
    { title: msg.familiarRoutes, dataIndex: 'familiarRoutes', key: 'familiarRoutes' },
    {
      title: commonMsg.status,
      dataIndex: 'status',
      key: 'status',
      sorter: true,
      width: 150,
      render: (status) => <StatusTag status={status} />,
    },
    {
      title: commonMsg.action,
      key: 'action',
      width: 77,
      align: 'center',
      render: (_: unknown, record: DriverRecord) => (
        <Dropdown
          trigger={['click']}
          menu={{
            items: [
              {
                key: MODAL_TYPE.VIEW,
                label: commonMsg.viewDetails,
                onClick: () => handleOpenModal(record.id, MODAL_TYPE.VIEW),
              },
              {
                key: MODAL_TYPE.EDIT,
                label: commonMsg.edit,
                onClick: () => handleOpenModal(record.id, MODAL_TYPE.EDIT),
              },
              {
                key: MODAL_TYPE.DELETE,
                label: commonMsg.delete,
                onClick: () => handleOpenModal(record.id, MODAL_TYPE.DELETE),
              },
            ],
          }}>
          <Button
            type='text'
            size='small'
            icon={
              <MoreIcon
                width={20}
                height={20}
              />
            }
          />
        </Dropdown>
      ),
    },
  ];

  return (
    <RightBannerLayout
      title={msg.title}
      className='driver'>
      <Flex
        justify='space-between'
        align='center'
        style={{ marginBottom: 24 }}>
        <Space className='driver-filter'>
          <InputTMS
            value={search}
            prefix={icon(SearchIcon)}
            placeholder={msg.search}
            className='search'
            onChange={(e) => handleSearch(e.target.value)}
          />
        </Space>
        <ButtonTMS
          type='primary'
          onClick={() => handleOpenModal('', MODAL_TYPE.CREATE)}>
          {msg.addDriver}
          {icon(PlusIcon)}
        </ButtonTMS>
      </Flex>

      <TableTMS
        columns={columns}
        dataSource={tableData}
        loading={isLoading}
        pagination={{ ...pagination, total: totalItems }}
        rowKey={(record) => record.id}
        onPaginationChange={(page, pageSize) => setPagination({ current: page, pageSize })}
        pageSizeOptions={[10, 20, 50, 100]}
        className='driver-table'
        heightConfig={{ rowHeight: 69, visibleRows: 7 }}
      />

      <DriverFormModal
        key={selectedRow ?? MODAL_TYPE.CREATE}
        open={isOpenFormModal}
        initialValues={selectedDriver}
        type={modalType}
        onSubmit={handleSubmit}
        onCancel={handleCancel}
      />
      <ModalConfirm
        open={modalType === MODAL_TYPE.DELETE}
        type='danger'
        title={msg.deleteDriver}
        description={msg.deleteDriverDescription}
        onOk={handleDelete}
        onCancel={handleCancel}
      />
    </RightBannerLayout>
  );
};

export default DriverManagement;
