import { useQuery, useMutation, type UseQueryOptions } from '@tanstack/react-query';
import { request } from '@/api/request';
import { queryKeys } from '@/react-query/query-keys';
import { queryClient } from '@/react-query/query-client';
import { useApiError } from '@/hooks';

export interface Driver {
  id: string;
  organizationId: string;
  driverCode: string;
  driverType: string;
  status: string;
  fullName: string;
  phone: string;
  licenseNo: string;
  licenseExpiryDate: string;
  branchId: string;
  fleetTeamId: string | null;
  employmentStatus: string;
  employmentType: string;
  driverGroup: string;
  joinDate: Date;
  iIdentityDocumentNumber: string;
  createdAt: string;
  updatedAt: string;
}

export interface DriversResponse {
  content: Driver[];
  page: number;
  size: number;
  totalElements: number;
  totalPages: number;
  first: boolean;
  last: boolean;
  sort: string[];
}

export interface GetDriversParams {
  organizationId: string;
  keyword?: string;
  driverType?: string;
  branchId?: string;
  employmentStatus?: string;
  page?: number;
  size?: number;
  sort?: string;
}

const apiGetDrivers = (params: GetDriversParams) => {
  const {
    organizationId,
    keyword,
    driverType,
    branchId,
    employmentStatus,
    page = 0,
    size = 20,
    sort = 'fullName,ASC',
  } = params;

  const query = new URLSearchParams();
  query.set('organizationId', organizationId);
  query.set('page', String(page));
  query.set('size', String(size));
  query.set('sort', sort);
  if (keyword) query.set('keyword', keyword);
  if (driverType) query.set('driverType', driverType);
  if (branchId) query.set('branchId', branchId);
  if (employmentStatus) query.set('employmentStatus', employmentStatus);

  return request<DriversResponse>('get', `/master-data/drivers?${query.toString()}`);
};

const apiCreateDriver = (data: Partial<Driver>) => request<Driver>('post', '/drivers', data);

const apiUpdateDriver = (driverId: string, data: Partial<Driver>) =>
  request<Driver>('put', `/drivers/${driverId}`, data);

const apiDeleteDriver = (driverId: string) => request<Driver>('patch', `/drivers/${driverId}/delete`);

export const useGetDrivers = (
  params: GetDriversParams,
  options?: Omit<UseQueryOptions<DriversResponse>, 'queryKey' | 'queryFn'>,
) =>
  useQuery({
    queryKey: [queryKeys.drivers, params],
    queryFn: () => apiGetDrivers(params),
    ...options,
  });

export const useCreateDriver = () => {
  const { handleApiError } = useApiError();
  return useMutation({
    mutationFn: (data: Partial<Driver>) => apiCreateDriver(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [queryKeys.drivers] });
    },
    onError: handleApiError,
  });
};

export const useUpdateDriver = () => {
  const { handleApiError } = useApiError();
  return useMutation({
    mutationFn: ({ driverId, data }: { driverId: string; data: Partial<Driver> }) => apiUpdateDriver(driverId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [queryKeys.drivers] });
    },
    onError: handleApiError,
  });
};

export const useDeleteDriver = () => {
  const { handleApiError } = useApiError();
  return useMutation({
    mutationFn: ({ driverId }: { driverId: string }) => apiDeleteDriver(driverId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [queryKeys.drivers] });
    },
    onError: handleApiError,
  });
};
