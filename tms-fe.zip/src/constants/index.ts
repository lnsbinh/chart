export const ROLES = {
  ADMIN: 'ADMIN',
  SUPERVISOR: 'SUPERVISOR',
  DISPATCHER: 'DISPATCHER',
  OPS_STAFF: 'OPERATION_STAFF',
  FINANCE: 'FINANCE_OPS',
  DRIVER: 'DRIVER',
} as const;

export const USER_STATUS = {
  ACTIVE: 'ACTIVE',
  LOCKED: 'LOCKED',
} as const;

export type UserStatus = (typeof USER_STATUS)[keyof typeof USER_STATUS];

export const GENERIC_STATUS = {
  ACTIVE: 'active',
  INACTIVE: 'inactive',
} as const;

export type GenericStatus = (typeof GENERIC_STATUS)[keyof typeof GENERIC_STATUS];

export const MODAL_TYPE = {
  EDIT: 'edit',
  DELETE: 'delete',
  VIEW: 'view',
  CREATE: 'create',
};
export type ModalType = (typeof MODAL_TYPE)[keyof typeof MODAL_TYPE];
