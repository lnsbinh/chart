import { ROLES } from '@/constants';

export const getRoles = (msg: {
  admin: string;
  supervisor: string;
  dispatcher: string;
  opsStaff: string;
  finance: string;
  driver: string;
}) => [
  { label: msg.admin, value: ROLES.ADMIN },
  { label: msg.supervisor, value: ROLES.SUPERVISOR },
  { label: msg.dispatcher, value: ROLES.DISPATCHER },
  { label: msg.opsStaff, value: ROLES.OPS_STAFF },
  { label: msg.finance, value: ROLES.FINANCE },
  { label: msg.driver, value: ROLES.DRIVER },
];
