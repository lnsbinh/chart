export interface BaseResponse<T> {
  data: T;
  message: string;
  success: boolean;
}
export interface ServerError {
  message: string;
  code: number;
}
