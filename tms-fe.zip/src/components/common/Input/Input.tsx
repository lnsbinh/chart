/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useContext } from 'react';
import classNames from 'classnames';
import { DatePicker, Input, InputNumber } from 'antd';
import type { InputProps, InputNumberProps, DatePickerProps } from 'antd';
import type { TextAreaProps, PasswordProps } from 'antd/es/input';
import DisabledContext from 'antd/es/config-provider/DisabledContext';
import { CalendarIcon } from '@/assets';

import './style.less';

const { TextArea } = Input;

type InputType = 'text' | 'password' | 'number' | 'textarea' | 'date';

interface BaseProps {
  type?: InputType;
  className?: string;
  disableControlsWhenEmpty?: boolean;
  disabled?: boolean;
  readOnly?: boolean;
  placeholder?: string;
  addonAfter?: React.ReactNode;
}

type TextProps = BaseProps & InputProps & { type?: 'text' };
type PasswordInputProps = BaseProps & PasswordProps & { type: 'password' };
type NumberProps = BaseProps & InputNumberProps & { type: 'number' };
type TextAreaInputProps = BaseProps & TextAreaProps & { type: 'textarea' };
type DateProps = BaseProps & DatePickerProps & { type: 'date' };

type AppInputProps = TextProps | PasswordInputProps | NumberProps | TextAreaInputProps | DateProps;

const AppInput = React.forwardRef<any, AppInputProps>((props, ref) => {
  const {
    type = 'text',
    className,
    disableControlsWhenEmpty = true,
    placeholder,
    disabled,
    readOnly,
    addonAfter,
    style,
    value,
    ...rest
  } = props as any;

  const contextDisabled = useContext(DisabledContext);
  const isDisabled = disabled ?? contextDisabled;

  // Hide placeholder when disabled/readOnly
  const finalPlaceholder = isDisabled || readOnly ? undefined : placeholder;

  const baseClass = classNames('app-input', className);

  // Always show suffix if exists
  const showSuffix = !!addonAfter;

  // 🔐 Password
  if (type === 'password') {
    return (
      <Input.Password
        ref={ref}
        className={baseClass}
        placeholder={finalPlaceholder}
        disabled={isDisabled}
        {...(rest as PasswordProps)}
      />
    );
  }

  // 🔢 Number
  if (type === 'number') {
    const numberProps = rest as InputNumberProps;

    const hasValue = value !== undefined && value !== null && value !== '';

    const classes = classNames(baseClass, 'app-input-with-suffix', {
      'controls-disabled': disableControlsWhenEmpty && !hasValue,
    });

    return (
      <div className='app-input-wrapper'>
        <InputNumber
          ref={ref}
          className={classes}
          placeholder={finalPlaceholder}
          disabled={isDisabled}
          style={{
            width: '100%',
            paddingRight: showSuffix ? 40 : undefined,
            ...style,
          }}
          value={value}
          {...numberProps}
        />
        {showSuffix && (
          <span
            className={classNames('app-input-suffix', {
              'app-input-suffix--disabled': isDisabled,
            })}>
            {addonAfter}
          </span>
        )}
      </div>
    );
  }

  // 📝 TextArea
  if (type === 'textarea') {
    return (
      <TextArea
        ref={ref}
        className={baseClass}
        placeholder={finalPlaceholder}
        disabled={isDisabled}
        readOnly={readOnly}
        {...(rest as TextAreaProps)}
      />
    );
  }

  // 📅 DatePicker
  if (type === 'date') {
    return (
      <DatePicker
        ref={ref}
        format='DD/MM/YYYY'
        className={baseClass}
        style={{ width: '100%', ...style }}
        placeholder={finalPlaceholder}
        disabled={isDisabled}
        suffixIcon={<CalendarIcon />}
        {...(rest as DatePickerProps)}
      />
    );
  }

  // 🔤 Default Input
  return (
    <div className='app-input-wrapper'>
      <Input
        ref={ref}
        className={classNames(baseClass, 'app-input-with-suffix')}
        placeholder={finalPlaceholder}
        disabled={isDisabled}
        readOnly={readOnly}
        style={{
          paddingRight: showSuffix ? 40 : undefined,
          ...style,
        }}
        value={value}
        {...(rest as InputProps)}
      />
      {showSuffix && (
        <span
          className={classNames('app-input-suffix', {
            'app-input-suffix--disabled': isDisabled,
          })}>
          {addonAfter}
        </span>
      )}
    </div>
  );
});

AppInput.displayName = 'AppInput';

export default AppInput;
