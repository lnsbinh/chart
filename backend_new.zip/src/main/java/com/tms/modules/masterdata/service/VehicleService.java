package com.tms.modules.masterdata.service;

import com.tms.modules.masterdata.dto.PagedResponse;
import com.tms.shared.model.masterdata.VehicleEntity;
import com.tms.modules.masterdata.repository.VehicleRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class VehicleService {
    private final VehicleRepository repository;

    public VehicleService(VehicleRepository repository) { this.repository = repository; }

    public PagedResponse<VehicleEntity> search(UUID organizationId, String keyword, String vehicleType, UUID branchId, String operationalState, String statusCode, Pageable pageable) {
        Pageable safePageable = normalizePageable(pageable, Sort.by("plateNo").ascending());
        String keywordLike = normalizeLike(keyword);
        return PagedResponse.from(repository.search(organizationId, keywordLike, normalize(vehicleType), branchId, normalize(operationalState), normalize(statusCode), safePageable));
    }

    public VehicleEntity get(UUID organizationId, UUID id) {
        return repository.findByIdAndOrganizationId(id, organizationId).orElseThrow();
    }

    public VehicleEntity create(VehicleEntity entity) { return repository.save(entity); }

    public VehicleEntity update(UUID organizationId, UUID id, VehicleEntity request) {
        VehicleEntity entity = get(organizationId, id);
        entity.setVehicleCode(request.getVehicleCode());
        entity.setVehicleType(request.getVehicleType());
        entity.setPlateNo(request.getPlateNo());
        entity.setChassisNo(request.getChassisNo());
        entity.setEngineNo(request.getEngineNo());
        entity.setBranchId(request.getBranchId());
        entity.setFleetTeamId(request.getFleetTeamId());
        entity.setPayloadKg(request.getPayloadKg());
        entity.setVolumeM3(request.getVolumeM3());
        entity.setContainerCapability(request.getContainerCapability());
        entity.setStatusCode(request.getStatusCode());
        entity.setOperationalState(request.getOperationalState());
        return repository.save(entity);
    }

    public VehicleEntity deactivate(UUID organizationId, UUID id) {
        VehicleEntity entity = get(organizationId, id);
        entity.setStatusCode("INACTIVE");
        return repository.save(entity);
    }

    private Pageable normalizePageable(Pageable pageable, Sort defaultSort) {
        if (pageable == null) {
            return PageRequest.of(0, 20, defaultSort);
        }
        Sort sort = pageable.getSort().isSorted() ? pageable.getSort() : defaultSort;
        return PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), sort);
    }

    private String normalize(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    private String normalizeLike(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        return "%" + value.trim().toLowerCase() + "%";
    }
}
