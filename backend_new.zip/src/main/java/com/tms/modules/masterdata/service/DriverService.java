package com.tms.modules.masterdata.service;

import com.tms.modules.masterdata.dto.PagedResponse;
import com.tms.shared.model.masterdata.DriverEntity;
import com.tms.modules.masterdata.repository.DriverRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class DriverService {
    private final DriverRepository repository;

    public DriverService(DriverRepository repository) { this.repository = repository; }

    public PagedResponse<DriverEntity> search(UUID organizationId, String keyword, String driverType, UUID branchId, String employmentStatus, Pageable pageable) {
        Pageable safePageable = normalizePageable(pageable, Sort.by("fullName").ascending());
        String keywordLike = normalizeLike(keyword);
        return PagedResponse.from(repository.search(organizationId, keywordLike, normalize(driverType), branchId, normalize(employmentStatus), safePageable));
    }

    public DriverEntity get(UUID organizationId, UUID id) {
        return repository.findByIdAndOrganizationId(id, organizationId).orElseThrow();
    }

    public DriverEntity create(DriverEntity entity) { return repository.save(entity); }

    public DriverEntity update(UUID organizationId, UUID id, DriverEntity request) {
        DriverEntity entity = get(organizationId, id);
        entity.setDriverCode(request.getDriverCode());
        entity.setDriverType(request.getDriverType());
        entity.setFullName(request.getFullName());
        entity.setPhone(request.getPhone());
        entity.setLicenseNo(request.getLicenseNo());
        entity.setLicenseExpiryDate(request.getLicenseExpiryDate());
        entity.setBranchId(request.getBranchId());
        entity.setFleetTeamId(request.getFleetTeamId());
        entity.setEmploymentStatus(request.getEmploymentStatus());
        return repository.save(entity);
    }

    public DriverEntity deactivate(UUID organizationId, UUID id) {
        DriverEntity entity = get(organizationId, id);
        entity.setEmploymentStatus("INACTIVE");
        return repository.save(entity);
    }

    private Pageable normalizePageable(Pageable pageable, Sort defaultSort) {
        if (pageable == null) {
            return PageRequest.of(0, 20, defaultSort);
        }
        Sort sort = pageable.getSort().isSorted() ? pageable.getSort() : defaultSort;
        return PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), sort);
    }

    private String normalize(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    private String normalizeLike(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        return "%" + value.trim().toLowerCase() + "%";
    }
}
