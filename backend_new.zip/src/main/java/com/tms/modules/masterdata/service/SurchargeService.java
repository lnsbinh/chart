package com.tms.modules.masterdata.service;

import com.tms.shared.model.masterdata.SurchargeEntity;
import com.tms.modules.masterdata.repository.SurchargeRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class SurchargeService {
    private final SurchargeRepository repository;

    public SurchargeService(SurchargeRepository repository) { this.repository = repository; }

    public List<SurchargeEntity> list(UUID organizationId, String statusCode) {
        if (statusCode != null && !statusCode.isBlank()) {
            return repository.findByOrganizationIdAndStatusCodeOrderBySurchargeCode(organizationId, statusCode);
        }
        return repository.findByOrganizationIdOrderBySurchargeCode(organizationId);
    }

    public SurchargeEntity get(UUID organizationId, UUID id) {
        return repository.findByIdAndOrganizationId(id, organizationId).orElseThrow();
    }

    public SurchargeEntity create(SurchargeEntity entity) { return repository.save(entity); }

    public SurchargeEntity update(UUID organizationId, UUID id, SurchargeEntity request) {
        SurchargeEntity entity = get(organizationId, id);
        entity.setSurchargeCode(request.getSurchargeCode());
        entity.setSurchargeName(request.getSurchargeName());
        entity.setChargeMethod(request.getChargeMethod());
        entity.setDefaultAmount(request.getDefaultAmount());
        entity.setCurrencyCode(request.getCurrencyCode());
        entity.setStatusCode(request.getStatusCode());
        return repository.save(entity);
    }

    public SurchargeEntity deactivate(UUID organizationId, UUID id) {
        SurchargeEntity entity = get(organizationId, id);
        entity.setStatusCode("INACTIVE");
        return repository.save(entity);
    }
}
