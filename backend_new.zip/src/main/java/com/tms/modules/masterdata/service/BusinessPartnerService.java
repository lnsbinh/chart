package com.tms.modules.masterdata.service;

import com.tms.modules.masterdata.dto.PagedResponse;
import com.tms.shared.model.masterdata.BusinessPartnerEntity;
import com.tms.modules.masterdata.repository.BusinessPartnerRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class BusinessPartnerService {
    private final BusinessPartnerRepository repository;

    public BusinessPartnerService(BusinessPartnerRepository repository) {
        this.repository = repository;
    }

    public PagedResponse<BusinessPartnerEntity> search(UUID organizationId, String keyword, String partnerType, String statusCode, Pageable pageable) {
        Pageable safePageable = normalizePageable(pageable, Sort.by("partnerCode").ascending());
        String keywordLike = normalizeLike(keyword);
        return PagedResponse.from(repository.search(organizationId, keywordLike, normalize(partnerType), normalize(statusCode), safePageable));
    }

    public BusinessPartnerEntity get(UUID organizationId, UUID id) {
        return repository.findByIdAndOrganizationId(id, organizationId).orElseThrow();
    }

    public BusinessPartnerEntity create(BusinessPartnerEntity entity) {
        return repository.save(entity);
    }

    public BusinessPartnerEntity update(UUID organizationId, UUID id, BusinessPartnerEntity request) {
        BusinessPartnerEntity entity = get(organizationId, id);
        entity.setPartnerType(request.getPartnerType());
        entity.setPartnerCode(request.getPartnerCode());
        entity.setPartnerName(request.getPartnerName());
        entity.setTaxCode(request.getTaxCode());
        entity.setPhone(request.getPhone());
        entity.setEmail(request.getEmail());
        entity.setAddress(request.getAddress());
        entity.setPaymentTermDays(request.getPaymentTermDays());
        entity.setCreditLimitAmount(request.getCreditLimitAmount());
        entity.setStatusCode(request.getStatusCode());
        return repository.save(entity);
    }

    public BusinessPartnerEntity deactivate(UUID organizationId, UUID id) {
        BusinessPartnerEntity entity = get(organizationId, id);
        entity.setStatusCode("INACTIVE");
        return repository.save(entity);
    }

    private Pageable normalizePageable(Pageable pageable, Sort defaultSort) {
        if (pageable == null) {
            return PageRequest.of(0, 20, defaultSort);
        }
        Sort sort = pageable.getSort().isSorted() ? pageable.getSort() : defaultSort;
        return PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), sort);
    }

    private String normalize(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    private String normalizeLike(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        return "%" + value.trim().toLowerCase() + "%";
    }
}
