package com.tms.modules.masterdata.controller;

import com.tms.shared.model.masterdata.BusinessPartnerContactEntity;
import com.tms.modules.masterdata.service.BusinessPartnerContactService;
import com.tms.security.annotation.RequireAnyPermission;
import com.tms.security.annotation.RequireAnyRole;
import com.tms.modules.iam.constants.RoleCodes;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/master-data/business-partner-contacts")
@RequireAnyRole({
        RoleCodes.SUPER_ADMIN,
        RoleCodes.ORG_ADMIN,
        RoleCodes.SUPERVISOR,
        RoleCodes.DISPATCHER,
        RoleCodes.OPERATION_STAFF,
        RoleCodes.FINANCE_OPS
})
@RequireAnyPermission({
        "customer.read", "customer.all",
        "outsourced_carrier.read", "outsourced_carrier.all"
})
@Tag(name = "Master Data - Business Partner Contacts")
public class BusinessPartnerContactsController {
    private final BusinessPartnerContactService service;

    public BusinessPartnerContactsController(BusinessPartnerContactService service) { this.service = service; }

    @GetMapping
    @Operation(summary = "List contacts by business partner")
    public List<BusinessPartnerContactEntity> list(
            @Parameter(description = "Business partner ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000011"))
            @RequestParam UUID businessPartnerId) { return service.listByPartner(businessPartnerId); }

    @PostMapping
    @RequireAnyRole({RoleCodes.SUPER_ADMIN, RoleCodes.ORG_ADMIN, RoleCodes.OPERATION_STAFF})
    @RequireAnyPermission({
            "customer.update", "customer.all",
            "outsourced_carrier.update", "outsourced_carrier.all"
    })
    @Operation(summary = "Create contact")
    public BusinessPartnerContactEntity create(@RequestBody BusinessPartnerContactEntity request) { return service.create(request); }

    @DeleteMapping("/{id}")
    @RequireAnyRole({RoleCodes.SUPER_ADMIN, RoleCodes.ORG_ADMIN, RoleCodes.OPERATION_STAFF})
    @RequireAnyPermission({
            "customer.delete", "customer.all",
            "outsourced_carrier.delete", "outsourced_carrier.all"
    })
    @Operation(summary = "Delete contact")
    public void delete(
            @Parameter(description = "Contact ID", schema = @Schema(example = "00000000-0000-0000-0000-000000000013"))
            @PathVariable UUID id) { service.delete(id); }
}
