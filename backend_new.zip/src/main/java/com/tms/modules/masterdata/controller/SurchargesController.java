package com.tms.modules.masterdata.controller;

import com.tms.shared.model.masterdata.SurchargeEntity;
import com.tms.modules.masterdata.service.SurchargeService;
import com.tms.security.annotation.RequireAnyPermission;
import com.tms.security.annotation.RequireAnyRole;
import com.tms.modules.iam.constants.RoleCodes;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/master-data/surcharges")
@RequireAnyRole({
        RoleCodes.SUPER_ADMIN,
        RoleCodes.ORG_ADMIN,
        RoleCodes.SUPERVISOR,
        RoleCodes.DISPATCHER,
        RoleCodes.OPERATION_STAFF,
        RoleCodes.FINANCE_OPS
})
@RequireAnyPermission({"surcharge.read", "surcharge.all"})
@Tag(name = "Master Data - Surcharges")
public class SurchargesController {
    private final SurchargeService service;

    public SurchargesController(SurchargeService service) { this.service = service; }

    @GetMapping
    @Operation(summary = "List surcharges")
    public List<SurchargeEntity> list(
            @Parameter(description = "Organization ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000001"))
            @RequestParam UUID organizationId,
            @Parameter(description = "Surcharge status", schema = @Schema(defaultValue = "ACTIVE"))
            @RequestParam(required = false) String statusCode) { return service.list(organizationId, statusCode); }

    @GetMapping("/{id}")
    @Operation(summary = "Get surcharge by ID")
    public SurchargeEntity get(
            @Parameter(description = "Organization ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000001"))
            @RequestParam UUID organizationId,
            @Parameter(description = "Surcharge ID", schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id) { return service.get(organizationId, id); }

    @PostMapping
    @RequireAnyRole({RoleCodes.SUPER_ADMIN, RoleCodes.ORG_ADMIN, RoleCodes.OPERATION_STAFF})
    @RequireAnyPermission({"surcharge.update", "surcharge.all"})
    @Operation(summary = "Create surcharge")
    public SurchargeEntity create(@RequestBody SurchargeEntity request) { return service.create(request); }

    @PutMapping("/{id}")
    @RequireAnyRole({RoleCodes.SUPER_ADMIN, RoleCodes.ORG_ADMIN, RoleCodes.OPERATION_STAFF})
    @RequireAnyPermission({"surcharge.update", "surcharge.all"})
    @Operation(summary = "Update surcharge")
    public SurchargeEntity update(
            @Parameter(description = "Organization ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000001"))
            @RequestParam UUID organizationId,
            @Parameter(description = "Surcharge ID", schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id,
            @RequestBody SurchargeEntity request) { return service.update(organizationId, id, request); }

    @PatchMapping("/{id}/deactivate")
    @RequireAnyRole({RoleCodes.SUPER_ADMIN, RoleCodes.ORG_ADMIN, RoleCodes.OPERATION_STAFF})
    @RequireAnyPermission({"surcharge.delete", "surcharge.all"})
    @Operation(summary = "Deactivate surcharge")
    public SurchargeEntity deactivate(
            @Parameter(description = "Organization ID", schema = @Schema(defaultValue = "00000000-0000-0000-0000-000000000001"))
            @RequestParam UUID organizationId,
            @Parameter(description = "Surcharge ID", schema = @Schema(example = "00000000-0000-0000-0000-000000000010"))
            @PathVariable UUID id) { return service.deactivate(organizationId, id); }
}
