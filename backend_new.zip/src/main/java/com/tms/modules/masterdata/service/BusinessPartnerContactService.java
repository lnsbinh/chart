package com.tms.modules.masterdata.service;

import com.tms.shared.model.masterdata.BusinessPartnerContactEntity;
import com.tms.modules.masterdata.repository.BusinessPartnerContactRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class BusinessPartnerContactService {
    private final BusinessPartnerContactRepository repository;

    public BusinessPartnerContactService(BusinessPartnerContactRepository repository) {
        this.repository = repository;
    }

    public List<BusinessPartnerContactEntity> listByPartner(UUID businessPartnerId) {
        return repository.findByBusinessPartnerIdOrderByFullName(businessPartnerId);
    }

    public BusinessPartnerContactEntity create(BusinessPartnerContactEntity entity) {
        return repository.save(entity);
    }

    public void delete(UUID id) {
        repository.deleteById(id);
    }
}
