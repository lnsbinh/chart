package com.tms.modules.masterdata.repository;

import com.tms.shared.model.masterdata.BusinessPartnerEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;
import java.util.UUID;

public interface BusinessPartnerRepository extends JpaRepository<BusinessPartnerEntity, UUID> {
    @Query("""
        select bp
        from BusinessPartnerEntity bp
        where bp.organizationId = :organizationId
        and (
            :keywordLike is null
            or lower(coalesce(bp.partnerCode, '')) like :keywordLike
            or lower(coalesce(bp.partnerName, '')) like :keywordLike
            or lower(coalesce(bp.phone, '')) like :keywordLike
            or lower(coalesce(bp.email, '')) like :keywordLike
          )
        and (:partnerType is null or bp.partnerType = :partnerType)
        and (:statusCode is null or bp.statusCode = :statusCode)
    """)
    Page<BusinessPartnerEntity> search(
            @Param("organizationId") UUID organizationId,
            @Param("keywordLike") String keywordLike,
            @Param("partnerType") String partnerType,
            @Param("statusCode") String statusCode,
            Pageable pageable
    );

    Optional<BusinessPartnerEntity> findByIdAndOrganizationId(UUID id, UUID organizationId);
}
