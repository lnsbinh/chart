package com.tms.modules.iam.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EffectivePermissionGrant implements Serializable {
    private String permissionCode;
    private String scopeType;
    private UUID organizationId;
    private UUID branchId;
}
