package com.tms.modules.iam.service.rbac;

import com.tms.shared.model.iam.SensitiveActionPolicyEntity;
import com.tms.modules.iam.repository.SensitiveActionPolicyRepository;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class SensitiveActionPolicyService {
    private final SensitiveActionPolicyRepository repository;

    public SensitiveActionPolicyService(SensitiveActionPolicyRepository repository) {
        this.repository = repository;
    }

    public Map<String, Object> getPolicy(String actionCode) {
        List<SensitiveActionPolicyEntity> rows = repository.findByActionCodeAndStatusOrderByParamKeyAsc(actionCode, "ACTIVE");
        Map<String, Object> out = new LinkedHashMap<>();
        for (SensitiveActionPolicyEntity row : rows) {
            out.put(row.getParamKey(), parse(row.getParamType(), row.getParamValue()));
        }
        return out;
    }

    private Object parse(String type, String value) {
        return switch (type) {
            case "BOOLEAN" -> Boolean.parseBoolean(value);
            case "INTEGER" -> Integer.parseInt(value);
            default -> value;
        };
    }
}
