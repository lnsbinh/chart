package com.tms.modules.iam.service.rbac;

import com.tms.shared.model.iam.PermissionEntity;
import com.tms.modules.iam.repository.PermissionRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class PermissionService {
    private final PermissionRepository permissionRepository;

    public PermissionService(PermissionRepository permissionRepository) {
        this.permissionRepository = permissionRepository;
    }

    public List<PermissionEntity> getAllPermissions() { return permissionRepository.findAll(); }
    public PermissionEntity addPermission(PermissionEntity permission) { return permissionRepository.save(permission); }
    public void deletePermission(UUID id) { permissionRepository.deleteById(id); }
}
