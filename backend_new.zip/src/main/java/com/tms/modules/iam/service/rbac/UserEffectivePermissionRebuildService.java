package com.tms.modules.iam.service.rbac;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Service
public class UserEffectivePermissionRebuildService {

    private final JdbcTemplate jdbcTemplate;

    public UserEffectivePermissionRebuildService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Transactional
    public void rebuildForUser(UUID userId) {
        jdbcTemplate.update("delete from iam.user_effective_permissions where user_id = ?", userId);

        jdbcTemplate.update("""
                with recursive resolved_roles as (
                    select
                        ura.user_id,
                        ura.role_id,
                        ura.scope_type,
                        ura.organization_id,
                        ura.branch_id
                    from iam.user_role_assignments ura
                    where ura.status = 'ACTIVE'
                      and (ura.valid_from is null or ura.valid_from <= current_timestamp)
                      and (ura.valid_to is null or ura.valid_to >= current_timestamp)
                      and ura.user_id = ?

                    union

                    select
                        rr.user_id,
                        rh.child_role_id as role_id,
                        rr.scope_type,
                        rr.organization_id,
                        rr.branch_id
                    from resolved_roles rr
                    join iam.role_hierarchy rh on rh.parent_role_id = rr.role_id
                ),
                effective_role_permissions as (
                    select distinct
                        rr.user_id,
                        rp.permission_id,
                        rr.scope_type,
                        rr.organization_id,
                        rr.branch_id
                    from resolved_roles rr
                    join iam.role_permissions rp on rp.role_id = rr.role_id
                )
                insert into iam.user_effective_permissions (
                    user_id,
                    permission_id,
                    scope_type,
                    organization_id,
                    branch_id
                )
                select
                    erp.user_id,
                    erp.permission_id,
                    erp.scope_type,
                    erp.organization_id,
                    erp.branch_id
                from effective_role_permissions erp
                on conflict do nothing
                """, userId);
    }
}
