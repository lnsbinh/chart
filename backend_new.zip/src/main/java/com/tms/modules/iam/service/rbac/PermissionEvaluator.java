package com.tms.modules.iam.service.rbac;

import com.tms.modules.iam.dto.AppSecurityContext;
import com.tms.modules.iam.dto.EffectivePermissionGrant;
import com.tms.modules.iam.dto.RequestScopeContext;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

@Service
public class PermissionEvaluator {

    private final RequestScopeContextResolver requestScopeContextResolver;

    public PermissionEvaluator(RequestScopeContextResolver requestScopeContextResolver) {
        this.requestScopeContextResolver = requestScopeContextResolver;
    }

    public boolean evaluateAny(String[] permissions, AppSecurityContext context) {
        return evaluateAny(Arrays.asList(permissions), context);
    }

    public boolean evaluateAny(List<String> permissions, AppSecurityContext context) {
        if (context == null || permissions == null || permissions.isEmpty()) {
            return false;
        }
        RequestScopeContext requestScope = requestScopeContextResolver.resolveCurrent();
        for (String permission : permissions) {
            if (hasPermissionForScope(permission, requestScope, context)) {
                return true;
            }
        }
        return false;
    }

    private boolean hasPermissionForScope(String permission, RequestScopeContext requestScope, AppSecurityContext context) {
        if (context.getEffectivePermissionGrants() == null || context.getEffectivePermissionGrants().isEmpty()) {
            return false;
        }
        for (EffectivePermissionGrant grant : context.getEffectivePermissionGrants()) {
            if (!permission.equals(grant.getPermissionCode())) {
                continue;
            }
            if (scopeMatches(grant, requestScope)) {
                return true;
            }
        }
        return false;
    }

    private boolean scopeMatches(EffectivePermissionGrant grant, RequestScopeContext requestScope) {
        if ("GLOBAL".equalsIgnoreCase(grant.getScopeType())) {
            return true;
        }
        UUID requestOrganizationId = requestScope.getOrganizationId();
        UUID requestBranchId = requestScope.getBranchId();

        if ("ORGANIZATION".equalsIgnoreCase(grant.getScopeType())) {
            return requestOrganizationId == null || requestOrganizationId.equals(grant.getOrganizationId());
        }
        if ("BRANCH".equalsIgnoreCase(grant.getScopeType())) {
            boolean orgMatches = requestOrganizationId == null || requestOrganizationId.equals(grant.getOrganizationId());
            boolean branchMatches = requestBranchId == null || requestBranchId.equals(grant.getBranchId());
            return orgMatches && branchMatches;
        }
        return false;
    }
}
