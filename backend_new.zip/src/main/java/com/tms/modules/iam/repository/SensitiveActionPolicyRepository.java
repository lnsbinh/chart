package com.tms.modules.iam.repository;

import com.tms.shared.model.iam.SensitiveActionPolicyEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface SensitiveActionPolicyRepository extends JpaRepository<SensitiveActionPolicyEntity, UUID> {
    List<SensitiveActionPolicyEntity> findByActionCodeAndStatusOrderByParamKeyAsc(String actionCode, String status);
}
