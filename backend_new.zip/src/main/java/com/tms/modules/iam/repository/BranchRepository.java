package com.tms.modules.iam.repository;

import com.tms.shared.model.iam.BranchEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface BranchRepository extends JpaRepository<BranchEntity, UUID> {
    Optional<BranchEntity> findByIdAndOrganizationId(UUID id, UUID organizationId);

    List<BranchEntity> findByIdIn(List<UUID> ids);
}
