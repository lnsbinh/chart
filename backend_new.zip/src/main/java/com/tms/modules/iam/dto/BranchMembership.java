package com.tms.modules.iam.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BranchMembership implements Serializable {
    private UUID organizationId;
    private UUID branchId;
    private String branchCode;
    private String branchName;
    private boolean primary;
}
