package com.tms.modules.iam.repository;

import com.tms.shared.model.iam.PermissionEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;

public interface PermissionRepository extends JpaRepository<PermissionEntity, UUID> {

    @Query(value = """
            with recursive role_tree as (
                select r.id
                from iam.roles r
                where r.id = cast(:assignedRoleId as uuid)

                union

                select rh.child_role_id
                from iam.role_hierarchy rh
                join role_tree rt on rt.id = rh.parent_role_id
            )
            select distinct p.*
            from role_tree rt
            join iam.role_permissions rp on rp.role_id = rt.id
            join iam.permissions p on p.id = rp.permission_id
            where p.status = 'ACTIVE'
            order by p.module_code, p.resource_code, p.action_code, p.code
            """, nativeQuery = true)
    List<PermissionEntity> findActiveEffectiveByAssignedRoleId(@Param("assignedRoleId") UUID assignedRoleId);

    @Query(value = """
            select
                p.id,
                p.code,
                p.name,
                p.display_name_vi,
                p.display_name_en,
                p.description_vi,
                p.description_en,
                p.module_code,
                p.resource_code,
                p.action_code,
                p.assignment_scope_hint,
                p.is_sensitive,
                p.status,
                p.created_at,
                p.updated_at
            from iam.permissions p
            where p.status = 'ACTIVE'
            order by p.module_code, p.resource_code, p.action_code, p.code
            """, nativeQuery = true)
    List<PermissionEntity> findActiveCatalog();
}
