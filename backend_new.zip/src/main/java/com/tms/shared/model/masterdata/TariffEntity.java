package com.tms.shared.model.masterdata;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

import java.time.OffsetDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "tariffs", schema = "master_data")
public class TariffEntity {
    @Id
    @UuidGenerator
    private UUID id;
    @Column(name = "organization_id", nullable = false)
    @Schema(example = "00000000-0000-0000-0000-000000000001")
    private UUID organizationId;

    @Column(name = "customer_id")
    @Schema(example = "00000000-0000-0000-0000-000000000011")
    private UUID customerId;

    @Column(name = "route_id")
    @Schema(example = "00000000-0000-0000-0000-000000000012")
    private UUID routeId;

    @Column(name = "vehicle_type")
    @Schema(example = "TRACTOR")
    private String vehicleType;

    @Column(name = "container_type")
    @Schema(example = "20DC")
    private String containerType;

    @Column(name = "currency_code", nullable = false)
    @Schema(example = "VND", defaultValue = "VND")
    private String currencyCode = "VND";

    @Column(name = "base_price", nullable = false, precision = 18, scale = 2)
    @Schema(example = "5000000")
    private java.math.BigDecimal basePrice;

    @Column(name = "effective_from", nullable = false)
    @Schema(type = "string", format = "date", example = "2026-04-01")
    private java.time.LocalDate effectiveFrom;

    @Column(name = "effective_to")
    @Schema(type = "string", format = "date", example = "2026-12-31")
    private java.time.LocalDate effectiveTo;

    @Column(name = "status_code", nullable = false)
    @Schema(example = "ACTIVE", defaultValue = "ACTIVE")
    private String statusCode = "ACTIVE";

    @Column(name = "created_at", nullable = false)
    private OffsetDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private OffsetDateTime updatedAt;

    @PrePersist
    void onCreate() {
        OffsetDateTime now = OffsetDateTime.now();
        if (currencyCode == null) currencyCode = "VND";
        if (statusCode == null) statusCode = "ACTIVE";
        createdAt = now;
        updatedAt = now;
    }

    @PreUpdate
    void onUpdate() {
        updatedAt = OffsetDateTime.now();
    }
}