package com.tms.shared.model.masterdata;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

import java.time.OffsetDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "business_partner_contacts", schema = "master_data")
public class BusinessPartnerContactEntity {
    @Id
    @UuidGenerator
    private UUID id;
    @Column(name = "business_partner_id", nullable = false)
    @Schema(example = "00000000-0000-0000-0000-000000000011")
    private UUID businessPartnerId;

    @Column(name = "full_name", nullable = false)
    @Schema(example = "Tran Thi B")
    private String fullName;

    @Column(name = "phone")
    private String phone;

    @Column(name = "email")
    private String email;

    @Column(name = "job_title")
    private String jobTitle;

    @Column(name = "is_default", nullable = false)
    @Schema(example = "true", defaultValue = "false")
    private boolean isDefault;

    @Column(name = "created_at", nullable = false)
    private OffsetDateTime createdAt;

    @PrePersist
    void onCreate() {
        OffsetDateTime now = OffsetDateTime.now();
        createdAt = now;
    }

    @PreUpdate
    void onUpdate() {
        // no-op
    }
}