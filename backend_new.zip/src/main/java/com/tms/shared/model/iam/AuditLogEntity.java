package com.tms.shared.model.iam;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.OffsetDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "audit_logs", schema = "iam")
public class AuditLogEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "event_code", nullable = false)
    private String eventCode;
    @Column(nullable = false)
    private String category;
    @Column(name = "subject_type")
    private String subjectType;
    @Column(name = "subject_id")
    private String subjectId;
    private String username;
    @Column(name = "client_id")
    private String clientId;
    @Column(name = "organization_id")
    private UUID organizationId;
    @Column(name = "branch_id")
    private UUID branchId;
    @Column(name = "target_type")
    private String targetType;
    @Column(name = "target_id")
    private String targetId;
    @Column(name = "action_code")
    private String actionCode;
    @Column(nullable = false)
    private String result;
    private String reason;
    @Column(name = "trace_id")
    private String traceId;
    @Column(name = "ip_address")
    private String ipAddress;
    @Column(name = "user_agent")
    private String userAgent;
    @Column(name = "metadata_json", nullable = false, columnDefinition = "jsonb")
    private String metadataJson = "{}";
    @Column(name = "occurred_at", nullable = false)
    private OffsetDateTime occurredAt;

    @PrePersist void onCreate() { if (occurredAt == null) occurredAt = OffsetDateTime.now(); }
}
