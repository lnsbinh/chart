package com.tms.shared.model.masterdata;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

import java.time.OffsetDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "surcharges", schema = "master_data")
public class SurchargeEntity {
    @Id
    @UuidGenerator
    private UUID id;
    @Column(name = "organization_id", nullable = false)
    @Schema(example = "00000000-0000-0000-0000-000000000001")
    private UUID organizationId;

    @Column(name = "surcharge_code", nullable = false)
    @Schema(example = "SUR001")
    private String surchargeCode;

    @Column(name = "surcharge_name", nullable = false)
    @Schema(example = "Waiting Fee")
    private String surchargeName;

    @Column(name = "charge_method", nullable = false)
    @Schema(example = "FIXED")
    private String chargeMethod;

    @Column(name = "default_amount", precision = 18, scale = 2)
    private java.math.BigDecimal defaultAmount;

    @Column(name = "currency_code", nullable = false)
    @Schema(example = "VND", defaultValue = "VND")
    private String currencyCode = "VND";

    @Column(name = "status_code", nullable = false)
    @Schema(example = "ACTIVE", defaultValue = "ACTIVE")
    private String statusCode = "ACTIVE";

    @Column(name = "created_at", nullable = false)
    private OffsetDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private OffsetDateTime updatedAt;

    @PrePersist
    void onCreate() {
        OffsetDateTime now = OffsetDateTime.now();
        if (currencyCode == null) currencyCode = "VND";
        if (statusCode == null) statusCode = "ACTIVE";
        createdAt = now;
        updatedAt = now;
    }

    @PreUpdate
    void onUpdate() {
        updatedAt = OffsetDateTime.now();
    }
}