-- Đổi tên cột external_subject thành keycloak_user_id
ALTER TABLE iam.users
    RENAME COLUMN external_subject TO keycloak_user_name;

-- Đổi tên cột home_organization_id thành organization_id
ALTER TABLE iam.users
    RENAME COLUMN home_organization_id TO organization_id;

ALTER TABLE iam.users
    ADD COLUMN keycloak_user_id UUID;

ALTER TABLE iam.users
    ADD COLUMN user_code varchar(30) unique;

ALTER TABLE iam.users
    ADD COLUMN password_hash TEXT;

-- Thêm cột first_name
ALTER TABLE iam.users
    ADD COLUMN first_name TEXT;

-- Thêm cột last_name
ALTER TABLE iam.users
    ADD COLUMN last_name TEXT;

-- Thêm cột phone
ALTER TABLE iam.users
    ADD COLUMN phone VARCHAR(20);

-- Thêm cột avatar_url
ALTER TABLE iam.users
    ADD COLUMN avatar_url TEXT;

-- Thêm cột default_branch_id
ALTER TABLE iam.users
    ADD COLUMN default_branch_id UUID;

-- Thêm cột is_deleted (có thể là boolean)
ALTER TABLE iam.users
    ADD COLUMN is_deleted BOOLEAN DEFAULT FALSE;


ALTER TABLE iam.branches
    ADD COLUMN address text;